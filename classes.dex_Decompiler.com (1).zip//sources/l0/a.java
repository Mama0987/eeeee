package l0;

import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;
import androidx.annotation.NonNull;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private final a f12582a;

    a(a aVar) {
        this.f12582a = aVar;
    }

    public static a b(@NonNull Context context, @NonNull Uri uri) {
        return new c((a) null, context, DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri)));
    }

    public abstract a a(@NonNull String str, @NonNull String str2);

    public abstract String c();

    @NonNull
    public abstract Uri d();

    public abstract boolean e();

    @NonNull
    public abstract a[] f();
}
