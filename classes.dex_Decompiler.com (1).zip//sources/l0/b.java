package l0;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

class b {
    private static void a(AutoCloseable autoCloseable) {
        if (autoCloseable != null) {
            try {
                autoCloseable.close();
            } catch (RuntimeException e10) {
                throw e10;
            } catch (Exception unused) {
            }
        }
    }

    public static String b(Context context, Uri uri) {
        return e(context, uri, "_display_name", (String) null);
    }

    private static String c(Context context, Uri uri) {
        return e(context, uri, "mime_type", (String) null);
    }

    public static boolean d(Context context, Uri uri) {
        String c10 = c(context, uri);
        return !"vnd.android.document/directory".equals(c10) && !TextUtils.isEmpty(c10);
    }

    private static String e(Context context, Uri uri, String str, String str2) {
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(uri, new String[]{str}, (String) null, (String[]) null, (String) null);
            if (cursor.moveToFirst() && !cursor.isNull(0)) {
                return cursor.getString(0);
            }
            a(cursor);
            return str2;
        } catch (Exception e10) {
            Log.w("DocumentFile", "Failed query: " + e10);
            return str2;
        } finally {
            a(cursor);
        }
    }
}
