package l0;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Log;
import java.util.ArrayList;

class c extends a {

    /* renamed from: b  reason: collision with root package name */
    private Context f12583b;

    /* renamed from: c  reason: collision with root package name */
    private Uri f12584c;

    c(a aVar, Context context, Uri uri) {
        super(aVar);
        this.f12583b = context;
        this.f12584c = uri;
    }

    private static void g(AutoCloseable autoCloseable) {
        if (autoCloseable != null) {
            try {
                autoCloseable.close();
            } catch (RuntimeException e10) {
                throw e10;
            } catch (Exception unused) {
            }
        }
    }

    private static Uri h(Context context, Uri uri, String str, String str2) {
        try {
            return DocumentsContract.createDocument(context.getContentResolver(), uri, str, str2);
        } catch (Exception unused) {
            return null;
        }
    }

    public a a(String str, String str2) {
        Uri h10 = h(this.f12583b, this.f12584c, str, str2);
        if (h10 != null) {
            return new c(this, this.f12583b, h10);
        }
        return null;
    }

    public String c() {
        return b.b(this.f12583b, this.f12584c);
    }

    public Uri d() {
        return this.f12584c;
    }

    public boolean e() {
        return b.d(this.f12583b, this.f12584c);
    }

    public a[] f() {
        ContentResolver contentResolver = this.f12583b.getContentResolver();
        Uri uri = this.f12584c;
        Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
        ArrayList arrayList = new ArrayList();
        Cursor cursor = null;
        try {
            cursor = contentResolver.query(buildChildDocumentsUriUsingTree, new String[]{"document_id"}, (String) null, (String[]) null, (String) null);
            while (cursor.moveToNext()) {
                arrayList.add(DocumentsContract.buildDocumentUriUsingTree(this.f12584c, cursor.getString(0)));
            }
        } catch (Exception e10) {
            Log.w("DocumentFile", "Failed query: " + e10);
        } catch (Throwable th) {
            g((AutoCloseable) null);
            throw th;
        }
        g(cursor);
        Uri[] uriArr = (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
        a[] aVarArr = new a[uriArr.length];
        for (int i10 = 0; i10 < uriArr.length; i10++) {
            aVarArr[i10] = new c(this, this.f12583b, uriArr[i10]);
        }
        return aVarArr;
    }
}
