package w4;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import q4.t0;
import qb.a0;
import s4.k;
import v3.e0;
import v3.n0;

@Metadata
public final class e {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final e f17190a = new e();

    private e() {
    }

    public static final void d() {
        if (e0.p()) {
            h();
        }
    }

    @NotNull
    public static final File[] e() {
        File f10 = k.f();
        if (f10 == null) {
            return new File[0];
        }
        File[] listFiles = f10.listFiles(new d());
        Intrinsics.checkNotNullExpressionValue(listFiles, "reportDir.listFiles { dir, name ->\n      name.matches(Regex(String.format(\"^%s[0-9]+.json$\", InstrumentUtility.ERROR_REPORT_PREFIX)))\n    }");
        return listFiles;
    }

    /* access modifiers changed from: private */
    public static final boolean f(File file, String str) {
        Intrinsics.checkNotNullExpressionValue(str, "name");
        a0 a0Var = a0.f14418a;
        String format = String.format("^%s[0-9]+.json$", Arrays.copyOf(new Object[]{"error_log_"}, 1));
        Intrinsics.checkNotNullExpressionValue(format, "java.lang.String.format(format, *args)");
        return new Regex(format).b(str);
    }

    public static final void g(String str) {
        try {
            new a(str).e();
        } catch (Exception unused) {
        }
    }

    public static final void h() {
        if (!t0.a0()) {
            File[] e10 = e();
            ArrayList arrayList = new ArrayList();
            int length = e10.length;
            int i10 = 0;
            int i11 = 0;
            while (i11 < length) {
                File file = e10[i11];
                i11++;
                a aVar = new a(file);
                if (aVar.d()) {
                    arrayList.add(aVar);
                }
            }
            u.s(arrayList, new b());
            JSONArray jSONArray = new JSONArray();
            while (i10 < arrayList.size() && i10 < 1000) {
                jSONArray.put(arrayList.get(i10));
                i10++;
            }
            k kVar = k.f15141a;
            k.s("error_reports", jSONArray, new c(arrayList));
        }
    }

    /* access modifiers changed from: private */
    public static final int i(a aVar, a aVar2) {
        Intrinsics.checkNotNullExpressionValue(aVar2, "o2");
        return aVar.b(aVar2);
    }

    /* access modifiers changed from: private */
    public static final void j(ArrayList arrayList, n0 n0Var) {
        Intrinsics.checkNotNullParameter(arrayList, "$validReports");
        Intrinsics.checkNotNullParameter(n0Var, "response");
        try {
            if (n0Var.b() == null) {
                JSONObject d10 = n0Var.d();
                if (Intrinsics.a(d10 == null ? null : Boolean.valueOf(d10.getBoolean("success")), Boolean.TRUE)) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        ((a) it.next()).a();
                    }
                }
            }
        } catch (JSONException unused) {
        }
    }
}
