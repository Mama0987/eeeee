package w4;

import java.util.ArrayList;
import v3.i0;
import v3.n0;

public final /* synthetic */ class c implements i0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ArrayList f17189a;

    public /* synthetic */ c(ArrayList arrayList) {
        this.f17189a = arrayList;
    }

    public final void b(n0 n0Var) {
        e.j(this.f17189a, n0Var);
    }
}
