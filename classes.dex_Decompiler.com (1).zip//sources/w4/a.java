package w4;

import com.FF.voiceengine.FFVoiceConst;
import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;
import s4.k;

@Metadata
public final class a {
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    public static final C0313a f17185d = new C0313a((DefaultConstructorMarker) null);
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private String f17186a;

    /* renamed from: b  reason: collision with root package name */
    private String f17187b;

    /* renamed from: c  reason: collision with root package name */
    private Long f17188c;

    @Metadata
    /* renamed from: w4.a$a  reason: collision with other inner class name */
    public static final class C0313a {
        private C0313a() {
        }

        public /* synthetic */ C0313a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    public a(@NotNull File file) {
        Intrinsics.checkNotNullParameter(file, "file");
        String name = file.getName();
        Intrinsics.checkNotNullExpressionValue(name, "file.name");
        this.f17186a = name;
        JSONObject r10 = k.r(name, true);
        if (r10 != null) {
            this.f17188c = Long.valueOf(r10.optLong("timestamp", 0));
            this.f17187b = r10.optString("error_message", (String) null);
        }
    }

    public a(String str) {
        this.f17188c = Long.valueOf(System.currentTimeMillis() / ((long) FFVoiceConst.FFVoiceEvent.FFVoice_EVENT_EOF));
        this.f17187b = str;
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("error_log_");
        Long l10 = this.f17188c;
        if (l10 != null) {
            stringBuffer.append(l10.longValue());
            stringBuffer.append(".json");
            String stringBuffer2 = stringBuffer.toString();
            Intrinsics.checkNotNullExpressionValue(stringBuffer2, "StringBuffer()\n            .append(InstrumentUtility.ERROR_REPORT_PREFIX)\n            .append(timestamp as Long)\n            .append(\".json\")\n            .toString()");
            this.f17186a = stringBuffer2;
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Long");
    }

    public final void a() {
        k kVar = k.f15141a;
        k.d(this.f17186a);
    }

    public final int b(@NotNull a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "data");
        Long l10 = this.f17188c;
        if (l10 == null) {
            return -1;
        }
        long longValue = l10.longValue();
        Long l11 = aVar.f17188c;
        if (l11 == null) {
            return 1;
        }
        return Intrinsics.g(l11.longValue(), longValue);
    }

    public final JSONObject c() {
        JSONObject jSONObject = new JSONObject();
        try {
            Long l10 = this.f17188c;
            if (l10 != null) {
                jSONObject.put("timestamp", l10);
            }
            jSONObject.put("error_message", this.f17187b);
            return jSONObject;
        } catch (JSONException unused) {
            return null;
        }
    }

    public final boolean d() {
        return (this.f17187b == null || this.f17188c == null) ? false : true;
    }

    public final void e() {
        if (d()) {
            k kVar = k.f15141a;
            k.t(this.f17186a, toString());
        }
    }

    @NotNull
    public String toString() {
        JSONObject c10 = c();
        if (c10 == null) {
            return super.toString();
        }
        String jSONObject = c10.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject, "params.toString()");
        return jSONObject;
    }
}
