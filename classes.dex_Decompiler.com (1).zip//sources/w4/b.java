package w4;

import java.util.Comparator;

public final /* synthetic */ class b implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return e.i((a) obj, (a) obj2);
    }
}
