package k3;

import android.content.Intent;
import t3.b;

public interface a {
    boolean a(Intent intent, p3.a aVar);

    boolean b(b bVar);
}
