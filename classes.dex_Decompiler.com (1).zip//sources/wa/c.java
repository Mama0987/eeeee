package wa;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Log;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import qa.d;

public class c {
    public static Map<String, String> a(String str) {
        StringBuilder sb2;
        String str2;
        String str3;
        if (str == null) {
            return null;
        }
        String[] split = str.split("&");
        HashMap hashMap = new HashMap(split.length);
        for (String str4 : split) {
            String[] split2 = str4.split("=");
            if (split2 == null || split2.length <= 0) {
                sb2 = new StringBuilder();
                sb2.append(str4);
                str2 = " splitted to nothing";
            } else {
                String str5 = split2[0];
                if (str5 == null) {
                    sb2 = new StringBuilder();
                    sb2.append(str4);
                    str2 = " splitted to null key";
                } else if (split2.length <= 1 || (str3 = split2[1]) == null) {
                    Log.v("VKSDK", split2[0] + " has no value");
                    hashMap.put(split2[0], (Object) null);
                } else {
                    hashMap.put(str5, str3);
                }
            }
            sb2.append(str2);
            Log.v("VKSDK", sb2.toString());
        }
        return hashMap;
    }

    public static String b(Context context) {
        try {
            PackageManager packageManager = context.getApplicationContext().getPackageManager();
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
            return (String) (applicationInfo != null ? packageManager.getApplicationLabel(applicationInfo) : "(unknown)");
        } catch (Exception unused) {
            return null;
        }
    }

    public static String[] c(Context context, String str) {
        if (context != null) {
            try {
                if (context.getPackageManager() != null) {
                    Signature[] signatureArr = context.getPackageManager().getPackageInfo(str, 64).signatures;
                    String[] strArr = new String[signatureArr.length];
                    int length = signatureArr.length;
                    int i10 = 0;
                    int i11 = 0;
                    while (i10 < length) {
                        Signature signature = signatureArr[i10];
                        MessageDigest instance = MessageDigest.getInstance("SHA");
                        instance.update(signature.toByteArray());
                        int i12 = i11 + 1;
                        strArr[i11] = j(instance.digest());
                        i10++;
                        i11 = i12;
                    }
                    return strArr;
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public static String d(String str) {
        if (str == null || str.length() == 0) {
            return "";
        }
        int indexOf = str.indexOf("//");
        int i10 = indexOf == -1 ? 0 : indexOf + 2;
        int indexOf2 = str.indexOf(47, i10);
        if (indexOf2 < 0) {
            indexOf2 = str.length();
        }
        int indexOf3 = str.indexOf(58, i10);
        if (indexOf3 > 0 && indexOf3 < indexOf2) {
            indexOf2 = indexOf3;
        }
        return str.substring(i10, indexOf2);
    }

    public static boolean e(Context context, String str) {
        try {
            context.getPackageManager().getPackageInfo(str, 128);
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    public static boolean f(Context context, String str) {
        return context.getPackageManager().queryIntentActivities(new Intent(str), 65536).size() > 0;
    }

    public static Map<String, Object> g(Object... objArr) {
        Object obj;
        int length = objArr.length % 2;
        LinkedHashMap linkedHashMap = new LinkedHashMap(objArr.length / 2);
        int i10 = 0;
        while (true) {
            int i11 = i10 + 1;
            if (i11 >= objArr.length) {
                return linkedHashMap;
            }
            String str = objArr[i10];
            if (!(str == null || (obj = objArr[i11]) == null || !(str instanceof String))) {
                linkedHashMap.put(str, obj);
            }
            i10 += 2;
        }
    }

    public static String h(String str) {
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(str.getBytes());
            byte[] digest = instance.digest();
            StringBuilder sb2 = new StringBuilder();
            for (byte b10 : digest) {
                String hexString = Integer.toHexString(b10 & 255);
                while (hexString.length() < 2) {
                    hexString = "0" + hexString;
                }
                sb2.append(hexString);
            }
            return sb2.toString();
        } catch (NoSuchAlgorithmException unused) {
            return "";
        }
    }

    public static d i(Object... objArr) {
        return new d(g(objArr));
    }

    private static String j(byte[] bArr) {
        BigInteger bigInteger = new BigInteger(1, bArr);
        return String.format("%0" + (bArr.length << 1) + "X", new Object[]{bigInteger});
    }
}
