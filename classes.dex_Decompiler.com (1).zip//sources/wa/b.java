package wa;

import android.net.Uri;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import ta.r;

public class b {
    public static String a(Collection<?> collection, String str) {
        return TextUtils.join(str, collection);
    }

    public static String b(Map<String, ?> map) {
        return c(map, false);
    }

    public static String c(Map<String, ?> map, boolean z10) {
        ArrayList arrayList = new ArrayList(map.size());
        for (Map.Entry next : map.entrySet()) {
            Object value = next.getValue();
            if (value instanceof r) {
                value = ((r) value).W();
            }
            Object[] objArr = new Object[2];
            objArr[0] = next.getKey();
            String valueOf = String.valueOf(value);
            if (z10) {
                valueOf = Uri.encode(valueOf);
            }
            objArr[1] = valueOf;
            arrayList.add(String.format("%s=%s", objArr));
        }
        return a(arrayList, "&");
    }
}
