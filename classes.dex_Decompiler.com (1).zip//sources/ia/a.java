package ia;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.annotation.NonNull;

public class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new C0180a();

    /* renamed from: f  reason: collision with root package name */
    private static int f11424f = 1;

    /* renamed from: g  reason: collision with root package name */
    private static int f11425g = 2;
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final String f11426a;
    @NonNull

    /* renamed from: b  reason: collision with root package name */
    private final Uri f11427b;
    @NonNull

    /* renamed from: c  reason: collision with root package name */
    private final Uri f11428c;

    /* renamed from: d  reason: collision with root package name */
    private final boolean f11429d;

    /* renamed from: e  reason: collision with root package name */
    private final boolean f11430e;

    /* renamed from: ia.a$a  reason: collision with other inner class name */
    static class C0180a implements Parcelable.Creator<a> {
        C0180a() {
        }

        /* renamed from: a */
        public final a createFromParcel(Parcel parcel) {
            return new a(parcel, (C0180a) null);
        }

        /* renamed from: b */
        public final a[] newArray(int i10) {
            return new a[i10];
        }
    }

    public static class b {
        /* access modifiers changed from: private */
        @NonNull

        /* renamed from: a  reason: collision with root package name */
        public final String f11431a;
        /* access modifiers changed from: private */
        @NonNull

        /* renamed from: b  reason: collision with root package name */
        public Uri f11432b;
        /* access modifiers changed from: private */
        @NonNull

        /* renamed from: c  reason: collision with root package name */
        public Uri f11433c;
        /* access modifiers changed from: private */

        /* renamed from: d  reason: collision with root package name */
        public boolean f11434d;
        /* access modifiers changed from: private */

        /* renamed from: e  reason: collision with root package name */
        public boolean f11435e;

        public b(@NonNull String str) {
            if (!TextUtils.isEmpty(str)) {
                this.f11431a = str;
                this.f11432b = Uri.parse("https://access.line.me/v2");
                this.f11433c = Uri.parse("https://access.line.me/dialog/oauth/weblogin");
                return;
            }
            throw new IllegalArgumentException("channelId is empty.");
        }

        @NonNull
        public a f() {
            return new a(this, (C0180a) null);
        }
    }

    private a(@NonNull Parcel parcel) {
        this.f11426a = parcel.readString();
        Class<Uri> cls = Uri.class;
        this.f11427b = (Uri) parcel.readParcelable(cls.getClassLoader());
        this.f11428c = (Uri) parcel.readParcelable(cls.getClassLoader());
        int readInt = parcel.readInt();
        boolean z10 = true;
        this.f11429d = (f11424f & readInt) > 0;
        this.f11430e = (readInt & f11425g) <= 0 ? false : z10;
    }

    /* synthetic */ a(Parcel parcel, C0180a aVar) {
        this(parcel);
    }

    private a(@NonNull b bVar) {
        this.f11426a = bVar.f11431a;
        this.f11427b = bVar.f11432b;
        this.f11428c = bVar.f11433c;
        this.f11429d = bVar.f11434d;
        this.f11430e = bVar.f11435e;
    }

    /* synthetic */ a(b bVar, C0180a aVar) {
        this(bVar);
    }

    @NonNull
    public String a() {
        return this.f11426a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        a aVar = (a) obj;
        if (this.f11429d == aVar.f11429d && this.f11430e == aVar.f11430e && this.f11426a.equals(aVar.f11426a) && this.f11427b.equals(aVar.f11427b)) {
            return this.f11428c.equals(aVar.f11428c);
        }
        return false;
    }

    public int hashCode() {
        return (((((((this.f11426a.hashCode() * 31) + this.f11427b.hashCode()) * 31) + this.f11428c.hashCode()) * 31) + (this.f11429d ? 1 : 0)) * 31) + (this.f11430e ? 1 : 0);
    }

    @NonNull
    public Uri j() {
        return this.f11427b;
    }

    @NonNull
    public Uri k() {
        return this.f11428c;
    }

    public boolean l() {
        return this.f11430e;
    }

    public boolean m() {
        return this.f11429d;
    }

    public String toString() {
        return "LineAuthenticationConfig{channelId=" + this.f11426a + ", endPointBaseUrl=" + this.f11427b + ", webLoginPageUrl=" + this.f11428c + ", isLineAppAuthenticationDisabled=" + this.f11429d + ", isEncryptorPreparationDisabled=" + this.f11430e + '}';
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f11426a);
        parcel.writeParcelable(this.f11427b, i10);
        parcel.writeParcelable(this.f11428c, i10);
        int i11 = 0;
        int i12 = (this.f11429d ? f11424f : 0) | 0;
        if (this.f11430e) {
            i11 = f11425g;
        }
        parcel.writeInt(i12 | i11);
    }
}
