package ia;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import ca.b;
import ca.d;
import ca.e;
import ca.f;

public class c implements Parcelable {
    public static final Parcelable.Creator<c> CREATOR = new a();

    /* renamed from: e  reason: collision with root package name */
    public static final c f11436e = new c(d.CANCEL, b.f4650c);
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final d f11437a;

    /* renamed from: b  reason: collision with root package name */
    private final f f11438b;

    /* renamed from: c  reason: collision with root package name */
    private final e f11439c;
    @NonNull

    /* renamed from: d  reason: collision with root package name */
    private final b f11440d;

    static class a implements Parcelable.Creator<c> {
        a() {
        }

        /* renamed from: a */
        public final c createFromParcel(Parcel parcel) {
            return new c(parcel, (a) null);
        }

        /* renamed from: b */
        public final c[] newArray(int i10) {
            return new c[i10];
        }
    }

    private c(@NonNull Parcel parcel) {
        this.f11437a = (d) parcel.readSerializable();
        this.f11438b = (f) parcel.readParcelable(f.class.getClassLoader());
        this.f11439c = (e) parcel.readParcelable(ca.a.class.getClassLoader());
        this.f11440d = (b) parcel.readParcelable(b.class.getClassLoader());
    }

    /* synthetic */ c(Parcel parcel, a aVar) {
        this(parcel);
    }

    public c(@NonNull d dVar, @NonNull b bVar) {
        this(dVar, (f) null, (e) null, bVar);
    }

    c(@NonNull d dVar, f fVar, e eVar, @NonNull b bVar) {
        this.f11437a = dVar;
        this.f11438b = fVar;
        this.f11439c = eVar;
        this.f11440d = bVar;
    }

    public c(@NonNull f fVar, @NonNull e eVar) {
        this(d.SUCCESS, fVar, eVar, b.f4650c);
    }

    @NonNull
    public b a() {
        return this.f11440d;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        c cVar = (c) obj;
        if (this.f11437a != cVar.f11437a) {
            return false;
        }
        f fVar = this.f11438b;
        if (fVar == null ? cVar.f11438b != null : !fVar.equals(cVar.f11438b)) {
            return false;
        }
        e eVar = this.f11439c;
        if (eVar == null ? cVar.f11439c == null : eVar.equals(cVar.f11439c)) {
            return this.f11440d.equals(cVar.f11440d);
        }
        return false;
    }

    public int hashCode() {
        int hashCode = this.f11437a.hashCode() * 31;
        f fVar = this.f11438b;
        int i10 = 0;
        int hashCode2 = (hashCode + (fVar != null ? fVar.hashCode() : 0)) * 31;
        e eVar = this.f11439c;
        if (eVar != null) {
            i10 = eVar.hashCode();
        }
        return ((hashCode2 + i10) * 31) + this.f11440d.hashCode();
    }

    public e j() {
        return this.f11439c;
    }

    @NonNull
    public d k() {
        return this.f11437a;
    }

    public String toString() {
        return "LineLoginResult{errorData=" + this.f11440d + ", responseCode=" + this.f11437a + ", lineProfile=" + this.f11438b + ", lineCredential=" + this.f11439c + '}';
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeSerializable(this.f11437a);
        parcel.writeParcelable(this.f11438b, i10);
        parcel.writeParcelable(this.f11439c, i10);
        parcel.writeParcelable(this.f11440d, i10);
    }
}
