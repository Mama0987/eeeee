package ia;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import ca.d;
import com.linecorp.linesdk.auth.internal.LineAuthenticationActivity;
import da.c;
import ia.a;
import java.util.Collections;
import java.util.List;

public class b {
    @NonNull
    public static Intent a(@NonNull Context context, @NonNull a aVar, @NonNull List<String> list) {
        if (!aVar.l()) {
            c.b(context);
        }
        return LineAuthenticationActivity.a(context, aVar, list);
    }

    @NonNull
    public static Intent b(@NonNull Context context, @NonNull String str) {
        return a(context, new a.b(str).f(), Collections.emptyList());
    }

    @NonNull
    public static c c(Intent intent) {
        return intent == null ? new c(d.INTERNAL_ERROR, new ca.b("Callback intent is null")) : LineAuthenticationActivity.b(intent);
    }
}
