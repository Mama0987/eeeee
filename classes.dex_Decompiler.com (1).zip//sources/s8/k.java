package s8;

import java.util.concurrent.Callable;

public final /* synthetic */ class k implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m f15310a;

    public /* synthetic */ k(m mVar) {
        this.f15310a = mVar;
    }

    public final Object call() {
        return this.f15310a.i();
    }
}
