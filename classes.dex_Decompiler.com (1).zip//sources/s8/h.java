package s8;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Locale;
import p8.f;
import s8.g;

class h implements c {

    /* renamed from: d  reason: collision with root package name */
    private static final Charset f15298d = Charset.forName("UTF-8");

    /* renamed from: a  reason: collision with root package name */
    private final File f15299a;

    /* renamed from: b  reason: collision with root package name */
    private final int f15300b;

    /* renamed from: c  reason: collision with root package name */
    private g f15301c;

    class a implements g.d {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ byte[] f15302a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int[] f15303b;

        a(byte[] bArr, int[] iArr) {
            this.f15302a = bArr;
            this.f15303b = iArr;
        }

        public void a(InputStream inputStream, int i10) throws IOException {
            try {
                inputStream.read(this.f15302a, this.f15303b[0], i10);
                int[] iArr = this.f15303b;
                iArr[0] = iArr[0] + i10;
            } finally {
                inputStream.close();
            }
        }
    }

    private static class b {

        /* renamed from: a  reason: collision with root package name */
        public final byte[] f15305a;

        /* renamed from: b  reason: collision with root package name */
        public final int f15306b;

        b(byte[] bArr, int i10) {
            this.f15305a = bArr;
            this.f15306b = i10;
        }
    }

    h(File file, int i10) {
        this.f15299a = file;
        this.f15300b = i10;
    }

    private void f(long j10, String str) {
        if (this.f15301c != null) {
            if (str == null) {
                str = "null";
            }
            try {
                int i10 = this.f15300b / 4;
                if (str.length() > i10) {
                    str = "..." + str.substring(str.length() - i10);
                }
                this.f15301c.e(String.format(Locale.US, "%d %s%n", new Object[]{Long.valueOf(j10), str.replaceAll("\r", " ").replaceAll("\n", " ")}).getBytes(f15298d));
                while (!this.f15301c.m() && this.f15301c.G() > this.f15300b) {
                    this.f15301c.A();
                }
            } catch (IOException e10) {
                f.f().e("There was a problem writing to the Crashlytics log.", e10);
            }
        }
    }

    private b g() {
        if (!this.f15299a.exists()) {
            return null;
        }
        h();
        g gVar = this.f15301c;
        if (gVar == null) {
            return null;
        }
        int[] iArr = {0};
        byte[] bArr = new byte[gVar.G()];
        try {
            this.f15301c.i(new a(bArr, iArr));
        } catch (IOException e10) {
            f.f().e("A problem occurred while reading the Crashlytics log file.", e10);
        }
        return new b(bArr, iArr[0]);
    }

    private void h() {
        if (this.f15301c == null) {
            try {
                this.f15301c = new g(this.f15299a);
            } catch (IOException e10) {
                f f10 = f.f();
                f10.e("Could not open log file: " + this.f15299a, e10);
            }
        }
    }

    public void a() {
        com.google.firebase.crashlytics.internal.common.h.f(this.f15301c, "There was a problem closing the Crashlytics log file.");
        this.f15301c = null;
    }

    public String b() {
        byte[] c10 = c();
        if (c10 != null) {
            return new String(c10, f15298d);
        }
        return null;
    }

    public byte[] c() {
        b g10 = g();
        if (g10 == null) {
            return null;
        }
        int i10 = g10.f15306b;
        byte[] bArr = new byte[i10];
        System.arraycopy(g10.f15305a, 0, bArr, 0, i10);
        return bArr;
    }

    public void d() {
        a();
        this.f15299a.delete();
    }

    public void e(long j10, String str) {
        h();
        f(j10, str);
    }
}
