package s8;

final class b extends i {

    /* renamed from: b  reason: collision with root package name */
    private final String f15268b;

    /* renamed from: c  reason: collision with root package name */
    private final String f15269c;

    /* renamed from: d  reason: collision with root package name */
    private final String f15270d;

    /* renamed from: e  reason: collision with root package name */
    private final String f15271e;

    /* renamed from: f  reason: collision with root package name */
    private final long f15272f;

    b(String str, String str2, String str3, String str4, long j10) {
        if (str != null) {
            this.f15268b = str;
            if (str2 != null) {
                this.f15269c = str2;
                if (str3 != null) {
                    this.f15270d = str3;
                    if (str4 != null) {
                        this.f15271e = str4;
                        this.f15272f = j10;
                        return;
                    }
                    throw new NullPointerException("Null variantId");
                }
                throw new NullPointerException("Null parameterValue");
            }
            throw new NullPointerException("Null parameterKey");
        }
        throw new NullPointerException("Null rolloutId");
    }

    public String c() {
        return this.f15269c;
    }

    public String d() {
        return this.f15270d;
    }

    public String e() {
        return this.f15268b;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return this.f15268b.equals(iVar.e()) && this.f15269c.equals(iVar.c()) && this.f15270d.equals(iVar.d()) && this.f15271e.equals(iVar.g()) && this.f15272f == iVar.f();
    }

    public long f() {
        return this.f15272f;
    }

    public String g() {
        return this.f15271e;
    }

    public int hashCode() {
        long j10 = this.f15272f;
        return ((((((((this.f15268b.hashCode() ^ 1000003) * 1000003) ^ this.f15269c.hashCode()) * 1000003) ^ this.f15270d.hashCode()) * 1000003) ^ this.f15271e.hashCode()) * 1000003) ^ ((int) (j10 ^ (j10 >>> 32)));
    }

    public String toString() {
        return "RolloutAssignment{rolloutId=" + this.f15268b + ", parameterKey=" + this.f15269c + ", parameterValue=" + this.f15270d + ", variantId=" + this.f15271e + ", templateVersion=" + this.f15272f + "}";
    }
}
