package s8;

interface c {
    void a();

    String b();

    byte[] c();

    void d();

    void e(long j10, String str);
}
