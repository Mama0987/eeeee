package s8;

import c9.a;
import e9.d;
import org.json.JSONException;
import org.json.JSONObject;
import t8.f0;

public abstract class i {

    /* renamed from: a  reason: collision with root package name */
    public static final a f15307a = new d().j(a.f15261a).i();

    static i a(String str) throws JSONException {
        JSONObject jSONObject = new JSONObject(str);
        return b(jSONObject.getString("rolloutId"), jSONObject.getString("parameterKey"), jSONObject.getString("parameterValue"), jSONObject.getString("variantId"), jSONObject.getLong("templateVersion"));
    }

    public static i b(String str, String str2, String str3, String str4, long j10) {
        return new b(str, str2, i(str3), str4, j10);
    }

    private static String i(String str) {
        return str.length() > 256 ? str.substring(0, 256) : str;
    }

    public abstract String c();

    public abstract String d();

    public abstract String e();

    public abstract long f();

    public abstract String g();

    public f0.e.d.C0283e h() {
        return f0.e.d.C0283e.a().d(f0.e.d.C0283e.b.a().c(g()).b(e()).a()).b(c()).c(d()).e(f()).a();
    }
}
