package s8;

import com.google.firebase.crashlytics.internal.persistence.FileStore;
import java.io.File;

public class e {

    /* renamed from: c  reason: collision with root package name */
    private static final b f15276c = new b();

    /* renamed from: a  reason: collision with root package name */
    private final FileStore f15277a;

    /* renamed from: b  reason: collision with root package name */
    private c f15278b;

    private static final class b implements c {
        private b() {
        }

        public void a() {
        }

        public String b() {
            return null;
        }

        public byte[] c() {
            return null;
        }

        public void d() {
        }

        public void e(long j10, String str) {
        }
    }

    public e(FileStore fileStore) {
        this.f15277a = fileStore;
        this.f15278b = f15276c;
    }

    public e(FileStore fileStore, String str) {
        this(fileStore);
        e(str);
    }

    private File d(String str) {
        return this.f15277a.o(str, "userlog");
    }

    public void a() {
        this.f15278b.d();
    }

    public byte[] b() {
        return this.f15278b.c();
    }

    public String c() {
        return this.f15278b.b();
    }

    public final void e(String str) {
        this.f15278b.a();
        this.f15278b = f15276c;
        if (str != null) {
            f(d(str), 65536);
        }
    }

    /* access modifiers changed from: package-private */
    public void f(File file, int i10) {
        this.f15278b = new h(file, i10);
    }

    public void g(long j10, String str) {
        this.f15278b.e(j10, str);
    }
}
