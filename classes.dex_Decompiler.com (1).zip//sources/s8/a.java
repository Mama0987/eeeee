package s8;

import c9.c;
import c9.d;
import c9.e;
import d9.b;
import java.io.IOException;

public final class a implements d9.a {

    /* renamed from: a  reason: collision with root package name */
    public static final d9.a f15261a = new a();

    /* renamed from: s8.a$a  reason: collision with other inner class name */
    private static final class C0257a implements d<i> {

        /* renamed from: a  reason: collision with root package name */
        static final C0257a f15262a = new C0257a();

        /* renamed from: b  reason: collision with root package name */
        private static final c f15263b = c.d("rolloutId");

        /* renamed from: c  reason: collision with root package name */
        private static final c f15264c = c.d("parameterKey");

        /* renamed from: d  reason: collision with root package name */
        private static final c f15265d = c.d("parameterValue");

        /* renamed from: e  reason: collision with root package name */
        private static final c f15266e = c.d("variantId");

        /* renamed from: f  reason: collision with root package name */
        private static final c f15267f = c.d("templateVersion");

        private C0257a() {
        }

        /* renamed from: b */
        public void a(i iVar, e eVar) throws IOException {
            eVar.a(f15263b, iVar.e());
            eVar.a(f15264c, iVar.c());
            eVar.a(f15265d, iVar.d());
            eVar.a(f15266e, iVar.g());
            eVar.e(f15267f, iVar.f());
        }
    }

    private a() {
    }

    public void a(b<?> bVar) {
        C0257a aVar = C0257a.f15262a;
        bVar.a(i.class, aVar);
        bVar.a(b.class, aVar);
    }
}
