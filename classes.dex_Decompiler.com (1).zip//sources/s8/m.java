package s8;

import com.google.firebase.crashlytics.internal.common.CrashlyticsBackgroundWorker;
import com.google.firebase.crashlytics.internal.common.h;
import com.google.firebase.crashlytics.internal.persistence.FileStore;
import h.b;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicReference;
import t8.f0;

public class m {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final f f15312a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final CrashlyticsBackgroundWorker f15313b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public String f15314c;

    /* renamed from: d  reason: collision with root package name */
    private final a f15315d = new a(false);

    /* renamed from: e  reason: collision with root package name */
    private final a f15316e = new a(true);

    /* renamed from: f  reason: collision with root package name */
    private final j f15317f = new j(128);

    /* renamed from: g  reason: collision with root package name */
    private final AtomicMarkableReference<String> f15318g = new AtomicMarkableReference<>((Object) null, false);

    private class a {

        /* renamed from: a  reason: collision with root package name */
        final AtomicMarkableReference<d> f15319a;

        /* renamed from: b  reason: collision with root package name */
        private final AtomicReference<Callable<Void>> f15320b = new AtomicReference<>((Object) null);

        /* renamed from: c  reason: collision with root package name */
        private final boolean f15321c;

        public a(boolean z10) {
            this.f15321c = z10;
            this.f15319a = new AtomicMarkableReference<>(new d(64, z10 ? 8192 : 1024), false);
        }

        /* access modifiers changed from: private */
        public /* synthetic */ Void c() throws Exception {
            this.f15320b.set((Object) null);
            e();
            return null;
        }

        private void d() {
            l lVar = new l(this);
            if (b.a(this.f15320b, (Object) null, lVar)) {
                m.this.f15313b.h(lVar);
            }
        }

        private void e() {
            Map<String, String> map;
            synchronized (this) {
                if (this.f15319a.isMarked()) {
                    map = this.f15319a.getReference().a();
                    AtomicMarkableReference<d> atomicMarkableReference = this.f15319a;
                    atomicMarkableReference.set(atomicMarkableReference.getReference(), false);
                } else {
                    map = null;
                }
            }
            if (map != null) {
                m.this.f15312a.q(m.this.f15314c, map, this.f15321c);
            }
        }

        public Map<String, String> b() {
            return this.f15319a.getReference().a();
        }

        public boolean f(String str, String str2) {
            synchronized (this) {
                if (!this.f15319a.getReference().d(str, str2)) {
                    return false;
                }
                AtomicMarkableReference<d> atomicMarkableReference = this.f15319a;
                atomicMarkableReference.set(atomicMarkableReference.getReference(), true);
                d();
                return true;
            }
        }

        public void g(Map<String, String> map) {
            synchronized (this) {
                this.f15319a.getReference().e(map);
                AtomicMarkableReference<d> atomicMarkableReference = this.f15319a;
                atomicMarkableReference.set(atomicMarkableReference.getReference(), true);
            }
            d();
        }
    }

    public m(String str, FileStore fileStore, CrashlyticsBackgroundWorker crashlyticsBackgroundWorker) {
        this.f15314c = str;
        this.f15312a = new f(fileStore);
        this.f15313b = crashlyticsBackgroundWorker;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object i() throws Exception {
        l();
        return null;
    }

    public static m j(String str, FileStore fileStore, CrashlyticsBackgroundWorker crashlyticsBackgroundWorker) {
        f fVar = new f(fileStore);
        m mVar = new m(str, fileStore, crashlyticsBackgroundWorker);
        mVar.f15315d.f15319a.getReference().e(fVar.i(str, false));
        mVar.f15316e.f15319a.getReference().e(fVar.i(str, true));
        mVar.f15318g.set(fVar.k(str), false);
        mVar.f15317f.c(fVar.j(str));
        return mVar;
    }

    public static String k(String str, FileStore fileStore) {
        return new f(fileStore).k(str);
    }

    private void l() {
        boolean z10;
        String str;
        synchronized (this.f15318g) {
            z10 = false;
            if (this.f15318g.isMarked()) {
                str = h();
                this.f15318g.set(str, false);
                z10 = true;
            } else {
                str = null;
            }
        }
        if (z10) {
            this.f15312a.s(this.f15314c, str);
        }
    }

    public Map<String, String> e() {
        return this.f15315d.b();
    }

    public Map<String, String> f() {
        return this.f15316e.b();
    }

    public List<f0.e.d.C0283e> g() {
        return this.f15317f.a();
    }

    public String h() {
        return this.f15318g.getReference();
    }

    public boolean m(String str, String str2) {
        return this.f15315d.f(str, str2);
    }

    public void n(Map<String, String> map) {
        this.f15315d.g(map);
    }

    public boolean o(String str, String str2) {
        return this.f15316e.f(str, str2);
    }

    public void p(String str) {
        synchronized (this.f15314c) {
            this.f15314c = str;
            Map<String, String> b10 = this.f15315d.b();
            List<i> b11 = this.f15317f.b();
            if (h() != null) {
                this.f15312a.s(str, h());
            }
            if (!b10.isEmpty()) {
                this.f15312a.p(str, b10);
            }
            if (!b11.isEmpty()) {
                this.f15312a.r(str, b11);
            }
        }
    }

    public void q(String str) {
        String c10 = d.c(str, 1024);
        synchronized (this.f15318g) {
            if (!h.y(c10, this.f15318g.getReference())) {
                this.f15318g.set(c10, true);
                this.f15313b.h(new k(this));
            }
        }
    }
}
