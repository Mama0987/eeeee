package s8;

import com.appff.haptic.base.Utils;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

class g implements Closeable {

    /* renamed from: g  reason: collision with root package name */
    private static final Logger f15282g = Logger.getLogger(g.class.getName());
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final RandomAccessFile f15283a;

    /* renamed from: b  reason: collision with root package name */
    int f15284b;

    /* renamed from: c  reason: collision with root package name */
    private int f15285c;

    /* renamed from: d  reason: collision with root package name */
    private b f15286d;

    /* renamed from: e  reason: collision with root package name */
    private b f15287e;

    /* renamed from: f  reason: collision with root package name */
    private final byte[] f15288f = new byte[16];

    class a implements d {

        /* renamed from: a  reason: collision with root package name */
        boolean f15289a = true;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ StringBuilder f15290b;

        a(StringBuilder sb2) {
            this.f15290b = sb2;
        }

        public void a(InputStream inputStream, int i10) throws IOException {
            if (this.f15289a) {
                this.f15289a = false;
            } else {
                this.f15290b.append(", ");
            }
            this.f15290b.append(i10);
        }
    }

    static class b {

        /* renamed from: c  reason: collision with root package name */
        static final b f15292c = new b(0, 0);

        /* renamed from: a  reason: collision with root package name */
        final int f15293a;

        /* renamed from: b  reason: collision with root package name */
        final int f15294b;

        b(int i10, int i11) {
            this.f15293a = i10;
            this.f15294b = i11;
        }

        public String toString() {
            return getClass().getSimpleName() + "[position = " + this.f15293a + ", length = " + this.f15294b + "]";
        }
    }

    private final class c extends InputStream {

        /* renamed from: a  reason: collision with root package name */
        private int f15295a;

        /* renamed from: b  reason: collision with root package name */
        private int f15296b;

        private c(b bVar) {
            this.f15295a = g.this.H(bVar.f15293a + 4);
            this.f15296b = bVar.f15294b;
        }

        /* synthetic */ c(g gVar, b bVar, a aVar) {
            this(bVar);
        }

        public int read() throws IOException {
            if (this.f15296b == 0) {
                return -1;
            }
            g.this.f15283a.seek((long) this.f15295a);
            int read = g.this.f15283a.read();
            this.f15295a = g.this.H(this.f15295a + 1);
            this.f15296b--;
            return read;
        }

        public int read(byte[] bArr, int i10, int i11) throws IOException {
            Object unused = g.n(bArr, "buffer");
            if ((i10 | i11) < 0 || i11 > bArr.length - i10) {
                throw new ArrayIndexOutOfBoundsException();
            }
            int i12 = this.f15296b;
            if (i12 <= 0) {
                return -1;
            }
            if (i11 > i12) {
                i11 = i12;
            }
            g.this.B(this.f15295a, bArr, i10, i11);
            this.f15295a = g.this.H(this.f15295a + i11);
            this.f15296b -= i11;
            return i11;
        }
    }

    public interface d {
        void a(InputStream inputStream, int i10) throws IOException;
    }

    public g(File file) throws IOException {
        if (!file.exists()) {
            k(file);
        }
        this.f15283a = o(file);
        s();
    }

    /* access modifiers changed from: private */
    public void B(int i10, byte[] bArr, int i11, int i12) throws IOException {
        RandomAccessFile randomAccessFile;
        int H = H(i10);
        int i13 = H + i12;
        int i14 = this.f15284b;
        if (i13 <= i14) {
            this.f15283a.seek((long) H);
            randomAccessFile = this.f15283a;
        } else {
            int i15 = i14 - H;
            this.f15283a.seek((long) H);
            this.f15283a.readFully(bArr, i11, i15);
            this.f15283a.seek(16);
            randomAccessFile = this.f15283a;
            i11 += i15;
            i12 -= i15;
        }
        randomAccessFile.readFully(bArr, i11, i12);
    }

    private void E(int i10, byte[] bArr, int i11, int i12) throws IOException {
        RandomAccessFile randomAccessFile;
        int H = H(i10);
        int i13 = H + i12;
        int i14 = this.f15284b;
        if (i13 <= i14) {
            this.f15283a.seek((long) H);
            randomAccessFile = this.f15283a;
        } else {
            int i15 = i14 - H;
            this.f15283a.seek((long) H);
            this.f15283a.write(bArr, i11, i15);
            this.f15283a.seek(16);
            randomAccessFile = this.f15283a;
            i11 += i15;
            i12 -= i15;
        }
        randomAccessFile.write(bArr, i11, i12);
    }

    private void F(int i10) throws IOException {
        this.f15283a.setLength((long) i10);
        this.f15283a.getChannel().force(true);
    }

    /* access modifiers changed from: private */
    public int H(int i10) {
        int i11 = this.f15284b;
        return i10 < i11 ? i10 : (i10 + 16) - i11;
    }

    private void K(int i10, int i11, int i12, int i13) throws IOException {
        P(this.f15288f, i10, i11, i12, i13);
        this.f15283a.seek(0);
        this.f15283a.write(this.f15288f);
    }

    private static void N(byte[] bArr, int i10, int i11) {
        bArr[i10] = (byte) (i11 >> 24);
        bArr[i10 + 1] = (byte) (i11 >> 16);
        bArr[i10 + 2] = (byte) (i11 >> 8);
        bArr[i10 + 3] = (byte) i11;
    }

    private static void P(byte[] bArr, int... iArr) {
        int i10 = 0;
        for (int N : iArr) {
            N(bArr, i10, N);
            i10 += 4;
        }
    }

    private void h(int i10) throws IOException {
        int i11 = i10 + 4;
        int z10 = z();
        if (z10 < i11) {
            int i12 = this.f15284b;
            do {
                z10 += i12;
                i12 <<= 1;
            } while (z10 < i11);
            F(i12);
            b bVar = this.f15287e;
            int H = H(bVar.f15293a + 4 + bVar.f15294b);
            if (H < this.f15286d.f15293a) {
                FileChannel channel = this.f15283a.getChannel();
                channel.position((long) this.f15284b);
                long j10 = (long) (H - 4);
                if (channel.transferTo(16, j10, channel) != j10) {
                    throw new AssertionError("Copied insufficient number of bytes!");
                }
            }
            int i13 = this.f15287e.f15293a;
            int i14 = this.f15286d.f15293a;
            if (i13 < i14) {
                int i15 = (this.f15284b + i13) - 16;
                K(i12, this.f15285c, i14, i15);
                this.f15287e = new b(i15, this.f15287e.f15294b);
            } else {
                K(i12, this.f15285c, i14, i13);
            }
            this.f15284b = i12;
        }
    }

    /* JADX INFO: finally extract failed */
    private static void k(File file) throws IOException {
        File file2 = new File(file.getPath() + ".tmp");
        RandomAccessFile o10 = o(file2);
        try {
            o10.setLength(4096);
            o10.seek(0);
            byte[] bArr = new byte[16];
            P(bArr, 4096, 0, 0, 0);
            o10.write(bArr);
            o10.close();
            if (!file2.renameTo(file)) {
                throw new IOException("Rename failed!");
            }
        } catch (Throwable th) {
            o10.close();
            throw th;
        }
    }

    /* access modifiers changed from: private */
    public static <T> T n(T t10, String str) {
        if (t10 != null) {
            return t10;
        }
        throw new NullPointerException(str);
    }

    private static RandomAccessFile o(File file) throws FileNotFoundException {
        return new RandomAccessFile(file, "rwd");
    }

    private b p(int i10) throws IOException {
        if (i10 == 0) {
            return b.f15292c;
        }
        this.f15283a.seek((long) i10);
        return new b(i10, this.f15283a.readInt());
    }

    private void s() throws IOException {
        this.f15283a.seek(0);
        this.f15283a.readFully(this.f15288f);
        int t10 = t(this.f15288f, 0);
        this.f15284b = t10;
        if (((long) t10) <= this.f15283a.length()) {
            this.f15285c = t(this.f15288f, 4);
            int t11 = t(this.f15288f, 8);
            int t12 = t(this.f15288f, 12);
            this.f15286d = p(t11);
            this.f15287e = p(t12);
            return;
        }
        throw new IOException("File is truncated. Expected length: " + this.f15284b + ", Actual length: " + this.f15283a.length());
    }

    private static int t(byte[] bArr, int i10) {
        return ((bArr[i10] & 255) << 24) + ((bArr[i10 + 1] & 255) << 16) + ((bArr[i10 + 2] & 255) << 8) + (bArr[i10 + 3] & 255);
    }

    private int z() {
        return this.f15284b - G();
    }

    public synchronized void A() throws IOException {
        if (m()) {
            throw new NoSuchElementException();
        } else if (this.f15285c == 1) {
            g();
        } else {
            b bVar = this.f15286d;
            int H = H(bVar.f15293a + 4 + bVar.f15294b);
            B(H, this.f15288f, 0, 4);
            int t10 = t(this.f15288f, 0);
            K(this.f15284b, this.f15285c - 1, H, this.f15287e.f15293a);
            this.f15285c--;
            this.f15286d = new b(H, t10);
        }
    }

    public int G() {
        if (this.f15285c == 0) {
            return 16;
        }
        b bVar = this.f15287e;
        int i10 = bVar.f15293a;
        int i11 = this.f15286d.f15293a;
        return i10 >= i11 ? (i10 - i11) + 4 + bVar.f15294b + 16 : (((i10 + 4) + bVar.f15294b) + this.f15284b) - i11;
    }

    public synchronized void close() throws IOException {
        this.f15283a.close();
    }

    public void e(byte[] bArr) throws IOException {
        f(bArr, 0, bArr.length);
    }

    public synchronized void f(byte[] bArr, int i10, int i11) throws IOException {
        int i12;
        n(bArr, "buffer");
        if ((i10 | i11) < 0 || i11 > bArr.length - i10) {
            throw new IndexOutOfBoundsException();
        }
        h(i11);
        boolean m10 = m();
        if (m10) {
            i12 = 16;
        } else {
            b bVar = this.f15287e;
            i12 = H(bVar.f15293a + 4 + bVar.f15294b);
        }
        b bVar2 = new b(i12, i11);
        N(this.f15288f, 0, i11);
        E(bVar2.f15293a, this.f15288f, 0, 4);
        E(bVar2.f15293a + 4, bArr, i10, i11);
        K(this.f15284b, this.f15285c + 1, m10 ? bVar2.f15293a : this.f15286d.f15293a, bVar2.f15293a);
        this.f15287e = bVar2;
        this.f15285c++;
        if (m10) {
            this.f15286d = bVar2;
        }
    }

    public synchronized void g() throws IOException {
        K(Utils.CONTINUOUS_EVENT, 0, 0, 0);
        this.f15285c = 0;
        b bVar = b.f15292c;
        this.f15286d = bVar;
        this.f15287e = bVar;
        if (this.f15284b > 4096) {
            F(Utils.CONTINUOUS_EVENT);
        }
        this.f15284b = Utils.CONTINUOUS_EVENT;
    }

    public synchronized void i(d dVar) throws IOException {
        int i10 = this.f15286d.f15293a;
        for (int i11 = 0; i11 < this.f15285c; i11++) {
            b p10 = p(i10);
            dVar.a(new c(this, p10, (a) null), p10.f15294b);
            i10 = H(p10.f15293a + 4 + p10.f15294b);
        }
    }

    public synchronized boolean m() {
        return this.f15285c == 0;
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(getClass().getSimpleName());
        sb2.append('[');
        sb2.append("fileLength=");
        sb2.append(this.f15284b);
        sb2.append(", size=");
        sb2.append(this.f15285c);
        sb2.append(", first=");
        sb2.append(this.f15286d);
        sb2.append(", last=");
        sb2.append(this.f15287e);
        sb2.append(", element lengths=[");
        try {
            i(new a(sb2));
        } catch (IOException e10) {
            f15282g.log(Level.WARNING, "read error", e10);
        }
        sb2.append("]]");
        return sb2.toString();
    }
}
