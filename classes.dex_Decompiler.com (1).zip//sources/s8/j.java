package s8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import p8.f;
import t8.f0;

public class j {

    /* renamed from: a  reason: collision with root package name */
    private final List<i> f15308a = new ArrayList();

    /* renamed from: b  reason: collision with root package name */
    private final int f15309b;

    public j(int i10) {
        this.f15309b = i10;
    }

    public List<f0.e.d.C0283e> a() {
        List<i> b10 = b();
        ArrayList arrayList = new ArrayList();
        for (int i10 = 0; i10 < b10.size(); i10++) {
            arrayList.add(b10.get(i10).h());
        }
        return arrayList;
    }

    public synchronized List<i> b() {
        return Collections.unmodifiableList(new ArrayList(this.f15308a));
    }

    public synchronized boolean c(List<i> list) {
        this.f15308a.clear();
        if (list.size() > this.f15309b) {
            f f10 = f.f();
            f10.k("Ignored " + 0 + " entries when adding rollout assignments. Maximum allowable: " + this.f15309b);
            return this.f15308a.addAll(list.subList(0, this.f15309b));
        }
        return this.f15308a.addAll(list);
    }
}
