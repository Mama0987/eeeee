package s8;

import java.util.concurrent.Callable;
import s8.m;

public final /* synthetic */ class l implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m.a f15311a;

    public /* synthetic */ l(m.a aVar) {
        this.f15311a = aVar;
    }

    public final Object call() {
        return this.f15311a.c();
    }
}
