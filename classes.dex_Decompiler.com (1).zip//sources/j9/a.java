package j9;

import androidx.annotation.NonNull;

public interface a {
    void a(@NonNull String str);
}
