package y;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.core.graphics.k;
import com.FF.voiceengine.FFVoiceConst;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import t.g;
import y.i;

class h {

    /* renamed from: a  reason: collision with root package name */
    static final t.e<String, Typeface> f17713a = new t.e<>(16);

    /* renamed from: b  reason: collision with root package name */
    private static final ExecutorService f17714b = j.a("fonts-androidx", 10, FFVoiceConst.FFVoice_RTC_SERVER_REGION.RTC_EXT_SERVER);

    /* renamed from: c  reason: collision with root package name */
    static final Object f17715c = new Object();

    /* renamed from: d  reason: collision with root package name */
    static final g<String, ArrayList<z.a<e>>> f17716d = new g<>();

    class a implements Callable<e> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ String f17717a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Context f17718b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ g f17719c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ int f17720d;

        a(String str, Context context, g gVar, int i10) {
            this.f17717a = str;
            this.f17718b = context;
            this.f17719c = gVar;
            this.f17720d = i10;
        }

        /* renamed from: a */
        public e call() {
            return h.c(this.f17717a, this.f17718b, this.f17719c, this.f17720d);
        }
    }

    class b implements z.a<e> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ a f17721a;

        b(a aVar) {
            this.f17721a = aVar;
        }

        /* renamed from: a */
        public void accept(e eVar) {
            if (eVar == null) {
                eVar = new e(-3);
            }
            this.f17721a.b(eVar);
        }
    }

    class c implements Callable<e> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ String f17722a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Context f17723b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ g f17724c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ int f17725d;

        c(String str, Context context, g gVar, int i10) {
            this.f17722a = str;
            this.f17723b = context;
            this.f17724c = gVar;
            this.f17725d = i10;
        }

        /* renamed from: a */
        public e call() {
            try {
                return h.c(this.f17722a, this.f17723b, this.f17724c, this.f17725d);
            } catch (Throwable unused) {
                return new e(-3);
            }
        }
    }

    class d implements z.a<e> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ String f17726a;

        d(String str) {
            this.f17726a = str;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x001c, code lost:
            if (r0 >= r2.size()) goto L_0x002a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x001e, code lost:
            ((z.a) r2.get(r0)).accept(r5);
            r0 = r0 + 1;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x002a, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0017, code lost:
            r0 = 0;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void accept(y.h.e r5) {
            /*
                r4 = this;
                java.lang.Object r0 = y.h.f17715c
                monitor-enter(r0)
                t.g<java.lang.String, java.util.ArrayList<z.a<y.h$e>>> r1 = y.h.f17716d     // Catch:{ all -> 0x002b }
                java.lang.String r2 = r4.f17726a     // Catch:{ all -> 0x002b }
                java.lang.Object r2 = r1.get(r2)     // Catch:{ all -> 0x002b }
                java.util.ArrayList r2 = (java.util.ArrayList) r2     // Catch:{ all -> 0x002b }
                if (r2 != 0) goto L_0x0011
                monitor-exit(r0)     // Catch:{ all -> 0x002b }
                return
            L_0x0011:
                java.lang.String r3 = r4.f17726a     // Catch:{ all -> 0x002b }
                r1.remove(r3)     // Catch:{ all -> 0x002b }
                monitor-exit(r0)     // Catch:{ all -> 0x002b }
                r0 = 0
            L_0x0018:
                int r1 = r2.size()
                if (r0 >= r1) goto L_0x002a
                java.lang.Object r1 = r2.get(r0)
                z.a r1 = (z.a) r1
                r1.accept(r5)
                int r0 = r0 + 1
                goto L_0x0018
            L_0x002a:
                return
            L_0x002b:
                r5 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x002b }
                throw r5
            */
            throw new UnsupportedOperationException("Method not decompiled: y.h.d.accept(y.h$e):void");
        }
    }

    static final class e {

        /* renamed from: a  reason: collision with root package name */
        final Typeface f17727a;

        /* renamed from: b  reason: collision with root package name */
        final int f17728b;

        e(int i10) {
            this.f17727a = null;
            this.f17728b = i10;
        }

        @SuppressLint({"WrongConstant"})
        e(@NonNull Typeface typeface) {
            this.f17727a = typeface;
            this.f17728b = 0;
        }

        /* access modifiers changed from: package-private */
        @SuppressLint({"WrongConstant"})
        public boolean a() {
            return this.f17728b == 0;
        }
    }

    private static String a(@NonNull g gVar, int i10) {
        return gVar.d() + "-" + i10;
    }

    @SuppressLint({"WrongConstant"})
    private static int b(@NonNull i.a aVar) {
        int i10 = 1;
        if (aVar.c() != 0) {
            return aVar.c() != 1 ? -3 : -2;
        }
        i.b[] b10 = aVar.b();
        if (!(b10 == null || b10.length == 0)) {
            int length = b10.length;
            i10 = 0;
            int i11 = 0;
            while (i11 < length) {
                int b11 = b10[i11].b();
                if (b11 == 0) {
                    i11++;
                } else if (b11 < 0) {
                    return -3;
                } else {
                    return b11;
                }
            }
        }
        return i10;
    }

    @NonNull
    static e c(@NonNull String str, @NonNull Context context, @NonNull g gVar, int i10) {
        t.e<String, Typeface> eVar = f17713a;
        Typeface c10 = eVar.c(str);
        if (c10 != null) {
            return new e(c10);
        }
        try {
            i.a e10 = e.e(context, gVar, (CancellationSignal) null);
            int b10 = b(e10);
            if (b10 != 0) {
                return new e(b10);
            }
            Typeface b11 = k.b(context, (CancellationSignal) null, e10.b(), i10);
            if (b11 == null) {
                return new e(-3);
            }
            eVar.d(str, b11);
            return new e(b11);
        } catch (PackageManager.NameNotFoundException unused) {
            return new e(-1);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x003b, code lost:
        r9 = new y.h.c(r0, r5, r6, r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0040, code lost:
        if (r8 != null) goto L_0x0044;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0042, code lost:
        r8 = f17714b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0044, code lost:
        y.j.b(r8, r9, new y.h.d(r0));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x004c, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static android.graphics.Typeface d(@androidx.annotation.NonNull android.content.Context r5, @androidx.annotation.NonNull y.g r6, int r7, java.util.concurrent.Executor r8, @androidx.annotation.NonNull y.a r9) {
        /*
            java.lang.String r0 = a(r6, r7)
            t.e<java.lang.String, android.graphics.Typeface> r1 = f17713a
            java.lang.Object r1 = r1.c(r0)
            android.graphics.Typeface r1 = (android.graphics.Typeface) r1
            if (r1 == 0) goto L_0x0017
            y.h$e r5 = new y.h$e
            r5.<init>((android.graphics.Typeface) r1)
            r9.b(r5)
            return r1
        L_0x0017:
            y.h$b r1 = new y.h$b
            r1.<init>(r9)
            java.lang.Object r9 = f17715c
            monitor-enter(r9)
            t.g<java.lang.String, java.util.ArrayList<z.a<y.h$e>>> r2 = f17716d     // Catch:{ all -> 0x004d }
            java.lang.Object r3 = r2.get(r0)     // Catch:{ all -> 0x004d }
            java.util.ArrayList r3 = (java.util.ArrayList) r3     // Catch:{ all -> 0x004d }
            r4 = 0
            if (r3 == 0) goto L_0x002f
            r3.add(r1)     // Catch:{ all -> 0x004d }
            monitor-exit(r9)     // Catch:{ all -> 0x004d }
            return r4
        L_0x002f:
            java.util.ArrayList r3 = new java.util.ArrayList     // Catch:{ all -> 0x004d }
            r3.<init>()     // Catch:{ all -> 0x004d }
            r3.add(r1)     // Catch:{ all -> 0x004d }
            r2.put(r0, r3)     // Catch:{ all -> 0x004d }
            monitor-exit(r9)     // Catch:{ all -> 0x004d }
            y.h$c r9 = new y.h$c
            r9.<init>(r0, r5, r6, r7)
            if (r8 != 0) goto L_0x0044
            java.util.concurrent.ExecutorService r8 = f17714b
        L_0x0044:
            y.h$d r5 = new y.h$d
            r5.<init>(r0)
            y.j.b(r8, r9, r5)
            return r4
        L_0x004d:
            r5 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x004d }
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: y.h.d(android.content.Context, y.g, int, java.util.concurrent.Executor, y.a):android.graphics.Typeface");
    }

    static Typeface e(@NonNull Context context, @NonNull g gVar, @NonNull a aVar, int i10, int i11) {
        String a10 = a(gVar, i10);
        Typeface c10 = f17713a.c(a10);
        if (c10 != null) {
            aVar.b(new e(c10));
            return c10;
        } else if (i11 == -1) {
            e c11 = c(a10, context, gVar, i10);
            aVar.b(c11);
            return c11.f17727a;
        } else {
            try {
                e eVar = (e) j.c(f17714b, new a(a10, context, gVar, i10), i11);
                aVar.b(eVar);
                return eVar.f17727a;
            } catch (InterruptedException unused) {
                aVar.b(new e(-3));
                return null;
            }
        }
    }
}
