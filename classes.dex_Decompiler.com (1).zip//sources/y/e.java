package y;

import android.content.ContentProviderClient;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.RemoteException;
import android.util.Log;
import androidx.annotation.NonNull;
import com.appff.haptic.base.Utils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import y.i;

class e {

    /* renamed from: a  reason: collision with root package name */
    private static final Comparator<byte[]> f17704a = new c();

    private interface a {
        Cursor a(Uri uri, String[] strArr, String str, String[] strArr2, String str2, CancellationSignal cancellationSignal);

        void close();
    }

    private static class b implements a {

        /* renamed from: a  reason: collision with root package name */
        private final ContentProviderClient f17705a;

        b(Context context, Uri uri) {
            this.f17705a = context.getContentResolver().acquireUnstableContentProviderClient(uri);
        }

        public Cursor a(Uri uri, String[] strArr, String str, String[] strArr2, String str2, CancellationSignal cancellationSignal) {
            ContentProviderClient contentProviderClient = this.f17705a;
            if (contentProviderClient == null) {
                return null;
            }
            try {
                return contentProviderClient.query(uri, strArr, str, strArr2, str2, cancellationSignal);
            } catch (RemoteException e10) {
                Log.w("FontsProvider", "Unable to query the content provider", e10);
                return null;
            }
        }

        public void close() {
            ContentProviderClient contentProviderClient = this.f17705a;
            if (contentProviderClient != null) {
                contentProviderClient.release();
            }
        }
    }

    private static class c implements a {

        /* renamed from: a  reason: collision with root package name */
        private final ContentProviderClient f17706a;

        c(Context context, Uri uri) {
            this.f17706a = context.getContentResolver().acquireUnstableContentProviderClient(uri);
        }

        public Cursor a(Uri uri, String[] strArr, String str, String[] strArr2, String str2, CancellationSignal cancellationSignal) {
            ContentProviderClient contentProviderClient = this.f17706a;
            if (contentProviderClient == null) {
                return null;
            }
            try {
                return contentProviderClient.query(uri, strArr, str, strArr2, str2, cancellationSignal);
            } catch (RemoteException e10) {
                Log.w("FontsProvider", "Unable to query the content provider", e10);
                return null;
            }
        }

        public void close() {
            ContentProviderClient contentProviderClient = this.f17706a;
            if (contentProviderClient != null) {
                contentProviderClient.close();
            }
        }
    }

    private static List<byte[]> b(Signature[] signatureArr) {
        ArrayList arrayList = new ArrayList();
        for (Signature byteArray : signatureArr) {
            arrayList.add(byteArray.toByteArray());
        }
        return arrayList;
    }

    private static boolean c(List<byte[]> list, List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i10 = 0; i10 < list.size(); i10++) {
            if (!Arrays.equals(list.get(i10), list2.get(i10))) {
                return false;
            }
        }
        return true;
    }

    private static List<List<byte[]>> d(g gVar, Resources resources) {
        return gVar.b() != null ? gVar.b() : androidx.core.content.res.e.c(resources, gVar.c());
    }

    @NonNull
    static i.a e(@NonNull Context context, @NonNull g gVar, CancellationSignal cancellationSignal) throws PackageManager.NameNotFoundException {
        ProviderInfo f10 = f(context.getPackageManager(), gVar, context.getResources());
        return f10 == null ? i.a.a(1, (i.b[]) null) : i.a.a(0, h(context, gVar, f10.authority, cancellationSignal));
    }

    static ProviderInfo f(@NonNull PackageManager packageManager, @NonNull g gVar, Resources resources) throws PackageManager.NameNotFoundException {
        String e10 = gVar.e();
        ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(e10, 0);
        if (resolveContentProvider == null) {
            throw new PackageManager.NameNotFoundException("No package found for authority: " + e10);
        } else if (resolveContentProvider.packageName.equals(gVar.f())) {
            List<byte[]> b10 = b(packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures);
            Collections.sort(b10, f17704a);
            List<List<byte[]>> d10 = d(gVar, resources);
            for (int i10 = 0; i10 < d10.size(); i10++) {
                ArrayList arrayList = new ArrayList(d10.get(i10));
                Collections.sort(arrayList, f17704a);
                if (c(b10, arrayList)) {
                    return resolveContentProvider;
                }
            }
            return null;
        } else {
            throw new PackageManager.NameNotFoundException("Found content provider " + e10 + ", but package was not " + gVar.f());
        }
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ int g(byte[] bArr, byte[] bArr2) {
        if (bArr.length != bArr2.length) {
            return bArr.length - bArr2.length;
        }
        for (int i10 = 0; i10 < bArr.length; i10++) {
            byte b10 = bArr[i10];
            byte b11 = bArr2[i10];
            if (b10 != b11) {
                return b10 - b11;
            }
        }
        return 0;
    }

    /* JADX INFO: finally extract failed */
    @NonNull
    static i.b[] h(Context context, g gVar, String str, CancellationSignal cancellationSignal) {
        int i10;
        String str2 = str;
        ArrayList arrayList = new ArrayList();
        Uri build = new Uri.Builder().scheme("content").authority(str2).build();
        Uri build2 = new Uri.Builder().scheme("content").authority(str2).appendPath("file").build();
        a a10 = d.a(context, build);
        Cursor cursor = null;
        try {
            boolean z10 = true;
            Cursor a11 = a10.a(build, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{gVar.g()}, (String) null, cancellationSignal);
            if (a11 != null && a11.getCount() > 0) {
                int columnIndex = a11.getColumnIndex("result_code");
                ArrayList arrayList2 = new ArrayList();
                int columnIndex2 = a11.getColumnIndex("_id");
                int columnIndex3 = a11.getColumnIndex("file_id");
                int columnIndex4 = a11.getColumnIndex("font_ttc_index");
                int columnIndex5 = a11.getColumnIndex("font_weight");
                int columnIndex6 = a11.getColumnIndex("font_italic");
                while (a11.moveToNext()) {
                    int i11 = columnIndex != -1 ? a11.getInt(columnIndex) : 0;
                    int i12 = columnIndex4 != -1 ? a11.getInt(columnIndex4) : 0;
                    int i13 = i11;
                    Uri withAppendedId = columnIndex3 == -1 ? ContentUris.withAppendedId(build, a11.getLong(columnIndex2)) : ContentUris.withAppendedId(build2, a11.getLong(columnIndex3));
                    int i14 = columnIndex5 != -1 ? a11.getInt(columnIndex5) : Utils.HE_DEFAULT_RELATIVE_TIME;
                    if (columnIndex6 == -1 || a11.getInt(columnIndex6) != z10) {
                        i10 = i13;
                        z10 = false;
                    } else {
                        i10 = i13;
                    }
                    arrayList2.add(i.b.a(withAppendedId, i12, i14, z10, i10));
                    z10 = true;
                }
                arrayList = arrayList2;
            }
            if (a11 != null) {
                a11.close();
            }
            a10.close();
            return (i.b[]) arrayList.toArray(new i.b[0]);
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
            a10.close();
            throw th;
        }
    }
}
