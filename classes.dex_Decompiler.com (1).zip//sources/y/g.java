package y;

import android.util.Base64;
import androidx.annotation.NonNull;
import java.util.List;
import z.d;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    private final String f17707a;

    /* renamed from: b  reason: collision with root package name */
    private final String f17708b;

    /* renamed from: c  reason: collision with root package name */
    private final String f17709c;

    /* renamed from: d  reason: collision with root package name */
    private final List<List<byte[]>> f17710d;

    /* renamed from: e  reason: collision with root package name */
    private final int f17711e = 0;

    /* renamed from: f  reason: collision with root package name */
    private final String f17712f;

    public g(@NonNull String str, @NonNull String str2, @NonNull String str3, @NonNull List<List<byte[]>> list) {
        this.f17707a = (String) d.f(str);
        this.f17708b = (String) d.f(str2);
        this.f17709c = (String) d.f(str3);
        this.f17710d = (List) d.f(list);
        this.f17712f = a(str, str2, str3);
    }

    private String a(@NonNull String str, @NonNull String str2, @NonNull String str3) {
        return str + "-" + str2 + "-" + str3;
    }

    public List<List<byte[]>> b() {
        return this.f17710d;
    }

    public int c() {
        return this.f17711e;
    }

    /* access modifiers changed from: package-private */
    @NonNull
    public String d() {
        return this.f17712f;
    }

    @NonNull
    public String e() {
        return this.f17707a;
    }

    @NonNull
    public String f() {
        return this.f17708b;
    }

    @NonNull
    public String g() {
        return this.f17709c;
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append("FontRequest {mProviderAuthority: " + this.f17707a + ", mProviderPackage: " + this.f17708b + ", mQuery: " + this.f17709c + ", mCertificates:");
        for (int i10 = 0; i10 < this.f17710d.size(); i10++) {
            sb2.append(" [");
            List list = this.f17710d.get(i10);
            for (int i11 = 0; i11 < list.size(); i11++) {
                sb2.append(" \"");
                sb2.append(Base64.encodeToString((byte[]) list.get(i11), 0));
                sb2.append("\"");
            }
            sb2.append(" ]");
        }
        sb2.append("}");
        sb2.append("mCertificatesArray: " + this.f17711e);
        return sb2.toString();
    }
}
