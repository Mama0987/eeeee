package y;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.core.graphics.k;
import java.util.concurrent.Executor;
import z.d;

public class i {

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        private final int f17729a;

        /* renamed from: b  reason: collision with root package name */
        private final b[] f17730b;

        @Deprecated
        public a(int i10, b[] bVarArr) {
            this.f17729a = i10;
            this.f17730b = bVarArr;
        }

        static a a(int i10, b[] bVarArr) {
            return new a(i10, bVarArr);
        }

        public b[] b() {
            return this.f17730b;
        }

        public int c() {
            return this.f17729a;
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        private final Uri f17731a;

        /* renamed from: b  reason: collision with root package name */
        private final int f17732b;

        /* renamed from: c  reason: collision with root package name */
        private final int f17733c;

        /* renamed from: d  reason: collision with root package name */
        private final boolean f17734d;

        /* renamed from: e  reason: collision with root package name */
        private final int f17735e;

        @Deprecated
        public b(@NonNull Uri uri, int i10, int i11, boolean z10, int i12) {
            this.f17731a = (Uri) d.f(uri);
            this.f17732b = i10;
            this.f17733c = i11;
            this.f17734d = z10;
            this.f17735e = i12;
        }

        static b a(@NonNull Uri uri, int i10, int i11, boolean z10, int i12) {
            return new b(uri, i10, i11, z10, i12);
        }

        public int b() {
            return this.f17735e;
        }

        public int c() {
            return this.f17732b;
        }

        @NonNull
        public Uri d() {
            return this.f17731a;
        }

        public int e() {
            return this.f17733c;
        }

        public boolean f() {
            return this.f17734d;
        }
    }

    public static class c {
        public void a(int i10) {
            throw null;
        }

        public void b(Typeface typeface) {
            throw null;
        }
    }

    public static Typeface a(@NonNull Context context, CancellationSignal cancellationSignal, @NonNull b[] bVarArr) {
        return k.b(context, cancellationSignal, bVarArr, 0);
    }

    @NonNull
    public static a b(@NonNull Context context, CancellationSignal cancellationSignal, @NonNull g gVar) throws PackageManager.NameNotFoundException {
        return e.e(context, gVar, cancellationSignal);
    }

    public static Typeface c(@NonNull Context context, @NonNull g gVar, int i10, boolean z10, int i11, @NonNull Handler handler, @NonNull c cVar) {
        a aVar = new a(cVar, handler);
        return z10 ? h.e(context, gVar, aVar, i10, i11) : h.d(context, gVar, i10, (Executor) null, aVar);
    }
}
