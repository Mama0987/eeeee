package y;

import android.graphics.Typeface;
import android.os.Handler;
import androidx.annotation.NonNull;
import y.h;
import y.i;

class a {
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final i.c f17696a;
    @NonNull

    /* renamed from: b  reason: collision with root package name */
    private final Handler f17697b;

    /* renamed from: y.a$a  reason: collision with other inner class name */
    class C0323a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ i.c f17698a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Typeface f17699b;

        C0323a(i.c cVar, Typeface typeface) {
            this.f17698a = cVar;
            this.f17699b = typeface;
        }

        public void run() {
            this.f17698a.b(this.f17699b);
        }
    }

    class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ i.c f17701a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f17702b;

        b(i.c cVar, int i10) {
            this.f17701a = cVar;
            this.f17702b = i10;
        }

        public void run() {
            this.f17701a.a(this.f17702b);
        }
    }

    a(@NonNull i.c cVar, @NonNull Handler handler) {
        this.f17696a = cVar;
        this.f17697b = handler;
    }

    private void a(int i10) {
        this.f17697b.post(new b(this.f17696a, i10));
    }

    private void c(@NonNull Typeface typeface) {
        this.f17697b.post(new C0323a(this.f17696a, typeface));
    }

    /* access modifiers changed from: package-private */
    public void b(@NonNull h.e eVar) {
        if (eVar.a()) {
            c(eVar.f17727a);
        } else {
            a(eVar.f17728b);
        }
    }
}
