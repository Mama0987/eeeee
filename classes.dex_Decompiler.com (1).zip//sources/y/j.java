package y;

import android.os.Handler;
import android.os.Process;
import androidx.annotation.NonNull;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

class j {

    private static class a implements ThreadFactory {

        /* renamed from: a  reason: collision with root package name */
        private String f17736a;

        /* renamed from: b  reason: collision with root package name */
        private int f17737b;

        /* renamed from: y.j$a$a  reason: collision with other inner class name */
        private static class C0324a extends Thread {

            /* renamed from: a  reason: collision with root package name */
            private final int f17738a;

            C0324a(Runnable runnable, String str, int i10) {
                super(runnable, str);
                this.f17738a = i10;
            }

            public void run() {
                Process.setThreadPriority(this.f17738a);
                super.run();
            }
        }

        a(@NonNull String str, int i10) {
            this.f17736a = str;
            this.f17737b = i10;
        }

        public Thread newThread(Runnable runnable) {
            return new C0324a(runnable, this.f17736a, this.f17737b);
        }
    }

    private static class b<T> implements Runnable {
        @NonNull

        /* renamed from: a  reason: collision with root package name */
        private Callable<T> f17739a;
        @NonNull

        /* renamed from: b  reason: collision with root package name */
        private z.a<T> f17740b;
        @NonNull

        /* renamed from: c  reason: collision with root package name */
        private Handler f17741c;

        class a implements Runnable {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ z.a f17742a;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ Object f17743b;

            a(z.a aVar, Object obj) {
                this.f17742a = aVar;
                this.f17743b = obj;
            }

            public void run() {
                this.f17742a.accept(this.f17743b);
            }
        }

        b(@NonNull Handler handler, @NonNull Callable<T> callable, @NonNull z.a<T> aVar) {
            this.f17739a = callable;
            this.f17740b = aVar;
            this.f17741c = handler;
        }

        public void run() {
            T t10;
            try {
                t10 = this.f17739a.call();
            } catch (Exception unused) {
                t10 = null;
            }
            this.f17741c.post(new a(this.f17740b, t10));
        }
    }

    static ThreadPoolExecutor a(@NonNull String str, int i10, int i11) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, (long) i11, TimeUnit.MILLISECONDS, new LinkedBlockingDeque(), new a(str, i10));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    static <T> void b(@NonNull Executor executor, @NonNull Callable<T> callable, @NonNull z.a<T> aVar) {
        executor.execute(new b(b.a(), callable, aVar));
    }

    static <T> T c(@NonNull ExecutorService executorService, @NonNull Callable<T> callable, int i10) throws InterruptedException {
        try {
            return executorService.submit(callable).get((long) i10, TimeUnit.MILLISECONDS);
        } catch (ExecutionException e10) {
            throw new RuntimeException(e10);
        } catch (InterruptedException e11) {
            throw e11;
        } catch (TimeoutException unused) {
            throw new InterruptedException("timeout");
        }
    }
}
