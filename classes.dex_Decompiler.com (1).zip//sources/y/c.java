package y;

import java.util.Comparator;

public final /* synthetic */ class c implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return e.g((byte[]) obj, (byte[]) obj2);
    }
}
