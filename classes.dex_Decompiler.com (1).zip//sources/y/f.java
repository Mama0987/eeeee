package y;

public final /* synthetic */ class f {
}
