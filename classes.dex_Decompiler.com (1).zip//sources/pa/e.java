package pa;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public static final int f13974a = 2131755341;
}
