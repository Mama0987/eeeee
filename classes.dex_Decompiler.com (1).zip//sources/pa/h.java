package pa;

import java.util.HashMap;
import java.util.Random;

public class h {

    /* renamed from: b  reason: collision with root package name */
    private static final HashMap<Long, h> f13976b = new HashMap<>();

    /* renamed from: a  reason: collision with root package name */
    private long f13977a = 0;

    public static h a(long j10) {
        return f13976b.get(Long.valueOf(j10));
    }

    public long j() {
        if (f13976b.containsKey(Long.valueOf(this.f13977a))) {
            return this.f13977a;
        }
        Random random = new Random();
        while (true) {
            long nextLong = random.nextLong();
            HashMap<Long, h> hashMap = f13976b;
            if (!hashMap.containsKey(Long.valueOf(nextLong)) && nextLong != 0) {
                hashMap.put(Long.valueOf(nextLong), this);
                this.f13977a = nextLong;
                return nextLong;
            }
        }
    }

    public void k() {
        f13976b.remove(Long.valueOf(this.f13977a));
        this.f13977a = 0;
    }
}
