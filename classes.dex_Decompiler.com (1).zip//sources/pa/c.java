package pa;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public static final int f13971a = 2131492946;

    /* renamed from: b  reason: collision with root package name */
    public static final int f13972b = 2131492947;
}
