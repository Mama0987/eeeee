package pa;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final int f13966a = 2131296346;

    /* renamed from: b  reason: collision with root package name */
    public static final int f13967b = 2131296372;

    /* renamed from: c  reason: collision with root package name */
    public static final int f13968c = 2131296409;

    /* renamed from: d  reason: collision with root package name */
    public static final int f13969d = 2131296455;

    /* renamed from: e  reason: collision with root package name */
    public static final int f13970e = 2131296459;
}
