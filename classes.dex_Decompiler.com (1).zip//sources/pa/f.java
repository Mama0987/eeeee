package pa;

import com.vk.sdk.a;

public abstract class f {

    /* renamed from: a  reason: collision with root package name */
    private boolean f13975a = false;

    public abstract void a(a aVar, a aVar2);
}
