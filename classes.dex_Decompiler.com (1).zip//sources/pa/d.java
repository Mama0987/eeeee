package pa;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static final int f13973a = 2131689669;
}
