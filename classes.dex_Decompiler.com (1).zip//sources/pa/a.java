package pa;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final int f13965a = 2131165353;
}
