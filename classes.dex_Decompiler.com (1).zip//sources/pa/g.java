package pa;

import qa.c;

public interface g<RESULT> {
    void a(c cVar);

    void onResult(RESULT result);
}
