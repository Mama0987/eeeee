package d5;

import android.content.Intent;
import q4.e;
import v3.o;

public final /* synthetic */ class l implements e.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f10282a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ o f10283b;

    public /* synthetic */ l(int i10, o oVar) {
        this.f10282a = i10;
        this.f10283b = oVar;
    }

    public final boolean a(int i10, Intent intent) {
        return m.x(this.f10282a, this.f10283b, i10, intent);
    }
}
