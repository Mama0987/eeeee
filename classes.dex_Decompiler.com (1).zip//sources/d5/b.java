package d5;

import eb.r;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Metadata
public final class b {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final b f10247a = new b();
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final HashMap<Class<?>, d> f10248b = i0.k(r.a(String.class, new a()), r.a(String[].class, new C0130b()), r.a(JSONArray.class, new c()));

    @Metadata
    public static final class a implements d {
        a() {
        }

        public void a(@NotNull JSONObject jSONObject, @NotNull String str, Object obj) throws JSONException {
            Intrinsics.checkNotNullParameter(jSONObject, "json");
            Intrinsics.checkNotNullParameter(str, "key");
            jSONObject.put(str, obj);
        }
    }

    @Metadata
    /* renamed from: d5.b$b  reason: collision with other inner class name */
    public static final class C0130b implements d {
        C0130b() {
        }

        public void a(@NotNull JSONObject jSONObject, @NotNull String str, Object obj) throws JSONException {
            Intrinsics.checkNotNullParameter(jSONObject, "json");
            Intrinsics.checkNotNullParameter(str, "key");
            JSONArray jSONArray = new JSONArray();
            if (obj != null) {
                String[] strArr = (String[]) obj;
                int length = strArr.length;
                int i10 = 0;
                while (i10 < length) {
                    String str2 = strArr[i10];
                    i10++;
                    jSONArray.put(str2);
                }
                jSONObject.put(str, jSONArray);
                return;
            }
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<kotlin.String?>");
        }
    }

    @Metadata
    public static final class c implements d {
        c() {
        }

        public void a(@NotNull JSONObject jSONObject, @NotNull String str, Object obj) throws JSONException {
            Intrinsics.checkNotNullParameter(jSONObject, "json");
            Intrinsics.checkNotNullParameter(str, "key");
            throw new IllegalArgumentException("JSONArray's are not supported in bundles.");
        }
    }

    @Metadata
    private interface d {
        void a(@NotNull JSONObject jSONObject, @NotNull String str, Object obj) throws JSONException;
    }

    private b() {
    }

    public static final JSONObject a(e5.a aVar) throws JSONException {
        if (aVar == null) {
            return null;
        }
        JSONObject jSONObject = new JSONObject();
        for (String next : aVar.k()) {
            Object j10 = aVar.j(next);
            if (j10 != null) {
                d dVar = f10248b.get(j10.getClass());
                if (dVar != null) {
                    dVar.a(jSONObject, next, j10);
                } else {
                    throw new IllegalArgumentException(Intrinsics.k("Unsupported type: ", j10.getClass()));
                }
            }
        }
        return jSONObject;
    }
}
