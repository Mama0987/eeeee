package d5;

import android.os.Parcel;
import android.os.Parcelable;
import e5.e;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class j extends e<j, Object> {
    @NotNull
    public static final Parcelable.Creator<j> CREATOR = new a();
    @NotNull

    /* renamed from: n  reason: collision with root package name */
    public static final b f10273n = new b((DefaultConstructorMarker) null);

    /* renamed from: g  reason: collision with root package name */
    private final String f10274g;

    /* renamed from: h  reason: collision with root package name */
    private final String f10275h;

    /* renamed from: i  reason: collision with root package name */
    private final String f10276i;

    /* renamed from: j  reason: collision with root package name */
    private final String f10277j;

    /* renamed from: k  reason: collision with root package name */
    private final String f10278k;

    /* renamed from: l  reason: collision with root package name */
    private final String f10279l;

    /* renamed from: m  reason: collision with root package name */
    private final String f10280m;

    @Metadata
    public static final class a implements Parcelable.Creator<j> {
        a() {
        }

        @NotNull
        /* renamed from: a */
        public j createFromParcel(@NotNull Parcel parcel) {
            Intrinsics.checkNotNullParameter(parcel, "parcel");
            return new j(parcel);
        }

        @NotNull
        /* renamed from: b */
        public j[] newArray(int i10) {
            return new j[i10];
        }
    }

    @Metadata
    public static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(@NotNull Parcel parcel) {
        super(parcel);
        Intrinsics.checkNotNullParameter(parcel, "parcel");
        this.f10274g = parcel.readString();
        this.f10275h = parcel.readString();
        this.f10276i = parcel.readString();
        this.f10277j = parcel.readString();
        this.f10278k = parcel.readString();
        this.f10279l = parcel.readString();
        this.f10280m = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public final String s() {
        return this.f10275h;
    }

    public final String u() {
        return this.f10277j;
    }

    public final String v() {
        return this.f10278k;
    }

    public final String w() {
        return this.f10276i;
    }

    public void writeToParcel(@NotNull Parcel parcel, int i10) {
        Intrinsics.checkNotNullParameter(parcel, "out");
        super.writeToParcel(parcel, i10);
        parcel.writeString(this.f10274g);
        parcel.writeString(this.f10275h);
        parcel.writeString(this.f10276i);
        parcel.writeString(this.f10277j);
        parcel.writeString(this.f10278k);
        parcel.writeString(this.f10279l);
        parcel.writeString(this.f10280m);
    }

    public final String x() {
        return this.f10280m;
    }

    public final String y() {
        return this.f10279l;
    }

    public final String z() {
        return this.f10274g;
    }
}
