package d5;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import q4.h;

@Metadata
public enum i implements h {
    SHARE_DIALOG(20130618),
    PHOTOS(20140204),
    VIDEO(20141028),
    MULTIMEDIA(20160327),
    HASHTAG(20160327),
    LINK_SHARE_QUOTES(20160327);
    

    /* renamed from: a  reason: collision with root package name */
    private final int f10272a;

    private i(int i10) {
        this.f10272a = i10;
    }

    public int a() {
        return this.f10272a;
    }

    @NotNull
    public String g() {
        return "com.facebook.platform.action.request.FEED_DIALOG";
    }
}
