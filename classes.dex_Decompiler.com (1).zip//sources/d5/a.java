package d5;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import q4.h;

@Metadata
public enum a implements h {
    SHARE_CAMERA_EFFECT(20170417);
    

    /* renamed from: a  reason: collision with root package name */
    private final int f10246a;

    private a(int i10) {
        this.f10246a = i10;
    }

    public int a() {
        return this.f10246a;
    }

    @NotNull
    public String g() {
        return "com.facebook.platform.action.request.CAMERA_EFFECT";
    }
}
