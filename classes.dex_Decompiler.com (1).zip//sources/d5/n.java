package d5;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import q4.h;

@Metadata
public enum n implements h {
    SHARE_STORY_ASSET(20170417);
    

    /* renamed from: a  reason: collision with root package name */
    private final int f10288a;

    private n(int i10) {
        this.f10288a = i10;
    }

    public int a() {
        return this.f10288a;
    }

    @NotNull
    public String g() {
        return "com.facebook.platform.action.request.SHARE_STORY";
    }
}
