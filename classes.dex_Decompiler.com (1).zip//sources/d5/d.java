package d5;

import android.os.Bundle;
import e5.e;
import e5.g;
import e5.k;
import e5.n;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import q4.t0;

@Metadata
public final class d {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final d f10249a = new d();

    private d() {
    }

    private final Bundle a(g gVar, boolean z10) {
        return d(gVar, z10);
    }

    private final Bundle b(k kVar, List<String> list, boolean z10) {
        Bundle d10 = d(kVar, z10);
        d10.putStringArrayList("com.facebook.platform.extra.PHOTOS", new ArrayList(list));
        return d10;
    }

    public static final Bundle c(@NotNull UUID uuid, @NotNull e<?, ?> eVar, boolean z10) {
        Intrinsics.checkNotNullParameter(uuid, "callId");
        Intrinsics.checkNotNullParameter(eVar, "shareContent");
        if (eVar instanceof g) {
            return f10249a.a((g) eVar, z10);
        }
        if (eVar instanceof k) {
            m mVar = m.f10284a;
            k kVar = (k) eVar;
            List<String> i10 = m.i(kVar, uuid);
            if (i10 == null) {
                i10 = q.h();
            }
            return f10249a.b(kVar, i10, z10);
        }
        boolean z11 = eVar instanceof n;
        return null;
    }

    private final Bundle d(e<?, ?> eVar, boolean z10) {
        Bundle bundle = new Bundle();
        t0 t0Var = t0.f14237a;
        t0.t0(bundle, "com.facebook.platform.extra.LINK", eVar.a());
        t0.s0(bundle, "com.facebook.platform.extra.PLACE", eVar.l());
        t0.s0(bundle, "com.facebook.platform.extra.REF", eVar.m());
        bundle.putBoolean("com.facebook.platform.extra.DATA_FAILURES_FATAL", z10);
        Collection k10 = eVar.k();
        if (!(k10 == null || k10.isEmpty())) {
            bundle.putStringArrayList("com.facebook.platform.extra.FRIENDS", new ArrayList(k10));
        }
        return bundle;
    }
}
