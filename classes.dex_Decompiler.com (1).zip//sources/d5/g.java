package d5;

import android.os.Bundle;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import q4.a;
import v3.o;
import v3.r;

@Metadata
public abstract class g {

    /* renamed from: a  reason: collision with root package name */
    private final o<?> f10259a;

    public g(o<?> oVar) {
        this.f10259a = oVar;
    }

    public void a(@NotNull a aVar) {
        Intrinsics.checkNotNullParameter(aVar, "appCall");
        o<?> oVar = this.f10259a;
        if (oVar != null) {
            oVar.onCancel();
        }
    }

    public void b(@NotNull a aVar, @NotNull r rVar) {
        Intrinsics.checkNotNullParameter(aVar, "appCall");
        Intrinsics.checkNotNullParameter(rVar, "error");
        o<?> oVar = this.f10259a;
        if (oVar != null) {
            oVar.a(rVar);
        }
    }

    public abstract void c(@NotNull a aVar, Bundle bundle);
}
