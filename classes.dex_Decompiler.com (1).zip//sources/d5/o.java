package d5;

import android.annotation.SuppressLint;
import android.os.Bundle;
import e5.c;
import e5.e;
import e5.f;
import e5.g;
import e5.j;
import e5.k;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import q4.t0;

@Metadata
public final class o {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final o f10289a = new o();

    private o() {
    }

    @NotNull
    public static final Bundle a(@NotNull c cVar) {
        String str;
        String obj;
        String obj2;
        Intrinsics.checkNotNullParameter(cVar, "gameRequestContent");
        Bundle bundle = new Bundle();
        t0 t0Var = t0.f14237a;
        t0.s0(bundle, "message", cVar.m());
        t0.q0(bundle, "to", cVar.r());
        t0.s0(bundle, "title", cVar.getTitle());
        t0.s0(bundle, "data", cVar.k());
        c.a a10 = cVar.a();
        String str2 = null;
        if (a10 == null || (obj2 = a10.toString()) == null) {
            str = null;
        } else {
            Locale locale = Locale.ENGLISH;
            Intrinsics.checkNotNullExpressionValue(locale, "ENGLISH");
            str = obj2.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue(str, "(this as java.lang.String).toLowerCase(locale)");
        }
        t0.s0(bundle, "action_type", str);
        t0.s0(bundle, "object_id", cVar.q());
        c.e l10 = cVar.l();
        if (!(l10 == null || (obj = l10.toString()) == null)) {
            Locale locale2 = Locale.ENGLISH;
            Intrinsics.checkNotNullExpressionValue(locale2, "ENGLISH");
            str2 = obj.toLowerCase(locale2);
            Intrinsics.checkNotNullExpressionValue(str2, "(this as java.lang.String).toLowerCase(locale)");
        }
        t0.s0(bundle, "filters", str2);
        t0.q0(bundle, "suggestions", cVar.s());
        return bundle;
    }

    @NotNull
    public static final Bundle b(@NotNull g gVar) {
        Intrinsics.checkNotNullParameter(gVar, "shareLinkContent");
        Bundle d10 = d(gVar);
        t0 t0Var = t0.f14237a;
        t0.t0(d10, "href", gVar.a());
        t0.s0(d10, "quote", gVar.s());
        return d10;
    }

    @NotNull
    public static final Bundle c(@NotNull k kVar) {
        Intrinsics.checkNotNullParameter(kVar, "sharePhotoContent");
        Bundle d10 = d(kVar);
        List<j> s10 = kVar.s();
        if (s10 == null) {
            s10 = q.h();
        }
        Iterable<j> iterable = s10;
        ArrayList arrayList = new ArrayList(r.p(iterable, 10));
        for (j m10 : iterable) {
            arrayList.add(String.valueOf(m10.m()));
        }
        Object[] array = arrayList.toArray(new String[0]);
        if (array != null) {
            d10.putStringArray("media", (String[]) array);
            return d10;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    @NotNull
    public static final Bundle d(@NotNull e<?, ?> eVar) {
        Intrinsics.checkNotNullParameter(eVar, "shareContent");
        Bundle bundle = new Bundle();
        t0 t0Var = t0.f14237a;
        f q10 = eVar.q();
        t0.s0(bundle, "hashtag", q10 == null ? null : q10.a());
        return bundle;
    }

    @NotNull
    public static final Bundle e(@NotNull j jVar) {
        Intrinsics.checkNotNullParameter(jVar, "shareFeedContent");
        Bundle bundle = new Bundle();
        t0 t0Var = t0.f14237a;
        t0.s0(bundle, "to", jVar.z());
        t0.s0(bundle, "link", jVar.s());
        t0.s0(bundle, "picture", jVar.y());
        t0.s0(bundle, "source", jVar.x());
        t0.s0(bundle, "name", jVar.w());
        t0.s0(bundle, "caption", jVar.u());
        t0.s0(bundle, "description", jVar.v());
        return bundle;
    }

    @NotNull
    @SuppressLint({"DeprecatedMethod"})
    public static final Bundle f(@NotNull g gVar) {
        Intrinsics.checkNotNullParameter(gVar, "shareLinkContent");
        Bundle bundle = new Bundle();
        t0 t0Var = t0.f14237a;
        t0.s0(bundle, "link", t0.P(gVar.a()));
        t0.s0(bundle, "quote", gVar.s());
        f q10 = gVar.q();
        t0.s0(bundle, "hashtag", q10 == null ? null : q10.a());
        return bundle;
    }
}
