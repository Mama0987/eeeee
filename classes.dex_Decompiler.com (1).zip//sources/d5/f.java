package d5;

import android.os.Bundle;
import e5.d;
import e5.e;
import e5.g;
import e5.i;
import e5.k;
import e5.l;
import e5.n;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;
import q4.t0;
import v3.r;

@Metadata
public final class f {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final f f10258a = new f();

    private f() {
    }

    private final Bundle a(d dVar, Bundle bundle, boolean z10) {
        Bundle h10 = h(dVar, z10);
        t0 t0Var = t0.f14237a;
        t0.s0(h10, "effect_id", dVar.u());
        if (bundle != null) {
            h10.putBundle("effect_textures", bundle);
        }
        try {
            b bVar = b.f10247a;
            JSONObject a10 = b.a(dVar.s());
            if (a10 != null) {
                t0.s0(h10, "effect_arguments", a10.toString());
            }
            return h10;
        } catch (JSONException e10) {
            throw new r(Intrinsics.k("Unable to create a JSON Object from the provided CameraEffectArguments: ", e10.getMessage()));
        }
    }

    private final Bundle b(g gVar, boolean z10) {
        Bundle h10 = h(gVar, z10);
        t0 t0Var = t0.f14237a;
        t0.s0(h10, "QUOTE", gVar.s());
        t0.t0(h10, "MESSENGER_LINK", gVar.a());
        t0.t0(h10, "TARGET_DISPLAY", gVar.a());
        return h10;
    }

    private final Bundle c(i iVar, List<Bundle> list, boolean z10) {
        Bundle h10 = h(iVar, z10);
        h10.putParcelableArrayList("MEDIA", new ArrayList(list));
        return h10;
    }

    private final Bundle d(k kVar, List<String> list, boolean z10) {
        Bundle h10 = h(kVar, z10);
        h10.putStringArrayList("PHOTOS", new ArrayList(list));
        return h10;
    }

    private final Bundle e(l lVar, Bundle bundle, Bundle bundle2, boolean z10) {
        Bundle h10 = h(lVar, z10);
        if (bundle != null) {
            h10.putParcelable("bg_asset", bundle);
        }
        if (bundle2 != null) {
            h10.putParcelable("interactive_asset_uri", bundle2);
        }
        Collection v10 = lVar.v();
        if (!(v10 == null || v10.isEmpty())) {
            h10.putStringArrayList("top_background_color_list", new ArrayList(v10));
        }
        t0 t0Var = t0.f14237a;
        t0.s0(h10, "content_url", lVar.s());
        return h10;
    }

    private final Bundle f(n nVar, String str, boolean z10) {
        Bundle h10 = h(nVar, z10);
        t0 t0Var = t0.f14237a;
        t0.s0(h10, "TITLE", nVar.u());
        t0.s0(h10, "DESCRIPTION", nVar.s());
        t0.s0(h10, "VIDEO", str);
        return h10;
    }

    public static final Bundle g(@NotNull UUID uuid, @NotNull e<?, ?> eVar, boolean z10) {
        Intrinsics.checkNotNullParameter(uuid, "callId");
        Intrinsics.checkNotNullParameter(eVar, "shareContent");
        if (eVar instanceof g) {
            return f10258a.b((g) eVar, z10);
        }
        if (eVar instanceof k) {
            m mVar = m.f10284a;
            k kVar = (k) eVar;
            List<String> i10 = m.i(kVar, uuid);
            if (i10 == null) {
                i10 = q.h();
            }
            return f10258a.d(kVar, i10, z10);
        } else if (eVar instanceof n) {
            m mVar2 = m.f10284a;
            n nVar = (n) eVar;
            return f10258a.f(nVar, m.o(nVar, uuid), z10);
        } else if (eVar instanceof i) {
            m mVar3 = m.f10284a;
            i iVar = (i) eVar;
            List<Bundle> g10 = m.g(iVar, uuid);
            if (g10 == null) {
                g10 = q.h();
            }
            return f10258a.c(iVar, g10, z10);
        } else if (eVar instanceof d) {
            m mVar4 = m.f10284a;
            d dVar = (d) eVar;
            return f10258a.a(dVar, m.m(dVar, uuid), z10);
        } else if (!(eVar instanceof l)) {
            return null;
        } else {
            m mVar5 = m.f10284a;
            l lVar = (l) eVar;
            return f10258a.e(lVar, m.f(lVar, uuid), m.l(lVar, uuid), z10);
        }
    }

    private final Bundle h(e<?, ?> eVar, boolean z10) {
        Bundle bundle = new Bundle();
        t0 t0Var = t0.f14237a;
        t0.t0(bundle, "LINK", eVar.a());
        t0.s0(bundle, "PLACE", eVar.l());
        t0.s0(bundle, "PAGE", eVar.j());
        t0.s0(bundle, "REF", eVar.m());
        t0.s0(bundle, "REF", eVar.m());
        bundle.putBoolean("DATA_FAILURES_FATAL", z10);
        Collection k10 = eVar.k();
        if (!(k10 == null || k10.isEmpty())) {
            bundle.putStringArrayList("FRIENDS", new ArrayList(k10));
        }
        e5.f q10 = eVar.q();
        t0.s0(bundle, "HASHTAG", q10 == null ? null : q10.a());
        return bundle;
    }
}
