package d5;

import android.graphics.Bitmap;
import android.net.Uri;
import e5.e;
import e5.g;
import e5.i;
import e5.j;
import e5.k;
import e5.l;
import e5.m;
import e5.n;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import q4.t0;
import q4.u0;
import qb.a0;
import v3.e0;
import v3.r;

@Metadata
public final class h {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final h f10260a = new h();
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final c f10261b = new d();
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private static final c f10262c = new c();
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private static final c f10263d = new a();
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    private static final c f10264e = new b();

    @Metadata
    private static final class a extends c {
        public void b(@NotNull g gVar) {
            Intrinsics.checkNotNullParameter(gVar, "linkContent");
            t0 t0Var = t0.f14237a;
            if (!t0.d0(gVar.s())) {
                throw new r("Cannot share link content with quote using the share api");
            }
        }

        public void d(@NotNull i iVar) {
            Intrinsics.checkNotNullParameter(iVar, "mediaContent");
            throw new r("Cannot share ShareMediaContent using the share api");
        }

        public void e(@NotNull j jVar) {
            Intrinsics.checkNotNullParameter(jVar, "photo");
            h.f10260a.v(jVar, this);
        }

        public void i(@NotNull n nVar) {
            Intrinsics.checkNotNullParameter(nVar, "videoContent");
            t0 t0Var = t0.f14237a;
            if (!t0.d0(nVar.l())) {
                throw new r("Cannot share video content with place IDs using the share api");
            } else if (!t0.e0(nVar.k())) {
                throw new r("Cannot share video content with people IDs using the share api");
            } else if (!t0.d0(nVar.m())) {
                throw new r("Cannot share video content with referrer URL using the share api");
            }
        }
    }

    @Metadata
    private static final class b extends c {
        public void g(l lVar) {
            h.f10260a.y(lVar, this);
        }
    }

    @Metadata
    public static class c {
        public void a(@NotNull e5.d dVar) {
            Intrinsics.checkNotNullParameter(dVar, "cameraEffectContent");
            h.f10260a.l(dVar);
        }

        public void b(@NotNull g gVar) {
            Intrinsics.checkNotNullParameter(gVar, "linkContent");
            h.f10260a.q(gVar, this);
        }

        public void c(@NotNull e5.h<?, ?> hVar) {
            Intrinsics.checkNotNullParameter(hVar, "medium");
            h.s(hVar, this);
        }

        public void d(@NotNull i iVar) {
            Intrinsics.checkNotNullParameter(iVar, "mediaContent");
            h.f10260a.r(iVar, this);
        }

        public void e(@NotNull j jVar) {
            Intrinsics.checkNotNullParameter(jVar, "photo");
            h.f10260a.w(jVar, this);
        }

        public void f(@NotNull k kVar) {
            Intrinsics.checkNotNullParameter(kVar, "photoContent");
            h.f10260a.u(kVar, this);
        }

        public void g(l lVar) {
            h.f10260a.y(lVar, this);
        }

        public void h(m mVar) {
            h.f10260a.z(mVar, this);
        }

        public void i(@NotNull n nVar) {
            Intrinsics.checkNotNullParameter(nVar, "videoContent");
            h.f10260a.A(nVar, this);
        }
    }

    @Metadata
    private static final class d extends c {
        public void d(@NotNull i iVar) {
            Intrinsics.checkNotNullParameter(iVar, "mediaContent");
            throw new r("Cannot share ShareMediaContent via web sharing dialogs");
        }

        public void e(@NotNull j jVar) {
            Intrinsics.checkNotNullParameter(jVar, "photo");
            h.f10260a.x(jVar, this);
        }

        public void i(@NotNull n nVar) {
            Intrinsics.checkNotNullParameter(nVar, "videoContent");
            throw new r("Cannot share ShareVideoContent via web sharing dialogs");
        }
    }

    private h() {
    }

    /* access modifiers changed from: private */
    public final void A(n nVar, c cVar) {
        cVar.h(nVar.w());
        j v10 = nVar.v();
        if (v10 != null) {
            cVar.e(v10);
        }
    }

    private final void k(e<?, ?> eVar, c cVar) throws r {
        if (eVar == null) {
            throw new r("Must provide non-null content to share");
        } else if (eVar instanceof g) {
            cVar.b((g) eVar);
        } else if (eVar instanceof k) {
            cVar.f((k) eVar);
        } else if (eVar instanceof n) {
            cVar.i((n) eVar);
        } else if (eVar instanceof i) {
            cVar.d((i) eVar);
        } else if (eVar instanceof e5.d) {
            cVar.a((e5.d) eVar);
        } else if (eVar instanceof l) {
            cVar.g((l) eVar);
        }
    }

    /* access modifiers changed from: private */
    public final void l(e5.d dVar) {
        if (t0.d0(dVar.u())) {
            throw new r("Must specify a non-empty effectId");
        }
    }

    public static final void m(e<?, ?> eVar) {
        f10260a.k(eVar, f10262c);
    }

    public static final void n(e<?, ?> eVar) {
        f10260a.k(eVar, f10262c);
    }

    public static final void o(e<?, ?> eVar) {
        f10260a.k(eVar, f10264e);
    }

    public static final void p(e<?, ?> eVar) {
        f10260a.k(eVar, f10261b);
    }

    /* access modifiers changed from: private */
    public final void q(g gVar, c cVar) {
        Uri a10 = gVar.a();
        if (a10 != null && !t0.f0(a10)) {
            throw new r("Content Url must be an http:// or https:// url");
        }
    }

    /* access modifiers changed from: private */
    public final void r(i iVar, c cVar) {
        List<e5.h<?, ?>> s10 = iVar.s();
        if (s10 == null || s10.isEmpty()) {
            throw new r("Must specify at least one medium in ShareMediaContent.");
        } else if (s10.size() <= 6) {
            for (e5.h<?, ?> c10 : s10) {
                cVar.c(c10);
            }
        } else {
            a0 a0Var = a0.f14418a;
            String format = String.format(Locale.ROOT, "Cannot add more than %d media.", Arrays.copyOf(new Object[]{6}, 1));
            Intrinsics.checkNotNullExpressionValue(format, "java.lang.String.format(locale, format, *args)");
            throw new r(format);
        }
    }

    public static final void s(@NotNull e5.h<?, ?> hVar, @NotNull c cVar) {
        Intrinsics.checkNotNullParameter(hVar, "medium");
        Intrinsics.checkNotNullParameter(cVar, "validator");
        if (hVar instanceof j) {
            cVar.e((j) hVar);
        } else if (hVar instanceof m) {
            cVar.h((m) hVar);
        } else {
            a0 a0Var = a0.f14418a;
            String format = String.format(Locale.ROOT, "Invalid media type: %s", Arrays.copyOf(new Object[]{hVar.getClass().getSimpleName()}, 1));
            Intrinsics.checkNotNullExpressionValue(format, "java.lang.String.format(locale, format, *args)");
            throw new r(format);
        }
    }

    private final void t(j jVar) {
        if (jVar != null) {
            Bitmap k10 = jVar.k();
            Uri m10 = jVar.m();
            if (k10 == null && m10 == null) {
                throw new r("SharePhoto does not have a Bitmap or ImageUrl specified");
            }
            return;
        }
        throw new r("Cannot share a null SharePhoto");
    }

    /* access modifiers changed from: private */
    public final void u(k kVar, c cVar) {
        List<j> s10 = kVar.s();
        if (s10 == null || s10.isEmpty()) {
            throw new r("Must specify at least one Photo in SharePhotoContent.");
        } else if (s10.size() <= 6) {
            for (j e10 : s10) {
                cVar.e(e10);
            }
        } else {
            a0 a0Var = a0.f14418a;
            String format = String.format(Locale.ROOT, "Cannot add more than %d photos.", Arrays.copyOf(new Object[]{6}, 1));
            Intrinsics.checkNotNullExpressionValue(format, "java.lang.String.format(locale, format, *args)");
            throw new r(format);
        }
    }

    /* access modifiers changed from: private */
    public final void v(j jVar, c cVar) {
        t(jVar);
        Bitmap k10 = jVar.k();
        Uri m10 = jVar.m();
        if (k10 == null && t0.f0(m10)) {
            throw new r("Cannot set the ImageUrl of a SharePhoto to the Uri of an image on the web when sharing SharePhotoContent");
        }
    }

    /* access modifiers changed from: private */
    public final void w(j jVar, c cVar) {
        v(jVar, cVar);
        if (jVar.k() == null) {
            t0 t0Var = t0.f14237a;
            if (t0.f0(jVar.m())) {
                return;
            }
        }
        u0 u0Var = u0.f14248a;
        u0.d(e0.l());
    }

    /* access modifiers changed from: private */
    public final void x(j jVar, c cVar) {
        t(jVar);
    }

    /* access modifiers changed from: private */
    public final void y(l lVar, c cVar) {
        if (lVar == null || (lVar.u() == null && lVar.w() == null)) {
            throw new r("Must pass the Facebook app a background asset, a sticker asset, or both");
        }
        if (lVar.u() != null) {
            cVar.c(lVar.u());
        }
        if (lVar.w() != null) {
            cVar.e(lVar.w());
        }
    }

    /* access modifiers changed from: private */
    public final void z(m mVar, c cVar) {
        if (mVar != null) {
            Uri k10 = mVar.k();
            if (k10 == null) {
                throw new r("ShareVideo does not have a LocalUrl specified");
            } else if (!t0.Y(k10) && !t0.b0(k10)) {
                throw new r("ShareVideo must reference a video that is on the device");
            }
        } else {
            throw new r("Cannot share a null ShareVideo");
        }
    }
}
