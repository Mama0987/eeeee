package d5;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import e5.b;
import e5.d;
import e5.h;
import e5.i;
import e5.j;
import e5.k;
import e5.l;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import q4.e;
import q4.i0;
import q4.k0;
import q4.t0;
import v3.e0;
import v3.i0;
import v3.o;
import v3.o0;
import v3.r;
import v3.t;
import w3.f0;

@Metadata
public final class m {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final m f10284a = new m();

    @Metadata
    public static final class a extends g {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ o<c5.a> f10285b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(o<c5.a> oVar) {
            super(oVar);
            this.f10285b = oVar;
        }

        public void a(@NotNull q4.a aVar) {
            Intrinsics.checkNotNullParameter(aVar, "appCall");
            m mVar = m.f10284a;
            m.q(this.f10285b);
        }

        public void b(@NotNull q4.a aVar, @NotNull r rVar) {
            Intrinsics.checkNotNullParameter(aVar, "appCall");
            Intrinsics.checkNotNullParameter(rVar, "error");
            m mVar = m.f10284a;
            m.r(this.f10285b, rVar);
        }

        public void c(@NotNull q4.a aVar, Bundle bundle) {
            Intrinsics.checkNotNullParameter(aVar, "appCall");
            if (bundle != null) {
                String h10 = m.h(bundle);
                if (h10 == null || m.n("post", h10, true)) {
                    m.s(this.f10285b, m.j(bundle));
                } else if (m.n("cancel", h10, true)) {
                    m.q(this.f10285b);
                } else {
                    m.r(this.f10285b, new r("UnknownError"));
                }
            }
        }
    }

    private m() {
    }

    private final q4.a c(int i10, int i11, Intent intent) {
        UUID r10 = k0.r(intent);
        if (r10 == null) {
            return null;
        }
        return q4.a.f14046d.b(r10, i10);
    }

    private final i0.a d(UUID uuid, Uri uri, Bitmap bitmap) {
        if (bitmap != null) {
            return i0.d(uuid, bitmap);
        }
        if (uri != null) {
            return i0.e(uuid, uri);
        }
        return null;
    }

    private final i0.a e(UUID uuid, h<?, ?> hVar) {
        Uri uri;
        Bitmap bitmap;
        if (hVar instanceof j) {
            j jVar = (j) hVar;
            bitmap = jVar.k();
            uri = jVar.m();
        } else if (hVar instanceof e5.m) {
            uri = ((e5.m) hVar).k();
            bitmap = null;
        } else {
            uri = null;
            bitmap = null;
        }
        return d(uuid, uri, bitmap);
    }

    public static final Bundle f(l lVar, @NotNull UUID uuid) {
        Intrinsics.checkNotNullParameter(uuid, "appCallId");
        Bundle bundle = null;
        if (!(lVar == null || lVar.u() == null)) {
            h<?, ?> u10 = lVar.u();
            i0.a e10 = f10284a.e(uuid, u10);
            if (e10 == null) {
                return null;
            }
            bundle = new Bundle();
            bundle.putString("type", u10.j().name());
            bundle.putString("uri", e10.b());
            String n10 = n(e10.e());
            if (n10 != null) {
                t0.s0(bundle, "extension", n10);
            }
            i0 i0Var = i0.f14131a;
            i0.a(p.e(e10));
        }
        return bundle;
    }

    public static final List<Bundle> g(i iVar, @NotNull UUID uuid) {
        Bundle bundle;
        Intrinsics.checkNotNullParameter(uuid, "appCallId");
        List<h<?, ?>> s10 = iVar == null ? null : iVar.s();
        if (s10 == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (h hVar : s10) {
            i0.a e10 = f10284a.e(uuid, hVar);
            if (e10 == null) {
                bundle = null;
            } else {
                arrayList.add(e10);
                bundle = new Bundle();
                bundle.putString("type", hVar.j().name());
                bundle.putString("uri", e10.b());
            }
            if (bundle != null) {
                arrayList2.add(bundle);
            }
        }
        i0.a(arrayList);
        return arrayList2;
    }

    public static final String h(@NotNull Bundle bundle) {
        Intrinsics.checkNotNullParameter(bundle, "result");
        String str = "completionGesture";
        if (!bundle.containsKey(str)) {
            str = "com.facebook.platform.extra.COMPLETION_GESTURE";
        }
        return bundle.getString(str);
    }

    public static final List<String> i(k kVar, @NotNull UUID uuid) {
        Intrinsics.checkNotNullParameter(uuid, "appCallId");
        List<j> s10 = kVar == null ? null : kVar.s();
        if (s10 == null) {
            return null;
        }
        ArrayList<i0.a> arrayList = new ArrayList<>();
        for (j e10 : s10) {
            i0.a e11 = f10284a.e(uuid, e10);
            if (e11 != null) {
                arrayList.add(e11);
            }
        }
        ArrayList arrayList2 = new ArrayList(r.p(arrayList, 10));
        for (i0.a b10 : arrayList) {
            arrayList2.add(b10.b());
        }
        i0.a(arrayList);
        return arrayList2;
    }

    public static final String j(@NotNull Bundle bundle) {
        Intrinsics.checkNotNullParameter(bundle, "result");
        if (bundle.containsKey("postId")) {
            return bundle.getString("postId");
        }
        String str = "com.facebook.platform.extra.POST_ID";
        if (!bundle.containsKey(str)) {
            str = "post_id";
        }
        return bundle.getString(str);
    }

    @NotNull
    public static final g k(o<c5.a> oVar) {
        return new a(oVar);
    }

    public static final Bundle l(l lVar, @NotNull UUID uuid) {
        Intrinsics.checkNotNullParameter(uuid, "appCallId");
        if (lVar == null || lVar.w() == null) {
            return null;
        }
        new ArrayList().add(lVar.w());
        i0.a e10 = f10284a.e(uuid, lVar.w());
        if (e10 == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        bundle.putString("uri", e10.b());
        String n10 = n(e10.e());
        if (n10 != null) {
            t0.s0(bundle, "extension", n10);
        }
        i0 i0Var = i0.f14131a;
        i0.a(p.e(e10));
        return bundle;
    }

    public static final Bundle m(d dVar, @NotNull UUID uuid) {
        Intrinsics.checkNotNullParameter(uuid, "appCallId");
        b v10 = dVar == null ? null : dVar.v();
        if (v10 == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        ArrayList arrayList = new ArrayList();
        for (String next : v10.l()) {
            i0.a d10 = f10284a.d(uuid, v10.k(next), v10.j(next));
            if (d10 != null) {
                arrayList.add(d10);
                bundle.putString(next, d10.b());
            }
        }
        i0.a(arrayList);
        return bundle;
    }

    public static final String n(Uri uri) {
        if (uri == null) {
            return null;
        }
        String uri2 = uri.toString();
        Intrinsics.checkNotNullExpressionValue(uri2, "uri.toString()");
        int L = StringsKt__StringsKt.L(uri2, '.', 0, false, 6, (Object) null);
        if (L == -1) {
            return null;
        }
        String substring = uri2.substring(L);
        Intrinsics.checkNotNullExpressionValue(substring, "(this as java.lang.String).substring(startIndex)");
        return substring;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x000a, code lost:
        r1 = r1.w();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.String o(e5.n r1, @org.jetbrains.annotations.NotNull java.util.UUID r2) {
        /*
            java.lang.String r0 = "appCallId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r0 = 0
            if (r1 != 0) goto L_0x000a
        L_0x0008:
            r1 = r0
            goto L_0x0015
        L_0x000a:
            e5.m r1 = r1.w()
            if (r1 != 0) goto L_0x0011
            goto L_0x0008
        L_0x0011:
            android.net.Uri r1 = r1.k()
        L_0x0015:
            if (r1 != 0) goto L_0x0018
            return r0
        L_0x0018:
            q4.i0$a r1 = q4.i0.e(r2, r1)
            java.util.List r2 = kotlin.collections.p.e(r1)
            java.util.Collection r2 = (java.util.Collection) r2
            q4.i0.a(r2)
            java.lang.String r1 = r1.b()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: d5.m.o(e5.n, java.util.UUID):java.lang.String");
    }

    public static final boolean p(int i10, int i11, Intent intent, g gVar) {
        q4.a c10 = f10284a.c(i10, i11, intent);
        if (c10 == null) {
            return false;
        }
        i0 i0Var = i0.f14131a;
        i0.c(c10.c());
        if (gVar == null) {
            return true;
        }
        Bundle bundle = null;
        r t10 = intent != null ? k0.t(k0.s(intent)) : null;
        if (t10 == null) {
            if (intent != null) {
                bundle = k0.A(intent);
            }
            gVar.c(c10, bundle);
        } else if (t10 instanceof t) {
            gVar.a(c10);
        } else {
            gVar.b(c10, t10);
        }
        return true;
    }

    public static final void q(o<c5.a> oVar) {
        f10284a.t("cancelled", (String) null);
        if (oVar != null) {
            oVar.onCancel();
        }
    }

    public static final void r(o<c5.a> oVar, @NotNull r rVar) {
        Intrinsics.checkNotNullParameter(rVar, "ex");
        f10284a.t("error", rVar.getMessage());
        if (oVar != null) {
            oVar.a(rVar);
        }
    }

    public static final void s(o<c5.a> oVar, String str) {
        f10284a.t("succeeded", (String) null);
        if (oVar != null) {
            oVar.onSuccess(new c5.a(str));
        }
    }

    private final void t(String str, String str2) {
        f0 f0Var = new f0(e0.l());
        Bundle bundle = new Bundle();
        bundle.putString("fb_share_dialog_outcome", str);
        if (str2 != null) {
            bundle.putString("error_message", str2);
        }
        f0Var.g("fb_share_dialog_result", bundle);
    }

    @NotNull
    public static final v3.i0 u(v3.a aVar, @NotNull Uri uri, i0.b bVar) throws FileNotFoundException {
        Intrinsics.checkNotNullParameter(uri, "imageUri");
        String path = uri.getPath();
        if (t0.b0(uri) && path != null) {
            return v(aVar, new File(path), bVar);
        }
        if (t0.Y(uri)) {
            i0.g gVar = new i0.g(uri, "image/png");
            Bundle bundle = new Bundle(1);
            bundle.putParcelable("file", gVar);
            return new v3.i0(aVar, "me/staging_resources", bundle, o0.POST, bVar, (String) null, 32, (DefaultConstructorMarker) null);
        }
        throw new r("The image Uri must be either a file:// or content:// Uri");
    }

    @NotNull
    public static final v3.i0 v(v3.a aVar, File file, i0.b bVar) throws FileNotFoundException {
        i0.g gVar = new i0.g(ParcelFileDescriptor.open(file, 268435456), "image/png");
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("file", gVar);
        return new v3.i0(aVar, "me/staging_resources", bundle, o0.POST, bVar, (String) null, 32, (DefaultConstructorMarker) null);
    }

    public static final void w(int i10, v3.m mVar, o<c5.a> oVar) {
        if (mVar instanceof e) {
            ((e) mVar).c(i10, new l(i10, oVar));
            return;
        }
        throw new r("Unexpected CallbackManager, please use the provided Factory.");
    }

    /* access modifiers changed from: private */
    public static final boolean x(int i10, o oVar, int i11, Intent intent) {
        return p(i10, i11, intent, k(oVar));
    }

    public static final void y(int i10) {
        e.f14090b.c(i10, new k(i10));
    }

    /* access modifiers changed from: private */
    public static final boolean z(int i10, int i11, Intent intent) {
        return p(i10, i11, intent, k((o<c5.a>) null));
    }
}
