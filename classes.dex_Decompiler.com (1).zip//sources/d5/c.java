package d5;

import e5.c;
import q4.u0;

public class c {
    public static void a(e5.c cVar) {
        u0.m(cVar.m(), "message");
        int i10 = 0;
        if (!((cVar.q() != null) ^ (cVar.a() == c.a.ASKFOR || cVar.a() == c.a.SEND))) {
            if (cVar.r() != null) {
                i10 = 1;
            }
            if (cVar.s() != null) {
                i10++;
            }
            if (cVar.l() != null) {
                i10++;
            }
            if (i10 > 1) {
                throw new IllegalArgumentException("Parameters to, filters and suggestions are mutually exclusive");
            }
            return;
        }
        throw new IllegalArgumentException("Object id should be provided if and only if action type is send or askfor");
    }
}
