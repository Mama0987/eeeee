package d5;

import q4.h;

public enum e implements h {
    MESSAGE_DIALOG(20140204),
    PHOTOS(20140324),
    VIDEO(20141218),
    MESSENGER_GENERIC_TEMPLATE(20171115),
    MESSENGER_OPEN_GRAPH_MUSIC_TEMPLATE(20171115),
    MESSENGER_MEDIA_TEMPLATE(20171115);
    

    /* renamed from: a  reason: collision with root package name */
    private int f10257a;

    private e(int i10) {
        this.f10257a = i10;
    }

    public int a() {
        return this.f10257a;
    }

    public String g() {
        return "com.facebook.platform.action.request.MESSAGE_DIALOG";
    }
}
