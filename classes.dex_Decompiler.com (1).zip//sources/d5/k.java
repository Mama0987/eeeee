package d5;

import android.content.Intent;
import q4.e;

public final /* synthetic */ class k implements e.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f10281a;

    public /* synthetic */ k(int i10) {
        this.f10281a = i10;
    }

    public final boolean a(int i10, Intent intent) {
        return m.z(this.f10281a, i10, intent);
    }
}
