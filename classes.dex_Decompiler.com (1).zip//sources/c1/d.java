package c1;

import a1.l;
import android.annotation.SuppressLint;
import e1.j;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class d {
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    public static final b f4414e = new b((DefaultConstructorMarker) null);
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public final String f4415a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    public final Map<String, a> f4416b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    public final Set<c> f4417c;

    /* renamed from: d  reason: collision with root package name */
    public final Set<e> f4418d;

    @Metadata
    public static final class a {
        @NotNull

        /* renamed from: h  reason: collision with root package name */
        public static final C0076a f4419h = new C0076a((DefaultConstructorMarker) null);
        @NotNull

        /* renamed from: a  reason: collision with root package name */
        public final String f4420a;
        @NotNull

        /* renamed from: b  reason: collision with root package name */
        public final String f4421b;

        /* renamed from: c  reason: collision with root package name */
        public final boolean f4422c;

        /* renamed from: d  reason: collision with root package name */
        public final int f4423d;

        /* renamed from: e  reason: collision with root package name */
        public final String f4424e;

        /* renamed from: f  reason: collision with root package name */
        public final int f4425f;

        /* renamed from: g  reason: collision with root package name */
        public final int f4426g;

        @Metadata
        /* renamed from: c1.d$a$a  reason: collision with other inner class name */
        public static final class C0076a {
            private C0076a() {
            }

            public /* synthetic */ C0076a(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private final boolean a(String str) {
                if (str.length() == 0) {
                    return false;
                }
                int i10 = 0;
                int i11 = 0;
                int i12 = 0;
                while (i10 < str.length()) {
                    char charAt = str.charAt(i10);
                    int i13 = i12 + 1;
                    if (i12 == 0 && charAt != '(') {
                        return false;
                    }
                    if (charAt == '(') {
                        i11++;
                    } else if (charAt == ')' && i11 - 1 == 0 && i12 != str.length() - 1) {
                        return false;
                    }
                    i10++;
                    i12 = i13;
                }
                return i11 == 0;
            }

            @SuppressLint({"SyntheticAccessor"})
            public final boolean b(@NotNull String str, String str2) {
                Intrinsics.checkNotNullParameter(str, "current");
                if (Intrinsics.a(str, str2)) {
                    return true;
                }
                if (!a(str)) {
                    return false;
                }
                String substring = str.substring(1, str.length() - 1);
                Intrinsics.checkNotNullExpressionValue(substring, "this as java.lang.String…ing(startIndex, endIndex)");
                return Intrinsics.a(StringsKt__StringsKt.o0(substring).toString(), str2);
            }
        }

        public a(@NotNull String str, @NotNull String str2, boolean z10, int i10, String str3, int i11) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, "type");
            this.f4420a = str;
            this.f4421b = str2;
            this.f4422c = z10;
            this.f4423d = i10;
            this.f4424e = str3;
            this.f4425f = i11;
            this.f4426g = a(str2);
        }

        private final int a(String str) {
            if (str == null) {
                return 5;
            }
            Locale locale = Locale.US;
            Intrinsics.checkNotNullExpressionValue(locale, "US");
            String upperCase = str.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue(upperCase, "this as java.lang.String).toUpperCase(locale)");
            if (StringsKt__StringsKt.y(upperCase, "INT", false, 2, (Object) null)) {
                return 3;
            }
            if (StringsKt__StringsKt.y(upperCase, "CHAR", false, 2, (Object) null) || StringsKt__StringsKt.y(upperCase, "CLOB", false, 2, (Object) null) || StringsKt__StringsKt.y(upperCase, "TEXT", false, 2, (Object) null)) {
                return 2;
            }
            if (StringsKt__StringsKt.y(upperCase, "BLOB", false, 2, (Object) null)) {
                return 5;
            }
            return (StringsKt__StringsKt.y(upperCase, "REAL", false, 2, (Object) null) || StringsKt__StringsKt.y(upperCase, "FLOA", false, 2, (Object) null) || StringsKt__StringsKt.y(upperCase, "DOUB", false, 2, (Object) null)) ? 4 : 1;
        }

        public boolean equals(Object obj) {
            String str;
            String str2;
            String str3;
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a) || this.f4423d != ((a) obj).f4423d) {
                return false;
            }
            a aVar = (a) obj;
            if (!Intrinsics.a(this.f4420a, aVar.f4420a) || this.f4422c != aVar.f4422c) {
                return false;
            }
            if (this.f4425f == 1 && aVar.f4425f == 2 && (str3 = this.f4424e) != null && !f4419h.b(str3, aVar.f4424e)) {
                return false;
            }
            if (this.f4425f == 2 && aVar.f4425f == 1 && (str2 = aVar.f4424e) != null && !f4419h.b(str2, this.f4424e)) {
                return false;
            }
            int i10 = this.f4425f;
            if (i10 != 0 && i10 == aVar.f4425f) {
                if ((str = this.f4424e) == null ? aVar.f4424e != null : !f4419h.b(str, aVar.f4424e)) {
                    return false;
                }
            }
            return this.f4426g == aVar.f4426g;
        }

        public int hashCode() {
            return (((((this.f4420a.hashCode() * 31) + this.f4426g) * 31) + (this.f4422c ? 1231 : 1237)) * 31) + this.f4423d;
        }

        @NotNull
        public String toString() {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("Column{name='");
            sb2.append(this.f4420a);
            sb2.append("', type='");
            sb2.append(this.f4421b);
            sb2.append("', affinity='");
            sb2.append(this.f4426g);
            sb2.append("', notNull=");
            sb2.append(this.f4422c);
            sb2.append(", primaryKeyPosition=");
            sb2.append(this.f4423d);
            sb2.append(", defaultValue='");
            String str = this.f4424e;
            if (str == null) {
                str = "undefined";
            }
            sb2.append(str);
            sb2.append("'}");
            return sb2.toString();
        }
    }

    @Metadata
    public static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final d a(@NotNull j jVar, @NotNull String str) {
            Intrinsics.checkNotNullParameter(jVar, "database");
            Intrinsics.checkNotNullParameter(str, "tableName");
            return e.f(jVar, str);
        }
    }

    @Metadata
    public static final class c {
        @NotNull

        /* renamed from: a  reason: collision with root package name */
        public final String f4427a;
        @NotNull

        /* renamed from: b  reason: collision with root package name */
        public final String f4428b;
        @NotNull

        /* renamed from: c  reason: collision with root package name */
        public final String f4429c;
        @NotNull

        /* renamed from: d  reason: collision with root package name */
        public final List<String> f4430d;
        @NotNull

        /* renamed from: e  reason: collision with root package name */
        public final List<String> f4431e;

        public c(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull List<String> list, @NotNull List<String> list2) {
            Intrinsics.checkNotNullParameter(str, "referenceTable");
            Intrinsics.checkNotNullParameter(str2, "onDelete");
            Intrinsics.checkNotNullParameter(str3, "onUpdate");
            Intrinsics.checkNotNullParameter(list, "columnNames");
            Intrinsics.checkNotNullParameter(list2, "referenceColumnNames");
            this.f4427a = str;
            this.f4428b = str2;
            this.f4429c = str3;
            this.f4430d = list;
            this.f4431e = list2;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            if (Intrinsics.a(this.f4427a, cVar.f4427a) && Intrinsics.a(this.f4428b, cVar.f4428b) && Intrinsics.a(this.f4429c, cVar.f4429c) && Intrinsics.a(this.f4430d, cVar.f4430d)) {
                return Intrinsics.a(this.f4431e, cVar.f4431e);
            }
            return false;
        }

        public int hashCode() {
            return (((((((this.f4427a.hashCode() * 31) + this.f4428b.hashCode()) * 31) + this.f4429c.hashCode()) * 31) + this.f4430d.hashCode()) * 31) + this.f4431e.hashCode();
        }

        @NotNull
        public String toString() {
            return "ForeignKey{referenceTable='" + this.f4427a + "', onDelete='" + this.f4428b + " +', onUpdate='" + this.f4429c + "', columnNames=" + this.f4430d + ", referenceColumnNames=" + this.f4431e + '}';
        }
    }

    @Metadata
    /* renamed from: c1.d$d  reason: collision with other inner class name */
    public static final class C0077d implements Comparable<C0077d> {

        /* renamed from: a  reason: collision with root package name */
        private final int f4432a;

        /* renamed from: b  reason: collision with root package name */
        private final int f4433b;
        @NotNull

        /* renamed from: c  reason: collision with root package name */
        private final String f4434c;
        @NotNull

        /* renamed from: d  reason: collision with root package name */
        private final String f4435d;

        public C0077d(int i10, int i11, @NotNull String str, @NotNull String str2) {
            Intrinsics.checkNotNullParameter(str, "from");
            Intrinsics.checkNotNullParameter(str2, "to");
            this.f4432a = i10;
            this.f4433b = i11;
            this.f4434c = str;
            this.f4435d = str2;
        }

        /* renamed from: a */
        public int compareTo(@NotNull C0077d dVar) {
            Intrinsics.checkNotNullParameter(dVar, "other");
            int i10 = this.f4432a - dVar.f4432a;
            return i10 == 0 ? this.f4433b - dVar.f4433b : i10;
        }

        @NotNull
        public final String g() {
            return this.f4434c;
        }

        public final int h() {
            return this.f4432a;
        }

        @NotNull
        public final String i() {
            return this.f4435d;
        }
    }

    @Metadata
    public static final class e {
        @NotNull

        /* renamed from: e  reason: collision with root package name */
        public static final a f4436e = new a((DefaultConstructorMarker) null);
        @NotNull

        /* renamed from: a  reason: collision with root package name */
        public final String f4437a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f4438b;
        @NotNull

        /* renamed from: c  reason: collision with root package name */
        public final List<String> f4439c;
        @NotNull

        /* renamed from: d  reason: collision with root package name */
        public List<String> f4440d;

        @Metadata
        public static final class a {
            private a() {
            }

            public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }
        }

        public e(@NotNull String str, boolean z10, @NotNull List<String> list, @NotNull List<String> list2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(list, "columns");
            Intrinsics.checkNotNullParameter(list2, "orders");
            this.f4437a = str;
            this.f4438b = z10;
            this.f4439c = list;
            this.f4440d = list2;
            Collection collection = list2;
            boolean isEmpty = collection.isEmpty();
            ArrayList arrayList = collection;
            if (isEmpty) {
                int size = list.size();
                ArrayList arrayList2 = new ArrayList(size);
                for (int i10 = 0; i10 < size; i10++) {
                    arrayList2.add(l.ASC.name());
                }
                arrayList = arrayList2;
            }
            this.f4440d = (List) arrayList;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof e)) {
                return false;
            }
            e eVar = (e) obj;
            if (this.f4438b == eVar.f4438b && Intrinsics.a(this.f4439c, eVar.f4439c) && Intrinsics.a(this.f4440d, eVar.f4440d)) {
                return m.v(this.f4437a, "index_", false, 2, (Object) null) ? m.v(eVar.f4437a, "index_", false, 2, (Object) null) : Intrinsics.a(this.f4437a, eVar.f4437a);
            }
            return false;
        }

        public int hashCode() {
            return ((((((m.v(this.f4437a, "index_", false, 2, (Object) null) ? -1184239155 : this.f4437a.hashCode()) * 31) + (this.f4438b ? 1 : 0)) * 31) + this.f4439c.hashCode()) * 31) + this.f4440d.hashCode();
        }

        @NotNull
        public String toString() {
            return "Index{name='" + this.f4437a + "', unique=" + this.f4438b + ", columns=" + this.f4439c + ", orders=" + this.f4440d + "'}";
        }
    }

    public d(@NotNull String str, @NotNull Map<String, a> map, @NotNull Set<c> set, Set<e> set2) {
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(map, "columns");
        Intrinsics.checkNotNullParameter(set, "foreignKeys");
        this.f4415a = str;
        this.f4416b = map;
        this.f4417c = set;
        this.f4418d = set2;
    }

    @NotNull
    public static final d a(@NotNull j jVar, @NotNull String str) {
        return f4414e.a(jVar, str);
    }

    public boolean equals(Object obj) {
        Set<e> set;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        if (!Intrinsics.a(this.f4415a, dVar.f4415a) || !Intrinsics.a(this.f4416b, dVar.f4416b) || !Intrinsics.a(this.f4417c, dVar.f4417c)) {
            return false;
        }
        Set<e> set2 = this.f4418d;
        if (set2 == null || (set = dVar.f4418d) == null) {
            return true;
        }
        return Intrinsics.a(set2, set);
    }

    public int hashCode() {
        return (((this.f4415a.hashCode() * 31) + this.f4416b.hashCode()) * 31) + this.f4417c.hashCode();
    }

    @NotNull
    public String toString() {
        return "TableInfo{name='" + this.f4415a + "', columns=" + this.f4416b + ", foreignKeys=" + this.f4417c + ", indices=" + this.f4418d + '}';
    }
}
