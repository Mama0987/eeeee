package c1;

import android.annotation.SuppressLint;
import android.os.Build;
import com.appff.haptic.base.Utils;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class c {
    @SuppressLint({"LambdaLast"})
    public static final void a(@NotNull ReadableByteChannel readableByteChannel, @NotNull FileChannel fileChannel) throws IOException {
        Intrinsics.checkNotNullParameter(readableByteChannel, "input");
        Intrinsics.checkNotNullParameter(fileChannel, "output");
        try {
            if (Build.VERSION.SDK_INT <= 23) {
                InputStream newInputStream = Channels.newInputStream(readableByteChannel);
                OutputStream newOutputStream = Channels.newOutputStream(fileChannel);
                byte[] bArr = new byte[Utils.CONTINUOUS_EVENT];
                while (true) {
                    int read = newInputStream.read(bArr);
                    if (read <= 0) {
                        break;
                    }
                    newOutputStream.write(bArr, 0, read);
                }
            } else {
                fileChannel.transferFrom(readableByteChannel, 0, Long.MAX_VALUE);
            }
            fileChannel.force(false);
        } finally {
            readableByteChannel.close();
            fileChannel.close();
        }
    }
}
