package c1;

import android.database.Cursor;
import android.os.Build;
import android.util.Log;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class a {
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0071, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0072, code lost:
        mb.b.a(r7, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0075, code lost:
        throw r1;
     */
    @org.jetbrains.annotations.NotNull
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final android.database.Cursor a(@org.jetbrains.annotations.NotNull android.database.Cursor r7) {
        /*
            java.lang.String r0 = "c"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            android.database.MatrixCursor r0 = new android.database.MatrixCursor     // Catch:{ all -> 0x006f }
            java.lang.String[] r1 = r7.getColumnNames()     // Catch:{ all -> 0x006f }
            int r2 = r7.getCount()     // Catch:{ all -> 0x006f }
            r0.<init>(r1, r2)     // Catch:{ all -> 0x006f }
        L_0x0012:
            boolean r1 = r7.moveToNext()     // Catch:{ all -> 0x006f }
            r2 = 0
            if (r1 == 0) goto L_0x006b
            int r1 = r7.getColumnCount()     // Catch:{ all -> 0x006f }
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ all -> 0x006f }
            int r3 = r7.getColumnCount()     // Catch:{ all -> 0x006f }
            r4 = 0
        L_0x0024:
            if (r4 >= r3) goto L_0x0067
            int r5 = r7.getType(r4)     // Catch:{ all -> 0x006f }
            if (r5 == 0) goto L_0x0062
            r6 = 1
            if (r5 == r6) goto L_0x0057
            r6 = 2
            if (r5 == r6) goto L_0x004c
            r6 = 3
            if (r5 == r6) goto L_0x0045
            r6 = 4
            if (r5 != r6) goto L_0x003f
            byte[] r5 = r7.getBlob(r4)     // Catch:{ all -> 0x006f }
            r1[r4] = r5     // Catch:{ all -> 0x006f }
            goto L_0x0064
        L_0x003f:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x006f }
            r0.<init>()     // Catch:{ all -> 0x006f }
            throw r0     // Catch:{ all -> 0x006f }
        L_0x0045:
            java.lang.String r5 = r7.getString(r4)     // Catch:{ all -> 0x006f }
            r1[r4] = r5     // Catch:{ all -> 0x006f }
            goto L_0x0064
        L_0x004c:
            double r5 = r7.getDouble(r4)     // Catch:{ all -> 0x006f }
            java.lang.Double r5 = java.lang.Double.valueOf(r5)     // Catch:{ all -> 0x006f }
            r1[r4] = r5     // Catch:{ all -> 0x006f }
            goto L_0x0064
        L_0x0057:
            long r5 = r7.getLong(r4)     // Catch:{ all -> 0x006f }
            java.lang.Long r5 = java.lang.Long.valueOf(r5)     // Catch:{ all -> 0x006f }
            r1[r4] = r5     // Catch:{ all -> 0x006f }
            goto L_0x0064
        L_0x0062:
            r1[r4] = r2     // Catch:{ all -> 0x006f }
        L_0x0064:
            int r4 = r4 + 1
            goto L_0x0024
        L_0x0067:
            r0.addRow(r1)     // Catch:{ all -> 0x006f }
            goto L_0x0012
        L_0x006b:
            mb.b.a(r7, r2)
            return r0
        L_0x006f:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x0071 }
        L_0x0071:
            r1 = move-exception
            mb.b.a(r7, r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.a.a(android.database.Cursor):android.database.Cursor");
    }

    private static final int b(Cursor cursor, String str) {
        if (Build.VERSION.SDK_INT > 25) {
            return -1;
        }
        if (str.length() == 0) {
            return -1;
        }
        String[] columnNames = cursor.getColumnNames();
        Intrinsics.checkNotNullExpressionValue(columnNames, "columnNames");
        return c(columnNames, str);
    }

    public static final int c(@NotNull String[] strArr, @NotNull String str) {
        Intrinsics.checkNotNullParameter(strArr, "columnNames");
        Intrinsics.checkNotNullParameter(str, "name");
        String str2 = '.' + str;
        String str3 = '.' + str + '`';
        int length = strArr.length;
        int i10 = 0;
        int i11 = 0;
        while (i10 < length) {
            String str4 = strArr[i10];
            int i12 = i11 + 1;
            if (str4.length() >= str.length() + 2) {
                if (m.m(str4, str2, false, 2, (Object) null)) {
                    return i11;
                }
                if (str4.charAt(0) == '`' && m.m(str4, str3, false, 2, (Object) null)) {
                    return i11;
                }
            }
            i10++;
            i11 = i12;
        }
        return -1;
    }

    public static final int d(@NotNull Cursor cursor, @NotNull String str) {
        Intrinsics.checkNotNullParameter(cursor, "c");
        Intrinsics.checkNotNullParameter(str, "name");
        int columnIndex = cursor.getColumnIndex(str);
        if (columnIndex >= 0) {
            return columnIndex;
        }
        int columnIndex2 = cursor.getColumnIndex('`' + str + '`');
        return columnIndex2 >= 0 ? columnIndex2 : b(cursor, str);
    }

    public static final int e(@NotNull Cursor cursor, @NotNull String str) {
        String str2;
        Intrinsics.checkNotNullParameter(cursor, "c");
        Intrinsics.checkNotNullParameter(str, "name");
        int d10 = d(cursor, str);
        if (d10 >= 0) {
            return d10;
        }
        try {
            String[] columnNames = cursor.getColumnNames();
            Intrinsics.checkNotNullExpressionValue(columnNames, "c.columnNames");
            str2 = m.w(columnNames, (CharSequence) null, (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 63, (Object) null);
        } catch (Exception e10) {
            Log.d("RoomCursorUtil", "Cannot collect column names for debug purposes", e10);
            str2 = "unknown";
        }
        throw new IllegalArgumentException("column '" + str + "' does not exist. Available columns: " + str2);
    }
}
