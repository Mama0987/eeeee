package c1;

import a1.u;
import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.os.Build;
import android.os.CancellationSignal;
import e1.m;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class b {
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0060, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0061, code lost:
        mb.b.a(r1, r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0064, code lost:
        throw r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void a(@org.jetbrains.annotations.NotNull e1.j r6) {
        /*
            java.lang.String r0 = "db"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.util.List r0 = kotlin.collections.p.c()
            java.lang.String r1 = "SELECT name FROM sqlite_master WHERE type = 'trigger'"
            android.database.Cursor r1 = r6.i0(r1)
        L_0x000f:
            boolean r2 = r1.moveToNext()     // Catch:{ all -> 0x005e }
            r3 = 0
            if (r2 == 0) goto L_0x001e
            java.lang.String r2 = r1.getString(r3)     // Catch:{ all -> 0x005e }
            r0.add(r2)     // Catch:{ all -> 0x005e }
            goto L_0x000f
        L_0x001e:
            kotlin.Unit r2 = kotlin.Unit.f12470a     // Catch:{ all -> 0x005e }
            r2 = 0
            mb.b.a(r1, r2)
            java.util.List r0 = kotlin.collections.p.a(r0)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.Iterator r0 = r0.iterator()
        L_0x002e:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x005d
            java.lang.Object r1 = r0.next()
            java.lang.String r1 = (java.lang.String) r1
            java.lang.String r4 = "triggerName"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r4)
            java.lang.String r4 = "room_fts_content_sync_"
            r5 = 2
            boolean r4 = kotlin.text.m.v(r1, r4, r3, r5, r2)
            if (r4 == 0) goto L_0x002e
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "DROP TRIGGER IF EXISTS "
            r4.append(r5)
            r4.append(r1)
            java.lang.String r1 = r4.toString()
            r6.x(r1)
            goto L_0x002e
        L_0x005d:
            return
        L_0x005e:
            r6 = move-exception
            throw r6     // Catch:{ all -> 0x0060 }
        L_0x0060:
            r0 = move-exception
            mb.b.a(r1, r6)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.b.a(e1.j):void");
    }

    @NotNull
    public static final Cursor b(@NotNull u uVar, @NotNull m mVar, boolean z10, CancellationSignal cancellationSignal) {
        Intrinsics.checkNotNullParameter(uVar, "db");
        Intrinsics.checkNotNullParameter(mVar, "sqLiteQuery");
        Cursor x10 = uVar.x(mVar, cancellationSignal);
        if (!z10 || !(x10 instanceof AbstractWindowedCursor)) {
            return x10;
        }
        AbstractWindowedCursor abstractWindowedCursor = (AbstractWindowedCursor) x10;
        int count = abstractWindowedCursor.getCount();
        return (Build.VERSION.SDK_INT < 23 || (abstractWindowedCursor.hasWindow() ? abstractWindowedCursor.getWindow().getNumRows() : count) < count) ? a.a(x10) : x10;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x003d, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x003e, code lost:
        mb.b.a(r8, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0041, code lost:
        throw r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final int c(@org.jetbrains.annotations.NotNull java.io.File r8) throws java.io.IOException {
        /*
            java.lang.String r0 = "databaseFile"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.io.FileInputStream r0 = new java.io.FileInputStream
            r0.<init>(r8)
            java.nio.channels.FileChannel r8 = r0.getChannel()
            r0 = 4
            java.nio.ByteBuffer r7 = java.nio.ByteBuffer.allocate(r0)     // Catch:{ all -> 0x003b }
            r2 = 60
            r4 = 4
            r6 = 1
            r1 = r8
            r1.tryLock(r2, r4, r6)     // Catch:{ all -> 0x003b }
            r1 = 60
            r8.position(r1)     // Catch:{ all -> 0x003b }
            int r1 = r8.read(r7)     // Catch:{ all -> 0x003b }
            if (r1 != r0) goto L_0x0033
            r7.rewind()     // Catch:{ all -> 0x003b }
            int r0 = r7.getInt()     // Catch:{ all -> 0x003b }
            r1 = 0
            mb.b.a(r8, r1)
            return r0
        L_0x0033:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ all -> 0x003b }
            java.lang.String r1 = "Bad database header, unable to read 4 bytes at offset 60"
            r0.<init>(r1)     // Catch:{ all -> 0x003b }
            throw r0     // Catch:{ all -> 0x003b }
        L_0x003b:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x003d }
        L_0x003d:
            r1 = move-exception
            mb.b.a(r8, r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.b.c(java.io.File):int");
    }
}
