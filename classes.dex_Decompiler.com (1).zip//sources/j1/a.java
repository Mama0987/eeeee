package j1;

public interface a {
}
