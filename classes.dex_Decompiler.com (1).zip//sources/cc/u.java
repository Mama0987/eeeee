package cc;

import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class u<E> {
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    public static final a f4766e = new a((DefaultConstructorMarker) null);
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4767f;
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    private static final AtomicLongFieldUpdater f4768g;
    @NotNull

    /* renamed from: h  reason: collision with root package name */
    public static final h0 f4769h = new h0("REMOVE_FROZEN");
    private volatile Object _next;
    private volatile long _state;

    /* renamed from: a  reason: collision with root package name */
    private final int f4770a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f4771b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4772c;
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private final AtomicReferenceArray f4773d;

    @Metadata
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final int a(long j10) {
            return (j10 & 2305843009213693952L) != 0 ? 2 : 1;
        }

        public final long b(long j10, int i10) {
            return d(j10, 1073741823) | (((long) i10) << 0);
        }

        public final long c(long j10, int i10) {
            return d(j10, 1152921503533105152L) | (((long) i10) << 30);
        }

        public final long d(long j10, long j11) {
            return j10 & (~j11);
        }
    }

    @Metadata
    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final int f4774a;

        public b(int i10) {
            this.f4774a = i10;
        }
    }

    static {
        Class<u> cls = u.class;
        f4767f = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "_next");
        f4768g = AtomicLongFieldUpdater.newUpdater(cls, "_state");
    }

    public u(int i10, boolean z10) {
        this.f4770a = i10;
        this.f4771b = z10;
        int i11 = i10 - 1;
        this.f4772c = i11;
        this.f4773d = new AtomicReferenceArray(i10);
        boolean z11 = false;
        if (i11 <= 1073741823) {
            if (!((i10 & i11) == 0 ? true : z11)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            return;
        }
        throw new IllegalStateException("Check failed.".toString());
    }

    private final u<E> b(long j10) {
        u<E> uVar = new u<>(this.f4770a * 2, this.f4771b);
        int i10 = (int) ((1073741823 & j10) >> 0);
        int i11 = (int) ((1152921503533105152L & j10) >> 30);
        while (true) {
            int i12 = this.f4772c;
            if ((i10 & i12) != (i11 & i12)) {
                Object obj = this.f4773d.get(i12 & i10);
                if (obj == null) {
                    obj = new b(i10);
                }
                uVar.f4773d.set(uVar.f4772c & i10, obj);
                i10++;
            } else {
                f4768g.set(uVar, f4766e.d(j10, 1152921504606846976L));
                return uVar;
            }
        }
    }

    private final u<E> c(long j10) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4767f;
        while (true) {
            u<E> uVar = (u) atomicReferenceFieldUpdater.get(this);
            if (uVar != null) {
                return uVar;
            }
            androidx.concurrent.futures.b.a(f4767f, this, (Object) null, b(j10));
        }
    }

    private final u<E> e(int i10, E e10) {
        Object obj = this.f4773d.get(this.f4772c & i10);
        if (!(obj instanceof b) || ((b) obj).f4774a != i10) {
            return null;
        }
        this.f4773d.set(i10 & this.f4772c, e10);
        return this;
    }

    private final long h() {
        long j10;
        long j11;
        AtomicLongFieldUpdater atomicLongFieldUpdater = f4768g;
        do {
            j10 = atomicLongFieldUpdater.get(this);
            if ((j10 & 1152921504606846976L) != 0) {
                return j10;
            }
            j11 = j10 | 1152921504606846976L;
        } while (!atomicLongFieldUpdater.compareAndSet(this, j10, j11));
        return j11;
    }

    private final u<E> k(int i10, int i11) {
        long j10;
        int i12;
        AtomicLongFieldUpdater atomicLongFieldUpdater = f4768g;
        do {
            j10 = atomicLongFieldUpdater.get(this);
            i12 = (int) ((1073741823 & j10) >> 0);
            if ((1152921504606846976L & j10) != 0) {
                return i();
            }
        } while (!f4768g.compareAndSet(this, j10, f4766e.b(j10, i11)));
        this.f4773d.set(this.f4772c & i12, (Object) null);
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x006c A[LOOP:1: B:20:0x006c->B:23:0x0081, LOOP_START, PHI: r0 
      PHI: (r0v3 cc.u) = (r0v2 cc.u), (r0v5 cc.u) binds: [B:19:0x0064, B:23:0x0081] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int a(@org.jetbrains.annotations.NotNull E r14) {
        /*
            r13 = this;
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f4768g
        L_0x0002:
            long r3 = r0.get(r13)
            r1 = 3458764513820540928(0x3000000000000000, double:1.727233711018889E-77)
            long r1 = r1 & r3
            r7 = 0
            int r5 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r5 == 0) goto L_0x0016
            cc.u$a r14 = f4766e
            int r14 = r14.a(r3)
            return r14
        L_0x0016:
            r1 = 1073741823(0x3fffffff, double:5.304989472E-315)
            long r1 = r1 & r3
            r9 = 0
            long r1 = r1 >> r9
            int r2 = (int) r1
            r5 = 1152921503533105152(0xfffffffc0000000, double:1.2882296003504729E-231)
            long r5 = r5 & r3
            r1 = 30
            long r5 = r5 >> r1
            int r10 = (int) r5
            int r11 = r13.f4772c
            int r1 = r10 + 2
            r1 = r1 & r11
            r5 = r2 & r11
            r6 = 1
            if (r1 != r5) goto L_0x0032
            return r6
        L_0x0032:
            boolean r1 = r13.f4771b
            r5 = 1073741823(0x3fffffff, float:1.9999999)
            if (r1 != 0) goto L_0x0051
            java.util.concurrent.atomic.AtomicReferenceArray r1 = r13.f4773d
            r12 = r10 & r11
            java.lang.Object r1 = r1.get(r12)
            if (r1 == 0) goto L_0x0051
            int r1 = r13.f4770a
            r3 = 1024(0x400, float:1.435E-42)
            if (r1 < r3) goto L_0x0050
            int r10 = r10 - r2
            r2 = r10 & r5
            int r1 = r1 >> 1
            if (r2 <= r1) goto L_0x0002
        L_0x0050:
            return r6
        L_0x0051:
            int r1 = r10 + 1
            r1 = r1 & r5
            java.util.concurrent.atomic.AtomicLongFieldUpdater r2 = f4768g
            cc.u$a r5 = f4766e
            long r5 = r5.c(r3, r1)
            r1 = r2
            r2 = r13
            boolean r1 = r1.compareAndSet(r2, r3, r5)
            if (r1 == 0) goto L_0x0002
            java.util.concurrent.atomic.AtomicReferenceArray r0 = r13.f4773d
            r1 = r10 & r11
            r0.set(r1, r14)
            r0 = r13
        L_0x006c:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r1 = f4768g
            long r1 = r1.get(r0)
            r3 = 1152921504606846976(0x1000000000000000, double:1.2882297539194267E-231)
            long r1 = r1 & r3
            int r3 = (r1 > r7 ? 1 : (r1 == r7 ? 0 : -1))
            if (r3 == 0) goto L_0x0083
            cc.u r0 = r0.i()
            cc.u r0 = r0.e(r10, r14)
            if (r0 != 0) goto L_0x006c
        L_0x0083:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: cc.u.a(java.lang.Object):int");
    }

    public final boolean d() {
        long j10;
        AtomicLongFieldUpdater atomicLongFieldUpdater = f4768g;
        do {
            j10 = atomicLongFieldUpdater.get(this);
            if ((j10 & 2305843009213693952L) != 0) {
                return true;
            }
            if ((1152921504606846976L & j10) != 0) {
                return false;
            }
        } while (!atomicLongFieldUpdater.compareAndSet(this, j10, j10 | 2305843009213693952L));
        return true;
    }

    public final int f() {
        long j10 = f4768g.get(this);
        return 1073741823 & (((int) ((j10 & 1152921503533105152L) >> 30)) - ((int) ((1073741823 & j10) >> 0)));
    }

    public final boolean g() {
        long j10 = f4768g.get(this);
        return ((int) ((1073741823 & j10) >> 0)) == ((int) ((j10 & 1152921503533105152L) >> 30));
    }

    @NotNull
    public final u<E> i() {
        return c(h());
    }

    public final Object j() {
        AtomicLongFieldUpdater atomicLongFieldUpdater = f4768g;
        while (true) {
            long j10 = atomicLongFieldUpdater.get(this);
            if ((1152921504606846976L & j10) != 0) {
                return f4769h;
            }
            int i10 = (int) ((1073741823 & j10) >> 0);
            int i11 = (int) ((1152921503533105152L & j10) >> 30);
            int i12 = this.f4772c;
            if ((i11 & i12) == (i10 & i12)) {
                return null;
            }
            Object obj = this.f4773d.get(i12 & i10);
            if (obj == null) {
                if (this.f4771b) {
                    return null;
                }
            } else if (obj instanceof b) {
                return null;
            } else {
                int i13 = (i10 + 1) & 1073741823;
                if (f4768g.compareAndSet(this, j10, f4766e.b(j10, i13))) {
                    this.f4773d.set(this.f4772c & i10, (Object) null);
                    return obj;
                } else if (this.f4771b) {
                    u uVar = this;
                    do {
                        uVar = uVar.k(i10, i13);
                    } while (uVar != null);
                    return obj;
                }
            }
        }
    }
}
