package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class a {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final Object f4711a = new h0("NO_DECISION");
}
