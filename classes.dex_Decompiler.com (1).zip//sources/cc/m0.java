package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class m0 {
    @NotNull
    public static final <T> ThreadLocal<T> a(@NotNull h0 h0Var) {
        return new ThreadLocal<>();
    }
}
