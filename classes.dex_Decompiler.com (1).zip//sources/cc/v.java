package cc;

import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import xb.c2;

@Metadata
public interface v {
    String a();

    @NotNull
    c2 b(@NotNull List<? extends v> list);

    int c();
}
