package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
final class b0 {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public final s f4713a;

    public b0(@NotNull s sVar) {
        this.f4713a = sVar;
    }

    @NotNull
    public String toString() {
        return "Removed[" + this.f4713a + ']';
    }
}
