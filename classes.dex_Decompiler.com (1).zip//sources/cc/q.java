package cc;

import kotlin.Metadata;

@Metadata
public class q extends s {
    public boolean t() {
        return false;
    }
}
