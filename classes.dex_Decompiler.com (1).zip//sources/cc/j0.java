package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
final /* synthetic */ class j0 {

    /* renamed from: a  reason: collision with root package name */
    private static final int f4733a = Runtime.getRuntime().availableProcessors();

    public static final int a() {
        return f4733a;
    }

    public static final String b(@NotNull String str) {
        try {
            return System.getProperty(str);
        } catch (SecurityException unused) {
            return null;
        }
    }
}
