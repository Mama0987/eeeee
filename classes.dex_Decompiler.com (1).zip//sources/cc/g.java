package cc;

import java.util.Collection;
import java.util.ServiceLoader;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import xb.h0;

@Metadata
public final class g {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private static final Collection<h0> f4722a;

    static {
        Class<h0> cls = h0.class;
        f4722a = i.j(g.a(ServiceLoader.load(cls, cls.getClassLoader()).iterator()));
    }

    @NotNull
    public static final Collection<h0> a() {
        return f4722a;
    }

    public static final void b(@NotNull Throwable th) {
        Thread currentThread = Thread.currentThread();
        currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, th);
    }
}
