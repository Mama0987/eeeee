package cc;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class i extends RuntimeException {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final transient CoroutineContext f4727a;

    public i(@NotNull CoroutineContext coroutineContext) {
        this.f4727a = coroutineContext;
    }

    @NotNull
    public Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }

    @NotNull
    public String getLocalizedMessage() {
        return this.f4727a.toString();
    }
}
