package cc;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.d;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import xb.b1;
import xb.m2;

@Metadata
public final class k {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final h0 f4734a = new h0("UNDEFINED");
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    public static final h0 f4735b = new h0("REUSABLE_CLAIMED");

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x008f, code lost:
        if (r8.Y0() != false) goto L_0x0091;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final <T> void b(@org.jetbrains.annotations.NotNull kotlin.coroutines.d<? super T> r6, @org.jetbrains.annotations.NotNull java.lang.Object r7, kotlin.jvm.functions.Function1<? super java.lang.Throwable, kotlin.Unit> r8) {
        /*
            boolean r0 = r6 instanceof cc.j
            if (r0 == 0) goto L_0x00b6
            cc.j r6 = (cc.j) r6
            java.lang.Object r8 = xb.d0.b(r7, r8)
            xb.g0 r0 = r6.f4729d
            kotlin.coroutines.CoroutineContext r1 = r6.a()
            boolean r0 = r0.Q(r1)
            r1 = 1
            if (r0 == 0) goto L_0x0026
            r6.f4731f = r8
            r6.f17653c = r1
            xb.g0 r7 = r6.f4729d
            kotlin.coroutines.CoroutineContext r8 = r6.a()
            r7.h(r8, r6)
            goto L_0x00b9
        L_0x0026:
            xb.m2 r0 = xb.m2.f17630a
            xb.b1 r0 = r0.b()
            boolean r2 = r0.r0()
            if (r2 == 0) goto L_0x003b
            r6.f4731f = r8
            r6.f17653c = r1
            r0.g0(r6)
            goto L_0x00b9
        L_0x003b:
            r0.l0(r1)
            r2 = 0
            kotlin.coroutines.CoroutineContext r3 = r6.a()     // Catch:{ all -> 0x00a9 }
            xb.r1$b r4 = xb.r1.N     // Catch:{ all -> 0x00a9 }
            kotlin.coroutines.CoroutineContext$Element r3 = r3.b(r4)     // Catch:{ all -> 0x00a9 }
            xb.r1 r3 = (xb.r1) r3     // Catch:{ all -> 0x00a9 }
            if (r3 == 0) goto L_0x0069
            boolean r4 = r3.c()     // Catch:{ all -> 0x00a9 }
            if (r4 != 0) goto L_0x0069
            java.util.concurrent.CancellationException r3 = r3.o()     // Catch:{ all -> 0x00a9 }
            r6.b(r8, r3)     // Catch:{ all -> 0x00a9 }
            eb.n$a r8 = eb.n.f10642b     // Catch:{ all -> 0x00a9 }
            java.lang.Object r8 = eb.o.a(r3)     // Catch:{ all -> 0x00a9 }
            java.lang.Object r8 = eb.n.b(r8)     // Catch:{ all -> 0x00a9 }
            r6.j(r8)     // Catch:{ all -> 0x00a9 }
            r8 = 1
            goto L_0x006a
        L_0x0069:
            r8 = 0
        L_0x006a:
            if (r8 != 0) goto L_0x00a2
            kotlin.coroutines.d<T> r8 = r6.f4730e     // Catch:{ all -> 0x00a9 }
            java.lang.Object r3 = r6.f4732g     // Catch:{ all -> 0x00a9 }
            kotlin.coroutines.CoroutineContext r4 = r8.a()     // Catch:{ all -> 0x00a9 }
            java.lang.Object r3 = cc.l0.c(r4, r3)     // Catch:{ all -> 0x00a9 }
            cc.h0 r5 = cc.l0.f4737a     // Catch:{ all -> 0x00a9 }
            if (r3 == r5) goto L_0x0081
            xb.o2 r8 = xb.f0.g(r8, r4, r3)     // Catch:{ all -> 0x00a9 }
            goto L_0x0082
        L_0x0081:
            r8 = r2
        L_0x0082:
            kotlin.coroutines.d<T> r5 = r6.f4730e     // Catch:{ all -> 0x0095 }
            r5.j(r7)     // Catch:{ all -> 0x0095 }
            kotlin.Unit r7 = kotlin.Unit.f12470a     // Catch:{ all -> 0x0095 }
            if (r8 == 0) goto L_0x0091
            boolean r7 = r8.Y0()     // Catch:{ all -> 0x00a9 }
            if (r7 == 0) goto L_0x00a2
        L_0x0091:
            cc.l0.a(r4, r3)     // Catch:{ all -> 0x00a9 }
            goto L_0x00a2
        L_0x0095:
            r7 = move-exception
            if (r8 == 0) goto L_0x009e
            boolean r8 = r8.Y0()     // Catch:{ all -> 0x00a9 }
            if (r8 == 0) goto L_0x00a1
        L_0x009e:
            cc.l0.a(r4, r3)     // Catch:{ all -> 0x00a9 }
        L_0x00a1:
            throw r7     // Catch:{ all -> 0x00a9 }
        L_0x00a2:
            boolean r7 = r0.y0()     // Catch:{ all -> 0x00a9 }
            if (r7 != 0) goto L_0x00a2
            goto L_0x00ad
        L_0x00a9:
            r7 = move-exception
            r6.g(r7, r2)     // Catch:{ all -> 0x00b1 }
        L_0x00ad:
            r0.S(r1)
            goto L_0x00b9
        L_0x00b1:
            r6 = move-exception
            r0.S(r1)
            throw r6
        L_0x00b6:
            r6.j(r7)
        L_0x00b9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: cc.k.b(kotlin.coroutines.d, java.lang.Object, kotlin.jvm.functions.Function1):void");
    }

    public static /* synthetic */ void c(d dVar, Object obj, Function1 function1, int i10, Object obj2) {
        if ((i10 & 2) != 0) {
            function1 = null;
        }
        b(dVar, obj, function1);
    }

    public static final boolean d(@NotNull j<? super Unit> jVar) {
        Unit unit = Unit.f12470a;
        b1 b10 = m2.f17630a.b();
        if (b10.s0()) {
            return false;
        }
        if (b10.r0()) {
            jVar.f4731f = unit;
            jVar.f17653c = 1;
            b10.g0(jVar);
            return true;
        }
        b10.l0(true);
        try {
            jVar.run();
            do {
            } while (b10.y0());
        } catch (Throwable th) {
            b10.S(true);
            throw th;
        }
        b10.S(true);
        return false;
    }
}
