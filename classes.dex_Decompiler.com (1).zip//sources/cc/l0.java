package cc;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import qb.l;
import xb.l2;

@Metadata
public final class l0 {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final h0 f4737a = new h0("NO_THREAD_ELEMENTS");
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final Function2<Object, CoroutineContext.Element, Object> f4738b = a.f4741a;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private static final Function2<l2<?>, CoroutineContext.Element, l2<?>> f4739c = b.f4742a;
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private static final Function2<p0, CoroutineContext.Element, p0> f4740d = c.f4743a;

    @Metadata
    static final class a extends l implements Function2<Object, CoroutineContext.Element, Object> {

        /* renamed from: a  reason: collision with root package name */
        public static final a f4741a = new a();

        a() {
            super(2);
        }

        /* renamed from: a */
        public final Object k(Object obj, @NotNull CoroutineContext.Element element) {
            if (!(element instanceof l2)) {
                return obj;
            }
            Integer num = obj instanceof Integer ? (Integer) obj : null;
            int intValue = num != null ? num.intValue() : 1;
            return intValue == 0 ? element : Integer.valueOf(intValue + 1);
        }
    }

    @Metadata
    static final class b extends l implements Function2<l2<?>, CoroutineContext.Element, l2<?>> {

        /* renamed from: a  reason: collision with root package name */
        public static final b f4742a = new b();

        b() {
            super(2);
        }

        /* renamed from: a */
        public final l2<?> k(l2<?> l2Var, @NotNull CoroutineContext.Element element) {
            if (l2Var != null) {
                return l2Var;
            }
            if (element instanceof l2) {
                return (l2) element;
            }
            return null;
        }
    }

    @Metadata
    static final class c extends l implements Function2<p0, CoroutineContext.Element, p0> {

        /* renamed from: a  reason: collision with root package name */
        public static final c f4743a = new c();

        c() {
            super(2);
        }

        @NotNull
        /* renamed from: a */
        public final p0 k(@NotNull p0 p0Var, @NotNull CoroutineContext.Element element) {
            if (element instanceof l2) {
                l2 l2Var = (l2) element;
                p0Var.a(l2Var, l2Var.P(p0Var.f4755a));
            }
            return p0Var;
        }
    }

    public static final void a(@NotNull CoroutineContext coroutineContext, Object obj) {
        if (obj != f4737a) {
            if (obj instanceof p0) {
                ((p0) obj).b(coroutineContext);
                return;
            }
            Object K = coroutineContext.K(null, f4739c);
            Intrinsics.d(K, "null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
            ((l2) K).B(coroutineContext, obj);
        }
    }

    @NotNull
    public static final Object b(@NotNull CoroutineContext coroutineContext) {
        Object K = coroutineContext.K(0, f4738b);
        Intrinsics.c(K);
        return K;
    }

    public static final Object c(@NotNull CoroutineContext coroutineContext, Object obj) {
        if (obj == null) {
            obj = b(coroutineContext);
        }
        if (obj == 0) {
            return f4737a;
        }
        if (obj instanceof Integer) {
            return coroutineContext.K(new p0(coroutineContext, ((Number) obj).intValue()), f4740d);
        }
        Intrinsics.d(obj, "null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
        return ((l2) obj).P(coroutineContext);
    }
}
