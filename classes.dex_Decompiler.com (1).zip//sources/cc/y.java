package cc;

import eb.e;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.NotNull;
import xb.c2;
import xb.s0;

@Metadata
final class y extends c2 implements s0 {

    /* renamed from: c  reason: collision with root package name */
    private final Throwable f4779c;

    /* renamed from: d  reason: collision with root package name */
    private final String f4780d;

    public y(Throwable th, String str) {
        this.f4779c = th;
        this.f4780d = str;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0023, code lost:
        if (r1 == null) goto L_0x0025;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final java.lang.Void g0() {
        /*
            r4 = this;
            java.lang.Throwable r0 = r4.f4779c
            if (r0 == 0) goto L_0x0036
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Module with the Main dispatcher had failed to initialize"
            r0.append(r1)
            java.lang.String r1 = r4.f4780d
            if (r1 == 0) goto L_0x0025
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = ". "
            r2.append(r3)
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            if (r1 != 0) goto L_0x0027
        L_0x0025:
            java.lang.String r1 = ""
        L_0x0027:
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.Throwable r2 = r4.f4779c
            r1.<init>(r0, r2)
            throw r1
        L_0x0036:
            cc.x.d()
            eb.e r0 = new eb.e
            r0.<init>()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: cc.y.g0():java.lang.Void");
    }

    public boolean Q(@NotNull CoroutineContext coroutineContext) {
        g0();
        throw new e();
    }

    @NotNull
    public c2 S() {
        return this;
    }

    @NotNull
    /* renamed from: e0 */
    public Void h(@NotNull CoroutineContext coroutineContext, @NotNull Runnable runnable) {
        g0();
        throw new e();
    }

    @NotNull
    public String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Dispatchers.Main[missing");
        if (this.f4779c != null) {
            str = ", cause=" + this.f4779c;
        } else {
            str = "";
        }
        sb2.append(str);
        sb2.append(']');
        return sb2.toString();
    }
}
