package cc;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.NotNull;
import xb.j0;

@Metadata
public final class f implements j0 {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final CoroutineContext f4721a;

    public f(@NotNull CoroutineContext coroutineContext) {
        this.f4721a = coroutineContext;
    }

    @NotNull
    public String toString() {
        return "CoroutineScope(coroutineContext=" + x() + ')';
    }

    @NotNull
    public CoroutineContext x() {
        return this.f4721a;
    }
}
