package cc;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.g;
import org.jetbrains.annotations.NotNull;
import xb.g0;
import xb.i0;
import xb.p0;
import xb.s0;

@Metadata
public final class o extends g0 implements s0 {
    @NotNull

    /* renamed from: h  reason: collision with root package name */
    private static final AtomicIntegerFieldUpdater f4747h = AtomicIntegerFieldUpdater.newUpdater(o.class, "runningWorkers");
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    public final g0 f4748c;

    /* renamed from: d  reason: collision with root package name */
    private final int f4749d;

    /* renamed from: e  reason: collision with root package name */
    private final /* synthetic */ s0 f4750e;
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private final t<Runnable> f4751f;
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    private final Object f4752g;
    private volatile int runningWorkers;

    @Metadata
    private final class a implements Runnable {
        @NotNull

        /* renamed from: a  reason: collision with root package name */
        private Runnable f4753a;

        public a(@NotNull Runnable runnable) {
            this.f4753a = runnable;
        }

        public void run() {
            int i10 = 0;
            while (true) {
                try {
                    this.f4753a.run();
                } catch (Throwable th) {
                    i0.a(g.f12515a, th);
                }
                Runnable c02 = o.this.e0();
                if (c02 != null) {
                    this.f4753a = c02;
                    i10++;
                    if (i10 >= 16 && o.this.f4748c.Q(o.this)) {
                        o.this.f4748c.h(o.this, this);
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    public o(@NotNull g0 g0Var, int i10) {
        this.f4748c = g0Var;
        this.f4749d = i10;
        s0 s0Var = g0Var instanceof s0 ? (s0) g0Var : null;
        this.f4750e = s0Var == null ? p0.a() : s0Var;
        this.f4751f = new t<>(false);
        this.f4752g = new Object();
    }

    /* access modifiers changed from: private */
    public final Runnable e0() {
        while (true) {
            Runnable d10 = this.f4751f.d();
            if (d10 != null) {
                return d10;
            }
            synchronized (this.f4752g) {
                AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f4747h;
                atomicIntegerFieldUpdater.decrementAndGet(this);
                if (this.f4751f.c() == 0) {
                    return null;
                }
                atomicIntegerFieldUpdater.incrementAndGet(this);
            }
        }
    }

    private final boolean g0() {
        synchronized (this.f4752g) {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f4747h;
            if (atomicIntegerFieldUpdater.get(this) >= this.f4749d) {
                return false;
            }
            atomicIntegerFieldUpdater.incrementAndGet(this);
            return true;
        }
    }

    public void h(@NotNull CoroutineContext coroutineContext, @NotNull Runnable runnable) {
        Runnable e02;
        this.f4751f.a(runnable);
        if (f4747h.get(this) < this.f4749d && g0() && (e02 = e0()) != null) {
            this.f4748c.h(this, new a(e02));
        }
    }

    public void s(@NotNull CoroutineContext coroutineContext, @NotNull Runnable runnable) {
        Runnable e02;
        this.f4751f.a(runnable);
        if (f4747h.get(this) < this.f4749d && g0() && (e02 = e0()) != null) {
            this.f4748c.s(this, new a(e02));
        }
    }
}
