package cc;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import qb.l;
import xb.i0;

@Metadata
public final class z {

    @Metadata
    static final class a extends l implements Function1<Throwable, Unit> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Function1<E, Unit> f4781a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ E f4782b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ CoroutineContext f4783c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(Function1<? super E, Unit> function1, E e10, CoroutineContext coroutineContext) {
            super(1);
            this.f4781a = function1;
            this.f4782b = e10;
            this.f4783c = coroutineContext;
        }

        public final void a(@NotNull Throwable th) {
            z.b(this.f4781a, this.f4782b, this.f4783c);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((Throwable) obj);
            return Unit.f12470a;
        }
    }

    @NotNull
    public static final <E> Function1<Throwable, Unit> a(@NotNull Function1<? super E, Unit> function1, E e10, @NotNull CoroutineContext coroutineContext) {
        return new a(function1, e10, coroutineContext);
    }

    public static final <E> void b(@NotNull Function1<? super E, Unit> function1, E e10, @NotNull CoroutineContext coroutineContext) {
        q0 c10 = c(function1, e10, (q0) null);
        if (c10 != null) {
            i0.a(coroutineContext, c10);
        }
    }

    public static final <E> q0 c(@NotNull Function1<? super E, Unit> function1, E e10, q0 q0Var) {
        try {
            function1.invoke(e10);
        } catch (Throwable th) {
            if (q0Var == null || q0Var.getCause() == th) {
                return new q0("Exception in undelivered element handler for " + e10, th);
            }
            b.a(q0Var, th);
        }
        return q0Var;
    }

    public static /* synthetic */ q0 d(Function1 function1, Object obj, q0 q0Var, int i10, Object obj2) {
        if ((i10 & 2) != 0) {
            q0Var = null;
        }
        return c(function1, obj, q0Var);
    }
}
