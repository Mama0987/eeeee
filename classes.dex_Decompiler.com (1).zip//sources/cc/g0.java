package cc;

import a.a;
import eb.n;
import eb.o;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class g0 {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private static final StackTraceElement f4723a = new a().a();

    /* renamed from: b  reason: collision with root package name */
    private static final String f4724b;

    /* renamed from: c  reason: collision with root package name */
    private static final String f4725c;

    static {
        Object obj;
        Object obj2;
        try {
            n.a aVar = n.f10642b;
            obj = n.b(ib.a.class.getCanonicalName());
        } catch (Throwable th) {
            n.a aVar2 = n.f10642b;
            obj = n.b(o.a(th));
        }
        if (n.d(obj) != null) {
            obj = "kotlin.coroutines.jvm.internal.BaseContinuationImpl";
        }
        f4724b = (String) obj;
        try {
            obj2 = n.b(g0.class.getCanonicalName());
        } catch (Throwable th2) {
            n.a aVar3 = n.f10642b;
            obj2 = n.b(o.a(th2));
        }
        if (n.d(obj2) != null) {
            obj2 = "kotlinx.coroutines.internal.StackTraceRecoveryKt";
        }
        f4725c = (String) obj2;
    }

    @NotNull
    public static final <E extends Throwable> E a(@NotNull E e10) {
        return e10;
    }
}
