package cc;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import qb.r;
import xb.n0;

@Metadata
public class s {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final AtomicReferenceFieldUpdater f4760a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4761b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4762c;
    private volatile Object _next = this;
    private volatile Object _prev = this;
    private volatile Object _removedRef;

    @Metadata
    public static abstract class a extends b<s> {
        @NotNull

        /* renamed from: b  reason: collision with root package name */
        public final s f4763b;

        /* renamed from: c  reason: collision with root package name */
        public s f4764c;

        public a(@NotNull s sVar) {
            this.f4763b = sVar;
        }

        /* renamed from: e */
        public void b(@NotNull s sVar, Object obj) {
            boolean z10 = obj == null;
            s sVar2 = z10 ? this.f4763b : this.f4764c;
            if (sVar2 != null && androidx.concurrent.futures.b.a(s.f4760a, sVar, this, sVar2) && z10) {
                s sVar3 = this.f4763b;
                s sVar4 = this.f4764c;
                Intrinsics.c(sVar4);
                sVar3.p(sVar4);
            }
        }
    }

    @Metadata
    /* synthetic */ class b extends r {
        b(Object obj) {
            super(obj, n0.class, "classSimpleName", "getClassSimpleName(Ljava/lang/Object;)Ljava/lang/String;", 1);
        }

        public Object get() {
            return n0.a(this.f14421b);
        }
    }

    static {
        Class<s> cls = s.class;
        Class<Object> cls2 = Object.class;
        f4760a = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_next");
        f4761b = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_prev");
        f4762c = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_removedRef");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v0, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: cc.s} */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        if (androidx.concurrent.futures.b.a(r4, r3, r2, ((cc.b0) r5).f4713a) != false) goto L_0x0045;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final cc.s n(cc.a0 r9) {
        /*
            r8 = this;
        L_0x0000:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r0 = f4761b
            java.lang.Object r0 = r0.get(r8)
            cc.s r0 = (cc.s) r0
            r1 = 0
            r2 = r0
        L_0x000a:
            r3 = r1
        L_0x000b:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = f4760a
            java.lang.Object r5 = r4.get(r2)
            if (r5 != r8) goto L_0x0020
            if (r0 != r2) goto L_0x0016
            return r2
        L_0x0016:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r1 = f4761b
            boolean r0 = androidx.concurrent.futures.b.a(r1, r8, r0, r2)
            if (r0 != 0) goto L_0x001f
            goto L_0x0000
        L_0x001f:
            return r2
        L_0x0020:
            boolean r6 = r8.t()
            if (r6 == 0) goto L_0x0027
            return r1
        L_0x0027:
            if (r5 != r9) goto L_0x002a
            return r2
        L_0x002a:
            boolean r6 = r5 instanceof cc.a0
            if (r6 == 0) goto L_0x0034
            cc.a0 r5 = (cc.a0) r5
            r5.a(r2)
            goto L_0x0000
        L_0x0034:
            boolean r6 = r5 instanceof cc.b0
            if (r6 == 0) goto L_0x0050
            if (r3 == 0) goto L_0x0047
            cc.b0 r5 = (cc.b0) r5
            cc.s r5 = r5.f4713a
            boolean r2 = androidx.concurrent.futures.b.a(r4, r3, r2, r5)
            if (r2 != 0) goto L_0x0045
            goto L_0x0000
        L_0x0045:
            r2 = r3
            goto L_0x000a
        L_0x0047:
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = f4761b
            java.lang.Object r2 = r4.get(r2)
            cc.s r2 = (cc.s) r2
            goto L_0x000b
        L_0x0050:
            java.lang.String r3 = "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }"
            kotlin.jvm.internal.Intrinsics.d(r5, r3)
            r3 = r5
            cc.s r3 = (cc.s) r3
            r7 = r3
            r3 = r2
            r2 = r7
            goto L_0x000b
        */
        throw new UnsupportedOperationException("Method not decompiled: cc.s.n(cc.a0):cc.s");
    }

    private final s o(s sVar) {
        while (sVar.t()) {
            sVar = (s) f4761b.get(sVar);
        }
        return sVar;
    }

    /* access modifiers changed from: private */
    public final void p(s sVar) {
        s sVar2;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4761b;
        do {
            sVar2 = (s) atomicReferenceFieldUpdater.get(sVar);
            if (q() != sVar) {
                return;
            }
        } while (!androidx.concurrent.futures.b.a(f4761b, sVar, sVar2, this));
        if (t()) {
            sVar.n((a0) null);
        }
    }

    private final b0 w() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4762c;
        b0 b0Var = (b0) atomicReferenceFieldUpdater.get(this);
        if (b0Var != null) {
            return b0Var;
        }
        b0 b0Var2 = new b0(this);
        atomicReferenceFieldUpdater.lazySet(this, b0Var2);
        return b0Var2;
    }

    public final boolean m(@NotNull s sVar) {
        f4761b.lazySet(sVar, this);
        f4760a.lazySet(sVar, this);
        while (q() == this) {
            if (androidx.concurrent.futures.b.a(f4760a, this, this, sVar)) {
                sVar.p(this);
                return true;
            }
        }
        return false;
    }

    @NotNull
    public final Object q() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4760a;
        while (true) {
            Object obj = atomicReferenceFieldUpdater.get(this);
            if (!(obj instanceof a0)) {
                return obj;
            }
            ((a0) obj).a(this);
        }
    }

    @NotNull
    public final s r() {
        return r.b(q());
    }

    @NotNull
    public final s s() {
        s n10 = n((a0) null);
        return n10 == null ? o((s) f4761b.get(this)) : n10;
    }

    public boolean t() {
        return q() instanceof b0;
    }

    @NotNull
    public String toString() {
        return new b(this) + '@' + n0.b(this);
    }

    public boolean u() {
        return v() == null;
    }

    public final s v() {
        Object q10;
        s sVar;
        do {
            q10 = q();
            if (q10 instanceof b0) {
                return ((b0) q10).f4713a;
            }
            if (q10 == this) {
                return (s) q10;
            }
            Intrinsics.d(q10, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
            sVar = (s) q10;
        } while (!androidx.concurrent.futures.b.a(f4760a, this, q10, sVar.w()));
        sVar.n((a0) null);
        return null;
    }

    public final int x(@NotNull s sVar, @NotNull s sVar2, @NotNull a aVar) {
        f4761b.lazySet(sVar, this);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4760a;
        atomicReferenceFieldUpdater.lazySet(sVar, sVar2);
        aVar.f4764c = sVar2;
        if (!androidx.concurrent.futures.b.a(atomicReferenceFieldUpdater, this, sVar2, aVar)) {
            return 0;
        }
        return aVar.a(this) == null ? 1 : 2;
    }
}
