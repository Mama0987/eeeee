package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class i0 {
    public static final int a() {
        return j0.a();
    }

    public static final int b(@NotNull String str, int i10, int i11, int i12) {
        return k0.a(str, i10, i11, i12);
    }

    public static final long c(@NotNull String str, long j10, long j11, long j12) {
        return k0.b(str, j10, j11, j12);
    }

    public static final String d(@NotNull String str) {
        return j0.b(str);
    }

    @NotNull
    public static final String e(@NotNull String str, @NotNull String str2) {
        return k0.c(str, str2);
    }

    public static final boolean f(@NotNull String str, boolean z10) {
        return k0.d(str, z10);
    }
}
