package cc;

import eb.n;
import eb.o;
import kotlin.Metadata;

@Metadata
public final class m {

    /* renamed from: a  reason: collision with root package name */
    private static final boolean f4744a;

    static {
        Object obj;
        try {
            n.a aVar = n.f10642b;
            obj = n.b(Class.forName("android.os.Build"));
        } catch (Throwable th) {
            n.a aVar2 = n.f10642b;
            obj = n.b(o.a(th));
        }
        f4744a = n.g(obj);
    }

    public static final boolean a() {
        return f4744a;
    }
}
