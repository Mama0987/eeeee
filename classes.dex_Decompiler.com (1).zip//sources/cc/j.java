package cc;

import androidx.concurrent.futures.b;
import ib.e;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.d;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import xb.a0;
import xb.b1;
import xb.d0;
import xb.g0;
import xb.l;
import xb.m;
import xb.m2;
import xb.n0;
import xb.u0;

@Metadata
public final class j<T> extends u0<T> implements e, d<T> {
    @NotNull

    /* renamed from: h  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4728h = AtomicReferenceFieldUpdater.newUpdater(j.class, Object.class, "_reusableCancellableContinuation");
    private volatile Object _reusableCancellableContinuation;
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    public final g0 f4729d;
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    public final d<T> f4730e;

    /* renamed from: f  reason: collision with root package name */
    public Object f4731f = k.f4734a;
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    public final Object f4732g = l0.b(a());

    public j(@NotNull g0 g0Var, @NotNull d<? super T> dVar) {
        super(-1);
        this.f4729d = g0Var;
        this.f4730e = dVar;
    }

    private final m<?> n() {
        Object obj = f4728h.get(this);
        if (obj instanceof m) {
            return (m) obj;
        }
        return null;
    }

    @NotNull
    public CoroutineContext a() {
        return this.f4730e.a();
    }

    public void b(Object obj, @NotNull Throwable th) {
        if (obj instanceof a0) {
            ((a0) obj).f17586b.invoke(th);
        }
    }

    @NotNull
    public d<T> d() {
        return this;
    }

    public e h() {
        d<T> dVar = this.f4730e;
        if (dVar instanceof e) {
            return (e) dVar;
        }
        return null;
    }

    public Object i() {
        Object obj = this.f4731f;
        this.f4731f = k.f4734a;
        return obj;
    }

    public void j(@NotNull Object obj) {
        CoroutineContext a10;
        Object c10;
        CoroutineContext a11 = this.f4730e.a();
        Object d10 = d0.d(obj, (Function1) null, 1, (Object) null);
        if (this.f4729d.Q(a11)) {
            this.f4731f = d10;
            this.f17653c = 0;
            this.f4729d.h(a11, this);
            return;
        }
        b1 b10 = m2.f17630a.b();
        if (b10.r0()) {
            this.f4731f = d10;
            this.f17653c = 0;
            b10.g0(this);
            return;
        }
        b10.l0(true);
        try {
            a10 = a();
            c10 = l0.c(a10, this.f4732g);
            this.f4730e.j(obj);
            Unit unit = Unit.f12470a;
            l0.a(a10, c10);
            do {
            } while (b10.y0());
        } catch (Throwable th) {
            try {
                g(th, (Throwable) null);
            } catch (Throwable th2) {
                b10.S(true);
                throw th2;
            }
        }
        b10.S(true);
    }

    public final void k() {
        do {
        } while (f4728h.get(this) == k.f4735b);
    }

    public final m<T> l() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4728h;
        while (true) {
            Object obj = atomicReferenceFieldUpdater.get(this);
            if (obj == null) {
                f4728h.set(this, k.f4735b);
                return null;
            } else if (obj instanceof m) {
                if (b.a(f4728h, this, obj, k.f4735b)) {
                    return (m) obj;
                }
            } else if (obj != k.f4735b && !(obj instanceof Throwable)) {
                throw new IllegalStateException(("Inconsistent state " + obj).toString());
            }
        }
    }

    public final void m(@NotNull CoroutineContext coroutineContext, T t10) {
        this.f4731f = t10;
        this.f17653c = 1;
        this.f4729d.s(coroutineContext, this);
    }

    public final boolean o() {
        return f4728h.get(this) != null;
    }

    public final boolean p(@NotNull Throwable th) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4728h;
        while (true) {
            Object obj = atomicReferenceFieldUpdater.get(this);
            h0 h0Var = k.f4735b;
            if (Intrinsics.a(obj, h0Var)) {
                if (b.a(f4728h, this, h0Var, th)) {
                    return true;
                }
            } else if (obj instanceof Throwable) {
                return true;
            } else {
                if (b.a(f4728h, this, obj, (Object) null)) {
                    return false;
                }
            }
        }
    }

    public final void q() {
        k();
        m<?> n10 = n();
        if (n10 != null) {
            n10.p();
        }
    }

    public final Throwable r(@NotNull l<?> lVar) {
        h0 h0Var;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4728h;
        do {
            Object obj = atomicReferenceFieldUpdater.get(this);
            h0Var = k.f4735b;
            if (obj != h0Var) {
                if (!(obj instanceof Throwable)) {
                    throw new IllegalStateException(("Inconsistent state " + obj).toString());
                } else if (b.a(f4728h, this, obj, (Object) null)) {
                    return (Throwable) obj;
                } else {
                    throw new IllegalArgumentException("Failed requirement.".toString());
                }
            }
        } while (!b.a(f4728h, this, h0Var, lVar));
        return null;
    }

    @NotNull
    public String toString() {
        return "DispatchedContinuation[" + this.f4729d + ", " + n0.c(this.f4730e) + ']';
    }
}
