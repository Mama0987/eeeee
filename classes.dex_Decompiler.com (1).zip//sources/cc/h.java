package cc;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.NotNull;
import xb.h0;
import xb.i0;

@Metadata
public final class h {
    public static final void a(@NotNull CoroutineContext coroutineContext, @NotNull Throwable th) {
        for (h0 N : g.a()) {
            try {
                N.N(coroutineContext, th);
            } catch (Throwable th2) {
                g.b(i0.b(th, th2));
            }
        }
        try {
            b.a(th, new i(coroutineContext));
        } catch (Throwable unused) {
        }
        g.b(th);
    }
}
