package cc;

import androidx.concurrent.futures.b;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public class t<E> {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4765a = AtomicReferenceFieldUpdater.newUpdater(t.class, Object.class, "_cur");
    private volatile Object _cur;

    public t(boolean z10) {
        this._cur = new u(8, z10);
    }

    public final boolean a(@NotNull E e10) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4765a;
        while (true) {
            u uVar = (u) atomicReferenceFieldUpdater.get(this);
            int a10 = uVar.a(e10);
            if (a10 == 0) {
                return true;
            }
            if (a10 == 1) {
                b.a(f4765a, this, uVar, uVar.i());
            } else if (a10 == 2) {
                return false;
            }
        }
    }

    public final void b() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4765a;
        while (true) {
            u uVar = (u) atomicReferenceFieldUpdater.get(this);
            if (!uVar.d()) {
                b.a(f4765a, this, uVar, uVar.i());
            } else {
                return;
            }
        }
    }

    public final int c() {
        return ((u) f4765a.get(this)).f();
    }

    public final E d() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4765a;
        while (true) {
            u uVar = (u) atomicReferenceFieldUpdater.get(this);
            E j10 = uVar.j();
            if (j10 != u.f4769h) {
                return j10;
            }
            b.a(f4765a, this, uVar, uVar.i());
        }
    }
}
