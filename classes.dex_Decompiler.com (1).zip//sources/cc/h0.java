package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class h0 {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public final String f4726a;

    public h0(@NotNull String str) {
        this.f4726a = str;
    }

    @NotNull
    public String toString() {
        return '<' + this.f4726a + '>';
    }
}
