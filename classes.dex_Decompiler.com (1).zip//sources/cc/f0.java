package cc;

import cc.e0;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class f0<S extends e0<S>> {
    @NotNull
    public static <S extends e0<S>> Object a(Object obj) {
        return obj;
    }

    @NotNull
    public static final S b(Object obj) {
        if (obj != d.f4715a) {
            Intrinsics.d(obj, "null cannot be cast to non-null type S of kotlinx.coroutines.internal.SegmentOrClosed");
            return (e0) obj;
        }
        throw new IllegalStateException("Does not contain segment".toString());
    }

    public static final boolean c(Object obj) {
        return obj == d.f4715a;
    }
}
