package cc;

import androidx.concurrent.futures.b;
import cc.e;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public abstract class e<N extends e<N>> {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4717a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f4718b;
    private volatile Object _next;
    private volatile Object _prev;

    static {
        Class<e> cls = e.class;
        Class<Object> cls2 = Object.class;
        f4717a = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_next");
        f4718b = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_prev");
    }

    public e(N n10) {
        this._prev = n10;
    }

    private final N c() {
        N g10 = g();
        while (g10 != null && g10.h()) {
            g10 = (e) f4718b.get(g10);
        }
        return g10;
    }

    private final N d() {
        N e10;
        N e11 = e();
        Intrinsics.c(e11);
        while (e11.h() && (e10 = e11.e()) != null) {
            e11 = e10;
        }
        return e11;
    }

    /* access modifiers changed from: private */
    public final Object f() {
        return f4717a.get(this);
    }

    public final void b() {
        f4718b.lazySet(this, (Object) null);
    }

    public final N e() {
        N a10 = f();
        if (a10 == d.f4715a) {
            return null;
        }
        return (e) a10;
    }

    public final N g() {
        return (e) f4718b.get(this);
    }

    public abstract boolean h();

    public final boolean i() {
        return e() == null;
    }

    public final boolean j() {
        return b.a(f4717a, this, (Object) null, d.f4715a);
    }

    public final void k() {
        Object obj;
        if (!i()) {
            while (true) {
                e c10 = c();
                e d10 = d();
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f4718b;
                do {
                    obj = atomicReferenceFieldUpdater.get(d10);
                } while (!b.a(atomicReferenceFieldUpdater, d10, obj, ((e) obj) == null ? null : c10));
                if (c10 != null) {
                    f4717a.set(c10, d10);
                }
                if ((!d10.h() || d10.i()) && (c10 == null || !c10.h())) {
                    return;
                }
            }
        }
    }

    public final boolean l(@NotNull N n10) {
        return b.a(f4717a, this, (Object) null, n10);
    }
}
