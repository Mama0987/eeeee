package cc;

import ib.e;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.d;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import xb.a;

@Metadata
public class d0<T> extends a<T> implements e {
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    public final d<T> f4716d;

    public d0(@NotNull CoroutineContext coroutineContext, @NotNull d<? super T> dVar) {
        super(coroutineContext, true, true);
        this.f4716d = dVar;
    }

    /* access modifiers changed from: protected */
    public void T(Object obj) {
        k.c(c.b(this.f4716d), xb.d0.a(obj, this.f4716d), (Function1) null, 2, (Object) null);
    }

    /* access modifiers changed from: protected */
    public void U0(Object obj) {
        d<T> dVar = this.f4716d;
        dVar.j(xb.d0.a(obj, dVar));
    }

    public final e h() {
        d<T> dVar = this.f4716d;
        if (dVar instanceof e) {
            return (e) dVar;
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public final boolean u0() {
        return true;
    }
}
