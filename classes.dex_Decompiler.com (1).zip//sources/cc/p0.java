package cc;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import xb.l2;

@Metadata
final class p0 {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public final CoroutineContext f4755a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private final Object[] f4756b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private final l2<Object>[] f4757c;

    /* renamed from: d  reason: collision with root package name */
    private int f4758d;

    public p0(@NotNull CoroutineContext coroutineContext, int i10) {
        this.f4755a = coroutineContext;
        this.f4756b = new Object[i10];
        this.f4757c = new l2[i10];
    }

    public final void a(@NotNull l2<?> l2Var, Object obj) {
        Object[] objArr = this.f4756b;
        int i10 = this.f4758d;
        objArr[i10] = obj;
        l2<Object>[] l2VarArr = this.f4757c;
        this.f4758d = i10 + 1;
        Intrinsics.d(l2Var, "null cannot be cast to non-null type kotlinx.coroutines.ThreadContextElement<kotlin.Any?>");
        l2VarArr[i10] = l2Var;
    }

    public final void b(@NotNull CoroutineContext coroutineContext) {
        int length = this.f4757c.length - 1;
        if (length >= 0) {
            while (true) {
                int i10 = length - 1;
                l2<Object> l2Var = this.f4757c[length];
                Intrinsics.c(l2Var);
                l2Var.B(coroutineContext, this.f4756b[length]);
                if (i10 >= 0) {
                    length = i10;
                } else {
                    return;
                }
            }
        }
    }
}
