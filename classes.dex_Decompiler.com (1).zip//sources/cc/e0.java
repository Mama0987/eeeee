package cc;

import cc.e0;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.NotNull;
import xb.f2;

@Metadata
public abstract class e0<S extends e0<S>> extends e<S> implements f2 {
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private static final AtomicIntegerFieldUpdater f4719d = AtomicIntegerFieldUpdater.newUpdater(e0.class, "cleanedAndPointers");

    /* renamed from: c  reason: collision with root package name */
    public final long f4720c;
    private volatile int cleanedAndPointers;

    public e0(long j10, S s10, int i10) {
        super(s10);
        this.f4720c = j10;
        this.cleanedAndPointers = i10 << 16;
    }

    public boolean h() {
        return f4719d.get(this) == n() && !i();
    }

    public final boolean m() {
        return f4719d.addAndGet(this, -65536) == n() && !i();
    }

    public abstract int n();

    public abstract void o(int i10, Throwable th, @NotNull CoroutineContext coroutineContext);

    public final void p() {
        if (f4719d.incrementAndGet(this) == n()) {
            k();
        }
    }

    public final boolean q() {
        int i10;
        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f4719d;
        do {
            i10 = atomicIntegerFieldUpdater.get(this);
            if (!(i10 != n() || i())) {
                return false;
            }
        } while (!atomicIntegerFieldUpdater.compareAndSet(this, i10, 65536 + i10));
        return true;
    }
}
