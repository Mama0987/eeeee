package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class q0 extends RuntimeException {
    public q0(@NotNull String str, @NotNull Throwable th) {
        super(str, th);
    }
}
