package cc;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import xb.n0;

@Metadata
public abstract class a0 {
    public abstract Object a(Object obj);

    @NotNull
    public String toString() {
        return n0.a(this) + '@' + n0.b(this);
    }
}
