package cc;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class r {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private static final Object f4759a = new h0("CONDITION_FALSE");

    @NotNull
    public static final Object a() {
        return f4759a;
    }

    @NotNull
    public static final s b(@NotNull Object obj) {
        s sVar;
        b0 b0Var = obj instanceof b0 ? (b0) obj : null;
        if (b0Var != null && (sVar = b0Var.f4713a) != null) {
            return sVar;
        }
        Intrinsics.d(obj, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
        return (s) obj;
    }
}
