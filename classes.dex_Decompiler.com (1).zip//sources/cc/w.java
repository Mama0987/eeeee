package cc;

import java.util.Iterator;
import java.util.List;
import java.util.ServiceLoader;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import xb.c2;

@Metadata
public final class w {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final w f4775a;

    /* renamed from: b  reason: collision with root package name */
    private static final boolean f4776b = i0.f("kotlinx.coroutines.fast.service.loader", true);
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    public static final c2 f4777c;

    static {
        w wVar = new w();
        f4775a = wVar;
        f4777c = wVar.a();
    }

    private w() {
    }

    private final c2 a() {
        Object obj;
        c2 e10;
        Class<v> cls = v.class;
        try {
            List<v> c10 = f4776b ? l.f4736a.c() : i.j(g.a(ServiceLoader.load(cls, cls.getClassLoader()).iterator()));
            Iterator it = c10.iterator();
            if (!it.hasNext()) {
                obj = null;
            } else {
                obj = it.next();
                if (it.hasNext()) {
                    int c11 = ((v) obj).c();
                    do {
                        Object next = it.next();
                        int c12 = ((v) next).c();
                        if (c11 < c12) {
                            obj = next;
                            c11 = c12;
                        }
                    } while (it.hasNext());
                }
            }
            v vVar = (v) obj;
            return (vVar == null || (e10 = x.e(vVar, c10)) == null) ? x.b((Throwable) null, (String) null, 3, (Object) null) : e10;
        } catch (Throwable th) {
            return x.b(th, (String) null, 2, (Object) null);
        }
    }
}
