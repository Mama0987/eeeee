package cc;

import kotlin.Metadata;

@Metadata
public interface o0 {
    n0<?> g();

    int getIndex();

    void h(n0<?> n0Var);

    void setIndex(int i10);
}
