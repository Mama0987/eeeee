package j4;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f11876a = 0;

    /* renamed from: j4.a$a  reason: collision with other inner class name */
    public interface C0185a {
    }

    private a() {
    }
}
