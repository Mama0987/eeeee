package fc;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import org.jetbrains.annotations.NotNull;

@Metadata
public interface b<R> {
    @NotNull
    CoroutineContext a();

    boolean e(@NotNull Object obj, Object obj2);

    void h(Object obj);
}
