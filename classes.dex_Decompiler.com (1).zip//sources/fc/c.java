package fc;

import cc.h0;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;
import pb.n;
import qb.l;

@Metadata
public final class c {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private static final n<Object, Object, Object, Object> f10962a = a.f10968a;
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    public static final h0 f10963b = new h0("STATE_REG");
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    public static final h0 f10964c = new h0("STATE_COMPLETED");
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    public static final h0 f10965d = new h0("STATE_CANCELLED");
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    public static final h0 f10966e = new h0("NO_RESULT");
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private static final h0 f10967f = new h0("PARAM_CLAUSE_0");

    @Metadata
    static final class a extends l implements n {

        /* renamed from: a  reason: collision with root package name */
        public static final a f10968a = new a();

        a() {
            super(3);
        }

        /* renamed from: a */
        public final Void d(@NotNull Object obj, Object obj2, Object obj3) {
            return null;
        }
    }

    /* access modifiers changed from: private */
    public static final d a(int i10) {
        if (i10 == 0) {
            return d.SUCCESSFUL;
        }
        if (i10 == 1) {
            return d.REREGISTER;
        }
        if (i10 == 2) {
            return d.CANCELLED;
        }
        if (i10 == 3) {
            return d.ALREADY_SELECTED;
        }
        throw new IllegalStateException(("Unexpected internal result: " + i10).toString());
    }

    /* access modifiers changed from: private */
    public static final boolean h(xb.l<? super Unit> lVar, Function1<? super Throwable, Unit> function1) {
        Object u10 = lVar.u(Unit.f12470a, (Object) null, function1);
        if (u10 == null) {
            return false;
        }
        lVar.M(u10);
        return true;
    }
}
