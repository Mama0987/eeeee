package fc;

import kotlin.Metadata;

@Metadata
public enum d {
    SUCCESSFUL,
    REREGISTER,
    CANCELLED,
    ALREADY_SELECTED
}
