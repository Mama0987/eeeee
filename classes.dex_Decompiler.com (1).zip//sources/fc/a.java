package fc;

import androidx.concurrent.futures.b;
import cc.e0;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import pb.n;
import xb.j;
import xb.l;
import xb.q2;
import xb.y0;

@Metadata
public class a<R> extends j implements b, q2 {
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private static final AtomicReferenceFieldUpdater f10950f = AtomicReferenceFieldUpdater.newUpdater(a.class, Object.class, "state");
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final CoroutineContext f10951a;

    /* renamed from: b  reason: collision with root package name */
    private List<a<R>.a> f10952b;

    /* renamed from: c  reason: collision with root package name */
    private Object f10953c;

    /* renamed from: d  reason: collision with root package name */
    private int f10954d;

    /* renamed from: e  reason: collision with root package name */
    private Object f10955e;
    private volatile Object state;

    @Metadata
    /* renamed from: fc.a$a  reason: collision with other inner class name */
    public final class C0159a {
        @NotNull

        /* renamed from: a  reason: collision with root package name */
        public final Object f10956a;

        /* renamed from: b  reason: collision with root package name */
        private final Object f10957b;

        /* renamed from: c  reason: collision with root package name */
        public final n<b<?>, Object, Object, Function1<Throwable, Unit>> f10958c;

        /* renamed from: d  reason: collision with root package name */
        public Object f10959d;

        /* renamed from: e  reason: collision with root package name */
        public int f10960e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ a<R> f10961f;

        public final Function1<Throwable, Unit> a(@NotNull b<?> bVar, Object obj) {
            n<b<?>, Object, Object, Function1<Throwable, Unit>> nVar = this.f10958c;
            if (nVar != null) {
                return nVar.d(bVar, this.f10957b, obj);
            }
            return null;
        }

        public final void b() {
            Object obj = this.f10959d;
            a<R> aVar = this.f10961f;
            y0 y0Var = null;
            if (obj instanceof e0) {
                ((e0) obj).o(this.f10960e, (Throwable) null, aVar.a());
                return;
            }
            if (obj instanceof y0) {
                y0Var = (y0) obj;
            }
            if (y0Var != null) {
                y0Var.i();
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: fc.a<R>$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: fc.a<R>$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: fc.a$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: fc.a<R>$a} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final fc.a<R>.a j(java.lang.Object r5) {
        /*
            r4 = this;
            java.util.List<fc.a<R>$a> r0 = r4.f10952b
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.Iterator r0 = r0.iterator()
        L_0x000c:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x0023
            java.lang.Object r2 = r0.next()
            r3 = r2
            fc.a$a r3 = (fc.a.C0159a) r3
            java.lang.Object r3 = r3.f10956a
            if (r3 != r5) goto L_0x001f
            r3 = 1
            goto L_0x0020
        L_0x001f:
            r3 = 0
        L_0x0020:
            if (r3 == 0) goto L_0x000c
            r1 = r2
        L_0x0023:
            fc.a$a r1 = (fc.a.C0159a) r1
            if (r1 == 0) goto L_0x0028
            return r1
        L_0x0028:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Clause with object "
            r1.append(r2)
            r1.append(r5)
            java.lang.String r5 = " is not found"
            r1.append(r5)
            java.lang.String r5 = r1.toString()
            java.lang.String r5 = r5.toString()
            r0.<init>(r5)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: fc.a.j(java.lang.Object):fc.a$a");
    }

    private final int n(Object obj, Object obj2) {
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f10950f;
            Object obj3 = atomicReferenceFieldUpdater.get(this);
            if (obj3 instanceof l) {
                a<R>.a j10 = j(obj);
                if (j10 == null) {
                    continue;
                } else {
                    Function1<Throwable, Unit> a10 = j10.a(this, obj2);
                    if (b.a(atomicReferenceFieldUpdater, this, obj3, j10)) {
                        this.f10955e = obj2;
                        if (c.h((l) obj3, a10)) {
                            return 0;
                        }
                        this.f10955e = null;
                        return 2;
                    }
                }
            } else {
                if (Intrinsics.a(obj3, c.f10964c) ? true : obj3 instanceof C0159a) {
                    return 3;
                }
                if (Intrinsics.a(obj3, c.f10965d)) {
                    return 2;
                }
                if (Intrinsics.a(obj3, c.f10963b)) {
                    if (b.a(atomicReferenceFieldUpdater, this, obj3, p.e(obj))) {
                        return 1;
                    }
                } else if (!(obj3 instanceof List)) {
                    throw new IllegalStateException(("Unexpected state: " + obj3).toString());
                } else if (b.a(atomicReferenceFieldUpdater, this, obj3, CollectionsKt___CollectionsKt.Q((Collection) obj3, obj))) {
                    return 1;
                }
            }
        }
    }

    @NotNull
    public CoroutineContext a() {
        return this.f10951a;
    }

    public void c(@NotNull e0<?> e0Var, int i10) {
        this.f10953c = e0Var;
        this.f10954d = i10;
    }

    public boolean e(@NotNull Object obj, Object obj2) {
        return n(obj, obj2) == 0;
    }

    public void h(Object obj) {
        this.f10955e = obj;
    }

    public void i(Throwable th) {
        Object obj;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f10950f;
        do {
            obj = atomicReferenceFieldUpdater.get(this);
            if (obj == c.f10964c) {
                return;
            }
        } while (!b.a(atomicReferenceFieldUpdater, this, obj, c.f10965d));
        List<a<R>.a> list = this.f10952b;
        if (list != null) {
            for (C0159a b10 : list) {
                b10.b();
            }
            this.f10955e = c.f10966e;
            this.f10952b = null;
        }
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        i((Throwable) obj);
        return Unit.f12470a;
    }

    @NotNull
    public final d m(@NotNull Object obj, Object obj2) {
        return c.a(n(obj, obj2));
    }
}
