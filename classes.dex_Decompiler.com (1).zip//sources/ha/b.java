package ha;

import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import ca.c;
import da.g;
import ea.d;
import ga.a;
import java.util.Collections;
import java.util.HashMap;

public final class b implements a {
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final String f11286a;
    @NonNull

    /* renamed from: b  reason: collision with root package name */
    private final ea.b f11287b;
    @NonNull

    /* renamed from: c  reason: collision with root package name */
    private final d f11288c;
    @NonNull

    /* renamed from: d  reason: collision with root package name */
    private final da.a f11289d;

    public b(@NonNull String str, @NonNull ea.b bVar, @NonNull d dVar, @NonNull da.a aVar) {
        this.f11286a = str;
        this.f11287b = bVar;
        this.f11288c = dVar;
        this.f11289d = aVar;
    }

    @NonNull
    public final c<?> a() {
        da.d e10 = this.f11289d.e();
        if (e10 == null) {
            return c.a(ca.d.INTERNAL_ERROR, new ca.b("access token is null"));
        }
        ea.b bVar = this.f11287b;
        c<?> a10 = bVar.f10629b.a(bVar.f10628a.buildUpon().appendPath("oauth").appendPath("revoke").build(), Collections.emptyMap(), Collections.singletonMap("refresh_token", e10.f10304d), ea.b.f10627g);
        if (a10.g()) {
            this.f11289d.c();
        }
        return a10;
    }

    @NonNull
    public final c<ca.a> b() {
        da.d e10 = this.f11289d.e();
        if (e10 == null || TextUtils.isEmpty(e10.f10304d)) {
            return c.a(ca.d.INTERNAL_ERROR, new ca.b("access token or refresh token is not found."));
        }
        ea.b bVar = this.f11287b;
        String str = this.f11286a;
        Uri build = bVar.f10628a.buildUpon().appendPath("oauth").appendPath("accessToken").build();
        HashMap hashMap = new HashMap(3);
        hashMap.put("grant_type", "refresh_token");
        hashMap.put("refresh_token", e10.f10304d);
        hashMap.put("client_id", str);
        c<g> a10 = bVar.f10629b.a(build, Collections.emptyMap(), hashMap, ea.b.f10626f);
        if (!a10.g()) {
            return c.a(a10.d(), a10.c());
        }
        g e11 = a10.e();
        da.d dVar = new da.d(e11.f10309a, e11.f10310b, System.currentTimeMillis(), TextUtils.isEmpty(e11.f10311c) ? e10.f10304d : e11.f10311c);
        this.f11289d.d(dVar);
        return c.b(new ca.a(dVar.f10301a, dVar.f10302b, dVar.f10303c));
    }
}
