package ha;

import androidx.annotation.NonNull;
import ca.c;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class a implements InvocationHandler {
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final ga.a f11284a;
    @NonNull

    /* renamed from: b  reason: collision with root package name */
    private final Map<Method, Boolean> f11285b;

    private a(@NonNull ga.a aVar) {
        this.f11284a = aVar;
        this.f11285b = new ConcurrentHashMap(0);
    }

    public /* synthetic */ a(ga.a aVar, byte b10) {
        this(aVar);
    }

    private boolean a(@NonNull Method method) {
        Boolean bool = this.f11285b.get(method);
        if (bool != null) {
            return bool.booleanValue();
        }
        String name = method.getName();
        Class[] parameterTypes = method.getParameterTypes();
        Class cls = this.f11284a.getClass();
        while (cls != null) {
            try {
                if (((c) cls.getDeclaredMethod(name, parameterTypes).getAnnotation(c.class)) != null) {
                    this.f11285b.put(method, Boolean.TRUE);
                    return true;
                }
                cls = cls.getSuperclass();
            } catch (NoSuchMethodException unused) {
            }
        }
        this.f11285b.put(method, Boolean.FALSE);
        return false;
    }

    public final Object invoke(Object obj, Method method, Object[] objArr) {
        try {
            Object invoke = method.invoke(this.f11284a, objArr);
            if (a(method)) {
                if ((invoke instanceof c) && ((c) invoke).c().a() == 403) {
                    c<ca.a> b10 = this.f11284a.b();
                    if (!b10.g()) {
                        return b10.f() ? b10 : invoke;
                    }
                    try {
                        return method.invoke(this.f11284a, objArr);
                    } catch (InvocationTargetException e10) {
                        throw e10.getTargetException();
                    }
                }
            }
            return invoke;
        } catch (InvocationTargetException e11) {
            throw e11.getTargetException();
        }
    }
}
