package u9;

import n8.c;
import n8.e;
import n8.h;

public final /* synthetic */ class a implements h {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f16493a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ c f16494b;

    public /* synthetic */ a(String str, c cVar) {
        this.f16493a = str;
        this.f16494b = cVar;
    }

    public final Object a(e eVar) {
        return b.c(this.f16493a, this.f16494b, eVar);
    }
}
