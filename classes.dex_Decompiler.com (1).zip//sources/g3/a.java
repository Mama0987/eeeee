package g3;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import i2.h;
import java.io.File;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public final String f10983a;

    /* renamed from: b  reason: collision with root package name */
    public final String f10984b;

    /* renamed from: c  reason: collision with root package name */
    public final String f10985c;

    /* renamed from: d  reason: collision with root package name */
    public final String f10986d;

    public String a() {
        StringBuilder sb2 = new StringBuilder();
        if (!TextUtils.isEmpty(this.f10983a)) {
            sb2.append(this.f10983a);
        }
        if (this.f10984b != null) {
            if (sb2.length() > 0) {
                sb2.append(10);
            }
            sb2.append(this.f10984b);
        }
        return sb2.toString();
    }

    public Uri b(Context context) {
        if (TextUtils.isEmpty(this.f10985c)) {
            return null;
        }
        return h.b(context, new File(this.f10985c));
    }

    public Uri c(Context context) {
        if (TextUtils.isEmpty(this.f10986d)) {
            return null;
        }
        return h.b(context, new File(this.f10986d));
    }
}
