package k1;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import java.lang.reflect.InvocationTargetException;
import l1.a0;
import l1.b0;
import l1.c0;
import l1.g;

public class c {

    /* renamed from: a  reason: collision with root package name */
    private static final Uri f12202a = Uri.parse("*");

    /* renamed from: b  reason: collision with root package name */
    private static final Uri f12203b = Uri.parse("");

    public static PackageInfo a() {
        if (Build.VERSION.SDK_INT >= 26) {
            return g.a();
        }
        try {
            return c();
        } catch (ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            return null;
        }
    }

    private static c0 b() {
        return b0.d();
    }

    @SuppressLint({"PrivateApi"})
    private static PackageInfo c() throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        return (PackageInfo) Class.forName("android.webkit.WebViewFactory").getMethod("getLoadedPackageInfo", new Class[0]).invoke((Object) null, new Object[0]);
    }

    public static boolean d() {
        if (a0.R.d()) {
            return b().getStatics().isMultiProcessEnabled();
        }
        throw a0.a();
    }
}
