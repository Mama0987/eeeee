package k1;

import androidx.annotation.NonNull;
import l1.a0;

public class d {
    public static boolean a(@NonNull String str) {
        return a0.b(str);
    }
}
