package k1;

import android.webkit.WebSettings;
import androidx.annotation.NonNull;
import l1.a;
import l1.a0;
import l1.b0;
import l1.v;
import l1.z;

public class b {
    private static z a(WebSettings webSettings) {
        return b0.c().a(webSettings);
    }

    @Deprecated
    public static void b(@NonNull WebSettings webSettings, int i10) {
        a.h hVar = a0.S;
        if (hVar.c()) {
            v.d(webSettings, i10);
        } else if (hVar.d()) {
            a(webSettings).a(i10);
        } else {
            throw a0.a();
        }
    }
}
