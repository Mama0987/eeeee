package k1;

public abstract class e {
}
