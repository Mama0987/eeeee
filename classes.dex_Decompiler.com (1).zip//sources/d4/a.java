package d4;

import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import q4.v;
import v3.e0;

@Metadata
public final class a {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final a f10232a = new a();

    /* renamed from: b  reason: collision with root package name */
    private static boolean f10233b;

    /* renamed from: c  reason: collision with root package name */
    private static boolean f10234c;

    private a() {
    }

    public static final void a() {
        f10233b = true;
        v vVar = v.f14250a;
        f10234c = v.d("FBSDKFeatureIntegritySample", e0.m(), false);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0024, code lost:
        r6 = r6[0];
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final java.lang.String b(java.lang.String r6) {
        /*
            r5 = this;
            r0 = 30
            float[] r1 = new float[r0]
            r2 = 0
            r3 = 0
        L_0x0006:
            if (r3 >= r0) goto L_0x000e
            r4 = 0
            r1[r3] = r4
            int r3 = r3 + 1
            goto L_0x0006
        L_0x000e:
            f4.f r0 = f4.f.f10773a
            f4.f$a r0 = f4.f.a.MTML_INTEGRITY_DETECT
            r3 = 1
            float[][] r4 = new float[r3][]
            r4[r2] = r1
            java.lang.String[] r1 = new java.lang.String[r3]
            r1[r2] = r6
            java.lang.String[] r6 = f4.f.q(r0, r4, r1)
            java.lang.String r0 = "none"
            if (r6 != 0) goto L_0x0024
            goto L_0x002a
        L_0x0024:
            r6 = r6[r2]
            if (r6 != 0) goto L_0x0029
            goto L_0x002a
        L_0x0029:
            r0 = r6
        L_0x002a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: d4.a.b(java.lang.String):java.lang.String");
    }

    public static final void c(@NotNull Map<String, String> map) {
        Intrinsics.checkNotNullParameter(map, "parameters");
        if (f10233b && !map.isEmpty()) {
            try {
                List<String> Z = CollectionsKt___CollectionsKt.Z(map.keySet());
                JSONObject jSONObject = new JSONObject();
                for (String str : Z) {
                    String str2 = map.get(str);
                    if (str2 != null) {
                        String str3 = str2;
                        a aVar = f10232a;
                        if (aVar.d(str) || aVar.d(str3)) {
                            map.remove(str);
                            if (!f10234c) {
                                str3 = "";
                            }
                            jSONObject.put(str, str3);
                        }
                    } else {
                        throw new IllegalStateException("Required value was null.".toString());
                    }
                }
                if (jSONObject.length() != 0) {
                    String jSONObject2 = jSONObject.toString();
                    Intrinsics.checkNotNullExpressionValue(jSONObject2, "restrictiveParamJson.toString()");
                    map.put("_onDeviceParams", jSONObject2);
                }
            } catch (Exception unused) {
            }
        }
    }

    private final boolean d(String str) {
        return !Intrinsics.a("none", b(str));
    }
}
