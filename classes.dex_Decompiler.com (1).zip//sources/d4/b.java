package d4;

import android.os.Build;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;
import q4.a0;
import q4.t0;
import q4.w;
import v3.e0;

@Metadata
public final class b {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final b f10235a = new b();

    /* renamed from: b  reason: collision with root package name */
    private static boolean f10236b;

    /* renamed from: c  reason: collision with root package name */
    private static JSONArray f10237c;
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private static String[] f10238d = {"event", "_locale", "_appVersion", "_deviceOS", "_platform", "_deviceModel", "_nativeAppID", "_nativeAppShortVersion", "_timezone", "_carrier", "_deviceOSTypeName", "_deviceOSVersion", "_remainingDiskGB"};

    private b() {
    }

    public static final void a() {
        f10235a.g();
        if (f10237c != null) {
            f10236b = true;
        }
    }

    public static final void b(@NotNull Bundle bundle, @NotNull String str) {
        String str2;
        String str3;
        Intrinsics.checkNotNullParameter(bundle, "params");
        Intrinsics.checkNotNullParameter(str, "event");
        bundle.putString("event", str);
        StringBuilder sb2 = new StringBuilder();
        t0 t0Var = t0.f14237a;
        Locale I = t0Var.I();
        String str4 = "";
        if (I == null || (str2 = I.getLanguage()) == null) {
            str2 = str4;
        }
        sb2.append(str2);
        sb2.append('_');
        Locale I2 = t0Var.I();
        if (I2 == null || (str3 = I2.getCountry()) == null) {
            str3 = str4;
        }
        sb2.append(str3);
        bundle.putString("_locale", sb2.toString());
        String Q = t0Var.Q();
        if (Q == null) {
            Q = str4;
        }
        bundle.putString("_appVersion", Q);
        bundle.putString("_deviceOS", "ANDROID");
        bundle.putString("_platform", "mobile");
        String str5 = Build.MODEL;
        if (str5 == null) {
            str5 = str4;
        }
        bundle.putString("_deviceModel", str5);
        bundle.putString("_nativeAppID", e0.m());
        String Q2 = t0Var.Q();
        if (Q2 != null) {
            str4 = Q2;
        }
        bundle.putString("_nativeAppShortVersion", str4);
        bundle.putString("_timezone", t0Var.D());
        bundle.putString("_carrier", t0Var.y());
        bundle.putString("_deviceOSTypeName", "ANDROID");
        bundle.putString("_deviceOSVersion", Build.VERSION.RELEASE);
        bundle.putLong("_remainingDiskGB", t0Var.w());
    }

    public static final String c(@NotNull JSONObject jSONObject) {
        Intrinsics.checkNotNullParameter(jSONObject, "logic");
        Iterator<String> keys = jSONObject.keys();
        if (keys.hasNext()) {
            return keys.next();
        }
        return null;
    }

    @NotNull
    public static final String d(Bundle bundle) {
        String optString;
        JSONArray jSONArray = f10237c;
        if (jSONArray == null) {
            return "[]";
        }
        Integer valueOf = jSONArray == null ? null : Integer.valueOf(jSONArray.length());
        if (valueOf != null && valueOf.intValue() == 0) {
            return "[]";
        }
        JSONArray jSONArray2 = f10237c;
        if (jSONArray2 != null) {
            ArrayList arrayList = new ArrayList();
            int length = jSONArray2.length();
            if (length > 0) {
                int i10 = 0;
                while (true) {
                    int i11 = i10 + 1;
                    String optString2 = jSONArray2.optString(i10);
                    if (optString2 != null) {
                        JSONObject jSONObject = new JSONObject(optString2);
                        long optLong = jSONObject.optLong("id");
                        if (!(optLong == 0 || (optString = jSONObject.optString("rule")) == null || !f(optString, bundle))) {
                            arrayList.add(Long.valueOf(optLong));
                        }
                    }
                    if (i11 >= length) {
                        break;
                    }
                    i10 = i11;
                }
            }
            String jSONArray3 = new JSONArray(arrayList).toString();
            Intrinsics.checkNotNullExpressionValue(jSONArray3, "JSONArray(res).toString()");
            return jSONArray3;
        }
        throw new NullPointerException("null cannot be cast to non-null type org.json.JSONArray");
    }

    public static final ArrayList<String> e(JSONArray jSONArray) {
        if (jSONArray == null) {
            return null;
        }
        ArrayList<String> arrayList = new ArrayList<>();
        int length = jSONArray.length();
        if (length > 0) {
            int i10 = 0;
            while (true) {
                int i11 = i10 + 1;
                arrayList.add(jSONArray.get(i10).toString());
                if (i11 >= length) {
                    break;
                }
                i10 = i11;
            }
        }
        return arrayList;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0007, code lost:
        r1 = new org.json.JSONObject(r5);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean f(java.lang.String r5, android.os.Bundle r6) {
        /*
            r0 = 0
            if (r5 == 0) goto L_0x009e
            if (r6 != 0) goto L_0x0007
            goto L_0x009e
        L_0x0007:
            org.json.JSONObject r1 = new org.json.JSONObject
            r1.<init>(r5)
            java.lang.String r5 = c(r1)
            if (r5 != 0) goto L_0x0013
            return r0
        L_0x0013:
            java.lang.Object r1 = r1.get(r5)
            int r2 = r5.hashCode()
            r3 = 3555(0xde3, float:4.982E-42)
            r4 = 1
            if (r2 == r3) goto L_0x006a
            r3 = 96727(0x179d7, float:1.35543E-40)
            if (r2 == r3) goto L_0x003e
            r3 = 109267(0x1aad3, float:1.53116E-40)
            if (r2 == r3) goto L_0x002b
            goto L_0x0072
        L_0x002b:
            java.lang.String r2 = "not"
            boolean r2 = r5.equals(r2)
            if (r2 != 0) goto L_0x0034
            goto L_0x0072
        L_0x0034:
            java.lang.String r5 = r1.toString()
            boolean r5 = f(r5, r6)
            r5 = r5 ^ r4
            return r5
        L_0x003e:
            java.lang.String r2 = "and"
            boolean r2 = r5.equals(r2)
            if (r2 != 0) goto L_0x0047
            goto L_0x0072
        L_0x0047:
            org.json.JSONArray r1 = (org.json.JSONArray) r1
            if (r1 != 0) goto L_0x004c
            return r0
        L_0x004c:
            int r5 = r1.length()
            if (r5 <= 0) goto L_0x0069
            r2 = 0
        L_0x0053:
            int r3 = r2 + 1
            java.lang.Object r2 = r1.get(r2)
            java.lang.String r2 = r2.toString()
            boolean r2 = f(r2, r6)
            if (r2 != 0) goto L_0x0064
            return r0
        L_0x0064:
            if (r3 < r5) goto L_0x0067
            goto L_0x0069
        L_0x0067:
            r2 = r3
            goto L_0x0053
        L_0x0069:
            return r4
        L_0x006a:
            java.lang.String r2 = "or"
            boolean r2 = r5.equals(r2)
            if (r2 != 0) goto L_0x007c
        L_0x0072:
            org.json.JSONObject r1 = (org.json.JSONObject) r1
            if (r1 != 0) goto L_0x0077
            return r0
        L_0x0077:
            boolean r5 = j(r5, r1, r6)
            return r5
        L_0x007c:
            org.json.JSONArray r1 = (org.json.JSONArray) r1
            if (r1 != 0) goto L_0x0081
            return r0
        L_0x0081:
            int r5 = r1.length()
            if (r5 <= 0) goto L_0x009e
            r2 = 0
        L_0x0088:
            int r3 = r2 + 1
            java.lang.Object r2 = r1.get(r2)
            java.lang.String r2 = r2.toString()
            boolean r2 = f(r2, r6)
            if (r2 == 0) goto L_0x0099
            return r4
        L_0x0099:
            if (r3 < r5) goto L_0x009c
            goto L_0x009e
        L_0x009c:
            r2 = r3
            goto L_0x0088
        L_0x009e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: d4.b.f(java.lang.String, android.os.Bundle):boolean");
    }

    private final void g() {
        a0 a0Var = a0.f14051a;
        w o10 = a0.o(e0.m(), false);
        if (o10 != null) {
            f10237c = o10.g();
        }
    }

    public static final void h(Bundle bundle, @NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "event");
        if (f10236b && bundle != null) {
            try {
                b(bundle, str);
                bundle.putString("_audiencePropertyIds", d(bundle));
                bundle.putString("cs_maca", "1");
                i(bundle);
            } catch (Exception unused) {
            }
        }
    }

    public static final void i(@NotNull Bundle bundle) {
        Intrinsics.checkNotNullParameter(bundle, "params");
        String[] strArr = f10238d;
        int length = strArr.length;
        int i10 = 0;
        while (i10 < length) {
            String str = strArr[i10];
            i10++;
            bundle.remove(str);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:106:0x0237, code lost:
        if (java.lang.Double.parseDouble(r5.toString()) >= java.lang.Double.parseDouble(r2)) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x0246, code lost:
        if (r9 != null) goto L_0x0249;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x0248, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:113:0x024d, code lost:
        if (r9.isEmpty() == false) goto L_0x0250;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:114:0x0250, code lost:
        r8 = r9.iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:116:0x0258, code lost:
        if (r8.hasNext() == false) goto L_0x0239;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x025a, code lost:
        r9 = (java.lang.String) r8.next();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:118:0x0260, code lost:
        if (r9 == null) goto L_0x0287;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:119:0x0262, code lost:
        r10 = java.util.Locale.ROOT;
        r9 = r9.toLowerCase(r10);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, "(this as java.lang.Strin….toLowerCase(Locale.ROOT)");
        r0 = r5.toString();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x026f, code lost:
        if (r0 == null) goto L_0x0281;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x0271, code lost:
        r10 = r0.toLowerCase(r10);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, "(this as java.lang.Strin….toLowerCase(Locale.ROOT)");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x027d, code lost:
        if ((!kotlin.jvm.internal.Intrinsics.a(r9, r10)) != false) goto L_0x0254;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:124:0x0286, code lost:
        throw new java.lang.NullPointerException("null cannot be cast to non-null type java.lang.String");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x028c, code lost:
        throw new java.lang.NullPointerException("null cannot be cast to non-null type java.lang.String");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x0297, code lost:
        if (r9 != null) goto L_0x029a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:0x0299, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:132:0x029e, code lost:
        if (r9.isEmpty() == false) goto L_0x02a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x02a2, code lost:
        r8 = r9.iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x02aa, code lost:
        if (r8.hasNext() == false) goto L_0x03b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:136:0x02ac, code lost:
        r9 = (java.lang.String) r8.next();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x02b2, code lost:
        if (r9 == null) goto L_0x02d8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:138:0x02b4, code lost:
        r10 = java.util.Locale.ROOT;
        r9 = r9.toLowerCase(r10);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, "(this as java.lang.Strin….toLowerCase(Locale.ROOT)");
        r0 = r5.toString();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:139:0x02c1, code lost:
        if (r0 == null) goto L_0x02d2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:140:0x02c3, code lost:
        r10 = r0.toLowerCase(r10);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, "(this as java.lang.Strin….toLowerCase(Locale.ROOT)");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:141:0x02ce, code lost:
        if (kotlin.jvm.internal.Intrinsics.a(r9, r10) == false) goto L_0x02a6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:143:0x02d7, code lost:
        throw new java.lang.NullPointerException("null cannot be cast to non-null type java.lang.String");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:145:0x02dd, code lost:
        throw new java.lang.NullPointerException("null cannot be cast to non-null type java.lang.String");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x0366, code lost:
        if (r9 != null) goto L_0x0375;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:172:0x0368, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:175:0x0372, code lost:
        if (r9 != null) goto L_0x0375;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:176:0x0374, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:202:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:203:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:204:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:205:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:206:?, code lost:
        return kotlin.jvm.internal.Intrinsics.a(r5.toString(), r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:207:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:212:?, code lost:
        return r9.contains(r5.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:240:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:249:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:250:?, code lost:
        return false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x01b3, code lost:
        if (java.lang.Double.parseDouble(r5.toString()) < java.lang.Double.parseDouble(r2)) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x01d8, code lost:
        if (java.lang.Double.parseDouble(r5.toString()) > java.lang.Double.parseDouble(r2)) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x01ed, code lost:
        if (kotlin.jvm.internal.Intrinsics.a(r5.toString(), r2) != false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0208, code lost:
        if (java.lang.Double.parseDouble(r5.toString()) <= java.lang.Double.parseDouble(r2)) goto L_?;
     */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x0239 A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean j(@org.jetbrains.annotations.NotNull java.lang.String r8, @org.jetbrains.annotations.NotNull org.json.JSONObject r9, android.os.Bundle r10) {
        /*
            java.lang.String r0 = "variable"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.lang.String r0 = "values"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = c(r9)
            r1 = 0
            if (r0 != 0) goto L_0x0012
            return r1
        L_0x0012:
            java.lang.Object r2 = r9.get(r0)
            java.lang.String r2 = r2.toString()
            org.json.JSONArray r9 = r9.optJSONArray(r0)
            java.util.ArrayList r9 = e(r9)
            java.lang.String r3 = "exists"
            boolean r3 = kotlin.jvm.internal.Intrinsics.a(r0, r3)
            r4 = 0
            if (r3 == 0) goto L_0x0043
            if (r10 != 0) goto L_0x002e
            goto L_0x0036
        L_0x002e:
            boolean r8 = r10.containsKey(r8)
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r8)
        L_0x0036:
            boolean r8 = java.lang.Boolean.parseBoolean(r2)
            java.lang.Boolean r8 = java.lang.Boolean.valueOf(r8)
            boolean r8 = kotlin.jvm.internal.Intrinsics.a(r4, r8)
            return r8
        L_0x0043:
            java.lang.String r3 = "(this as java.lang.Strin….toLowerCase(Locale.ROOT)"
            if (r10 != 0) goto L_0x0049
            r5 = r4
            goto L_0x0056
        L_0x0049:
            java.util.Locale r5 = java.util.Locale.ROOT
            java.lang.String r5 = r8.toLowerCase(r5)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r3)
            java.lang.Object r5 = r10.get(r5)
        L_0x0056:
            if (r5 != 0) goto L_0x0064
            if (r10 != 0) goto L_0x005c
            r5 = r4
            goto L_0x0061
        L_0x005c:
            java.lang.Object r8 = r10.get(r8)
            r5 = r8
        L_0x0061:
            if (r5 != 0) goto L_0x0064
            return r1
        L_0x0064:
            int r8 = r0.hashCode()
            r10 = 2
            r6 = 1
            java.lang.String r7 = "null cannot be cast to non-null type java.lang.String"
            switch(r8) {
                case -1729128927: goto L_0x037e;
                case -1179774633: goto L_0x0369;
                case -1039699439: goto L_0x035d;
                case -969266188: goto L_0x034b;
                case -966353971: goto L_0x0332;
                case -665609109: goto L_0x0328;
                case -567445985: goto L_0x0314;
                case -327990090: goto L_0x02de;
                case -159812115: goto L_0x028d;
                case -92753547: goto L_0x023c;
                case 60: goto L_0x021f;
                case 61: goto L_0x020b;
                case 62: goto L_0x01f0;
                case 1084: goto L_0x01db;
                case 1921: goto L_0x01c0;
                case 1952: goto L_0x01b6;
                case 1983: goto L_0x019b;
                case 3244: goto L_0x0191;
                case 3294: goto L_0x0187;
                case 3309: goto L_0x017d;
                case 3365: goto L_0x0173;
                case 3449: goto L_0x0169;
                case 3464: goto L_0x015f;
                case 3511: goto L_0x0155;
                case 102680: goto L_0x014b;
                case 107485: goto L_0x0141;
                case 108954: goto L_0x0137;
                case 127966736: goto L_0x0103;
                case 127966857: goto L_0x00f9;
                case 363990325: goto L_0x00c5;
                case 1091487233: goto L_0x00bb;
                case 1918401035: goto L_0x00a5;
                case 1961112862: goto L_0x0071;
                default: goto L_0x006f;
            }
        L_0x006f:
            goto L_0x03b3
        L_0x0071:
            java.lang.String r8 = "i_starts_with"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x007b
            goto L_0x03b3
        L_0x007b:
            java.lang.String r8 = r5.toString()
            if (r8 == 0) goto L_0x009f
            java.util.Locale r9 = java.util.Locale.ROOT
            java.lang.String r8 = r8.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r3)
            if (r2 == 0) goto L_0x0099
            java.lang.String r9 = r2.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            boolean r1 = kotlin.text.m.v(r8, r9, r1, r10, r4)
            goto L_0x03b3
        L_0x0099:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x009f:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x00a5:
            java.lang.String r8 = "not_contains"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x00af
            goto L_0x03b3
        L_0x00af:
            java.lang.String r8 = r5.toString()
            boolean r8 = kotlin.text.StringsKt__StringsKt.y(r8, r2, r1, r10, r4)
            if (r8 != 0) goto L_0x03b3
            goto L_0x0239
        L_0x00bb:
            java.lang.String r8 = "i_is_not_any"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0246
            goto L_0x03b3
        L_0x00c5:
            java.lang.String r8 = "i_contains"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x00cf
            goto L_0x03b3
        L_0x00cf:
            java.lang.String r8 = r5.toString()
            if (r8 == 0) goto L_0x00f3
            java.util.Locale r9 = java.util.Locale.ROOT
            java.lang.String r8 = r8.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r3)
            if (r2 == 0) goto L_0x00ed
            java.lang.String r9 = r2.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            boolean r1 = kotlin.text.StringsKt__StringsKt.y(r8, r9, r1, r10, r4)
            goto L_0x03b3
        L_0x00ed:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x00f3:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x00f9:
            java.lang.String r8 = "i_str_in"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0297
            goto L_0x03b3
        L_0x0103:
            java.lang.String r8 = "i_str_eq"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x010d
            goto L_0x03b3
        L_0x010d:
            java.lang.String r8 = r5.toString()
            if (r8 == 0) goto L_0x0131
            java.util.Locale r9 = java.util.Locale.ROOT
            java.lang.String r8 = r8.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r3)
            if (r2 == 0) goto L_0x012b
            java.lang.String r9 = r2.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            boolean r1 = kotlin.jvm.internal.Intrinsics.a(r8, r9)
            goto L_0x03b3
        L_0x012b:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x0131:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x0137:
            java.lang.String r8 = "neq"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01e5
            goto L_0x03b3
        L_0x0141:
            java.lang.String r8 = "lte"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01ca
            goto L_0x03b3
        L_0x014b:
            java.lang.String r8 = "gte"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01a5
            goto L_0x03b3
        L_0x0155:
            java.lang.String r8 = "ne"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01e5
            goto L_0x03b3
        L_0x015f:
            java.lang.String r8 = "lt"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0229
            goto L_0x03b3
        L_0x0169:
            java.lang.String r8 = "le"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01ca
            goto L_0x03b3
        L_0x0173:
            java.lang.String r8 = "in"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0372
            goto L_0x03b3
        L_0x017d:
            java.lang.String r8 = "gt"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01fa
            goto L_0x03b3
        L_0x0187:
            java.lang.String r8 = "ge"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01a5
            goto L_0x03b3
        L_0x0191:
            java.lang.String r8 = "eq"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0215
            goto L_0x03b3
        L_0x019b:
            java.lang.String r8 = ">="
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01a5
            goto L_0x03b3
        L_0x01a5:
            java.lang.String r8 = r5.toString()
            double r8 = java.lang.Double.parseDouble(r8)
            double r2 = java.lang.Double.parseDouble(r2)
            int r10 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r10 < 0) goto L_0x03b3
            goto L_0x020a
        L_0x01b6:
            java.lang.String r8 = "=="
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0215
            goto L_0x03b3
        L_0x01c0:
            java.lang.String r8 = "<="
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01ca
            goto L_0x03b3
        L_0x01ca:
            java.lang.String r8 = r5.toString()
            double r8 = java.lang.Double.parseDouble(r8)
            double r2 = java.lang.Double.parseDouble(r2)
            int r10 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r10 > 0) goto L_0x03b3
            goto L_0x0239
        L_0x01db:
            java.lang.String r8 = "!="
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01e5
            goto L_0x03b3
        L_0x01e5:
            java.lang.String r8 = r5.toString()
            boolean r8 = kotlin.jvm.internal.Intrinsics.a(r8, r2)
            if (r8 != 0) goto L_0x03b3
            goto L_0x020a
        L_0x01f0:
            java.lang.String r8 = ">"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x01fa
            goto L_0x03b3
        L_0x01fa:
            java.lang.String r8 = r5.toString()
            double r8 = java.lang.Double.parseDouble(r8)
            double r2 = java.lang.Double.parseDouble(r2)
            int r10 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r10 <= 0) goto L_0x03b3
        L_0x020a:
            goto L_0x0239
        L_0x020b:
            java.lang.String r8 = "="
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0215
            goto L_0x03b3
        L_0x0215:
            java.lang.String r8 = r5.toString()
            boolean r1 = kotlin.jvm.internal.Intrinsics.a(r8, r2)
            goto L_0x03b3
        L_0x021f:
            java.lang.String r8 = "<"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0229
            goto L_0x03b3
        L_0x0229:
            java.lang.String r8 = r5.toString()
            double r8 = java.lang.Double.parseDouble(r8)
            double r2 = java.lang.Double.parseDouble(r2)
            int r10 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r10 >= 0) goto L_0x03b3
        L_0x0239:
            r1 = 1
            goto L_0x03b3
        L_0x023c:
            java.lang.String r8 = "i_str_not_in"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0246
            goto L_0x03b3
        L_0x0246:
            if (r9 != 0) goto L_0x0249
            return r1
        L_0x0249:
            boolean r8 = r9.isEmpty()
            if (r8 == 0) goto L_0x0250
            goto L_0x020a
        L_0x0250:
            java.util.Iterator r8 = r9.iterator()
        L_0x0254:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L_0x0239
            java.lang.Object r9 = r8.next()
            java.lang.String r9 = (java.lang.String) r9
            if (r9 == 0) goto L_0x0287
            java.util.Locale r10 = java.util.Locale.ROOT
            java.lang.String r9 = r9.toLowerCase(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            java.lang.String r0 = r5.toString()
            if (r0 == 0) goto L_0x0281
            java.lang.String r10 = r0.toLowerCase(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r3)
            boolean r9 = kotlin.jvm.internal.Intrinsics.a(r9, r10)
            r9 = r9 ^ r6
            if (r9 != 0) goto L_0x0254
            goto L_0x03b3
        L_0x0281:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x0287:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x028d:
            java.lang.String r8 = "i_is_any"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0297
            goto L_0x03b3
        L_0x0297:
            if (r9 != 0) goto L_0x029a
            return r1
        L_0x029a:
            boolean r8 = r9.isEmpty()
            if (r8 == 0) goto L_0x02a2
            goto L_0x03b3
        L_0x02a2:
            java.util.Iterator r8 = r9.iterator()
        L_0x02a6:
            boolean r9 = r8.hasNext()
            if (r9 == 0) goto L_0x03b3
            java.lang.Object r9 = r8.next()
            java.lang.String r9 = (java.lang.String) r9
            if (r9 == 0) goto L_0x02d8
            java.util.Locale r10 = java.util.Locale.ROOT
            java.lang.String r9 = r9.toLowerCase(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            java.lang.String r0 = r5.toString()
            if (r0 == 0) goto L_0x02d2
            java.lang.String r10 = r0.toLowerCase(r10)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r3)
            boolean r9 = kotlin.jvm.internal.Intrinsics.a(r9, r10)
            if (r9 == 0) goto L_0x02a6
            goto L_0x020a
        L_0x02d2:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x02d8:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x02de:
            java.lang.String r8 = "i_str_neq"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x02e8
            goto L_0x03b3
        L_0x02e8:
            java.lang.String r8 = r5.toString()
            if (r8 == 0) goto L_0x030e
            java.util.Locale r9 = java.util.Locale.ROOT
            java.lang.String r8 = r8.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r3)
            if (r2 == 0) goto L_0x0308
            java.lang.String r9 = r2.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            boolean r8 = kotlin.jvm.internal.Intrinsics.a(r8, r9)
            if (r8 != 0) goto L_0x03b3
            goto L_0x0239
        L_0x0308:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x030e:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x0314:
            java.lang.String r8 = "contains"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x031e
            goto L_0x03b3
        L_0x031e:
            java.lang.String r8 = r5.toString()
            boolean r1 = kotlin.text.StringsKt__StringsKt.y(r8, r2, r1, r10, r4)
            goto L_0x03b3
        L_0x0328:
            java.lang.String r8 = "is_not_any"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0366
            goto L_0x03b3
        L_0x0332:
            java.lang.String r8 = "regex_match"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x033c
            goto L_0x03b3
        L_0x033c:
            kotlin.text.Regex r8 = new kotlin.text.Regex
            r8.<init>((java.lang.String) r2)
            java.lang.String r9 = r5.toString()
            boolean r1 = r8.b(r9)
            goto L_0x03b3
        L_0x034b:
            java.lang.String r8 = "starts_with"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0354
            goto L_0x03b3
        L_0x0354:
            java.lang.String r8 = r5.toString()
            boolean r1 = kotlin.text.m.v(r8, r2, r1, r10, r4)
            goto L_0x03b3
        L_0x035d:
            java.lang.String r8 = "not_in"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0366
            goto L_0x03b3
        L_0x0366:
            if (r9 != 0) goto L_0x0375
            return r1
        L_0x0369:
            java.lang.String r8 = "is_any"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0372
            goto L_0x03b3
        L_0x0372:
            if (r9 != 0) goto L_0x0375
            return r1
        L_0x0375:
            java.lang.String r8 = r5.toString()
            boolean r1 = r9.contains(r8)
            goto L_0x03b3
        L_0x037e:
            java.lang.String r8 = "i_not_contains"
            boolean r8 = r0.equals(r8)
            if (r8 != 0) goto L_0x0387
            goto L_0x03b3
        L_0x0387:
            java.lang.String r8 = r5.toString()
            if (r8 == 0) goto L_0x03ad
            java.util.Locale r9 = java.util.Locale.ROOT
            java.lang.String r8 = r8.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r3)
            if (r2 == 0) goto L_0x03a7
            java.lang.String r9 = r2.toLowerCase(r9)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r3)
            boolean r8 = kotlin.text.StringsKt__StringsKt.y(r8, r9, r1, r10, r4)
            if (r8 != 0) goto L_0x03b3
            goto L_0x020a
        L_0x03a7:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x03ad:
            java.lang.NullPointerException r8 = new java.lang.NullPointerException
            r8.<init>(r7)
            throw r8
        L_0x03b3:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: d4.b.j(java.lang.String, org.json.JSONObject, android.os.Bundle):boolean");
    }
}
