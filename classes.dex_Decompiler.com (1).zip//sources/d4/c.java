package d4;

import android.os.Bundle;
import com.appsflyer.AdRevenueScheme;
import eb.i;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import q4.a0;
import q4.w;
import qb.l;
import v3.e0;

@Metadata
public final class c {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final c f10239a = new c();

    /* renamed from: b  reason: collision with root package name */
    private static boolean f10240b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private static final i f10241c = k.a(a.f10243a);

    /* renamed from: d  reason: collision with root package name */
    private static HashSet<String> f10242d;

    @Metadata
    static final class a extends l implements Function0<HashSet<String>> {

        /* renamed from: a  reason: collision with root package name */
        public static final a f10243a = new a();

        a() {
            super(0);
        }

        @NotNull
        /* renamed from: a */
        public final HashSet<String> invoke() {
            return n0.f("_currency", "_valueToSum", "fb_availability", "fb_body_style", "fb_checkin_date", "fb_checkout_date", "fb_city", "fb_condition_of_vehicle", "fb_content_category", "fb_content_ids", "fb_content_name", "fb_content_type", "fb_contents", "fb_country", "fb_currency", "fb_delivery_category", "fb_departing_arrival_date", "fb_departing_departure_date", "fb_destination_airport", "fb_destination_ids", "fb_dma_code", "fb_drivetrain", "fb_exterior_color", "fb_fuel_type", "fb_hotel_score", "fb_interior_color", "fb_lease_end_date", "fb_lease_start_date", "fb_listing_type", "fb_make", "fb_mileage.unit", "fb_mileage.value", "fb_model", "fb_neighborhood", "fb_num_adults", "fb_num_children", "fb_num_infants", "fb_num_items", "fb_order_id", "fb_origin_airport", "fb_postal_code", "fb_predicted_ltv", "fb_preferred_baths_range", "fb_preferred_beds_range", "fb_preferred_neighborhoods", "fb_preferred_num_stops", "fb_preferred_price_range", "fb_preferred_star_ratings", "fb_price", "fb_property_type", "fb_region", "fb_returning_arrival_date", "fb_returning_departure_date", "fb_search_string", "fb_state_of_vehicle", "fb_status", "fb_suggested_destinations", "fb_suggested_home_listings", "fb_suggested_hotels", "fb_suggested_jobs", "fb_suggested_local_service_businesses", "fb_suggested_location_based_items", "fb_suggested_vehicles", "fb_transmission", "fb_travel_class", "fb_travel_end", "fb_travel_start", "fb_trim", "fb_user_bucket", "fb_value", "fb_vin", "fb_year", "lead_event_source", "predicted_ltv", "product_catalog_id", "app_user_id", "appVersion", "_eventName", "_eventName_md5", "_implicitlyLogged", "_inBackground", "_isTimedEvent", "_logTime", "_session_id", "_ui", "_valueToUpdate", "_is_fb_codeless", "_is_suggested_event", "_fb_pixel_referral_id", "fb_pixel_id", "trace_id", "subscription_id", "event_id", "_restrictedParams", "_onDeviceParams", "purchase_valid_result_type", "core_lib_included", "login_lib_included", "share_lib_included", "place_lib_included", "messenger_lib_included", "applinks_lib_included", "marketing_lib_included", "_codeless_action", "sdk_initialized", "billing_client_lib_included", "billing_service_lib_included", "user_data_keys", "device_push_token", "fb_mobile_pckg_fp", "fb_mobile_app_cert_hash", "aggregate_id", "anonymous_id", "campaign_ids", "fb_post_attachment", "receipt_data", AdRevenueScheme.AD_TYPE, "fb_content", "fb_content_id", "fb_description", "fb_level", "fb_max_rating_value", "fb_payment_info_available", "fb_registration_method", "fb_success", "pm", "_audiencePropertyIds", "cs_maca");
        }
    }

    private c() {
    }

    private final HashSet<String> a(JSONArray jSONArray) {
        if (jSONArray == null || jSONArray.length() == 0) {
            return null;
        }
        HashSet<String> hashSet = new HashSet<>();
        int length = jSONArray.length();
        if (length > 0) {
            int i10 = 0;
            while (true) {
                int i11 = i10 + 1;
                String string = jSONArray.getString(i10);
                Intrinsics.checkNotNullExpressionValue(string, "jsonArray.getString(i)");
                hashSet.add(string);
                if (i11 >= length) {
                    break;
                }
                i10 = i11;
            }
        }
        return hashSet;
    }

    public static final void b() {
        f10240b = true;
        f10239a.d();
    }

    private final void d() {
        a0 a0Var = a0.f14051a;
        w o10 = a0.o(e0.m(), false);
        if (o10 != null) {
            HashSet<String> a10 = a(o10.h());
            if (a10 == null) {
                a10 = c();
            }
            f10242d = a10;
        }
    }

    public static final void e(Bundle bundle) {
        if (f10240b && bundle != null && !bundle.isEmpty() && f10242d != null) {
            ArrayList<String> arrayList = new ArrayList<>();
            Set<String> keySet = bundle.keySet();
            Intrinsics.checkNotNullExpressionValue(keySet, "parameters.keySet()");
            for (String str : keySet) {
                HashSet<String> hashSet = f10242d;
                Intrinsics.c(hashSet);
                if (!hashSet.contains(str)) {
                    Intrinsics.checkNotNullExpressionValue(str, "param");
                    arrayList.add(str);
                }
            }
            for (String remove : arrayList) {
                bundle.remove(remove);
            }
            bundle.putString("pm", "1");
        }
    }

    @NotNull
    public final HashSet<String> c() {
        return (HashSet) f10241c.getValue();
    }
}
