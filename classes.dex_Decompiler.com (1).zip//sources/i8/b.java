package i8;

abstract class b {
}
