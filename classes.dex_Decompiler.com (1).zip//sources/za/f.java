package za;

public interface f extends a, e, g, j {
}
