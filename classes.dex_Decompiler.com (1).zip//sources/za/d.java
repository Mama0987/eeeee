package za;

import android.content.Intent;

public interface d {
    void a(Intent intent);

    void b(String str);
}
