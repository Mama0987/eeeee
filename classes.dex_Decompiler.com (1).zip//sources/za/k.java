package za;

public interface k {
    void setVideoBitRate(int i10);

    void setVideoFrameRate(float f10);
}
