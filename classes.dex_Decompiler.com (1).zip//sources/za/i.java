package za;

public interface i {
    void a();

    void b();
}
