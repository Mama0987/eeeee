package za;

public interface a {
    void onAudioEncodeProgress(int i10);
}
