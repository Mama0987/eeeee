package za;

public interface b extends a {
    void onAudioEncodeComplete();
}
