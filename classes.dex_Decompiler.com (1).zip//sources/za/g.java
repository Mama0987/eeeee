package za;

public interface g {
    void onMuxerEnd();

    void onMuxerProgress(int i10);

    void onMuxerStart();
}
