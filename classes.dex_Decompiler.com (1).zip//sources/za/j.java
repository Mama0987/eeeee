package za;

public interface j {
    void OnVideoCompletion(String str);

    void OnVideoPrepared(String str);

    void OnVideoSeekComplete(String str);

    void OnVideoStared(String str);
}
