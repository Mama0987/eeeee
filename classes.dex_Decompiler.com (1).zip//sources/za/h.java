package za;

import android.content.Intent;

public interface h {
    void a(String str);

    void b(Intent intent);
}
