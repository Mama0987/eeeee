package za;

public interface c {
    void a();

    void b();
}
