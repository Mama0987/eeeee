package k2;

import com.garena.pay.android.b;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Target({ElementType.METHOD, ElementType.PARAMETER, ElementType.LOCAL_VARIABLE})
@Metadata
@Retention(RetentionPolicy.RUNTIME)
public @interface p {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final a f12249a = a.f12250a;

    @Metadata
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ a f12250a = new a();

        private a() {
        }

        @NotNull
        public final b a(@p int i10) {
            return i10 != 1002 ? i10 != 1004 ? b.GOP_ERROR_SERVER : b.UNSUPPORTED_API : b.ERROR_IN_PARAMS;
        }
    }
}
