package k2;

import java.util.concurrent.Callable;

public final /* synthetic */ class h implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i f12222a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f12223b;

    public /* synthetic */ h(i iVar, String str) {
        this.f12222a = iVar;
        this.f12223b = str;
    }

    public final Object call() {
        return this.f12222a.l(this.f12223b);
    }
}
