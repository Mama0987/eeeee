package k2;

import android.content.Context;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import i2.d;
import i2.n;

public class c {

    /* renamed from: g  reason: collision with root package name */
    private static volatile String f12209g = "";

    /* renamed from: a  reason: collision with root package name */
    private String f12210a;

    /* renamed from: b  reason: collision with root package name */
    private String f12211b;

    /* renamed from: c  reason: collision with root package name */
    private String f12212c;

    /* renamed from: d  reason: collision with root package name */
    private String f12213d;

    /* renamed from: e  reason: collision with root package name */
    private String f12214e;

    /* renamed from: f  reason: collision with root package name */
    private String f12215f;

    public c() {
        this((String) null);
    }

    public c(String str) {
        this.f12210a = "";
        this.f12211b = "";
        this.f12212c = "";
        this.f12213d = "";
        this.f12214e = "";
        this.f12215f = "";
        b(str);
    }

    private String a(String str) {
        return TextUtils.isEmpty(str) ? "" : str;
    }

    private void b(String str) {
        String str2;
        String str3;
        try {
            this.f12212c = a("4.0.19P9");
            String str4 = Build.MODEL;
            if (TextUtils.isEmpty(str4)) {
                str2 = f12209g;
            } else {
                str2 = str4 + " " + f12209g;
            }
            this.f12210a = str2;
            String str5 = Build.VERSION.RELEASE;
            if (TextUtils.isEmpty(str5)) {
                str3 = "Android";
            } else {
                str3 = "Android " + str5;
            }
            this.f12211b = str3;
            this.f12213d = a(n.c());
            this.f12214e = a(n.a());
            this.f12215f = a(str);
        } catch (Exception e10) {
            d.b(e10);
        }
    }

    public static void c(Context context) {
        if (context != null && ((TelephonyManager) context.getSystemService("phone")).getPhoneType() == 0) {
            f12209g = "tablet";
        }
    }

    @NonNull
    public String toString() {
        return String.format("%s/%s(%s;%s;%s;%s;%s)", new Object[]{"GarenaMSDK", this.f12212c, this.f12210a, this.f12211b, this.f12213d, this.f12214e, this.f12215f});
    }
}
