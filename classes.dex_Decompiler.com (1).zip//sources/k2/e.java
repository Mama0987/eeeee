package k2;

import java.util.concurrent.Callable;

public final /* synthetic */ class e implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i f12218a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f12219b;

    public /* synthetic */ e(i iVar, String str) {
        this.f12218a = iVar;
        this.f12219b = str;
    }

    public final Object call() {
        return this.f12218a.i(this.f12219b);
    }
}
