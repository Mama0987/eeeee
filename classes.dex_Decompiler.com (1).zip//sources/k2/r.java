package k2;

import android.util.SparseArray;

public enum r {
    ERR_PARSE(-1, "Failed to parse response"),
    SUCCESS(0, "Success"),
    UNKNOWN(1, "Unknown error"),
    PENDING_TRANSACTION(3, "Pending transaction"),
    ERR_PARAMS(1001, "Error params"),
    ERR_TOKEN(1002, "Error token"),
    ERR_SCOPE(1003, "Error scope"),
    ERR_PLATFORM(1101, "Error user platform"),
    ERR_DISPLAY_RESULT(2000, "Error display result (task error)"),
    ERR_SUBS_BINDING(3001, "Error subscription binding"),
    ERR_SUBS_GET_DETAILS(3002, "Error subscription get details failed");
    

    /* renamed from: n  reason: collision with root package name */
    private static final SparseArray<r> f12263n = null;

    /* renamed from: a  reason: collision with root package name */
    private final int f12265a;

    /* renamed from: b  reason: collision with root package name */
    private final String f12266b;

    static {
        int i10;
        f12263n = new SparseArray<>();
        for (r rVar : values()) {
            f12263n.put(rVar.g(), rVar);
        }
    }

    private r(int i10, String str) {
        this.f12265a = i10;
        this.f12266b = str;
    }

    public static String i(int i10) {
        return f12263n.get(i10, ERR_PARSE).h();
    }

    public static r k(int i10) {
        r rVar = f12263n.get(i10);
        return rVar == null ? ERR_PARSE : rVar;
    }

    public int g() {
        return this.f12265a;
    }

    public String h() {
        return this.f12266b;
    }
}
