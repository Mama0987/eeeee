package k2;

import ic.g0;
import l2.e;

public final /* synthetic */ class l implements e {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f12241a;

    public /* synthetic */ l(String str) {
        this.f12241a = str;
    }

    public final String a(g0 g0Var) {
        return n.p(this.f12241a, g0Var);
    }
}
