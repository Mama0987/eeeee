package k2;

import tc.a;

public final /* synthetic */ class k implements a.b {
    public final void a(String str) {
        n.k(str);
    }
}
