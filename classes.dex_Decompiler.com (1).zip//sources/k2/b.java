package k2;

import com.FF.voiceengine.FFVoiceConst;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import w9.c;

@Metadata
public class b<T> {
    @c("code")

    /* renamed from: a  reason: collision with root package name */
    private int f12205a = FFVoiceConst.FFVoiceErrorCode.FFVoice_ERROR_UNKNOWN;
    @c("data")

    /* renamed from: b  reason: collision with root package name */
    private T f12206b;
    @NotNull
    @c("error")

    /* renamed from: c  reason: collision with root package name */
    private String f12207c = "";
    @NotNull
    @c("error_detail")

    /* renamed from: d  reason: collision with root package name */
    private String f12208d = "";

    public final int a() {
        return this.f12205a;
    }

    public final T b() {
        return this.f12206b;
    }

    @NotNull
    public final String c() {
        return this.f12207c;
    }

    @NotNull
    public String d() {
        return this.f12208d;
    }
}
