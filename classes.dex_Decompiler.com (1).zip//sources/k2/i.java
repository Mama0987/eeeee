package k2;

import android.text.TextUtils;
import com.google.gson.Gson;
import com.google.gson.u;
import ic.d0;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class i {

    /* renamed from: j  reason: collision with root package name */
    public static final Gson f12224j;

    /* renamed from: a  reason: collision with root package name */
    private final b f12225a;

    /* renamed from: b  reason: collision with root package name */
    private final e f12226b;

    /* renamed from: c  reason: collision with root package name */
    private final c f12227c;

    /* renamed from: d  reason: collision with root package name */
    private final List<d> f12228d;

    /* renamed from: e  reason: collision with root package name */
    private Map<String, String> f12229e;

    /* renamed from: f  reason: collision with root package name */
    private JSONObject f12230f;

    /* renamed from: g  reason: collision with root package name */
    private String f12231g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f12232h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f12233i;

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f12234a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                k2.i$e[] r0 = k2.i.e.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f12234a = r0
                k2.i$e r1 = k2.i.e.GET     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f12234a     // Catch:{ NoSuchFieldError -> 0x001d }
                k2.i$e r1 = k2.i.e.POST     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: k2.i.a.<clinit>():void");
        }
    }

    interface b {
    }

    private enum c {
        MAP,
        JSON
    }

    public interface d extends b {
        void onCompleted(JSONObject jSONObject);
    }

    public enum e {
        GET,
        POST
    }

    public interface f extends b {
        void a(String str);
    }

    static {
        com.google.gson.e eVar = new com.google.gson.e();
        u uVar = u.LONG_OR_DOUBLE;
        f12224j = eVar.f(uVar).e(uVar).b();
    }

    public i(e eVar, List<d> list, Map<String, String> map) {
        this(eVar, list, map, (b) null);
    }

    public i(e eVar, List<d> list, Map<String, String> map, b bVar) {
        this.f12233i = false;
        this.f12226b = eVar;
        this.f12228d = list;
        this.f12229e = map;
        this.f12227c = c.MAP;
        this.f12225a = bVar;
    }

    public i(e eVar, Map<String, String> map) {
        this(eVar, (List<d>) null, map);
    }

    public i(e eVar, Map<String, String> map, b bVar) {
        this(eVar, (List<d>) null, map, bVar);
    }

    private void e(String str) throws JSONException {
        b bVar = this.f12225a;
        if (bVar instanceof f) {
            f fVar = (f) bVar;
            if (str == null) {
                str = "";
            }
            fVar.a(str);
        } else if (bVar instanceof d) {
            ((d) bVar).onCompleted(!TextUtils.isEmpty(str) ? new JSONObject(str) : null);
        }
    }

    public static String h(e eVar, String str, Map<String, String> map, boolean z10, boolean z11) {
        i iVar = new i(eVar, map);
        iVar.n(z10);
        iVar.o(z11);
        return iVar.i(str);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object j(v1.i iVar) throws Exception {
        if (iVar.z() || iVar.v() == null) {
            e((String) null);
            return null;
        }
        e((String) iVar.v());
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object k(v1.i iVar) throws Exception {
        if (iVar.z()) {
            i2.d.b(iVar.u());
            e((String) null);
        }
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ String l(String str) throws Exception {
        int i10 = a.f12234a[this.f12226b.ordinal()];
        if (i10 != 1) {
            if (i10 != 2) {
                return null;
            }
            if (this.f12227c == c.JSON) {
                return s.b().q(str, this.f12228d, this.f12230f, false, this.f12232h);
            } else if (!TextUtils.isEmpty(this.f12231g)) {
                return s.b().n(str, this.f12228d, this.f12229e, this.f12231g, this.f12232h);
            } else {
                return s.b().p(str, this.f12228d, this.f12229e, this.f12233i, (String) null, (d0) null, this.f12232h);
            }
        } else if (!TextUtils.isEmpty(this.f12231g)) {
            return s.b().g(str, this.f12229e, this.f12231g, this.f12232h);
        } else {
            return s.b().i(str, this.f12229e, this.f12233i, this.f12228d, this.f12232h);
        }
    }

    public static JSONObject m(e eVar, String str, Map<String, String> map, boolean z10) throws Exception {
        try {
            return new JSONObject(h(eVar, str, map, z10, false));
        } catch (Exception unused) {
            throw new o5.b(com.garena.pay.android.b.NETWORK_RESPONSE_PARSE_FAIL);
        }
    }

    public void f(String str) {
        v1.i.f(new e(this, str)).l(new f(this), v1.i.f16633k).k(new g(this));
    }

    /* renamed from: g */
    public String i(String str) {
        v1.i f10 = v1.i.f(new h(this, str));
        try {
            f10.J();
            if (!f10.z()) {
                if (!f10.x()) {
                    return (String) f10.v();
                }
            }
            i2.d.b(f10.u());
            return null;
        } catch (InterruptedException e10) {
            i2.d.b(e10);
            return null;
        }
    }

    public i n(boolean z10) {
        this.f12232h = z10;
        return this;
    }

    public void o(boolean z10) {
        this.f12233i = z10;
    }

    public i p(String str) {
        this.f12231g = str;
        return this;
    }
}
