package k2;

import android.webkit.WebView;
import eb.n;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import v1.i;

@Metadata
public final class v {
    public static final void c(@NotNull WebView webView, @NotNull String str, @NotNull Function1<? super Boolean, Void> function1) {
        Intrinsics.checkNotNullParameter(webView, "<this>");
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(function1, "callback");
        i.f(new t(str)).l(new u(webView, function1), i.f16633k);
    }

    /* access modifiers changed from: private */
    public static final n d(String str) {
        Intrinsics.checkNotNullParameter(str, "$url");
        return n.a(n.f12243a.e(str));
    }

    /* access modifiers changed from: private */
    public static final Void e(WebView webView, Function1 function1, i iVar) {
        Boolean bool;
        Intrinsics.checkNotNullParameter(webView, "$this_loadUrlWithAutoSwitch");
        Intrinsics.checkNotNullParameter(function1, "$callback");
        Object v10 = iVar.v();
        Intrinsics.checkNotNullExpressionValue(v10, "result.result");
        Object i10 = ((n) v10).i();
        if (n.d(i10) == null) {
            webView.loadUrl((String) i10);
            bool = Boolean.TRUE;
        } else {
            bool = Boolean.FALSE;
        }
        return (Void) function1.invoke(bool);
    }
}
