package k2;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import k2.i;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import o5.b;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class j {
    public static final <R> R a(@NotNull i.e eVar, @NotNull String str, @NotNull Map<String, String> map, @NotNull Class<R> cls) throws b {
        Intrinsics.checkNotNullParameter(eVar, "requestType");
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "params");
        Intrinsics.checkNotNullParameter(cls, "clazz");
        return c(eVar, str, map, cls, false, false, 48, (Object) null);
    }

    public static final <R> R b(@NotNull i.e eVar, @NotNull String str, @NotNull Map<String, String> map, @NotNull Class<R> cls, boolean z10, boolean z11) throws b {
        boolean z12;
        Intrinsics.checkNotNullParameter(eVar, "requestType");
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "params");
        Intrinsics.checkNotNullParameter(cls, "clazz");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Iterator<Map.Entry<String, String>> it = map.entrySet().iterator();
        while (true) {
            z12 = true;
            if (!it.hasNext()) {
                break;
            }
            Map.Entry next = it.next();
            if (next.getKey() == null || next.getValue() == null) {
                z12 = false;
            }
            if (z12) {
                linkedHashMap.put(next.getKey(), next.getValue());
            }
        }
        String h10 = i.h(eVar, str, linkedHashMap, z10, z11);
        if (h10 == null) {
            h10 = "";
        }
        if (h10.length() != 0) {
            z12 = false;
        }
        if (!z12) {
            return i.f12224j.l(h10, cls);
        }
        throw new b(com.garena.pay.android.b.NETWORK_EXCEPTION);
    }

    public static /* synthetic */ Object c(i.e eVar, String str, Map map, Class cls, boolean z10, boolean z11, int i10, Object obj) throws b {
        if ((i10 & 1) != 0) {
            eVar = i.e.POST;
        }
        return b(eVar, str, map, cls, (i10 & 16) != 0 ? false : z10, (i10 & 32) != 0 ? false : z11);
    }
}
