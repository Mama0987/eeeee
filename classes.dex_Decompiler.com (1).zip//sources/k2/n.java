package k2;

import co.datadome.sdk.DataDomeInterceptor;
import co.datadome.sdk.DataDomeSDKListener;
import com.beetalk.sdk.j;
import com.beetalk.sdk.s;
import eb.i;
import eb.n;
import ic.d0;
import ic.e;
import ic.g0;
import ic.o;
import ic.p;
import ic.q;
import ic.t;
import ic.z;
import java.io.File;
import java.net.InetAddress;
import java.util.List;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import l2.f;
import org.jetbrains.annotations.NotNull;
import qb.l;
import tc.a;

@Metadata
public final class n {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final n f12243a = new n();
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final i f12244b = k.a(b.f12246a);
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private static final l2.b f12245c = new l2.b();

    @Metadata
    public static final class a implements p {
        a() {
        }

        @NotNull
        public List<o> a(@NotNull z zVar) {
            Intrinsics.checkNotNullParameter(zVar, "url");
            if (s.f5405f.contains(zVar.toString())) {
                String d10 = new d2.i().d();
                Intrinsics.checkNotNullExpressionValue(d10, "cookie");
                if (d10.length() > 0) {
                    o e10 = o.e(zVar, d10);
                    List<o> e11 = e10 != null ? p.e(e10) : null;
                    return e11 == null ? q.h() : e11;
                }
            }
            return q.h();
        }

        public void b(@NotNull z zVar, @NotNull List<o> list) {
            Intrinsics.checkNotNullParameter(zVar, "url");
            Intrinsics.checkNotNullParameter(list, "cookies");
        }
    }

    @Metadata
    static final class b extends l implements Function0<d0> {

        /* renamed from: a  reason: collision with root package name */
        public static final b f12246a = new b();

        b() {
            super(0);
        }

        /* renamed from: a */
        public final d0 invoke() {
            return new d0.b().e(new e(new File(j.z().getCacheDir(), "msdk_http_cache"), 10485760)).j(new q(k4.p.f12322k)).d();
        }
    }

    @Metadata
    static final class c extends l implements Function0<d0.b> {

        /* renamed from: a  reason: collision with root package name */
        public static final c f12247a = new c();

        c() {
            super(0);
        }

        @NotNull
        /* renamed from: a */
        public final d0.b invoke() {
            return n.f12243a.l();
        }
    }

    @Metadata
    static final class d extends l implements Function0<d0.b> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ l2.e f12248a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(l2.e eVar) {
            super(0);
            this.f12248a = eVar;
        }

        @NotNull
        /* renamed from: a */
        public final d0.b invoke() {
            d0.b a10 = n.f12243a.l().a(new l2.a(this.f12248a));
            Intrinsics.checkNotNullExpressionValue(a10, "getClientBuilder()\n     …eptor(signatureProvider))");
            return a10;
        }
    }

    private n() {
    }

    private final p f() {
        return new a();
    }

    private final Object g(String str) {
        Object a10;
        try {
            n.a aVar = eb.n.f10642b;
            List<InetAddress> a11 = t.f11791a.a(str);
            Intrinsics.checkNotNullExpressionValue(a11, "ipList");
            if (!a11.isEmpty()) {
                a10 = Boolean.TRUE;
            } else {
                a10 = eb.o.a(new IllegalStateException("Cannot access this domain: " + str));
            }
            return eb.n.b(a10);
        } catch (Throwable th) {
            n.a aVar2 = eb.n.f10642b;
            return eb.n.b(eb.o.a(th));
        }
    }

    private final d0.b h(d0.b bVar) {
        TimeUnit timeUnit = TimeUnit.SECONDS;
        bVar.k(60, timeUnit);
        bVar.h(60, timeUnit);
        String cVar = new c().toString();
        Intrinsics.checkNotNullExpressionValue(cVar, "GarenaUserAgent().toString()");
        bVar.a(new f(cVar));
        bVar.a(new l2.d());
        bVar.a(new l2.c(f12245c));
        bVar.i(f12243a.f());
        return bVar;
    }

    public static /* synthetic */ d0 j(n nVar, boolean z10, String str, Function0 function0, int i10, Object obj) {
        if ((i10 & 2) != 0) {
            str = "";
        }
        if ((i10 & 4) != 0) {
            function0 = c.f12247a;
        }
        return nVar.i(z10, str, function0);
    }

    /* access modifiers changed from: private */
    public static final void k(String str) {
        i2.d.a("OkHttp:" + str, new Object[0]);
    }

    /* access modifiers changed from: private */
    public final d0.b l() {
        d0.b E = m().E();
        Intrinsics.checkNotNullExpressionValue(E, "defaultClient.newBuilder()");
        return h(E);
    }

    private final d0 m() {
        return (d0) f12244b.getValue();
    }

    private final d0 o(boolean z10, l2.e eVar) {
        return j(this, z10, (String) null, new d(eVar), 2, (Object) null);
    }

    /* access modifiers changed from: private */
    public static final String p(String str, g0 g0Var) {
        Intrinsics.checkNotNullParameter(str, "$signatureKey");
        Intrinsics.checkNotNullParameter(g0Var, "it");
        String a10 = i2.p.a(str, o.m(g0Var));
        Intrinsics.checkNotNullExpressionValue(a10, "HMAC256Digest(signatureK… it.parametersToString())");
        return a10;
    }

    /* access modifiers changed from: private */
    public static final String r(String str, g0 g0Var) {
        Intrinsics.checkNotNullParameter(str, "$signatureKey");
        Intrinsics.checkNotNullParameter(g0Var, "it");
        String a10 = i2.p.a(str, o.l(g0Var, false, 1, (Object) null));
        Intrinsics.checkNotNullExpressionValue(a10, "HMAC256Digest(signatureK…rametersToSortedString())");
        return a10;
    }

    @NotNull
    public final Object e(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "url");
        try {
            n.a aVar = eb.n.f10642b;
            z o10 = o.o(str);
            if (o10 == null) {
                return eb.n.b(eb.o.a(new IllegalStateException("Parse url failed")));
            }
            String f10 = o.f(o10);
            n nVar = f12243a;
            Intrinsics.checkNotNullExpressionValue(f10, "host");
            if (!eb.n.g(nVar.g(f10))) {
                String a10 = f12245c.a(f10);
                if (a10 == null) {
                    return eb.n.b(eb.o.a(new IllegalStateException("Backup host not found")));
                }
                str = o10.p().g(a10).c().toString();
                Intrinsics.checkNotNullExpressionValue(str, "httpUrl.newBuilder().hos…pHost).build().toString()");
            }
            return eb.n.b(str);
        } catch (Throwable th) {
            n.a aVar2 = eb.n.f10642b;
            return eb.n.b(eb.o.a(th));
        }
    }

    @NotNull
    public final d0 i(boolean z10, @NotNull String str, @NotNull Function0<d0.b> function0) {
        Intrinsics.checkNotNullParameter(str, "dataDomeUserAgent");
        Intrinsics.checkNotNullParameter(function0, "clientBuilderProvider");
        d0.b invoke = function0.invoke();
        if (z10) {
            DataDomeInterceptor a10 = new a(false, (DataDomeSDKListener) null, (String) null, 7, (DefaultConstructorMarker) null).a();
            invoke.i(a10.getDataDomeCookieJar(f12243a.f()));
            invoke.a(a10);
            if (str.length() > 0) {
                invoke.a(new f(str));
            }
        }
        tc.a aVar = new tc.a(new k());
        aVar.d(!s.f5402c ? a.C0286a.BODY : a.C0286a.NONE);
        invoke.a(aVar);
        d0 d10 = invoke.d();
        Intrinsics.checkNotNullExpressionValue(d10, "clientBuilderProvider().…     })\n        }.build()");
        return d10;
    }

    @NotNull
    public final d0 n(@NotNull String str, boolean z10) {
        Intrinsics.checkNotNullParameter(str, "signatureKey");
        return o(z10, new l(str));
    }

    @NotNull
    public final d0 q(@NotNull String str, boolean z10) {
        Intrinsics.checkNotNullParameter(str, "signatureKey");
        return o(z10, new m(str));
    }
}
