package k2;

import com.garena.pay.android.b;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class q {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final q f12251a = new q();

    private q() {
    }

    @NotNull
    public static final b a(String str) {
        if (str != null) {
            switch (str.hashCode()) {
                case -847806252:
                    if (str.equals("invalid_grant")) {
                        return b.ACCESS_TOKEN_INVALID_GRANT;
                    }
                    break;
                case -610623917:
                    if (str.equals("error_account_swapped")) {
                        return b.ACCOUNT_SECURITY_ALREADY_SWAPPED;
                    }
                    break;
                case 224059890:
                    if (str.equals("error_user_ban")) {
                        return b.ERROR_USER_BANNED;
                    }
                    break;
                case 2019871319:
                    if (str.equals("ssl_failure")) {
                        return b.NETWORK_CONNECTION_EXCEPTION;
                    }
                    break;
            }
        }
        return b.UNKNOWN_ERROR;
    }
}
