package k2;

import android.text.TextUtils;
import androidx.annotation.NonNull;

public class d {

    /* renamed from: a  reason: collision with root package name */
    public final String f12216a;

    /* renamed from: b  reason: collision with root package name */
    public final String f12217b;

    public d(String str, String str2) {
        this.f12216a = TextUtils.isEmpty(str) ? "" : str;
        this.f12217b = TextUtils.isEmpty(str2) ? "" : str2;
    }

    @NonNull
    public String toString() {
        return "[" + this.f12216a + " -> " + this.f12217b + "]";
    }
}
