package k2;

import android.app.Application;
import android.content.Context;
import co.datadome.sdk.DataDomeInterceptor;
import co.datadome.sdk.DataDomeSDK;
import co.datadome.sdk.DataDomeSDKListener;
import com.beetalk.sdk.j;
import com.beetalk.sdk.s;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class a {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final DataDomeSDK.Builder f12204a;

    public a(boolean z10, DataDomeSDKListener dataDomeSDKListener, @NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "cookie");
        Context z11 = j.z();
        Intrinsics.d(z11, "null cannot be cast to non-null type android.app.Application");
        DataDomeSDK.Builder backBehaviour = DataDomeSDK.with((Application) z11, s.r(), "4.0.19P9").listener(dataDomeSDKListener).bypassAcceptHeader(Boolean.valueOf(z10)).activateDatadomeLogger(Boolean.valueOf(s.q())).backBehaviour(DataDomeSDK.BackBehaviour.GO_BACK);
        if (str.length() > 0) {
            backBehaviour.setCookie(str);
        }
        Intrinsics.checkNotNullExpressionValue(backBehaviour, "with(\n            GGPlat…          }\n            }");
        this.f12204a = backBehaviour;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(boolean z10, DataDomeSDKListener dataDomeSDKListener, String str, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this((i10 & 1) != 0 ? false : z10, (i10 & 2) != 0 ? null : dataDomeSDKListener, (i10 & 4) != 0 ? "" : str);
    }

    @NotNull
    public final DataDomeInterceptor a() {
        Context z10 = j.z();
        Intrinsics.d(z10, "null cannot be cast to non-null type android.app.Application");
        return new DataDomeInterceptor((Application) z10, this.f12204a);
    }
}
