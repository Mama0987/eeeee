package k2;

import v1.g;
import v1.i;

public final /* synthetic */ class f implements g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i f12220a;

    public /* synthetic */ f(i iVar) {
        this.f12220a = iVar;
    }

    public final Object a(i iVar) {
        return this.f12220a.j(iVar);
    }
}
