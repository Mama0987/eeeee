package k2;

import android.os.Build;
import android.telephony.TelephonyManager;
import com.beetalk.sdk.j;
import eb.i;
import i2.d;
import i2.n;
import ic.b0;
import ic.d0;
import ic.g0;
import ic.h0;
import ic.i0;
import ic.j0;
import ic.w;
import ic.z;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.SSLHandshakeException;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import qb.a0;
import qb.l;

@Metadata
public final class s {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final b f12267a = new b((DefaultConstructorMarker) null);
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    public static final i<s> f12268b = k.a(a.f12269a);

    @Metadata
    static final class a extends l implements Function0<s> {

        /* renamed from: a  reason: collision with root package name */
        public static final a f12269a = new a();

        a() {
            super(0);
        }

        @NotNull
        /* renamed from: a */
        public final s invoke() {
            return new s((DefaultConstructorMarker) null);
        }
    }

    @Metadata
    public static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final s a() {
            return (s) s.f12268b.getValue();
        }
    }

    private s() {
    }

    public /* synthetic */ s(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }

    @NotNull
    public static final s b() {
        return f12267a.a();
    }

    public static /* synthetic */ String d(s sVar, String str, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            str = "";
        }
        return sVar.c(str);
    }

    private final String e(d0 d0Var, z zVar, Map<String, String> map, List<? extends d> list, boolean z10) {
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        z.a p10 = zVar.p();
        for (Map.Entry entry : entrySet) {
            p10.b((String) entry.getKey(), (String) entry.getValue());
        }
        String zVar2 = p10.c().toString();
        Intrinsics.checkNotNullExpressionValue(zVar2, "getData.entries.fold(htt…)\n            .toString()");
        if (list == null) {
            list = q.h();
        }
        g0.a aVar = new g0.a();
        for (d dVar : list) {
            aVar.a(dVar.f12216a, dVar.f12217b);
        }
        try {
            i0 a10 = d0Var.c(aVar.k(zVar2).c().b()).a();
            if (a10.i() || z10) {
                Intrinsics.checkNotNullExpressionValue(a10, "response");
                j0 d10 = o.d(a10);
                if (d10 != null) {
                    return d10.k();
                }
                return null;
            }
        } catch (Exception e10) {
            d.b(e10);
            if (e10 instanceof SSLHandshakeException) {
                return "{\n    \"error\":\"ssl_failure\"\n}";
            }
        }
        return null;
    }

    public static /* synthetic */ String j(s sVar, String str, Map map, boolean z10, List list, boolean z11, int i10, Object obj) {
        boolean z12 = (i10 & 4) != 0 ? false : z10;
        if ((i10 & 8) != 0) {
            list = null;
        }
        return sVar.i(str, map, z12, list, (i10 & 16) != 0 ? false : z11);
    }

    private final String k(d0 d0Var, String str, List<? extends d> list, h0 h0Var, boolean z10) {
        if (list == null) {
            list = q.h();
        }
        g0.a aVar = new g0.a();
        for (d dVar : list) {
            aVar.a(dVar.f12216a, dVar.f12217b);
        }
        try {
            i0 a10 = d0Var.c(aVar.k(str).g(h0Var).b()).a();
            if (a10.i() || z10) {
                Intrinsics.checkNotNullExpressionValue(a10, "response");
                j0 d10 = o.d(a10);
                if (d10 != null) {
                    return d10.k();
                }
                return null;
            }
        } catch (Exception e10) {
            d.b(e10);
            if (e10 instanceof SSLHandshakeException) {
                return "{\n    \"error\":\"ssl_failure\"\n}";
            }
        }
        return null;
    }

    private final String l(d0 d0Var, String str, List<? extends d> list, Map<String, String> map, boolean z10) {
        Set<Map.Entry<String, String>> entrySet = map.entrySet();
        w.a aVar = new w.a();
        for (Map.Entry entry : entrySet) {
            aVar.a((String) entry.getKey(), (String) entry.getValue());
        }
        w c10 = aVar.c();
        Intrinsics.checkNotNullExpressionValue(c10, "requestBody");
        return k(d0Var, str, list, c10, z10);
    }

    public static /* synthetic */ String s(s sVar, String str, List list, Map map, boolean z10, String str2, d0 d0Var, boolean z11, int i10, Object obj) {
        return sVar.p(str, (i10 & 2) != 0 ? null : list, map, (i10 & 8) != 0 ? false : z10, (i10 & 16) != 0 ? null : str2, (i10 & 32) != 0 ? null : d0Var, (i10 & 64) != 0 ? false : z11);
    }

    @NotNull
    public final String c(@NotNull String str) {
        String str2;
        Intrinsics.checkNotNullParameter(str, "extra");
        Object systemService = j.z().getSystemService("phone");
        TelephonyManager telephonyManager = systemService instanceof TelephonyManager ? (TelephonyManager) systemService : null;
        String str3 = telephonyManager != null && telephonyManager.getPhoneType() == 0 ? "tablet" : "";
        String str4 = Build.MODEL;
        if (!(str4 == null || str4.length() == 0)) {
            str3 = str4 + ' ' + str3;
        }
        String str5 = Build.VERSION.RELEASE;
        if (str5 == null || str5.length() == 0) {
            str2 = "Android";
        } else {
            str2 = "Android " + str5;
        }
        String c10 = n.c();
        String a10 = n.a();
        a0 a0Var = a0.f14418a;
        String format = String.format(Locale.getDefault(), "%s/%s(%s;%s;%s;%s;%s)", Arrays.copyOf(new Object[]{"GarenaMSDK", "4.0.19P9", str3, str2, c10, a10, str}, 7));
        Intrinsics.checkNotNullExpressionValue(format, "format(locale, format, *args)");
        return format;
    }

    public final String f(@NotNull String str, @NotNull Map<String, String> map) {
        Intrinsics.checkNotNullParameter(str, "baseUrl");
        Intrinsics.checkNotNullParameter(map, "getData");
        return j(this, str, map, false, (List) null, false, 28, (Object) null);
    }

    public final String g(@NotNull String str, @NotNull Map<String, String> map, @NotNull String str2, boolean z10) {
        Intrinsics.checkNotNullParameter(str, "baseUrl");
        Intrinsics.checkNotNullParameter(map, "getData");
        Intrinsics.checkNotNullParameter(str2, "signatureKey");
        z o10 = o.o(str);
        if (o10 == null) {
            return null;
        }
        return e(n.f12243a.q(str2, z10), o10, map, (List<? extends d>) null, false);
    }

    public final String h(@NotNull String str, @NotNull Map<String, String> map, boolean z10) {
        Intrinsics.checkNotNullParameter(str, "baseUrl");
        Intrinsics.checkNotNullParameter(map, "getData");
        return j(this, str, map, z10, (List) null, false, 24, (Object) null);
    }

    public final String i(@NotNull String str, @NotNull Map<String, String> map, boolean z10, List<? extends d> list, boolean z11) {
        Intrinsics.checkNotNullParameter(str, "baseUrl");
        Intrinsics.checkNotNullParameter(map, "getData");
        z o10 = o.o(str);
        if (o10 == null) {
            return null;
        }
        return e(n.j(n.f12243a, z11, (String) null, (Function0) null, 6, (Object) null), o10, map, list, z10);
    }

    public final String m(@NotNull String str, List<? extends d> list, @NotNull Map<String, String> map) {
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "postData");
        return s(this, str, list, map, false, (String) null, (d0) null, false, 120, (Object) null);
    }

    public final String n(@NotNull String str, List<? extends d> list, @NotNull Map<String, String> map, @NotNull String str2, boolean z10) {
        String str3 = str2;
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "postData");
        Intrinsics.checkNotNullParameter(str3, "signatureKey");
        return s(this, str, list, map, false, (String) null, n.f12243a.q(str3, z10), false, 64, (Object) null);
    }

    public final String o(@NotNull String str, List<? extends d> list, @NotNull Map<String, String> map, boolean z10, String str2) {
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "postData");
        return s(this, str, list, map, z10, str2, (d0) null, false, 96, (Object) null);
    }

    public final String p(@NotNull String str, List<? extends d> list, @NotNull Map<String, String> map, boolean z10, String str2, d0 d0Var, boolean z11) {
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "postData");
        if (d0Var == null) {
            d0Var = str2 == null || str2.length() == 0 ? n.j(n.f12243a, z11, (String) null, (Function0) null, 6, (Object) null) : n.f12243a.n(str2, z11);
        }
        return l(d0Var, str, list, map, z10);
    }

    public final String q(@NotNull String str, List<? extends d> list, @NotNull JSONObject jSONObject, boolean z10, boolean z11) {
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(jSONObject, "postJsonData");
        d0 j10 = n.j(n.f12243a, z11, (String) null, (Function0) null, 6, (Object) null);
        b0 p10 = o.p("application/json");
        String jSONObject2 = jSONObject.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, "postJsonData.toString()");
        return k(j10, str, list, o.q(jSONObject2, p10), z10);
    }

    public final String r(@NotNull String str, @NotNull Map<String, String> map) {
        Intrinsics.checkNotNullParameter(str, "url");
        Intrinsics.checkNotNullParameter(map, "postData");
        return s(this, str, (List) null, map, false, (String) null, (d0) null, false, 122, (Object) null);
    }
}
