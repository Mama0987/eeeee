package k2;

import java.util.concurrent.Callable;

public final /* synthetic */ class t implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f12270a;

    public /* synthetic */ t(String str) {
        this.f12270a = str;
    }

    public final Object call() {
        return v.d(this.f12270a);
    }
}
