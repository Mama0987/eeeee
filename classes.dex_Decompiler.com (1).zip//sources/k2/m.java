package k2;

import ic.g0;
import l2.e;

public final /* synthetic */ class m implements e {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f12242a;

    public /* synthetic */ m(String str) {
        this.f12242a = str;
    }

    public final String a(g0 g0Var) {
        return n.r(this.f12242a, g0Var);
    }
}
