package k2;

import android.net.Uri;
import eb.r;
import ic.b0;
import ic.g0;
import ic.h0;
import ic.i0;
import ic.j0;
import ic.y;
import ic.z;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import mc.e;
import mc.f;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class o {
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0030, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        mb.b.a(r1, r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0034, code lost:
        throw r2;
     */
    @org.jetbrains.annotations.NotNull
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.String a(ic.g0 r3) {
        /*
            java.lang.String r0 = ""
            if (r3 != 0) goto L_0x0005
            return r0
        L_0x0005:
            java.lang.String r1 = g(r3)
            boolean r1 = mc.f.b(r1)
            if (r1 != 0) goto L_0x0010
            return r0
        L_0x0010:
            ic.h0 r3 = c(r3)
            if (r3 != 0) goto L_0x0017
            return r0
        L_0x0017:
            okio.c r1 = new okio.c     // Catch:{ IOException -> 0x0035 }
            r1.<init>()     // Catch:{ IOException -> 0x0035 }
            r3.j(r1)     // Catch:{ all -> 0x002e }
            java.lang.String r3 = r1.D0()     // Catch:{ all -> 0x002e }
            r2 = 0
            mb.b.a(r1, r2)     // Catch:{ IOException -> 0x0035 }
            java.lang.String r1 = "{\n        Buffer().use {…eadUtf8()\n        }\n    }"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r1)     // Catch:{ IOException -> 0x0035 }
            r0 = r3
            goto L_0x0035
        L_0x002e:
            r3 = move-exception
            throw r3     // Catch:{ all -> 0x0030 }
        L_0x0030:
            r2 = move-exception
            mb.b.a(r1, r3)     // Catch:{ IOException -> 0x0035 }
            throw r2     // Catch:{ IOException -> 0x0035 }
        L_0x0035:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: k2.o.a(ic.g0):java.lang.String");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x004e, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x004f, code lost:
        mb.b.a(r5, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0052, code lost:
        throw r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0085, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0086, code lost:
        mb.b.a(r2, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0089, code lost:
        throw r0;
     */
    @org.jetbrains.annotations.NotNull
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.String b(ic.i0 r5) {
        /*
            java.lang.String r0 = ""
            if (r5 == 0) goto L_0x008a
            boolean r1 = n(r5)
            if (r1 != 0) goto L_0x000c
            goto L_0x008a
        L_0x000c:
            ic.j0 r1 = d(r5)
            if (r1 != 0) goto L_0x0013
            return r0
        L_0x0013:
            okio.e r0 = r1.i()
            r2 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            r0.t0(r2)
            okio.c r2 = r0.L()
            ic.y r5 = e(r5)
            java.lang.String r3 = "Content-Encoding"
            java.lang.String r5 = r5.c(r3)
            r3 = 1
            java.lang.String r4 = "gzip"
            boolean r5 = kotlin.text.m.n(r4, r5, r3)
            r3 = 0
            if (r5 == 0) goto L_0x0053
            okio.j r5 = new okio.j
            okio.c r2 = r2.clone()
            r5.<init>(r2)
            okio.c r2 = new okio.c     // Catch:{ all -> 0x004c }
            r2.<init>()     // Catch:{ all -> 0x004c }
            r2.o0(r5)     // Catch:{ all -> 0x004c }
            mb.b.a(r5, r3)
            goto L_0x0053
        L_0x004c:
            r0 = move-exception
            throw r0     // Catch:{ all -> 0x004e }
        L_0x004e:
            r1 = move-exception
            mb.b.a(r5, r0)
            throw r1
        L_0x0053:
            ic.b0 r5 = r1.f()
            if (r5 == 0) goto L_0x0061
            java.nio.charset.Charset r1 = kotlin.text.Charsets.UTF_8
            java.nio.charset.Charset r5 = r5.b(r1)
            if (r5 != 0) goto L_0x0063
        L_0x0061:
            java.nio.charset.Charset r5 = kotlin.text.Charsets.UTF_8
        L_0x0063:
            java.lang.String r1 = "contentType?.charset(Cha….UTF_8) ?: Charsets.UTF_8"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r1)
            okio.c r0 = r0.L()
            boolean r0 = kotlin.jvm.internal.Intrinsics.a(r2, r0)
            if (r0 == 0) goto L_0x0076
            okio.c r2 = r2.clone()
        L_0x0076:
            java.lang.String r5 = r2.k0(r5)     // Catch:{ all -> 0x0083 }
            mb.b.a(r2, r3)
            java.lang.String r0 = "if (buffer == source.buf…readString(charset)\n    }"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r0)
            return r5
        L_0x0083:
            r5 = move-exception
            throw r5     // Catch:{ all -> 0x0085 }
        L_0x0085:
            r0 = move-exception
            mb.b.a(r2, r5)
            throw r0
        L_0x008a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: k2.o.b(ic.i0):java.lang.String");
    }

    public static final h0 c(@NotNull g0 g0Var) {
        Intrinsics.checkNotNullParameter(g0Var, "<this>");
        return g0Var.a();
    }

    public static final j0 d(@NotNull i0 i0Var) {
        Intrinsics.checkNotNullParameter(i0Var, "<this>");
        return i0Var.a();
    }

    public static final y e(@NotNull i0 i0Var) {
        Intrinsics.checkNotNullParameter(i0Var, "<this>");
        return i0Var.g();
    }

    public static final String f(@NotNull z zVar) {
        Intrinsics.checkNotNullParameter(zVar, "<this>");
        return zVar.m();
    }

    public static final String g(@NotNull g0 g0Var) {
        Intrinsics.checkNotNullParameter(g0Var, "<this>");
        return g0Var.g();
    }

    public static final Set<String> h(@NotNull z zVar) {
        Intrinsics.checkNotNullParameter(zVar, "<this>");
        return zVar.D();
    }

    public static final z i(@NotNull g0 g0Var) {
        Intrinsics.checkNotNullParameter(g0Var, "<this>");
        return g0Var.j();
    }

    @NotNull
    public static final Map<String, String> j(g0 g0Var, boolean z10) {
        if (g0Var == null) {
            return i0.i();
        }
        if (f.b(g(g0Var))) {
            String a10 = a(g0Var);
            if (a10.length() == 0) {
                return i0.i();
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (String split$default : StringsKt__StringsKt.split$default(a10, new String[]{"&"}, false, 0, 6, (Object) null)) {
                List split$default2 = StringsKt__StringsKt.split$default(split$default, new String[]{"="}, false, 0, 6, (Object) null);
                if (split$default2.size() > 1) {
                    Object obj = split$default2.get(0);
                    String str = (String) split$default2.get(1);
                    if (z10) {
                        str = Uri.decode(str);
                    }
                    Intrinsics.checkNotNullExpressionValue(str, "if (decode) Uri.decode(kv[1]) else kv[1]");
                    linkedHashMap.put(obj, str);
                }
            }
            return linkedHashMap;
        }
        z i10 = i(g0Var);
        Intrinsics.checkNotNullExpressionValue(i10, "url");
        Set<String> h10 = h(i10);
        Intrinsics.checkNotNullExpressionValue(h10, "url.queryParameterNames");
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        for (String str2 : h10) {
            Intrinsics.checkNotNullExpressionValue(str2, "name");
            String B = i(g0Var).B(str2);
            if (B == null) {
                B = "";
            }
            linkedHashMap2.put(str2, B);
        }
        return linkedHashMap2;
    }

    @NotNull
    public static final String k(g0 g0Var, boolean z10) {
        Set entrySet = h0.h(j(g0Var, z10)).entrySet();
        Intrinsics.checkNotNullExpressionValue(entrySet, "parameters(decode).toSortedMap().entries");
        StringBuilder sb2 = new StringBuilder();
        int i10 = 0;
        for (Object next : entrySet) {
            int i11 = i10 + 1;
            if (i10 < 0) {
                q.o();
            }
            Map.Entry entry = (Map.Entry) next;
            Pair a10 = r.a(entry.getKey(), entry.getValue());
            if (i10 > 0) {
                sb2.append('&');
            }
            sb2.append((String) a10.c());
            sb2.append('=');
            String str = (String) a10.d();
            if (str == null) {
                str = "";
            }
            sb2.append(str);
            i10 = i11;
        }
        String sb3 = sb2.toString();
        Intrinsics.checkNotNullExpressionValue(sb3, "foldIndexed(StringBuilde…      sb\n    }.toString()");
        return sb3;
    }

    public static /* synthetic */ String l(g0 g0Var, boolean z10, int i10, Object obj) {
        if ((i10 & 1) != 0) {
            z10 = true;
        }
        return k(g0Var, z10);
    }

    @NotNull
    public static final String m(g0 g0Var) {
        if (g0Var == null) {
            return "";
        }
        if (f.b(g(g0Var))) {
            return a(g0Var);
        }
        z i10 = i(g0Var);
        Intrinsics.checkNotNullExpressionValue(i10, "url");
        Set<String> h10 = h(i10);
        Intrinsics.checkNotNullExpressionValue(h10, "url.queryParameterNames");
        StringBuilder sb2 = new StringBuilder();
        int i11 = 0;
        for (T next : h10) {
            int i12 = i11 + 1;
            if (i11 < 0) {
                q.o();
            }
            String str = (String) next;
            Pair a10 = r.a(str, i(g0Var).B(str));
            if (i11 > 0) {
                sb2.append('&');
            }
            sb2.append((String) a10.c());
            sb2.append('=');
            String str2 = (String) a10.d();
            if (str2 == null) {
                str2 = "";
            }
            sb2.append(str2);
            i11 = i12;
        }
        String sb3 = sb2.toString();
        Intrinsics.checkNotNullExpressionValue(sb3, "foldIndexed(StringBuilde…      sb\n    }.toString()");
        return sb3;
    }

    public static final boolean n(@NotNull i0 i0Var) {
        Intrinsics.checkNotNullParameter(i0Var, "<this>");
        return e.c(i0Var);
    }

    public static final z o(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        return z.r(str);
    }

    public static final b0 p(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        return b0.d(str);
    }

    @NotNull
    public static final h0 q(@NotNull String str, b0 b0Var) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        h0 d10 = h0.d(b0Var, str);
        Intrinsics.checkNotNullExpressionValue(d10, "create(contentType, this)");
        return d10;
    }
}
