package k2;

import android.webkit.WebView;
import kotlin.jvm.functions.Function1;
import v1.g;
import v1.i;

public final /* synthetic */ class u implements g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ WebView f12271a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Function1 f12272b;

    public /* synthetic */ u(WebView webView, Function1 function1) {
        this.f12271a = webView;
        this.f12272b = function1;
    }

    public final Object a(i iVar) {
        return v.e(this.f12271a, this.f12272b, iVar);
    }
}
