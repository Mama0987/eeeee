package k2;

import v1.i;

public final /* synthetic */ class g implements v1.g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i f12221a;

    public /* synthetic */ g(i iVar) {
        this.f12221a = iVar;
    }

    public final Object a(i iVar) {
        return this.f12221a.k(iVar);
    }
}
