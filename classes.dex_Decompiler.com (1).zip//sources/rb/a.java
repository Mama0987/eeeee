package rb;

import kotlin.Metadata;

@Metadata
public interface a {
}
