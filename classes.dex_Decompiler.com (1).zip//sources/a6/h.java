package a6;

import android.content.Context;
import b6.f;
import b6.x;
import c6.d;
import e6.a;

public abstract class h {
    static x a(Context context, d dVar, f fVar, a aVar) {
        return new b6.d(context, dVar, fVar);
    }
}
