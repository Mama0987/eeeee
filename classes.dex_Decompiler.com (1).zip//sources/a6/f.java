package a6;

import e6.a;

public abstract class f {
    static b6.f a(a aVar) {
        return b6.f.f(aVar);
    }
}
