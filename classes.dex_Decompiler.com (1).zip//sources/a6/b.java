package a6;

import d6.b;
import u5.i;
import u5.p;

public final /* synthetic */ class b implements b.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c f568a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ p f569b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ i f570c;

    public /* synthetic */ b(c cVar, p pVar, i iVar) {
        this.f568a = cVar;
        this.f569b = pVar;
        this.f570c = iVar;
    }

    public final Object a() {
        return this.f568a.d(this.f569b, this.f570c);
    }
}
