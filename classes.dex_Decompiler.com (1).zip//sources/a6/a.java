package a6;

import s5.i;
import u5.p;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c f564a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ p f565b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ i f566c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ u5.i f567d;

    public /* synthetic */ a(c cVar, p pVar, i iVar, u5.i iVar2) {
        this.f564a = cVar;
        this.f565b = pVar;
        this.f566c = iVar;
        this.f567d = iVar2;
    }

    public final void run() {
        this.f564a.e(this.f565b, this.f566c, this.f567d);
    }
}
