package a6;

import android.content.Context;
import b6.f;
import b6.x;
import c6.d;
import db.a;
import w5.b;

public final class i implements b<x> {

    /* renamed from: a  reason: collision with root package name */
    private final a<Context> f583a;

    /* renamed from: b  reason: collision with root package name */
    private final a<d> f584b;

    /* renamed from: c  reason: collision with root package name */
    private final a<f> f585c;

    /* renamed from: d  reason: collision with root package name */
    private final a<e6.a> f586d;

    public i(a<Context> aVar, a<d> aVar2, a<f> aVar3, a<e6.a> aVar4) {
        this.f583a = aVar;
        this.f584b = aVar2;
        this.f585c = aVar3;
        this.f586d = aVar4;
    }

    public static i a(a<Context> aVar, a<d> aVar2, a<f> aVar3, a<e6.a> aVar4) {
        return new i(aVar, aVar2, aVar3, aVar4);
    }

    public static x c(Context context, d dVar, f fVar, e6.a aVar) {
        return (x) w5.d.c(h.a(context, dVar, fVar, aVar), "Cannot return null from a non-@Nullable @Provides method");
    }

    /* renamed from: b */
    public x get() {
        return c(this.f583a.get(), this.f584b.get(), this.f585c.get(), this.f586d.get());
    }
}
