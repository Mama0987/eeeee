package a6;

import b6.x;
import c6.d;
import d6.b;
import java.util.concurrent.Executor;
import java.util.logging.Logger;
import u5.i;
import u5.p;
import u5.u;
import v5.e;
import v5.m;

public class c implements e {

    /* renamed from: f  reason: collision with root package name */
    private static final Logger f571f = Logger.getLogger(u.class.getName());

    /* renamed from: a  reason: collision with root package name */
    private final x f572a;

    /* renamed from: b  reason: collision with root package name */
    private final Executor f573b;

    /* renamed from: c  reason: collision with root package name */
    private final e f574c;

    /* renamed from: d  reason: collision with root package name */
    private final d f575d;

    /* renamed from: e  reason: collision with root package name */
    private final b f576e;

    public c(Executor executor, e eVar, x xVar, d dVar, b bVar) {
        this.f573b = executor;
        this.f574c = eVar;
        this.f572a = xVar;
        this.f575d = dVar;
        this.f576e = bVar;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Object d(p pVar, i iVar) {
        this.f575d.J(pVar, iVar);
        this.f572a.a(pVar, 1);
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void e(p pVar, s5.i iVar, i iVar2) {
        try {
            m a10 = this.f574c.a(pVar.b());
            if (a10 == null) {
                String format = String.format("Transport backend '%s' is not registered", new Object[]{pVar.b()});
                f571f.warning(format);
                iVar.a(new IllegalArgumentException(format));
                return;
            }
            this.f576e.b(new b(this, pVar, a10.a(iVar2)));
            iVar.a((Exception) null);
        } catch (Exception e10) {
            Logger logger = f571f;
            logger.warning("Error scheduling event " + e10.getMessage());
            iVar.a(e10);
        }
    }

    public void a(p pVar, i iVar, s5.i iVar2) {
        this.f573b.execute(new a(this, pVar, iVar2, iVar));
    }
}
