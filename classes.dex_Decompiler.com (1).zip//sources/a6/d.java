package a6;

import b6.x;
import db.a;
import java.util.concurrent.Executor;
import v5.e;
import w5.b;

public final class d implements b<c> {

    /* renamed from: a  reason: collision with root package name */
    private final a<Executor> f577a;

    /* renamed from: b  reason: collision with root package name */
    private final a<e> f578b;

    /* renamed from: c  reason: collision with root package name */
    private final a<x> f579c;

    /* renamed from: d  reason: collision with root package name */
    private final a<c6.d> f580d;

    /* renamed from: e  reason: collision with root package name */
    private final a<d6.b> f581e;

    public d(a<Executor> aVar, a<e> aVar2, a<x> aVar3, a<c6.d> aVar4, a<d6.b> aVar5) {
        this.f577a = aVar;
        this.f578b = aVar2;
        this.f579c = aVar3;
        this.f580d = aVar4;
        this.f581e = aVar5;
    }

    public static d a(a<Executor> aVar, a<e> aVar2, a<x> aVar3, a<c6.d> aVar4, a<d6.b> aVar5) {
        return new d(aVar, aVar2, aVar3, aVar4, aVar5);
    }

    public static c c(Executor executor, e eVar, x xVar, c6.d dVar, d6.b bVar) {
        return new c(executor, eVar, xVar, dVar, bVar);
    }

    /* renamed from: b */
    public c get() {
        return c(this.f577a.get(), this.f578b.get(), this.f579c.get(), this.f580d.get(), this.f581e.get());
    }
}
