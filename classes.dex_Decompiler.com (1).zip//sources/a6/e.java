package a6;

import u5.i;
import u5.p;

public interface e {
    void a(p pVar, i iVar, s5.i iVar2);
}
