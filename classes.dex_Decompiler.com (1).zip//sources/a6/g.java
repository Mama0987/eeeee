package a6;

import b6.f;
import db.a;
import w5.b;
import w5.d;

public final class g implements b<f> {

    /* renamed from: a  reason: collision with root package name */
    private final a<e6.a> f582a;

    public g(a<e6.a> aVar) {
        this.f582a = aVar;
    }

    public static f a(e6.a aVar) {
        return (f) d.c(f.a(aVar), "Cannot return null from a non-@Nullable @Provides method");
    }

    public static g b(a<e6.a> aVar) {
        return new g(aVar);
    }

    /* renamed from: c */
    public f get() {
        return a(this.f582a.get());
    }
}
