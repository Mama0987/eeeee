package h8;

import java.io.Serializable;
import java.util.Objects;

public final class l {

    static class a<T> implements k<T>, Serializable {
        private static final long serialVersionUID = 0;

        /* renamed from: a  reason: collision with root package name */
        final k<T> f11258a;

        /* renamed from: b  reason: collision with root package name */
        volatile transient boolean f11259b;

        /* renamed from: c  reason: collision with root package name */
        transient T f11260c;

        a(k<T> kVar) {
            this.f11258a = (k) h.i(kVar);
        }

        public T get() {
            if (!this.f11259b) {
                synchronized (this) {
                    if (!this.f11259b) {
                        T t10 = this.f11258a.get();
                        this.f11260c = t10;
                        this.f11259b = true;
                        return t10;
                    }
                }
            }
            return e.a(this.f11260c);
        }

        public String toString() {
            Object obj;
            if (this.f11259b) {
                String valueOf = String.valueOf(this.f11260c);
                StringBuilder sb2 = new StringBuilder(valueOf.length() + 25);
                sb2.append("<supplier that returned ");
                sb2.append(valueOf);
                sb2.append(">");
                obj = sb2.toString();
            } else {
                obj = this.f11258a;
            }
            String valueOf2 = String.valueOf(obj);
            StringBuilder sb3 = new StringBuilder(valueOf2.length() + 19);
            sb3.append("Suppliers.memoize(");
            sb3.append(valueOf2);
            sb3.append(")");
            return sb3.toString();
        }
    }

    static class b<T> implements k<T> {

        /* renamed from: a  reason: collision with root package name */
        volatile k<T> f11261a;

        /* renamed from: b  reason: collision with root package name */
        volatile boolean f11262b;

        /* renamed from: c  reason: collision with root package name */
        T f11263c;

        b(k<T> kVar) {
            this.f11261a = (k) h.i(kVar);
        }

        public T get() {
            if (!this.f11262b) {
                synchronized (this) {
                    if (!this.f11262b) {
                        k<T> kVar = this.f11261a;
                        Objects.requireNonNull(kVar);
                        T t10 = kVar.get();
                        this.f11263c = t10;
                        this.f11262b = true;
                        this.f11261a = null;
                        return t10;
                    }
                }
            }
            return e.a(this.f11263c);
        }

        public String toString() {
            Object obj = this.f11261a;
            if (obj == null) {
                String valueOf = String.valueOf(this.f11263c);
                StringBuilder sb2 = new StringBuilder(valueOf.length() + 25);
                sb2.append("<supplier that returned ");
                sb2.append(valueOf);
                sb2.append(">");
                obj = sb2.toString();
            }
            String valueOf2 = String.valueOf(obj);
            StringBuilder sb3 = new StringBuilder(valueOf2.length() + 19);
            sb3.append("Suppliers.memoize(");
            sb3.append(valueOf2);
            sb3.append(")");
            return sb3.toString();
        }
    }

    private static class c<T> implements k<T>, Serializable {
        private static final long serialVersionUID = 0;

        /* renamed from: a  reason: collision with root package name */
        final T f11264a;

        c(T t10) {
            this.f11264a = t10;
        }

        public boolean equals(Object obj) {
            if (obj instanceof c) {
                return f.a(this.f11264a, ((c) obj).f11264a);
            }
            return false;
        }

        public T get() {
            return this.f11264a;
        }

        public int hashCode() {
            return f.b(this.f11264a);
        }

        public String toString() {
            String valueOf = String.valueOf(this.f11264a);
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 22);
            sb2.append("Suppliers.ofInstance(");
            sb2.append(valueOf);
            sb2.append(")");
            return sb2.toString();
        }
    }

    public static <T> k<T> a(k<T> kVar) {
        return ((kVar instanceof b) || (kVar instanceof a)) ? kVar : kVar instanceof Serializable ? new a(kVar) : new b(kVar);
    }

    public static <T> k<T> b(T t10) {
        return new c(t10);
    }
}
