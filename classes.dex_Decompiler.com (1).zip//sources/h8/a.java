package h8;

final class a<T> extends g<T> {

    /* renamed from: a  reason: collision with root package name */
    static final a<Object> f11248a = new a<>();
    private static final long serialVersionUID = 0;

    private a() {
    }

    static <T> g<T> e() {
        return f11248a;
    }

    private Object readResolve() {
        return f11248a;
    }

    public T b() {
        throw new IllegalStateException("Optional.get() cannot be called on an absent value");
    }

    public boolean c() {
        return false;
    }

    public boolean equals(Object obj) {
        return obj == this;
    }

    public int hashCode() {
        return 2040732332;
    }

    public String toString() {
        return "Optional.absent()";
    }
}
