package h8;

public interface c<F, T> {
    T apply(F f10);

    boolean equals(Object obj);
}
