package h8;

final class e {
    static <T> T a(T t10) {
        return t10;
    }
}
