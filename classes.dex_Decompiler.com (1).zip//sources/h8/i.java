package h8;

final class i<T> extends g<T> {
    private static final long serialVersionUID = 0;

    /* renamed from: a  reason: collision with root package name */
    private final T f11257a;

    i(T t10) {
        this.f11257a = t10;
    }

    public T b() {
        return this.f11257a;
    }

    public boolean c() {
        return true;
    }

    public boolean equals(Object obj) {
        if (obj instanceof i) {
            return this.f11257a.equals(((i) obj).f11257a);
        }
        return false;
    }

    public int hashCode() {
        return this.f11257a.hashCode() + 1502476572;
    }

    public String toString() {
        String valueOf = String.valueOf(this.f11257a);
        StringBuilder sb2 = new StringBuilder(valueOf.length() + 13);
        sb2.append("Optional.of(");
        sb2.append(valueOf);
        sb2.append(")");
        return sb2.toString();
    }
}
