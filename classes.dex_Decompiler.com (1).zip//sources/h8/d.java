package h8;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

public final class d {

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final String f11249a;

        /* renamed from: b  reason: collision with root package name */
        private final a f11250b;

        /* renamed from: c  reason: collision with root package name */
        private a f11251c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f11252d;

        /* renamed from: e  reason: collision with root package name */
        private boolean f11253e;

        private static class a {

            /* renamed from: a  reason: collision with root package name */
            String f11254a;

            /* renamed from: b  reason: collision with root package name */
            Object f11255b;

            /* renamed from: c  reason: collision with root package name */
            a f11256c;

            private a() {
            }
        }

        private b(String str) {
            a aVar = new a();
            this.f11250b = aVar;
            this.f11251c = aVar;
            this.f11252d = false;
            this.f11253e = false;
            this.f11249a = (String) h.i(str);
        }

        private a a() {
            a aVar = new a();
            this.f11251c.f11256c = aVar;
            this.f11251c = aVar;
            return aVar;
        }

        private b b(Object obj) {
            a().f11255b = obj;
            return this;
        }

        private static boolean d(Object obj) {
            return obj instanceof CharSequence ? ((CharSequence) obj).length() == 0 : obj instanceof Collection ? ((Collection) obj).isEmpty() : obj instanceof Map ? ((Map) obj).isEmpty() : obj instanceof g ? !((g) obj).c() : obj.getClass().isArray() && Array.getLength(obj) == 0;
        }

        public b c(Object obj) {
            return b(obj);
        }

        public String toString() {
            boolean z10 = this.f11252d;
            boolean z11 = this.f11253e;
            StringBuilder sb2 = new StringBuilder(32);
            sb2.append(this.f11249a);
            sb2.append('{');
            String str = "";
            for (a aVar = this.f11250b.f11256c; aVar != null; aVar = aVar.f11256c) {
                Object obj = aVar.f11255b;
                if (obj == null) {
                    if (z10) {
                    }
                } else if (z11 && d(obj)) {
                }
                sb2.append(str);
                String str2 = aVar.f11254a;
                if (str2 != null) {
                    sb2.append(str2);
                    sb2.append('=');
                }
                if (obj == null || !obj.getClass().isArray()) {
                    sb2.append(obj);
                } else {
                    String deepToString = Arrays.deepToString(new Object[]{obj});
                    sb2.append(deepToString, 1, deepToString.length() - 1);
                }
                str = ", ";
            }
            sb2.append('}');
            return sb2.toString();
        }
    }

    public static b a(Object obj) {
        return new b(obj.getClass().getSimpleName());
    }
}
