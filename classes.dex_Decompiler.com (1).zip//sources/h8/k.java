package h8;

public interface k<T> {
    T get();
}
