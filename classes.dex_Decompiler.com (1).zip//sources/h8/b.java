package h8;

abstract class b {
}
