package h8;

import java.io.Serializable;

public abstract class g<T> implements Serializable {
    private static final long serialVersionUID = 0;

    g() {
    }

    public static <T> g<T> a() {
        return a.e();
    }

    public static <T> g<T> d(T t10) {
        return new i(h.i(t10));
    }

    public abstract T b();

    public abstract boolean c();
}
