package b9;

public interface a {
}
