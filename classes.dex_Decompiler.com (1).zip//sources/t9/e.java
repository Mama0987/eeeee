package t9;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class e {

    /* renamed from: a  reason: collision with root package name */
    private final Boolean f16069a;

    /* renamed from: b  reason: collision with root package name */
    private final Double f16070b;

    /* renamed from: c  reason: collision with root package name */
    private final Integer f16071c;

    /* renamed from: d  reason: collision with root package name */
    private final Integer f16072d;

    /* renamed from: e  reason: collision with root package name */
    private final Long f16073e;

    public e(Boolean bool, Double d10, Integer num, Integer num2, Long l10) {
        this.f16069a = bool;
        this.f16070b = d10;
        this.f16071c = num;
        this.f16072d = num2;
        this.f16073e = l10;
    }

    public final Integer a() {
        return this.f16072d;
    }

    public final Long b() {
        return this.f16073e;
    }

    public final Boolean c() {
        return this.f16069a;
    }

    public final Integer d() {
        return this.f16071c;
    }

    public final Double e() {
        return this.f16070b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        return Intrinsics.a(this.f16069a, eVar.f16069a) && Intrinsics.a(this.f16070b, eVar.f16070b) && Intrinsics.a(this.f16071c, eVar.f16071c) && Intrinsics.a(this.f16072d, eVar.f16072d) && Intrinsics.a(this.f16073e, eVar.f16073e);
    }

    public int hashCode() {
        Boolean bool = this.f16069a;
        int i10 = 0;
        int hashCode = (bool == null ? 0 : bool.hashCode()) * 31;
        Double d10 = this.f16070b;
        int hashCode2 = (hashCode + (d10 == null ? 0 : d10.hashCode())) * 31;
        Integer num = this.f16071c;
        int hashCode3 = (hashCode2 + (num == null ? 0 : num.hashCode())) * 31;
        Integer num2 = this.f16072d;
        int hashCode4 = (hashCode3 + (num2 == null ? 0 : num2.hashCode())) * 31;
        Long l10 = this.f16073e;
        if (l10 != null) {
            i10 = l10.hashCode();
        }
        return hashCode4 + i10;
    }

    @NotNull
    public String toString() {
        return "SessionConfigs(sessionEnabled=" + this.f16069a + ", sessionSamplingRate=" + this.f16070b + ", sessionRestartTimeout=" + this.f16071c + ", cacheDuration=" + this.f16072d + ", cacheUpdatedTime=" + this.f16073e + ')';
    }
}
