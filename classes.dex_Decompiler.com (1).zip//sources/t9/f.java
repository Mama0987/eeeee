package t9;

import android.content.Context;
import android.util.Log;
import com.google.firebase.installations.FirebaseInstallationsApi;
import k0.d;
import k0.e;
import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import qb.l;
import qb.t;
import qb.y;
import r9.v;
import r9.w;
import vb.i;
import wb.a;
import xb.j0;

@Metadata
public final class f {
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    public static final b f16074c = new b((DefaultConstructorMarker) null);
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    public static final sb.a<Context, h0.f<d>> f16075d = j0.a.b(w.f14931a.b(), new i0.b(a.f16078a), (Function1) null, (j0) null, 12, (Object) null);
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final h f16076a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private final h f16077b;

    @Metadata
    static final class a extends l implements Function1<h0.a, d> {

        /* renamed from: a  reason: collision with root package name */
        public static final a f16078a = new a();

        a() {
            super(1);
        }

        @NotNull
        /* renamed from: a */
        public final d invoke(@NotNull h0.a aVar) {
            Intrinsics.checkNotNullParameter(aVar, "ex");
            Log.w("SessionsSettings", "CorruptionException in settings DataStore in " + v.f14930a.e() + '.', aVar);
            return e.a();
        }
    }

    @Metadata
    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ i<Object>[] f16079a = {y.f(new t(b.class, "dataStore", "getDataStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;", 0))};

        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* access modifiers changed from: private */
        public final h0.f<d> b(Context context) {
            return (h0.f) f.f16075d.a(context, f16079a[0]);
        }

        @NotNull
        public final f c() {
            Object obj = com.google.firebase.l.a(com.google.firebase.c.f8634a).get(f.class);
            Intrinsics.checkNotNullExpressionValue(obj, "Firebase.app[SessionsSettings::class.java]");
            return (f) obj;
        }
    }

    @ib.f(c = "com.google.firebase.sessions.settings.SessionsSettings", f = "SessionsSettings.kt", l = {138, 139}, m = "updateSettings")
    @Metadata
    static final class c extends ib.d {

        /* renamed from: d  reason: collision with root package name */
        Object f16080d;

        /* renamed from: e  reason: collision with root package name */
        /* synthetic */ Object f16081e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ f f16082f;

        /* renamed from: g  reason: collision with root package name */
        int f16083g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(f fVar, kotlin.coroutines.d<? super c> dVar) {
            super(dVar);
            this.f16082f = fVar;
        }

        public final Object n(@NotNull Object obj) {
            this.f16081e = obj;
            this.f16083g |= Integer.MIN_VALUE;
            return this.f16082f.g(this);
        }
    }

    private f(Context context, CoroutineContext coroutineContext, CoroutineContext coroutineContext2, FirebaseInstallationsApi firebaseInstallationsApi, r9.b bVar) {
        this(new b(context), new c(coroutineContext2, firebaseInstallationsApi, bVar, new d(bVar, coroutineContext, (String) null, 4, (DefaultConstructorMarker) null), f16074c.b(context)));
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public f(@org.jetbrains.annotations.NotNull com.google.firebase.FirebaseApp r8, @org.jetbrains.annotations.NotNull kotlin.coroutines.CoroutineContext r9, @org.jetbrains.annotations.NotNull kotlin.coroutines.CoroutineContext r10, @org.jetbrains.annotations.NotNull com.google.firebase.installations.FirebaseInstallationsApi r11) {
        /*
            r7 = this;
            java.lang.String r0 = "firebaseApp"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.lang.String r0 = "blockingDispatcher"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = "backgroundDispatcher"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "firebaseInstallationsApi"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            android.content.Context r2 = r8.getApplicationContext()
            java.lang.String r0 = "firebaseApp.applicationContext"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r0)
            r9.a0 r0 = r9.a0.f14797a
            r9.b r6 = r0.b(r8)
            r1 = r7
            r3 = r9
            r4 = r10
            r5 = r11
            r1.<init>(r2, r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: t9.f.<init>(com.google.firebase.FirebaseApp, kotlin.coroutines.CoroutineContext, kotlin.coroutines.CoroutineContext, com.google.firebase.installations.FirebaseInstallationsApi):void");
    }

    public f(@NotNull h hVar, @NotNull h hVar2) {
        Intrinsics.checkNotNullParameter(hVar, "localOverrideSettings");
        Intrinsics.checkNotNullParameter(hVar2, "remoteSettings");
        this.f16076a = hVar;
        this.f16077b = hVar2;
    }

    private final boolean e(double d10) {
        return 0.0d <= d10 && d10 <= 1.0d;
    }

    private final boolean f(long j10) {
        return wb.a.L(j10) && wb.a.G(j10);
    }

    public final double b() {
        Double c10 = this.f16076a.c();
        if (c10 != null) {
            double doubleValue = c10.doubleValue();
            if (e(doubleValue)) {
                return doubleValue;
            }
        }
        Double c11 = this.f16077b.c();
        if (c11 == null) {
            return 1.0d;
        }
        double doubleValue2 = c11.doubleValue();
        if (e(doubleValue2)) {
            return doubleValue2;
        }
        return 1.0d;
    }

    public final long c() {
        wb.a b10 = this.f16076a.b();
        if (b10 != null) {
            long P = b10.P();
            if (f(P)) {
                return P;
            }
        }
        wb.a b11 = this.f16077b.b();
        if (b11 != null) {
            long P2 = b11.P();
            if (f(P2)) {
                return P2;
            }
        }
        a.C0314a aVar = wb.a.f17240b;
        return wb.c.h(30, wb.d.MINUTES);
    }

    public final boolean d() {
        Boolean a10 = this.f16076a.a();
        if (a10 != null) {
            return a10.booleanValue();
        }
        Boolean a11 = this.f16077b.a();
        if (a11 != null) {
            return a11.booleanValue();
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x005a A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object g(@org.jetbrains.annotations.NotNull kotlin.coroutines.d<? super kotlin.Unit> r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof t9.f.c
            if (r0 == 0) goto L_0x0013
            r0 = r6
            t9.f$c r0 = (t9.f.c) r0
            int r1 = r0.f16083g
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f16083g = r1
            goto L_0x0018
        L_0x0013:
            t9.f$c r0 = new t9.f$c
            r0.<init>(r5, r6)
        L_0x0018:
            java.lang.Object r6 = r0.f16081e
            java.lang.Object r1 = hb.d.c()
            int r2 = r0.f16083g
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x003c
            if (r2 == r4) goto L_0x0034
            if (r2 != r3) goto L_0x002c
            eb.o.b(r6)
            goto L_0x005b
        L_0x002c:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L_0x0034:
            java.lang.Object r2 = r0.f16080d
            t9.f r2 = (t9.f) r2
            eb.o.b(r6)
            goto L_0x004d
        L_0x003c:
            eb.o.b(r6)
            t9.h r6 = r5.f16076a
            r0.f16080d = r5
            r0.f16083g = r4
            java.lang.Object r6 = r6.d(r0)
            if (r6 != r1) goto L_0x004c
            return r1
        L_0x004c:
            r2 = r5
        L_0x004d:
            t9.h r6 = r2.f16077b
            r2 = 0
            r0.f16080d = r2
            r0.f16083g = r3
            java.lang.Object r6 = r6.d(r0)
            if (r6 != r1) goto L_0x005b
            return r1
        L_0x005b:
            kotlin.Unit r6 = kotlin.Unit.f12470a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: t9.f.g(kotlin.coroutines.d):java.lang.Object");
    }
}
