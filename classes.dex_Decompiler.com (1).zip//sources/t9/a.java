package t9;

import java.util.Map;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.d;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

@Metadata
public interface a {
    Object a(@NotNull Map<String, String> map, @NotNull Function2<? super JSONObject, ? super d<? super Unit>, ? extends Object> function2, @NotNull Function2<? super String, ? super d<? super Unit>, ? extends Object> function22, @NotNull d<? super Unit> dVar);
}
