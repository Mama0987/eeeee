package t9;

import android.content.Context;
import android.os.Bundle;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import t9.h;
import wb.c;
import wb.d;

@Metadata
public final class b implements h {
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private static final a f16039b = new a((DefaultConstructorMarker) null);

    /* renamed from: a  reason: collision with root package name */
    private final Bundle f16040a;

    @Metadata
    private static final class a {
        private a() {
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    public b(@NotNull Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
        this.f16040a = bundle == null ? Bundle.EMPTY : bundle;
    }

    public Boolean a() {
        if (this.f16040a.containsKey("firebase_sessions_enabled")) {
            return Boolean.valueOf(this.f16040a.getBoolean("firebase_sessions_enabled"));
        }
        return null;
    }

    public wb.a b() {
        if (this.f16040a.containsKey("firebase_sessions_sessions_restart_timeout")) {
            return wb.a.g(c.h(this.f16040a.getInt("firebase_sessions_sessions_restart_timeout"), d.SECONDS));
        }
        return null;
    }

    public Double c() {
        if (this.f16040a.containsKey("firebase_sessions_sampling_rate")) {
            return Double.valueOf(this.f16040a.getDouble("firebase_sessions_sampling_rate"));
        }
        return null;
    }

    public Object d(@NotNull kotlin.coroutines.d<? super Unit> dVar) {
        return h.a.a(this, dVar);
    }
}
