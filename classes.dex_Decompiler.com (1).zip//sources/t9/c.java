package t9;

import android.util.Log;
import com.google.firebase.installations.FirebaseInstallationsApi;
import eb.o;
import ib.f;
import ib.k;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import wb.a;

@Metadata
public final class c implements h {
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    private static final a f16041g = new a((DefaultConstructorMarker) null);
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final CoroutineContext f16042a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private final FirebaseInstallationsApi f16043b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private final r9.b f16044c;
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private final a f16045d;
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    public final g f16046e;
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private final gc.a f16047f = gc.c.b(false, 1, (Object) null);

    @Metadata
    private static final class a {
        private a() {
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    @f(c = "com.google.firebase.sessions.settings.RemoteSettings", f = "RemoteSettings.kt", l = {170, 76, 94}, m = "updateSettings")
    @Metadata
    static final class b extends ib.d {

        /* renamed from: d  reason: collision with root package name */
        Object f16048d;

        /* renamed from: e  reason: collision with root package name */
        Object f16049e;

        /* renamed from: f  reason: collision with root package name */
        /* synthetic */ Object f16050f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ c f16051g;

        /* renamed from: h  reason: collision with root package name */
        int f16052h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(c cVar, kotlin.coroutines.d<? super b> dVar) {
            super(dVar);
            this.f16051g = cVar;
        }

        public final Object n(@NotNull Object obj) {
            this.f16050f = obj;
            this.f16052h |= Integer.MIN_VALUE;
            return this.f16051g.d(this);
        }
    }

    @f(c = "com.google.firebase.sessions.settings.RemoteSettings$updateSettings$2$1", f = "RemoteSettings.kt", l = {125, 128, 131, 133, 134, 136}, m = "invokeSuspend")
    @Metadata
    /* renamed from: t9.c$c  reason: collision with other inner class name */
    static final class C0285c extends k implements Function2<JSONObject, kotlin.coroutines.d<? super Unit>, Object> {

        /* renamed from: e  reason: collision with root package name */
        Object f16053e;

        /* renamed from: f  reason: collision with root package name */
        Object f16054f;

        /* renamed from: g  reason: collision with root package name */
        int f16055g;

        /* renamed from: h  reason: collision with root package name */
        /* synthetic */ Object f16056h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ c f16057i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0285c(c cVar, kotlin.coroutines.d<? super C0285c> dVar) {
            super(2, dVar);
            this.f16057i = cVar;
        }

        @NotNull
        public final kotlin.coroutines.d<Unit> e(Object obj, @NotNull kotlin.coroutines.d<?> dVar) {
            C0285c cVar = new C0285c(this.f16057i, dVar);
            cVar.f16056h = obj;
            return cVar;
        }

        /* JADX WARNING: Can't fix incorrect switch cases order */
        /* JADX WARNING: Code restructure failed: missing block: B:40:0x00f6, code lost:
            r13 = (java.lang.Integer) r8.f14443a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x00fa, code lost:
            if (r13 == null) goto L_0x0119;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:42:0x00fc, code lost:
            r2 = r12.f16057i;
            r13.intValue();
            r12.f16056h = r1;
            r12.f16053e = r0;
            r12.f16054f = null;
            r12.f16055g = 2;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:43:0x0116, code lost:
            if (t9.c.e(r2).m((java.lang.Integer) r8.f14443a, r12) != r4) goto L_0x0119;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:44:0x0118, code lost:
            return r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:0x0119, code lost:
            r13 = (java.lang.Double) r1.f14443a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:46:0x011d, code lost:
            if (r13 == null) goto L_0x013c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:47:0x011f, code lost:
            r2 = r12.f16057i;
            r13.doubleValue();
            r12.f16056h = r0;
            r12.f16053e = null;
            r12.f16054f = null;
            r12.f16055g = 3;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:48:0x0139, code lost:
            if (t9.c.e(r2).i((java.lang.Double) r1.f14443a, r12) != r4) goto L_0x013c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:49:0x013b, code lost:
            return r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:50:0x013c, code lost:
            r13 = (java.lang.Integer) r0.f14443a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:51:0x0140, code lost:
            if (r13 == null) goto L_0x0162;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:52:0x0142, code lost:
            r1 = r12.f16057i;
            r13.intValue();
            r12.f16056h = null;
            r12.f16053e = null;
            r12.f16054f = null;
            r12.f16055g = 4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:53:0x015c, code lost:
            if (t9.c.e(r1).j((java.lang.Integer) r0.f14443a, r12) != r4) goto L_0x015f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x015e, code lost:
            return r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:55:0x015f, code lost:
            r13 = kotlin.Unit.f12470a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:56:0x0162, code lost:
            r13 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:57:0x0163, code lost:
            if (r13 != null) goto L_0x0182;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:58:0x0165, code lost:
            r13 = t9.c.e(r12.f16057i);
            r0 = ib.b.b(86400);
            r12.f16056h = null;
            r12.f16053e = null;
            r12.f16054f = null;
            r12.f16055g = 5;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:59:0x017f, code lost:
            if (r13.j(r0, r12) != r4) goto L_0x0182;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:60:0x0181, code lost:
            return r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:61:0x0182, code lost:
            r13 = t9.c.e(r12.f16057i);
            r0 = ib.b.c(java.lang.System.currentTimeMillis());
            r12.f16056h = null;
            r12.f16053e = null;
            r12.f16054f = null;
            r12.f16055g = 6;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:62:0x019d, code lost:
            if (r13.k(r0, r12) != r4) goto L_0x01a0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:63:0x019f, code lost:
            return r4;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:65:0x01a2, code lost:
            return kotlin.Unit.f12470a;
         */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x00d5  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x00f4  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object n(@org.jetbrains.annotations.NotNull java.lang.Object r13) {
            /*
                r12 = this;
                java.lang.String r0 = "cache_duration"
                java.lang.String r1 = "session_timeout_seconds"
                java.lang.String r2 = "sampling_rate"
                java.lang.String r3 = "sessions_enabled"
                java.lang.Object r4 = hb.d.c()
                int r5 = r12.f16055g
                r6 = 0
                switch(r5) {
                    case 0: goto L_0x0050;
                    case 1: goto L_0x003f;
                    case 2: goto L_0x0032;
                    case 3: goto L_0x0029;
                    case 4: goto L_0x0024;
                    case 5: goto L_0x001f;
                    case 6: goto L_0x001a;
                    default: goto L_0x0012;
                }
            L_0x0012:
                java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r13.<init>(r0)
                throw r13
            L_0x001a:
                eb.o.b(r13)
                goto L_0x01a0
            L_0x001f:
                eb.o.b(r13)
                goto L_0x0182
            L_0x0024:
                eb.o.b(r13)
                goto L_0x015f
            L_0x0029:
                java.lang.Object r0 = r12.f16056h
                qb.x r0 = (qb.x) r0
                eb.o.b(r13)
                goto L_0x013c
            L_0x0032:
                java.lang.Object r0 = r12.f16053e
                qb.x r0 = (qb.x) r0
                java.lang.Object r1 = r12.f16056h
                qb.x r1 = (qb.x) r1
                eb.o.b(r13)
                goto L_0x0119
            L_0x003f:
                java.lang.Object r0 = r12.f16054f
                qb.x r0 = (qb.x) r0
                java.lang.Object r1 = r12.f16053e
                qb.x r1 = (qb.x) r1
                java.lang.Object r2 = r12.f16056h
                qb.x r2 = (qb.x) r2
                eb.o.b(r13)
                goto L_0x00f1
            L_0x0050:
                eb.o.b(r13)
                java.lang.Object r13 = r12.f16056h
                org.json.JSONObject r13 = (org.json.JSONObject) r13
                java.lang.StringBuilder r5 = new java.lang.StringBuilder
                r5.<init>()
                java.lang.String r7 = "Fetched settings: "
                r5.append(r7)
                r5.append(r13)
                java.lang.String r5 = r5.toString()
                java.lang.String r7 = "SessionConfigFetcher"
                android.util.Log.d(r7, r5)
                qb.x r5 = new qb.x
                r5.<init>()
                qb.x r8 = new qb.x
                r8.<init>()
                qb.x r9 = new qb.x
                r9.<init>()
                java.lang.String r10 = "app_quality"
                boolean r11 = r13.has(r10)
                if (r11 == 0) goto L_0x00d2
                java.lang.Object r13 = r13.get(r10)
                java.lang.String r10 = "null cannot be cast to non-null type org.json.JSONObject"
                kotlin.jvm.internal.Intrinsics.d(r13, r10)
                org.json.JSONObject r13 = (org.json.JSONObject) r13
                boolean r10 = r13.has(r3)     // Catch:{ JSONException -> 0x00ca }
                if (r10 == 0) goto L_0x009c
                java.lang.Object r3 = r13.get(r3)     // Catch:{ JSONException -> 0x00ca }
                java.lang.Boolean r3 = (java.lang.Boolean) r3     // Catch:{ JSONException -> 0x00ca }
                goto L_0x009d
            L_0x009c:
                r3 = r6
            L_0x009d:
                boolean r10 = r13.has(r2)     // Catch:{ JSONException -> 0x00c8 }
                if (r10 == 0) goto L_0x00ab
                java.lang.Object r2 = r13.get(r2)     // Catch:{ JSONException -> 0x00c8 }
                java.lang.Double r2 = (java.lang.Double) r2     // Catch:{ JSONException -> 0x00c8 }
                r5.f14443a = r2     // Catch:{ JSONException -> 0x00c8 }
            L_0x00ab:
                boolean r2 = r13.has(r1)     // Catch:{ JSONException -> 0x00c8 }
                if (r2 == 0) goto L_0x00b9
                java.lang.Object r1 = r13.get(r1)     // Catch:{ JSONException -> 0x00c8 }
                java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ JSONException -> 0x00c8 }
                r8.f14443a = r1     // Catch:{ JSONException -> 0x00c8 }
            L_0x00b9:
                boolean r1 = r13.has(r0)     // Catch:{ JSONException -> 0x00c8 }
                if (r1 == 0) goto L_0x00d3
                java.lang.Object r13 = r13.get(r0)     // Catch:{ JSONException -> 0x00c8 }
                java.lang.Integer r13 = (java.lang.Integer) r13     // Catch:{ JSONException -> 0x00c8 }
                r9.f14443a = r13     // Catch:{ JSONException -> 0x00c8 }
                goto L_0x00d3
            L_0x00c8:
                r13 = move-exception
                goto L_0x00cc
            L_0x00ca:
                r13 = move-exception
                r3 = r6
            L_0x00cc:
                java.lang.String r0 = "Error parsing the configs remotely fetched: "
                android.util.Log.e(r7, r0, r13)
                goto L_0x00d3
            L_0x00d2:
                r3 = r6
            L_0x00d3:
                if (r3 == 0) goto L_0x00f4
                t9.c r13 = r12.f16057i
                r3.booleanValue()
                t9.g r13 = r13.f16046e
                r12.f16056h = r5
                r12.f16053e = r8
                r12.f16054f = r9
                r0 = 1
                r12.f16055g = r0
                java.lang.Object r13 = r13.n(r3, r12)
                if (r13 != r4) goto L_0x00ee
                return r4
            L_0x00ee:
                r2 = r5
                r1 = r8
                r0 = r9
            L_0x00f1:
                r8 = r1
                r1 = r2
                goto L_0x00f6
            L_0x00f4:
                r1 = r5
                r0 = r9
            L_0x00f6:
                T r13 = r8.f14443a
                java.lang.Integer r13 = (java.lang.Integer) r13
                if (r13 == 0) goto L_0x0119
                t9.c r2 = r12.f16057i
                r13.intValue()
                t9.g r13 = r2.f16046e
                T r2 = r8.f14443a
                java.lang.Integer r2 = (java.lang.Integer) r2
                r12.f16056h = r1
                r12.f16053e = r0
                r12.f16054f = r6
                r3 = 2
                r12.f16055g = r3
                java.lang.Object r13 = r13.m(r2, r12)
                if (r13 != r4) goto L_0x0119
                return r4
            L_0x0119:
                T r13 = r1.f14443a
                java.lang.Double r13 = (java.lang.Double) r13
                if (r13 == 0) goto L_0x013c
                t9.c r2 = r12.f16057i
                r13.doubleValue()
                t9.g r13 = r2.f16046e
                T r1 = r1.f14443a
                java.lang.Double r1 = (java.lang.Double) r1
                r12.f16056h = r0
                r12.f16053e = r6
                r12.f16054f = r6
                r2 = 3
                r12.f16055g = r2
                java.lang.Object r13 = r13.i(r1, r12)
                if (r13 != r4) goto L_0x013c
                return r4
            L_0x013c:
                T r13 = r0.f14443a
                java.lang.Integer r13 = (java.lang.Integer) r13
                if (r13 == 0) goto L_0x0162
                t9.c r1 = r12.f16057i
                r13.intValue()
                t9.g r13 = r1.f16046e
                T r0 = r0.f14443a
                java.lang.Integer r0 = (java.lang.Integer) r0
                r12.f16056h = r6
                r12.f16053e = r6
                r12.f16054f = r6
                r1 = 4
                r12.f16055g = r1
                java.lang.Object r13 = r13.j(r0, r12)
                if (r13 != r4) goto L_0x015f
                return r4
            L_0x015f:
                kotlin.Unit r13 = kotlin.Unit.f12470a
                goto L_0x0163
            L_0x0162:
                r13 = r6
            L_0x0163:
                if (r13 != 0) goto L_0x0182
                t9.c r13 = r12.f16057i
                t9.g r13 = r13.f16046e
                r0 = 86400(0x15180, float:1.21072E-40)
                java.lang.Integer r0 = ib.b.b(r0)
                r12.f16056h = r6
                r12.f16053e = r6
                r12.f16054f = r6
                r1 = 5
                r12.f16055g = r1
                java.lang.Object r13 = r13.j(r0, r12)
                if (r13 != r4) goto L_0x0182
                return r4
            L_0x0182:
                t9.c r13 = r12.f16057i
                t9.g r13 = r13.f16046e
                long r0 = java.lang.System.currentTimeMillis()
                java.lang.Long r0 = ib.b.c(r0)
                r12.f16056h = r6
                r12.f16053e = r6
                r12.f16054f = r6
                r1 = 6
                r12.f16055g = r1
                java.lang.Object r13 = r13.k(r0, r12)
                if (r13 != r4) goto L_0x01a0
                return r4
            L_0x01a0:
                kotlin.Unit r13 = kotlin.Unit.f12470a
                return r13
            */
            throw new UnsupportedOperationException("Method not decompiled: t9.c.C0285c.n(java.lang.Object):java.lang.Object");
        }

        /* renamed from: q */
        public final Object k(@NotNull JSONObject jSONObject, kotlin.coroutines.d<? super Unit> dVar) {
            return ((C0285c) e(jSONObject, dVar)).n(Unit.f12470a);
        }
    }

    @f(c = "com.google.firebase.sessions.settings.RemoteSettings$updateSettings$2$2", f = "RemoteSettings.kt", l = {}, m = "invokeSuspend")
    @Metadata
    static final class d extends k implements Function2<String, kotlin.coroutines.d<? super Unit>, Object> {

        /* renamed from: e  reason: collision with root package name */
        int f16058e;

        /* renamed from: f  reason: collision with root package name */
        /* synthetic */ Object f16059f;

        d(kotlin.coroutines.d<? super d> dVar) {
            super(2, dVar);
        }

        @NotNull
        public final kotlin.coroutines.d<Unit> e(Object obj, @NotNull kotlin.coroutines.d<?> dVar) {
            d dVar2 = new d(dVar);
            dVar2.f16059f = obj;
            return dVar2;
        }

        public final Object n(@NotNull Object obj) {
            Object unused = d.c();
            if (this.f16058e == 0) {
                o.b(obj);
                Log.e("SessionConfigFetcher", "Error failing to fetch the remote configs: " + ((String) this.f16059f));
                return Unit.f12470a;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* renamed from: q */
        public final Object k(@NotNull String str, kotlin.coroutines.d<? super Unit> dVar) {
            return ((d) e(str, dVar)).n(Unit.f12470a);
        }
    }

    public c(@NotNull CoroutineContext coroutineContext, @NotNull FirebaseInstallationsApi firebaseInstallationsApi, @NotNull r9.b bVar, @NotNull a aVar, @NotNull h0.f<k0.d> fVar) {
        Intrinsics.checkNotNullParameter(coroutineContext, "backgroundDispatcher");
        Intrinsics.checkNotNullParameter(firebaseInstallationsApi, "firebaseInstallationsApi");
        Intrinsics.checkNotNullParameter(bVar, "appInfo");
        Intrinsics.checkNotNullParameter(aVar, "configsFetcher");
        Intrinsics.checkNotNullParameter(fVar, "dataStore");
        this.f16042a = coroutineContext;
        this.f16043b = firebaseInstallationsApi;
        this.f16044c = bVar;
        this.f16045d = aVar;
        this.f16046e = new g(fVar);
    }

    private final String f(String str) {
        return new Regex("/").replace(str, "");
    }

    public Boolean a() {
        return this.f16046e.g();
    }

    public wb.a b() {
        Integer e10 = this.f16046e.e();
        if (e10 == null) {
            return null;
        }
        a.C0314a aVar = wb.a.f17240b;
        return wb.a.g(wb.c.h(e10.intValue(), wb.d.SECONDS));
    }

    public Double c() {
        return this.f16046e.f();
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0091 A[Catch:{ all -> 0x0052 }] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x009c A[SYNTHETIC, Splitter:B:39:0x009c] */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00bb A[Catch:{ all -> 0x0052 }] */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00c6  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x002c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object d(@org.jetbrains.annotations.NotNull kotlin.coroutines.d<? super kotlin.Unit> r17) {
        /*
            r16 = this;
            r1 = r16
            r0 = r17
            boolean r2 = r0 instanceof t9.c.b
            if (r2 == 0) goto L_0x0017
            r2 = r0
            t9.c$b r2 = (t9.c.b) r2
            int r3 = r2.f16052h
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r5 = r3 & r4
            if (r5 == 0) goto L_0x0017
            int r3 = r3 - r4
            r2.f16052h = r3
            goto L_0x001c
        L_0x0017:
            t9.c$b r2 = new t9.c$b
            r2.<init>(r1, r0)
        L_0x001c:
            java.lang.Object r0 = r2.f16050f
            java.lang.Object r3 = hb.d.c()
            int r4 = r2.f16052h
            java.lang.String r5 = "SessionConfigFetcher"
            r6 = 3
            r7 = 2
            r8 = 1
            r9 = 0
            if (r4 == 0) goto L_0x0062
            if (r4 == r8) goto L_0x0056
            if (r4 == r7) goto L_0x0046
            if (r4 != r6) goto L_0x003e
            java.lang.Object r2 = r2.f16048d
            gc.a r2 = (gc.a) r2
            eb.o.b(r0)     // Catch:{ all -> 0x003b }
            goto L_0x0151
        L_0x003b:
            r0 = move-exception
            goto L_0x0159
        L_0x003e:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r2)
            throw r0
        L_0x0046:
            java.lang.Object r4 = r2.f16049e
            gc.a r4 = (gc.a) r4
            java.lang.Object r10 = r2.f16048d
            t9.c r10 = (t9.c) r10
            eb.o.b(r0)     // Catch:{ all -> 0x0052 }
            goto L_0x00ad
        L_0x0052:
            r0 = move-exception
            r2 = r4
            goto L_0x0159
        L_0x0056:
            java.lang.Object r4 = r2.f16049e
            gc.a r4 = (gc.a) r4
            java.lang.Object r10 = r2.f16048d
            t9.c r10 = (t9.c) r10
            eb.o.b(r0)
            goto L_0x0089
        L_0x0062:
            eb.o.b(r0)
            gc.a r0 = r1.f16047f
            boolean r0 = r0.a()
            if (r0 != 0) goto L_0x0078
            t9.g r0 = r1.f16046e
            boolean r0 = r0.d()
            if (r0 != 0) goto L_0x0078
            kotlin.Unit r0 = kotlin.Unit.f12470a
            return r0
        L_0x0078:
            gc.a r0 = r1.f16047f
            r2.f16048d = r1
            r2.f16049e = r0
            r2.f16052h = r8
            java.lang.Object r4 = r0.b(r9, r2)
            if (r4 != r3) goto L_0x0087
            return r3
        L_0x0087:
            r4 = r0
            r10 = r1
        L_0x0089:
            t9.g r0 = r10.f16046e     // Catch:{ all -> 0x0052 }
            boolean r0 = r0.d()     // Catch:{ all -> 0x0052 }
            if (r0 != 0) goto L_0x009c
            java.lang.String r0 = "Remote settings cache not expired. Using cached values."
            android.util.Log.d(r5, r0)     // Catch:{ all -> 0x0052 }
            kotlin.Unit r0 = kotlin.Unit.f12470a     // Catch:{ all -> 0x0052 }
            r4.c(r9)
            return r0
        L_0x009c:
            r9.s$a r0 = r9.s.f14913c     // Catch:{ all -> 0x0052 }
            com.google.firebase.installations.FirebaseInstallationsApi r11 = r10.f16043b     // Catch:{ all -> 0x0052 }
            r2.f16048d = r10     // Catch:{ all -> 0x0052 }
            r2.f16049e = r4     // Catch:{ all -> 0x0052 }
            r2.f16052h = r7     // Catch:{ all -> 0x0052 }
            java.lang.Object r0 = r0.a(r11, r2)     // Catch:{ all -> 0x0052 }
            if (r0 != r3) goto L_0x00ad
            return r3
        L_0x00ad:
            r9.s r0 = (r9.s) r0     // Catch:{ all -> 0x0052 }
            java.lang.String r0 = r0.b()     // Catch:{ all -> 0x0052 }
            java.lang.String r11 = ""
            boolean r11 = kotlin.jvm.internal.Intrinsics.a(r0, r11)     // Catch:{ all -> 0x0052 }
            if (r11 == 0) goto L_0x00c6
            java.lang.String r0 = "Error getting Firebase Installation ID. Skipping this Session Event."
            android.util.Log.w(r5, r0)     // Catch:{ all -> 0x0052 }
            kotlin.Unit r0 = kotlin.Unit.f12470a     // Catch:{ all -> 0x0052 }
            r4.c(r9)
            return r0
        L_0x00c6:
            r11 = 5
            kotlin.Pair[] r11 = new kotlin.Pair[r11]     // Catch:{ all -> 0x0052 }
            java.lang.String r12 = "X-Crashlytics-Installation-ID"
            kotlin.Pair r0 = eb.r.a(r12, r0)     // Catch:{ all -> 0x0052 }
            r12 = 0
            r11[r12] = r0     // Catch:{ all -> 0x0052 }
            java.lang.String r0 = "X-Crashlytics-Device-Model"
            qb.a0 r13 = qb.a0.f14418a     // Catch:{ all -> 0x0052 }
            java.lang.String r13 = "%s/%s"
            java.lang.Object[] r14 = new java.lang.Object[r7]     // Catch:{ all -> 0x0052 }
            java.lang.String r15 = android.os.Build.MANUFACTURER     // Catch:{ all -> 0x0052 }
            r14[r12] = r15     // Catch:{ all -> 0x0052 }
            java.lang.String r12 = android.os.Build.MODEL     // Catch:{ all -> 0x0052 }
            r14[r8] = r12     // Catch:{ all -> 0x0052 }
            java.lang.Object[] r12 = java.util.Arrays.copyOf(r14, r7)     // Catch:{ all -> 0x0052 }
            java.lang.String r12 = java.lang.String.format(r13, r12)     // Catch:{ all -> 0x0052 }
            java.lang.String r13 = "format(format, *args)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r13)     // Catch:{ all -> 0x0052 }
            java.lang.String r12 = r10.f(r12)     // Catch:{ all -> 0x0052 }
            kotlin.Pair r0 = eb.r.a(r0, r12)     // Catch:{ all -> 0x0052 }
            r11[r8] = r0     // Catch:{ all -> 0x0052 }
            java.lang.String r0 = "X-Crashlytics-OS-Build-Version"
            java.lang.String r8 = android.os.Build.VERSION.INCREMENTAL     // Catch:{ all -> 0x0052 }
            java.lang.String r12 = "INCREMENTAL"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r12)     // Catch:{ all -> 0x0052 }
            java.lang.String r8 = r10.f(r8)     // Catch:{ all -> 0x0052 }
            kotlin.Pair r0 = eb.r.a(r0, r8)     // Catch:{ all -> 0x0052 }
            r11[r7] = r0     // Catch:{ all -> 0x0052 }
            java.lang.String r0 = "X-Crashlytics-OS-Display-Version"
            java.lang.String r7 = android.os.Build.VERSION.RELEASE     // Catch:{ all -> 0x0052 }
            java.lang.String r8 = "RELEASE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)     // Catch:{ all -> 0x0052 }
            java.lang.String r7 = r10.f(r7)     // Catch:{ all -> 0x0052 }
            kotlin.Pair r0 = eb.r.a(r0, r7)     // Catch:{ all -> 0x0052 }
            r11[r6] = r0     // Catch:{ all -> 0x0052 }
            java.lang.String r0 = "X-Crashlytics-API-Client-Version"
            r9.b r7 = r10.f16044c     // Catch:{ all -> 0x0052 }
            java.lang.String r7 = r7.f()     // Catch:{ all -> 0x0052 }
            kotlin.Pair r0 = eb.r.a(r0, r7)     // Catch:{ all -> 0x0052 }
            r7 = 4
            r11[r7] = r0     // Catch:{ all -> 0x0052 }
            java.util.Map r0 = kotlin.collections.i0.l(r11)     // Catch:{ all -> 0x0052 }
            java.lang.String r7 = "Fetching settings from server."
            android.util.Log.d(r5, r7)     // Catch:{ all -> 0x0052 }
            t9.a r5 = r10.f16045d     // Catch:{ all -> 0x0052 }
            t9.c$c r7 = new t9.c$c     // Catch:{ all -> 0x0052 }
            r7.<init>(r10, r9)     // Catch:{ all -> 0x0052 }
            t9.c$d r8 = new t9.c$d     // Catch:{ all -> 0x0052 }
            r8.<init>(r9)     // Catch:{ all -> 0x0052 }
            r2.f16048d = r4     // Catch:{ all -> 0x0052 }
            r2.f16049e = r9     // Catch:{ all -> 0x0052 }
            r2.f16052h = r6     // Catch:{ all -> 0x0052 }
            java.lang.Object r0 = r5.a(r0, r7, r8, r2)     // Catch:{ all -> 0x0052 }
            if (r0 != r3) goto L_0x0150
            return r3
        L_0x0150:
            r2 = r4
        L_0x0151:
            kotlin.Unit r0 = kotlin.Unit.f12470a     // Catch:{ all -> 0x003b }
            r2.c(r9)
            kotlin.Unit r0 = kotlin.Unit.f12470a
            return r0
        L_0x0159:
            r2.c(r9)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: t9.c.d(kotlin.coroutines.d):java.lang.Object");
    }
}
