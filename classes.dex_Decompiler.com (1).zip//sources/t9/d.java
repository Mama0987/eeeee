package t9;

import android.net.Uri;
import co.datadome.sdk.n;
import eb.o;
import ib.f;
import ib.k;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import qb.x;
import xb.g;
import xb.j0;

@Metadata
public final class d implements a {
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    public static final a f16060d = new a((DefaultConstructorMarker) null);
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final r9.b f16061a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private final CoroutineContext f16062b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private final String f16063c;

    @Metadata
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    @f(c = "com.google.firebase.sessions.settings.RemoteSettingsFetcher$doConfigFetch$2", f = "RemoteSettingsFetcher.kt", l = {68, 70, 73}, m = "invokeSuspend")
    @Metadata
    static final class b extends k implements Function2<j0, kotlin.coroutines.d<? super Unit>, Object> {

        /* renamed from: e  reason: collision with root package name */
        int f16064e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ d f16065f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ Map<String, String> f16066g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ Function2<JSONObject, kotlin.coroutines.d<? super Unit>, Object> f16067h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ Function2<String, kotlin.coroutines.d<? super Unit>, Object> f16068i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(d dVar, Map<String, String> map, Function2<? super JSONObject, ? super kotlin.coroutines.d<? super Unit>, ? extends Object> function2, Function2<? super String, ? super kotlin.coroutines.d<? super Unit>, ? extends Object> function22, kotlin.coroutines.d<? super b> dVar2) {
            super(2, dVar2);
            this.f16065f = dVar;
            this.f16066g = map;
            this.f16067h = function2;
            this.f16068i = function22;
        }

        @NotNull
        public final kotlin.coroutines.d<Unit> e(Object obj, @NotNull kotlin.coroutines.d<?> dVar) {
            return new b(this.f16065f, this.f16066g, this.f16067h, this.f16068i, dVar);
        }

        public final Object n(@NotNull Object obj) {
            Object c10 = d.c();
            int i10 = this.f16064e;
            if (i10 == 0) {
                o.b(obj);
                URLConnection openConnection = this.f16065f.c().openConnection();
                Intrinsics.d(openConnection, "null cannot be cast to non-null type javax.net.ssl.HttpsURLConnection");
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) openConnection;
                httpsURLConnection.setRequestMethod("GET");
                httpsURLConnection.setRequestProperty(n.HTTP_HEADER_ACCEPT, "application/json");
                for (Map.Entry next : this.f16066g.entrySet()) {
                    httpsURLConnection.setRequestProperty((String) next.getKey(), (String) next.getValue());
                }
                int responseCode = httpsURLConnection.getResponseCode();
                if (responseCode == 200) {
                    InputStream inputStream = httpsURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder sb2 = new StringBuilder();
                    x xVar = new x();
                    while (true) {
                        T readLine = bufferedReader.readLine();
                        xVar.f14443a = readLine;
                        if (readLine == null) {
                            break;
                        }
                        sb2.append(readLine);
                    }
                    bufferedReader.close();
                    inputStream.close();
                    JSONObject jSONObject = new JSONObject(sb2.toString());
                    Function2<JSONObject, kotlin.coroutines.d<? super Unit>, Object> function2 = this.f16067h;
                    this.f16064e = 1;
                    if (function2.k(jSONObject, this) == c10) {
                        return c10;
                    }
                } else {
                    Function2<String, kotlin.coroutines.d<? super Unit>, Object> function22 = this.f16068i;
                    String str = "Bad response code: " + responseCode;
                    this.f16064e = 2;
                    if (function22.k(str, this) == c10) {
                        return c10;
                    }
                }
            } else if (i10 == 1 || i10 == 2) {
                try {
                    o.b(obj);
                } catch (Exception e10) {
                    Function2<String, kotlin.coroutines.d<? super Unit>, Object> function23 = this.f16068i;
                    String message = e10.getMessage();
                    if (message == null) {
                        message = e10.toString();
                    }
                    this.f16064e = 3;
                    if (function23.k(message, this) == c10) {
                        return c10;
                    }
                }
            } else if (i10 == 3) {
                o.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.f12470a;
        }

        /* renamed from: q */
        public final Object k(@NotNull j0 j0Var, kotlin.coroutines.d<? super Unit> dVar) {
            return ((b) e(j0Var, dVar)).n(Unit.f12470a);
        }
    }

    public d(@NotNull r9.b bVar, @NotNull CoroutineContext coroutineContext, @NotNull String str) {
        Intrinsics.checkNotNullParameter(bVar, "appInfo");
        Intrinsics.checkNotNullParameter(coroutineContext, "blockingDispatcher");
        Intrinsics.checkNotNullParameter(str, "baseUrl");
        this.f16061a = bVar;
        this.f16062b = coroutineContext;
        this.f16063c = str;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(r9.b bVar, CoroutineContext coroutineContext, String str, int i10, DefaultConstructorMarker defaultConstructorMarker) {
        this(bVar, coroutineContext, (i10 & 4) != 0 ? "firebase-settings.crashlytics.com" : str);
    }

    /* access modifiers changed from: private */
    public final URL c() {
        return new URL(new Uri.Builder().scheme("https").authority(this.f16063c).appendPath("spi").appendPath("v2").appendPath("platforms").appendPath("android").appendPath("gmp").appendPath(this.f16061a.b()).appendPath("settings").appendQueryParameter("build_version", this.f16061a.a().a()).appendQueryParameter("display_version", this.f16061a.a().f()).build().toString());
    }

    public Object a(@NotNull Map<String, String> map, @NotNull Function2<? super JSONObject, ? super kotlin.coroutines.d<? super Unit>, ? extends Object> function2, @NotNull Function2<? super String, ? super kotlin.coroutines.d<? super Unit>, ? extends Object> function22, @NotNull kotlin.coroutines.d<? super Unit> dVar) {
        Object g10 = g.g(this.f16062b, new b(this, map, function2, function22, (kotlin.coroutines.d<? super b>) null), dVar);
        return g10 == d.c() ? g10 : Unit.f12470a;
    }
}
