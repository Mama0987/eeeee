package t9;

import ac.e;
import com.FF.voiceengine.FFVoiceConst;
import eb.o;
import ib.k;
import k0.d;
import k0.f;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import xb.j0;

@Metadata
public final class g {
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private static final b f16084c = new b((DefaultConstructorMarker) null);
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private static final d.a<Boolean> f16085d = f.a("firebase_sessions_enabled");
    @NotNull

    /* renamed from: e  reason: collision with root package name */
    private static final d.a<Double> f16086e = f.b("firebase_sessions_sampling_rate");
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private static final d.a<Integer> f16087f = f.d("firebase_sessions_restart_timeout");
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    private static final d.a<Integer> f16088g = f.d("firebase_sessions_cache_duration");
    @NotNull

    /* renamed from: h  reason: collision with root package name */
    private static final d.a<Long> f16089h = f.e("firebase_sessions_cache_updated_time");
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public final h0.f<k0.d> f16090a;

    /* renamed from: b  reason: collision with root package name */
    private e f16091b;

    @ib.f(c = "com.google.firebase.sessions.settings.SettingsCache$1", f = "SettingsCache.kt", l = {46}, m = "invokeSuspend")
    @Metadata
    static final class a extends k implements Function2<j0, kotlin.coroutines.d<? super Unit>, Object> {

        /* renamed from: e  reason: collision with root package name */
        Object f16092e;

        /* renamed from: f  reason: collision with root package name */
        int f16093f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ g f16094g;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(g gVar, kotlin.coroutines.d<? super a> dVar) {
            super(2, dVar);
            this.f16094g = gVar;
        }

        @NotNull
        public final kotlin.coroutines.d<Unit> e(Object obj, @NotNull kotlin.coroutines.d<?> dVar) {
            return new a(this.f16094g, dVar);
        }

        public final Object n(@NotNull Object obj) {
            g gVar;
            Object c10 = d.c();
            int i10 = this.f16093f;
            if (i10 == 0) {
                o.b(obj);
                g gVar2 = this.f16094g;
                e data = gVar2.f16090a.getData();
                this.f16092e = gVar2;
                this.f16093f = 1;
                Object i11 = ac.g.i(data, this);
                if (i11 == c10) {
                    return c10;
                }
                gVar = gVar2;
                obj = i11;
            } else if (i10 == 1) {
                gVar = (g) this.f16092e;
                o.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            gVar.l(((k0.d) obj).d());
            return Unit.f12470a;
        }

        /* renamed from: q */
        public final Object k(@NotNull j0 j0Var, kotlin.coroutines.d<? super Unit> dVar) {
            return ((a) e(j0Var, dVar)).n(Unit.f12470a);
        }
    }

    @Metadata
    private static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    @ib.f(c = "com.google.firebase.sessions.settings.SettingsCache", f = "SettingsCache.kt", l = {119}, m = "updateConfigValue")
    @Metadata
    static final class c<T> extends ib.d {

        /* renamed from: d  reason: collision with root package name */
        /* synthetic */ Object f16095d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ g f16096e;

        /* renamed from: f  reason: collision with root package name */
        int f16097f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(g gVar, kotlin.coroutines.d<? super c> dVar) {
            super(dVar);
            this.f16096e = gVar;
        }

        public final Object n(@NotNull Object obj) {
            this.f16095d = obj;
            this.f16097f |= Integer.MIN_VALUE;
            return this.f16096e.h((d.a) null, null, this);
        }
    }

    @ib.f(c = "com.google.firebase.sessions.settings.SettingsCache$updateConfigValue$2", f = "SettingsCache.kt", l = {}, m = "invokeSuspend")
    @Metadata
    static final class d extends k implements Function2<k0.a, kotlin.coroutines.d<? super Unit>, Object> {

        /* renamed from: e  reason: collision with root package name */
        int f16098e;

        /* renamed from: f  reason: collision with root package name */
        /* synthetic */ Object f16099f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ T f16100g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ d.a<T> f16101h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ g f16102i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(T t10, d.a<T> aVar, g gVar, kotlin.coroutines.d<? super d> dVar) {
            super(2, dVar);
            this.f16100g = t10;
            this.f16101h = aVar;
            this.f16102i = gVar;
        }

        @NotNull
        public final kotlin.coroutines.d<Unit> e(Object obj, @NotNull kotlin.coroutines.d<?> dVar) {
            d dVar2 = new d(this.f16100g, this.f16101h, this.f16102i, dVar);
            dVar2.f16099f = obj;
            return dVar2;
        }

        public final Object n(@NotNull Object obj) {
            Object unused = d.c();
            if (this.f16098e == 0) {
                o.b(obj);
                k0.a aVar = (k0.a) this.f16099f;
                T t10 = this.f16100g;
                if (t10 != null) {
                    aVar.i(this.f16101h, t10);
                } else {
                    aVar.h(this.f16101h);
                }
                this.f16102i.l(aVar);
                return Unit.f12470a;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }

        /* renamed from: q */
        public final Object k(@NotNull k0.a aVar, kotlin.coroutines.d<? super Unit> dVar) {
            return ((d) e(aVar, dVar)).n(Unit.f12470a);
        }
    }

    public g(@NotNull h0.f<k0.d> fVar) {
        Intrinsics.checkNotNullParameter(fVar, "dataStore");
        this.f16090a = fVar;
        Object unused = h.b((CoroutineContext) null, new a(this, (kotlin.coroutines.d<? super a>) null), 1, (Object) null);
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0033  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final <T> java.lang.Object h(k0.d.a<T> r6, T r7, kotlin.coroutines.d<? super kotlin.Unit> r8) {
        /*
            r5 = this;
            boolean r0 = r8 instanceof t9.g.c
            if (r0 == 0) goto L_0x0013
            r0 = r8
            t9.g$c r0 = (t9.g.c) r0
            int r1 = r0.f16097f
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f16097f = r1
            goto L_0x0018
        L_0x0013:
            t9.g$c r0 = new t9.g$c
            r0.<init>(r5, r8)
        L_0x0018:
            java.lang.Object r8 = r0.f16095d
            java.lang.Object r1 = hb.d.c()
            int r2 = r0.f16097f
            r3 = 1
            if (r2 == 0) goto L_0x0033
            if (r2 != r3) goto L_0x002b
            eb.o.b(r8)     // Catch:{ IOException -> 0x0029 }
            goto L_0x005d
        L_0x0029:
            r6 = move-exception
            goto L_0x0047
        L_0x002b:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L_0x0033:
            eb.o.b(r8)
            h0.f<k0.d> r8 = r5.f16090a     // Catch:{ IOException -> 0x0029 }
            t9.g$d r2 = new t9.g$d     // Catch:{ IOException -> 0x0029 }
            r4 = 0
            r2.<init>(r7, r6, r5, r4)     // Catch:{ IOException -> 0x0029 }
            r0.f16097f = r3     // Catch:{ IOException -> 0x0029 }
            java.lang.Object r6 = k0.g.a(r8, r2, r0)     // Catch:{ IOException -> 0x0029 }
            if (r6 != r1) goto L_0x005d
            return r1
        L_0x0047:
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "Failed to update cache config value: "
            r7.append(r8)
            r7.append(r6)
            java.lang.String r6 = r7.toString()
            java.lang.String r7 = "SettingsCache"
            android.util.Log.w(r7, r6)
        L_0x005d:
            kotlin.Unit r6 = kotlin.Unit.f12470a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: t9.g.h(k0.d$a, java.lang.Object, kotlin.coroutines.d):java.lang.Object");
    }

    /* access modifiers changed from: private */
    public final void l(k0.d dVar) {
        this.f16091b = new e((Boolean) dVar.b(f16085d), (Double) dVar.b(f16086e), (Integer) dVar.b(f16087f), (Integer) dVar.b(f16088g), (Long) dVar.b(f16089h));
    }

    public final boolean d() {
        e eVar = this.f16091b;
        e eVar2 = null;
        if (eVar == null) {
            Intrinsics.r("sessionConfigs");
            eVar = null;
        }
        Long b10 = eVar.b();
        e eVar3 = this.f16091b;
        if (eVar3 == null) {
            Intrinsics.r("sessionConfigs");
        } else {
            eVar2 = eVar3;
        }
        Integer a10 = eVar2.a();
        return b10 == null || a10 == null || (System.currentTimeMillis() - b10.longValue()) / ((long) FFVoiceConst.FFVoiceEvent.FFVoice_EVENT_EOF) >= ((long) a10.intValue());
    }

    public final Integer e() {
        e eVar = this.f16091b;
        if (eVar == null) {
            Intrinsics.r("sessionConfigs");
            eVar = null;
        }
        return eVar.d();
    }

    public final Double f() {
        e eVar = this.f16091b;
        if (eVar == null) {
            Intrinsics.r("sessionConfigs");
            eVar = null;
        }
        return eVar.e();
    }

    public final Boolean g() {
        e eVar = this.f16091b;
        if (eVar == null) {
            Intrinsics.r("sessionConfigs");
            eVar = null;
        }
        return eVar.c();
    }

    public final Object i(Double d10, @NotNull kotlin.coroutines.d<? super Unit> dVar) {
        Object h10 = h(f16086e, d10, dVar);
        return h10 == d.c() ? h10 : Unit.f12470a;
    }

    public final Object j(Integer num, @NotNull kotlin.coroutines.d<? super Unit> dVar) {
        Object h10 = h(f16088g, num, dVar);
        return h10 == d.c() ? h10 : Unit.f12470a;
    }

    public final Object k(Long l10, @NotNull kotlin.coroutines.d<? super Unit> dVar) {
        Object h10 = h(f16089h, l10, dVar);
        return h10 == d.c() ? h10 : Unit.f12470a;
    }

    public final Object m(Integer num, @NotNull kotlin.coroutines.d<? super Unit> dVar) {
        Object h10 = h(f16087f, num, dVar);
        return h10 == d.c() ? h10 : Unit.f12470a;
    }

    public final Object n(Boolean bool, @NotNull kotlin.coroutines.d<? super Unit> dVar) {
        Object h10 = h(f16085d, bool, dVar);
        return h10 == d.c() ? h10 : Unit.f12470a;
    }
}
