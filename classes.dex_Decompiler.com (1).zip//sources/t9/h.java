package t9;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.d;
import org.jetbrains.annotations.NotNull;

@Metadata
public interface h {

    @Metadata
    public static final class a {
        public static Object a(@NotNull h hVar, @NotNull d<? super Unit> dVar) {
            return Unit.f12470a;
        }
    }

    Boolean a();

    wb.a b();

    Double c();

    Object d(@NotNull d<? super Unit> dVar);
}
