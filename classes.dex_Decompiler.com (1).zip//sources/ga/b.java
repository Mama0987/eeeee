package ga;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import da.a;
import da.c;
import ea.d;
import java.lang.reflect.Proxy;

public class b {
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final Context f11018a;
    @NonNull

    /* renamed from: b  reason: collision with root package name */
    private final String f11019b;
    @NonNull

    /* renamed from: c  reason: collision with root package name */
    private Uri f11020c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f11021d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f11022e;

    public b(@NonNull Context context, @NonNull String str) {
        if (!TextUtils.isEmpty(str)) {
            this.f11018a = context.getApplicationContext();
            this.f11019b = str;
            this.f11020c = Uri.parse("https://access.line.me/v2");
            return;
        }
        throw new IllegalArgumentException("channel id is empty");
    }

    @NonNull
    public a a() {
        if (!this.f11022e) {
            c.b(this.f11018a);
        }
        ha.b bVar = new ha.b(this.f11019b, new ea.b(this.f11018a, this.f11020c), new d(this.f11018a, this.f11020c), new a(this.f11018a, this.f11019b));
        if (this.f11021d) {
            return bVar;
        }
        return (a) Proxy.newProxyInstance(ha.b.class.getClassLoader(), new Class[]{a.class}, new ha.a(bVar, (byte) 0));
    }
}
