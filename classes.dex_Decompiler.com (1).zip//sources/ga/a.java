package ga;

import androidx.annotation.NonNull;
import ca.c;

public interface a {
    @NonNull
    c<?> a();

    @NonNull
    c<ca.a> b();
}
