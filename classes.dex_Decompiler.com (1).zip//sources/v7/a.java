package v7;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.gms.internal.measurement.zzds;
import w7.s;

public class a {

    /* renamed from: a  reason: collision with root package name */
    private final zzds f17017a;

    /* renamed from: v7.a$a  reason: collision with other inner class name */
    public interface C0302a extends s {
    }

    public a(zzds zzds) {
        this.f17017a = zzds;
    }

    public void a(@NonNull String str, @NonNull String str2, Bundle bundle) {
        this.f17017a.D(str, str2, bundle);
    }

    public void b(@NonNull C0302a aVar) {
        this.f17017a.w(aVar);
    }

    public void c(@NonNull String str, @NonNull String str2, @NonNull Object obj) {
        this.f17017a.v(str, str2, obj, true);
    }

    public final void d(boolean z10) {
        this.f17017a.x(z10);
    }
}
