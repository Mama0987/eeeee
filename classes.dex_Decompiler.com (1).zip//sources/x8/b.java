package x8;

import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.datatransport.TransportFactory;
import com.google.android.datatransport.cct.a;
import com.google.android.gms.tasks.Task;
import com.google.firebase.crashlytics.internal.common.OnDemandCounter;
import com.google.firebase.crashlytics.internal.common.o;
import com.google.firebase.crashlytics.internal.settings.SettingsProvider;
import s5.c;
import s5.g;
import t8.f0;
import u5.u;
import u8.j;

public class b {

    /* renamed from: c  reason: collision with root package name */
    private static final j f17556c = new j();

    /* renamed from: d  reason: collision with root package name */
    private static final String f17557d = e("hts/cahyiseot-agolai.o/1frlglgc/aclg", "tp:/rsltcrprsp.ogepscmv/ieo/eaybtho");

    /* renamed from: e  reason: collision with root package name */
    private static final String f17558e = e("AzSBpY4F0rHiHFdinTvM", "IayrSTFL9eJ69YeSUO2");

    /* renamed from: f  reason: collision with root package name */
    private static final g<f0, byte[]> f17559f = new a();

    /* renamed from: a  reason: collision with root package name */
    private final e f17560a;

    /* renamed from: b  reason: collision with root package name */
    private final g<f0, byte[]> f17561b;

    b(e eVar, g<f0, byte[]> gVar) {
        this.f17560a = eVar;
        this.f17561b = gVar;
    }

    public static b b(Context context, SettingsProvider settingsProvider, OnDemandCounter onDemandCounter) {
        u.f(context);
        TransportFactory g10 = u.c().g(new a(f17557d, f17558e));
        c b10 = c.b("json");
        g<f0, byte[]> gVar = f17559f;
        return new b(new e(g10.a("FIREBASE_CRASHLYTICS_REPORT", f0.class, b10, gVar), settingsProvider.b(), onDemandCounter), gVar);
    }

    private static String e(String str, String str2) {
        int length = str.length() - str2.length();
        if (length < 0 || length > 1) {
            throw new IllegalArgumentException("Invalid input received");
        }
        StringBuilder sb2 = new StringBuilder(str.length() + str2.length());
        for (int i10 = 0; i10 < str.length(); i10++) {
            sb2.append(str.charAt(i10));
            if (str2.length() > i10) {
                sb2.append(str2.charAt(i10));
            }
        }
        return sb2.toString();
    }

    @NonNull
    public Task<o> c(@NonNull o oVar, boolean z10) {
        return this.f17560a.i(oVar, z10).a();
    }
}
