package x8;

import java.nio.charset.Charset;
import s5.g;
import t8.f0;

public final /* synthetic */ class a implements g {
    public final Object apply(Object obj) {
        return b.f17556c.M((f0) obj).getBytes(Charset.forName("UTF-8"));
    }
}
