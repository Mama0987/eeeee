package x8;

import java.util.concurrent.CountDownLatch;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f17566a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ CountDownLatch f17567b;

    public /* synthetic */ d(e eVar, CountDownLatch countDownLatch) {
        this.f17566a = eVar;
        this.f17567b = countDownLatch;
    }

    public final void run() {
        this.f17566a.m(this.f17567b);
    }
}
