package x8;

import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.crashlytics.internal.common.o;
import s5.i;

public final /* synthetic */ class c implements i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f17562a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ TaskCompletionSource f17563b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ boolean f17564c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ o f17565d;

    public /* synthetic */ c(e eVar, TaskCompletionSource taskCompletionSource, boolean z10, o oVar) {
        this.f17562a = eVar;
        this.f17563b = taskCompletionSource;
        this.f17564c = z10;
        this.f17565d = oVar;
    }

    public final void a(Exception exc) {
        this.f17562a.n(this.f17563b, this.f17564c, this.f17565d, exc);
    }
}
