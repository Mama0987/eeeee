package x8;

import android.annotation.SuppressLint;
import android.database.SQLException;
import android.os.SystemClock;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.crashlytics.internal.common.OnDemandCounter;
import com.google.firebase.crashlytics.internal.common.o;
import com.google.firebase.crashlytics.internal.common.p0;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import p8.f;
import s5.h;
import t8.f0;
import u5.l;
import y8.d;

final class e {

    /* renamed from: a  reason: collision with root package name */
    private final double f17568a;

    /* renamed from: b  reason: collision with root package name */
    private final double f17569b;

    /* renamed from: c  reason: collision with root package name */
    private final long f17570c;

    /* renamed from: d  reason: collision with root package name */
    private final long f17571d;

    /* renamed from: e  reason: collision with root package name */
    private final int f17572e;

    /* renamed from: f  reason: collision with root package name */
    private final BlockingQueue<Runnable> f17573f;

    /* renamed from: g  reason: collision with root package name */
    private final ThreadPoolExecutor f17574g;

    /* renamed from: h  reason: collision with root package name */
    private final h<f0> f17575h;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public final OnDemandCounter f17576i;

    /* renamed from: j  reason: collision with root package name */
    private int f17577j;

    /* renamed from: k  reason: collision with root package name */
    private long f17578k;

    private final class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final o f17579a;

        /* renamed from: b  reason: collision with root package name */
        private final TaskCompletionSource<o> f17580b;

        private b(o oVar, TaskCompletionSource<o> taskCompletionSource) {
            this.f17579a = oVar;
            this.f17580b = taskCompletionSource;
        }

        public void run() {
            e.this.p(this.f17579a, this.f17580b);
            e.this.f17576i.e();
            double e10 = e.this.g();
            f f10 = f.f();
            f10.b("Delay for: " + String.format(Locale.US, "%.2f", new Object[]{Double.valueOf(e10 / 1000.0d)}) + " s for report: " + this.f17579a.d());
            e.q(e10);
        }
    }

    @SuppressLint({"ThreadPoolCreation"})
    e(double d10, double d11, long j10, h<f0> hVar, OnDemandCounter onDemandCounter) {
        this.f17568a = d10;
        this.f17569b = d11;
        this.f17570c = j10;
        this.f17575h = hVar;
        this.f17576i = onDemandCounter;
        this.f17571d = SystemClock.elapsedRealtime();
        int i10 = (int) d10;
        this.f17572e = i10;
        ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(i10);
        this.f17573f = arrayBlockingQueue;
        this.f17574g = new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS, arrayBlockingQueue);
        this.f17577j = 0;
        this.f17578k = 0;
    }

    e(h<f0> hVar, d dVar, OnDemandCounter onDemandCounter) {
        this(dVar.f18015f, dVar.f18016g, ((long) dVar.f18017h) * 1000, hVar, onDemandCounter);
    }

    /* access modifiers changed from: private */
    public double g() {
        return Math.min(3600000.0d, (60000.0d / this.f17568a) * Math.pow(this.f17569b, (double) h()));
    }

    private int h() {
        if (this.f17578k == 0) {
            this.f17578k = o();
        }
        int o10 = (int) ((o() - this.f17578k) / this.f17570c);
        int min = l() ? Math.min(100, this.f17577j + o10) : Math.max(0, this.f17577j - o10);
        if (this.f17577j != min) {
            this.f17577j = min;
            this.f17578k = o();
        }
        return min;
    }

    private boolean k() {
        return this.f17573f.size() < this.f17572e;
    }

    private boolean l() {
        return this.f17573f.size() == this.f17572e;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void m(CountDownLatch countDownLatch) {
        try {
            l.a(this.f17575h, s5.e.HIGHEST);
        } catch (SQLException unused) {
        }
        countDownLatch.countDown();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void n(TaskCompletionSource taskCompletionSource, boolean z10, o oVar, Exception exc) {
        if (exc != null) {
            taskCompletionSource.d(exc);
            return;
        }
        if (z10) {
            j();
        }
        taskCompletionSource.e(oVar);
    }

    private long o() {
        return System.currentTimeMillis();
    }

    /* access modifiers changed from: private */
    public void p(o oVar, TaskCompletionSource<o> taskCompletionSource) {
        f f10 = f.f();
        f10.b("Sending report through Google DataTransport: " + oVar.d());
        this.f17575h.a(s5.d.g(oVar.b()), new c(this, taskCompletionSource, SystemClock.elapsedRealtime() - this.f17571d < 2000, oVar));
    }

    /* access modifiers changed from: private */
    public static void q(double d10) {
        try {
            Thread.sleep((long) d10);
        } catch (InterruptedException unused) {
        }
    }

    /* access modifiers changed from: package-private */
    public TaskCompletionSource<o> i(o oVar, boolean z10) {
        synchronized (this.f17573f) {
            TaskCompletionSource<o> taskCompletionSource = new TaskCompletionSource<>();
            if (z10) {
                this.f17576i.d();
                if (k()) {
                    f f10 = f.f();
                    f10.b("Enqueueing report: " + oVar.d());
                    f f11 = f.f();
                    f11.b("Queue size: " + this.f17573f.size());
                    this.f17574g.execute(new b(oVar, taskCompletionSource));
                    f f12 = f.f();
                    f12.b("Closing task for report: " + oVar.d());
                    taskCompletionSource.e(oVar);
                    return taskCompletionSource;
                }
                h();
                f f13 = f.f();
                f13.b("Dropping report due to queue being full: " + oVar.d());
                this.f17576i.c();
                taskCompletionSource.e(oVar);
                return taskCompletionSource;
            }
            p(oVar, taskCompletionSource);
            return taskCompletionSource;
        }
    }

    @SuppressLint({"DiscouragedApi", "ThreadPoolCreation"})
    public void j() {
        CountDownLatch countDownLatch = new CountDownLatch(1);
        new Thread(new d(this, countDownLatch)).start();
        p0.g(countDownLatch, 2, TimeUnit.SECONDS);
    }
}
