package n3;

import android.os.Bundle;

public class b extends q3.b {

    /* renamed from: d  reason: collision with root package name */
    public String f13235d;

    /* renamed from: e  reason: collision with root package name */
    public String f13236e;

    /* renamed from: f  reason: collision with root package name */
    public String f13237f;

    public b() {
    }

    public b(Bundle bundle) {
        b(bundle);
    }

    public void b(Bundle bundle) {
        super.b(bundle);
        this.f13235d = bundle.getString("_bytedance_params_authcode");
        this.f13236e = bundle.getString("_bytedance_params_state");
        this.f13237f = bundle.getString("_bytedance_params_granted_permission");
    }

    public int c() {
        return 2;
    }

    public void e(Bundle bundle) {
        super.e(bundle);
        bundle.putString("_bytedance_params_authcode", this.f13235d);
        bundle.putString("_bytedance_params_state", this.f13236e);
        bundle.putString("_bytedance_params_granted_permission", this.f13237f);
    }
}
