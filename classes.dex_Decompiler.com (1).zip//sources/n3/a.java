package n3;

import android.os.Bundle;

public class a extends q3.a {

    /* renamed from: e  reason: collision with root package name */
    public String f13228e;

    /* renamed from: f  reason: collision with root package name */
    public String f13229f;

    /* renamed from: g  reason: collision with root package name */
    public String f13230g;

    /* renamed from: h  reason: collision with root package name */
    public String f13231h;

    /* renamed from: i  reason: collision with root package name */
    public String f13232i;

    /* renamed from: j  reason: collision with root package name */
    public String f13233j;

    /* renamed from: k  reason: collision with root package name */
    public String f13234k;

    public a() {
    }

    public a(Bundle bundle) {
        b(bundle);
    }

    public void b(Bundle bundle) {
        super.b(bundle);
        this.f13228e = bundle.getString("_bytedance_params_state");
        this.f13230g = bundle.getString("_bytedance_params_client_key");
        this.f13229f = bundle.getString("_bytedance_params_redirect_uri");
        this.f13231h = bundle.getString("_bytedance_params_scope");
        this.f13232i = bundle.getString("_bytedance_params_optional_scope0");
        this.f13233j = bundle.getString("_bytedance_params_optional_scope1");
        this.f13234k = bundle.getString("language");
    }

    public int d() {
        return 1;
    }

    public String f() {
        return this.f13230g;
    }
}
