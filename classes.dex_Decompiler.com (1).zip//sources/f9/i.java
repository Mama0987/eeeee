package f9;

import androidx.annotation.NonNull;
import c9.b;
import c9.c;
import c9.g;
import java.io.IOException;

class i implements g {

    /* renamed from: a  reason: collision with root package name */
    private boolean f10900a = false;

    /* renamed from: b  reason: collision with root package name */
    private boolean f10901b = false;

    /* renamed from: c  reason: collision with root package name */
    private c f10902c;

    /* renamed from: d  reason: collision with root package name */
    private final f f10903d;

    i(f fVar) {
        this.f10903d = fVar;
    }

    private void a() {
        if (!this.f10900a) {
            this.f10900a = true;
            return;
        }
        throw new b("Cannot encode a second value in the ValueEncoderContext");
    }

    @NonNull
    public g b(String str) throws IOException {
        a();
        this.f10903d.i(this.f10902c, str, this.f10901b);
        return this;
    }

    @NonNull
    public g c(boolean z10) throws IOException {
        a();
        this.f10903d.o(this.f10902c, z10, this.f10901b);
        return this;
    }

    /* access modifiers changed from: package-private */
    public void d(c cVar, boolean z10) {
        this.f10900a = false;
        this.f10902c = cVar;
        this.f10901b = z10;
    }
}
