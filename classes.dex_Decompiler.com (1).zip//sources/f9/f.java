package f9;

import androidx.annotation.NonNull;
import c9.b;
import c9.c;
import c9.d;
import c9.e;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Map;

final class f implements e {

    /* renamed from: f  reason: collision with root package name */
    private static final Charset f10883f = Charset.forName("UTF-8");

    /* renamed from: g  reason: collision with root package name */
    private static final c f10884g = c.a("key").b(a.b().c(1).a()).a();

    /* renamed from: h  reason: collision with root package name */
    private static final c f10885h = c.a("value").b(a.b().c(2).a()).a();

    /* renamed from: i  reason: collision with root package name */
    private static final d<Map.Entry<Object, Object>> f10886i = new e();

    /* renamed from: a  reason: collision with root package name */
    private OutputStream f10887a;

    /* renamed from: b  reason: collision with root package name */
    private final Map<Class<?>, d<?>> f10888b;

    /* renamed from: c  reason: collision with root package name */
    private final Map<Class<?>, c9.f<?>> f10889c;

    /* renamed from: d  reason: collision with root package name */
    private final d<Object> f10890d;

    /* renamed from: e  reason: collision with root package name */
    private final i f10891e = new i(this);

    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f10892a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            /*
                f9.d$a[] r0 = f9.d.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f10892a = r0
                f9.d$a r1 = f9.d.a.DEFAULT     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f10892a     // Catch:{ NoSuchFieldError -> 0x001d }
                f9.d$a r1 = f9.d.a.SIGNED     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f10892a     // Catch:{ NoSuchFieldError -> 0x0028 }
                f9.d$a r1 = f9.d.a.FIXED     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: f9.f.a.<clinit>():void");
        }
    }

    f(OutputStream outputStream, Map<Class<?>, d<?>> map, Map<Class<?>, c9.f<?>> map2, d<Object> dVar) {
        this.f10887a = outputStream;
        this.f10888b = map;
        this.f10889c = map2;
        this.f10890d = dVar;
    }

    private static ByteBuffer p(int i10) {
        return ByteBuffer.allocate(i10).order(ByteOrder.LITTLE_ENDIAN);
    }

    private <T> long q(d<T> dVar, T t10) throws IOException {
        OutputStream outputStream;
        b bVar = new b();
        try {
            outputStream = this.f10887a;
            this.f10887a = bVar;
            dVar.a(t10, this);
            this.f10887a = outputStream;
            long a10 = bVar.a();
            bVar.close();
            return a10;
        } catch (Throwable th) {
            try {
                bVar.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    private <T> f r(d<T> dVar, c cVar, T t10, boolean z10) throws IOException {
        long q10 = q(dVar, t10);
        if (z10 && q10 == 0) {
            return this;
        }
        x((v(cVar) << 3) | 2);
        y(q10);
        dVar.a(t10, this);
        return this;
    }

    private <T> f s(c9.f<T> fVar, c cVar, T t10, boolean z10) throws IOException {
        this.f10891e.d(cVar, z10);
        fVar.a(t10, this.f10891e);
        return this;
    }

    private static d u(c cVar) {
        d dVar = (d) cVar.c(d.class);
        if (dVar != null) {
            return dVar;
        }
        throw new b("Field has no @Protobuf config");
    }

    private static int v(c cVar) {
        d dVar = (d) cVar.c(d.class);
        if (dVar != null) {
            return dVar.tag();
        }
        throw new b("Field has no @Protobuf config");
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void w(Map.Entry entry, e eVar) throws IOException {
        eVar.a(f10884g, entry.getKey());
        eVar.a(f10885h, entry.getValue());
    }

    private void x(int i10) throws IOException {
        while (true) {
            int i11 = (((long) (i10 & -128)) > 0 ? 1 : (((long) (i10 & -128)) == 0 ? 0 : -1));
            OutputStream outputStream = this.f10887a;
            if (i11 != 0) {
                outputStream.write((i10 & 127) | 128);
                i10 >>>= 7;
            } else {
                outputStream.write(i10 & 127);
                return;
            }
        }
    }

    private void y(long j10) throws IOException {
        while (true) {
            int i10 = ((-128 & j10) > 0 ? 1 : ((-128 & j10) == 0 ? 0 : -1));
            OutputStream outputStream = this.f10887a;
            if (i10 != 0) {
                outputStream.write((((int) j10) & 127) | 128);
                j10 >>>= 7;
            } else {
                outputStream.write(((int) j10) & 127);
                return;
            }
        }
    }

    @NonNull
    public e a(@NonNull c cVar, Object obj) throws IOException {
        return i(cVar, obj, true);
    }

    /* access modifiers changed from: package-private */
    public e c(@NonNull c cVar, double d10, boolean z10) throws IOException {
        if (z10 && d10 == 0.0d) {
            return this;
        }
        x((v(cVar) << 3) | 1);
        this.f10887a.write(p(8).putDouble(d10).array());
        return this;
    }

    @NonNull
    public e g(@NonNull c cVar, double d10) throws IOException {
        return c(cVar, d10, true);
    }

    /* access modifiers changed from: package-private */
    public e h(@NonNull c cVar, float f10, boolean z10) throws IOException {
        if (z10 && f10 == 0.0f) {
            return this;
        }
        x((v(cVar) << 3) | 5);
        this.f10887a.write(p(4).putFloat(f10).array());
        return this;
    }

    /* access modifiers changed from: package-private */
    public e i(@NonNull c cVar, Object obj, boolean z10) throws IOException {
        if (obj == null) {
            return this;
        }
        if (obj instanceof CharSequence) {
            CharSequence charSequence = (CharSequence) obj;
            if (z10 && charSequence.length() == 0) {
                return this;
            }
            x((v(cVar) << 3) | 2);
            byte[] bytes = charSequence.toString().getBytes(f10883f);
            x(bytes.length);
            this.f10887a.write(bytes);
            return this;
        } else if (obj instanceof Collection) {
            for (Object i10 : (Collection) obj) {
                i(cVar, i10, false);
            }
            return this;
        } else if (obj instanceof Map) {
            for (Map.Entry r10 : ((Map) obj).entrySet()) {
                r(f10886i, cVar, r10, false);
            }
            return this;
        } else if (obj instanceof Double) {
            return c(cVar, ((Double) obj).doubleValue(), z10);
        } else {
            if (obj instanceof Float) {
                return h(cVar, ((Float) obj).floatValue(), z10);
            }
            if (obj instanceof Number) {
                return m(cVar, ((Number) obj).longValue(), z10);
            }
            if (obj instanceof Boolean) {
                return o(cVar, ((Boolean) obj).booleanValue(), z10);
            }
            if (obj instanceof byte[]) {
                byte[] bArr = (byte[]) obj;
                if (z10 && bArr.length == 0) {
                    return this;
                }
                x((v(cVar) << 3) | 2);
                x(bArr.length);
                this.f10887a.write(bArr);
                return this;
            }
            d dVar = this.f10888b.get(obj.getClass());
            if (dVar != null) {
                return r(dVar, cVar, obj, z10);
            }
            c9.f fVar = this.f10889c.get(obj.getClass());
            return fVar != null ? s(fVar, cVar, obj, z10) : obj instanceof c ? f(cVar, ((c) obj).j()) : obj instanceof Enum ? f(cVar, ((Enum) obj).ordinal()) : r(this.f10890d, cVar, obj, z10);
        }
    }

    @NonNull
    /* renamed from: j */
    public f f(@NonNull c cVar, int i10) throws IOException {
        return k(cVar, i10, true);
    }

    /* access modifiers changed from: package-private */
    public f k(@NonNull c cVar, int i10, boolean z10) throws IOException {
        if (z10 && i10 == 0) {
            return this;
        }
        d u10 = u(cVar);
        int i11 = a.f10892a[u10.intEncoding().ordinal()];
        if (i11 == 1) {
            x(u10.tag() << 3);
            x(i10);
        } else if (i11 == 2) {
            x(u10.tag() << 3);
            x((i10 << 1) ^ (i10 >> 31));
        } else if (i11 == 3) {
            x((u10.tag() << 3) | 5);
            this.f10887a.write(p(4).putInt(i10).array());
        }
        return this;
    }

    @NonNull
    /* renamed from: l */
    public f e(@NonNull c cVar, long j10) throws IOException {
        return m(cVar, j10, true);
    }

    /* access modifiers changed from: package-private */
    public f m(@NonNull c cVar, long j10, boolean z10) throws IOException {
        if (z10 && j10 == 0) {
            return this;
        }
        d u10 = u(cVar);
        int i10 = a.f10892a[u10.intEncoding().ordinal()];
        if (i10 == 1) {
            x(u10.tag() << 3);
            y(j10);
        } else if (i10 == 2) {
            x(u10.tag() << 3);
            y((j10 >> 63) ^ (j10 << 1));
        } else if (i10 == 3) {
            x((u10.tag() << 3) | 1);
            this.f10887a.write(p(8).putLong(j10).array());
        }
        return this;
    }

    @NonNull
    /* renamed from: n */
    public f d(@NonNull c cVar, boolean z10) throws IOException {
        return o(cVar, z10, true);
    }

    /* access modifiers changed from: package-private */
    public f o(@NonNull c cVar, boolean z10, boolean z11) throws IOException {
        return k(cVar, z10 ? 1 : 0, z11);
    }

    /* access modifiers changed from: package-private */
    public f t(Object obj) throws IOException {
        if (obj == null) {
            return this;
        }
        d dVar = this.f10888b.get(obj.getClass());
        if (dVar != null) {
            dVar.a(obj, this);
            return this;
        }
        throw new b("No encoder for " + obj.getClass());
    }
}
