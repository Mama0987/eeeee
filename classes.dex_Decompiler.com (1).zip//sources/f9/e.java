package f9;

import c9.d;
import java.util.Map;

public final /* synthetic */ class e implements d {
    public final void a(Object obj, Object obj2) {
        f.w((Map.Entry) obj, (c9.e) obj2);
    }
}
