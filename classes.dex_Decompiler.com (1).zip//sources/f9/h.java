package f9;

import androidx.annotation.NonNull;
import c9.d;
import c9.e;
import c9.f;
import d9.b;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class h {

    /* renamed from: a  reason: collision with root package name */
    private final Map<Class<?>, d<?>> f10893a;

    /* renamed from: b  reason: collision with root package name */
    private final Map<Class<?>, f<?>> f10894b;

    /* renamed from: c  reason: collision with root package name */
    private final d<Object> f10895c;

    public static final class a implements b<a> {

        /* renamed from: d  reason: collision with root package name */
        private static final d<Object> f10896d = new g();

        /* renamed from: a  reason: collision with root package name */
        private final Map<Class<?>, d<?>> f10897a = new HashMap();

        /* renamed from: b  reason: collision with root package name */
        private final Map<Class<?>, f<?>> f10898b = new HashMap();

        /* renamed from: c  reason: collision with root package name */
        private d<Object> f10899c = f10896d;

        /* access modifiers changed from: private */
        public static /* synthetic */ void e(Object obj, e eVar) throws IOException {
            throw new c9.b("Couldn't find encoder for type " + obj.getClass().getCanonicalName());
        }

        public h c() {
            return new h(new HashMap(this.f10897a), new HashMap(this.f10898b), this.f10899c);
        }

        @NonNull
        public a d(@NonNull d9.a aVar) {
            aVar.a(this);
            return this;
        }

        @NonNull
        /* renamed from: f */
        public <U> a a(@NonNull Class<U> cls, @NonNull d<? super U> dVar) {
            this.f10897a.put(cls, dVar);
            this.f10898b.remove(cls);
            return this;
        }
    }

    h(Map<Class<?>, d<?>> map, Map<Class<?>, f<?>> map2, d<Object> dVar) {
        this.f10893a = map;
        this.f10894b = map2;
        this.f10895c = dVar;
    }

    public static a a() {
        return new a();
    }

    public void b(@NonNull Object obj, @NonNull OutputStream outputStream) throws IOException {
        new f(outputStream, this.f10893a, this.f10894b, this.f10895c).t(obj);
    }

    @NonNull
    public byte[] c(@NonNull Object obj) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            b(obj, byteArrayOutputStream);
        } catch (IOException unused) {
        }
        return byteArrayOutputStream.toByteArray();
    }
}
