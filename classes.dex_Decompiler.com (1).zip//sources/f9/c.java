package f9;

public interface c {
    int j();
}
