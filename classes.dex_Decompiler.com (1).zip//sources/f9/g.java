package f9;

import c9.d;
import c9.e;
import f9.h;

public final /* synthetic */ class g implements d {
    public final void a(Object obj, Object obj2) {
        h.a.e(obj, (e) obj2);
    }
}
