package f9;

import androidx.annotation.NonNull;
import java.io.OutputStream;

final class b extends OutputStream {

    /* renamed from: a  reason: collision with root package name */
    private long f10878a = 0;

    b() {
    }

    /* access modifiers changed from: package-private */
    public long a() {
        return this.f10878a;
    }

    public void write(int i10) {
        this.f10878a++;
    }

    public void write(byte[] bArr) {
        this.f10878a += (long) bArr.length;
    }

    public void write(@NonNull byte[] bArr, int i10, int i11) {
        int i12;
        if (i10 < 0 || i10 > bArr.length || i11 < 0 || (i12 = i10 + i11) > bArr.length || i12 < 0) {
            throw new IndexOutOfBoundsException();
        }
        this.f10878a += (long) i11;
    }
}
