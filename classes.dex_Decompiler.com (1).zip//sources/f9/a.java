package f9;

import f9.d;
import java.lang.annotation.Annotation;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    private int f10874a;

    /* renamed from: b  reason: collision with root package name */
    private d.a f10875b = d.a.DEFAULT;

    /* renamed from: f9.a$a  reason: collision with other inner class name */
    private static final class C0157a implements d {

        /* renamed from: b  reason: collision with root package name */
        private final int f10876b;

        /* renamed from: c  reason: collision with root package name */
        private final d.a f10877c;

        C0157a(int i10, d.a aVar) {
            this.f10876b = i10;
            this.f10877c = aVar;
        }

        public Class<? extends Annotation> annotationType() {
            return d.class;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof d)) {
                return false;
            }
            d dVar = (d) obj;
            return this.f10876b == dVar.tag() && this.f10877c.equals(dVar.intEncoding());
        }

        public int hashCode() {
            return (14552422 ^ this.f10876b) + (this.f10877c.hashCode() ^ 2041407134);
        }

        public d.a intEncoding() {
            return this.f10877c;
        }

        public int tag() {
            return this.f10876b;
        }

        public String toString() {
            return "@com.google.firebase.encoders.proto.Protobuf" + '(' + "tag=" + this.f10876b + "intEncoding=" + this.f10877c + ')';
        }
    }

    public static a b() {
        return new a();
    }

    public d a() {
        return new C0157a(this.f10874a, this.f10875b);
    }

    public a c(int i10) {
        this.f10874a = i10;
        return this;
    }
}
