package j6;

public interface a {
}
