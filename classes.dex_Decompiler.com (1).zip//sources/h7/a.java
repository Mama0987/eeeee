package h7;

@Deprecated
public interface a {
}
