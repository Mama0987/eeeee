package oc;

import java.io.IOException;
import okio.f;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    static final f f13557a = f.o("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");

    /* renamed from: b  reason: collision with root package name */
    private static final String[] f13558b = {"DATA", "HEADERS", "PRIORITY", "RST_STREAM", "SETTINGS", "PUSH_PROMISE", "PING", "GOAWAY", "WINDOW_UPDATE", "CONTINUATION"};

    /* renamed from: c  reason: collision with root package name */
    static final String[] f13559c = new String[64];

    /* renamed from: d  reason: collision with root package name */
    static final String[] f13560d = new String[256];

    static {
        int i10 = 0;
        int i11 = 0;
        while (true) {
            String[] strArr = f13560d;
            if (i11 >= strArr.length) {
                break;
            }
            strArr[i11] = jc.e.q("%8s", Integer.toBinaryString(i11)).replace(' ', '0');
            i11++;
        }
        String[] strArr2 = f13559c;
        strArr2[0] = "";
        strArr2[1] = "END_STREAM";
        int[] iArr = {1};
        strArr2[8] = "PADDED";
        strArr2[1 | 8] = strArr2[1] + "|PADDED";
        strArr2[4] = "END_HEADERS";
        strArr2[32] = "PRIORITY";
        strArr2[36] = "END_HEADERS|PRIORITY";
        int[] iArr2 = {4, 32, 36};
        for (int i12 = 0; i12 < 3; i12++) {
            int i13 = iArr2[i12];
            int i14 = iArr[0];
            String[] strArr3 = f13559c;
            int i15 = i14 | i13;
            strArr3[i15] = strArr3[i14] + '|' + strArr3[i13];
            strArr3[i15 | 8] = strArr3[i14] + '|' + strArr3[i13] + "|PADDED";
        }
        while (true) {
            String[] strArr4 = f13559c;
            if (i10 < strArr4.length) {
                if (strArr4[i10] == null) {
                    strArr4[i10] = f13560d[i10];
                }
                i10++;
            } else {
                return;
            }
        }
    }

    private e() {
    }

    static String a(byte b10, byte b11) {
        if (b11 == 0) {
            return "";
        }
        if (!(b10 == 2 || b10 == 3)) {
            if (b10 == 4 || b10 == 6) {
                return b11 == 1 ? "ACK" : f13560d[b11];
            }
            if (!(b10 == 7 || b10 == 8)) {
                String[] strArr = f13559c;
                String str = b11 < strArr.length ? strArr[b11] : f13560d[b11];
                return (b10 != 5 || (b11 & 4) == 0) ? (b10 != 0 || (b11 & 32) == 0) ? str : str.replace("PRIORITY", "COMPRESSED") : str.replace("HEADERS", "PUSH_PROMISE");
            }
        }
        return f13560d[b11];
    }

    static String b(boolean z10, int i10, int i11, byte b10, byte b11) {
        String[] strArr = f13558b;
        String q10 = b10 < strArr.length ? strArr[b10] : jc.e.q("0x%02x", Byte.valueOf(b10));
        String a10 = a(b10, b11);
        Object[] objArr = new Object[5];
        objArr[0] = z10 ? "<<" : ">>";
        objArr[1] = Integer.valueOf(i10);
        objArr[2] = Integer.valueOf(i11);
        objArr[3] = q10;
        objArr[4] = a10;
        return jc.e.q("%s 0x%08x %5d %-13s %s", objArr);
    }

    static IllegalArgumentException c(String str, Object... objArr) {
        throw new IllegalArgumentException(jc.e.q(str, objArr));
    }

    static IOException d(String str, Object... objArr) throws IOException {
        throw new IOException(jc.e.q(str, objArr));
    }
}
