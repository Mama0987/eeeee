package oc;

import ic.a0;
import ic.d0;
import ic.e0;
import ic.g0;
import ic.i0;
import ic.y;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import jc.a;
import jc.e;
import mc.c;
import mc.i;
import mc.k;
import okio.s;
import okio.t;

public final class g implements c {

    /* renamed from: g  reason: collision with root package name */
    private static final List<String> f13631g = e.u("connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade", ":method", ":path", ":scheme", ":authority");

    /* renamed from: h  reason: collision with root package name */
    private static final List<String> f13632h = e.u("connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade");

    /* renamed from: a  reason: collision with root package name */
    private final a0.a f13633a;

    /* renamed from: b  reason: collision with root package name */
    private final lc.e f13634b;

    /* renamed from: c  reason: collision with root package name */
    private final f f13635c;

    /* renamed from: d  reason: collision with root package name */
    private volatile i f13636d;

    /* renamed from: e  reason: collision with root package name */
    private final e0 f13637e;

    /* renamed from: f  reason: collision with root package name */
    private volatile boolean f13638f;

    public g(d0 d0Var, lc.e eVar, a0.a aVar, f fVar) {
        this.f13634b = eVar;
        this.f13633a = aVar;
        this.f13635c = fVar;
        List<e0> H = d0Var.H();
        e0 e0Var = e0.H2_PRIOR_KNOWLEDGE;
        this.f13637e = !H.contains(e0Var) ? e0.HTTP_2 : e0Var;
    }

    public static List<c> i(g0 g0Var) {
        y d10 = g0Var.d();
        ArrayList arrayList = new ArrayList(d10.i() + 4);
        arrayList.add(new c(c.f13530f, g0Var.g()));
        arrayList.add(new c(c.f13531g, i.c(g0Var.j())));
        String c10 = g0Var.c("Host");
        if (c10 != null) {
            arrayList.add(new c(c.f13533i, c10));
        }
        arrayList.add(new c(c.f13532h, g0Var.j().J()));
        int i10 = d10.i();
        for (int i11 = 0; i11 < i10; i11++) {
            String lowerCase = d10.e(i11).toLowerCase(Locale.US);
            if (!f13631g.contains(lowerCase) || (lowerCase.equals("te") && d10.j(i11).equals("trailers"))) {
                arrayList.add(new c(lowerCase, d10.j(i11)));
            }
        }
        return arrayList;
    }

    public static i0.a j(y yVar, e0 e0Var) throws IOException {
        y.a aVar = new y.a();
        int i10 = yVar.i();
        k kVar = null;
        for (int i11 = 0; i11 < i10; i11++) {
            String e10 = yVar.e(i11);
            String j10 = yVar.j(i11);
            if (e10.equals(":status")) {
                kVar = k.a("HTTP/1.1 " + j10);
            } else if (!f13632h.contains(e10)) {
                a.f11900a.b(aVar, e10, j10);
            }
        }
        if (kVar != null) {
            return new i0.a().o(e0Var).g(kVar.f13142b).l(kVar.f13143c).j(aVar.f());
        }
        throw new ProtocolException("Expected ':status' header not present");
    }

    public lc.e a() {
        return this.f13634b;
    }

    public void b() throws IOException {
        this.f13636d.h().close();
    }

    public i0.a c(boolean z10) throws IOException {
        i0.a j10 = j(this.f13636d.p(), this.f13637e);
        if (!z10 || a.f11900a.d(j10) != 100) {
            return j10;
        }
        return null;
    }

    public void cancel() {
        this.f13638f = true;
        if (this.f13636d != null) {
            this.f13636d.f(b.CANCEL);
        }
    }

    public void d(g0 g0Var) throws IOException {
        if (this.f13636d == null) {
            this.f13636d = this.f13635c.A(i(g0Var), g0Var.a() != null);
            if (!this.f13638f) {
                TimeUnit timeUnit = TimeUnit.MILLISECONDS;
                this.f13636d.l().g((long) this.f13633a.b(), timeUnit);
                this.f13636d.r().g((long) this.f13633a.c(), timeUnit);
                return;
            }
            this.f13636d.f(b.CANCEL);
            throw new IOException("Canceled");
        }
    }

    public s e(g0 g0Var, long j10) {
        return this.f13636d.h();
    }

    public void f() throws IOException {
        this.f13635c.flush();
    }

    public long g(i0 i0Var) {
        return mc.e.b(i0Var);
    }

    public t h(i0 i0Var) {
        return this.f13636d.i();
    }
}
