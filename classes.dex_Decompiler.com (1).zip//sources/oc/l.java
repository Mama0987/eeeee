package oc;

import java.io.IOException;
import java.util.List;
import okio.e;

public interface l {

    /* renamed from: a  reason: collision with root package name */
    public static final l f13689a = new a();

    class a implements l {
        a() {
        }

        public void a(int i10, b bVar) {
        }

        public boolean b(int i10, List<c> list) {
            return true;
        }

        public boolean c(int i10, List<c> list, boolean z10) {
            return true;
        }

        public boolean d(int i10, e eVar, int i11, boolean z10) throws IOException {
            eVar.skip((long) i11);
            return true;
        }
    }

    void a(int i10, b bVar);

    boolean b(int i10, List<c> list);

    boolean c(int i10, List<c> list, boolean z10);

    boolean d(int i10, e eVar, int i11, boolean z10) throws IOException;
}
