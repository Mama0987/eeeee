package oc;

import ic.y;
import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import java.util.Deque;
import okio.e;
import okio.s;
import okio.t;
import okio.u;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    long f13650a = 0;

    /* renamed from: b  reason: collision with root package name */
    long f13651b;

    /* renamed from: c  reason: collision with root package name */
    final int f13652c;

    /* renamed from: d  reason: collision with root package name */
    final f f13653d;

    /* renamed from: e  reason: collision with root package name */
    private final Deque<y> f13654e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f13655f;

    /* renamed from: g  reason: collision with root package name */
    private final b f13656g;

    /* renamed from: h  reason: collision with root package name */
    final a f13657h;

    /* renamed from: i  reason: collision with root package name */
    final c f13658i;

    /* renamed from: j  reason: collision with root package name */
    final c f13659j;

    /* renamed from: k  reason: collision with root package name */
    b f13660k;

    /* renamed from: l  reason: collision with root package name */
    IOException f13661l;

    final class a implements s {

        /* renamed from: a  reason: collision with root package name */
        private final okio.c f13662a = new okio.c();

        /* renamed from: b  reason: collision with root package name */
        private y f13663b;

        /* renamed from: c  reason: collision with root package name */
        boolean f13664c;

        /* renamed from: d  reason: collision with root package name */
        boolean f13665d;

        a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
            r1.f13659j.u();
            r11.f13666e.c();
            r9 = java.lang.Math.min(r11.f13666e.f13651b, r11.f13662a.size());
            r1 = r11.f13666e;
            r1.f13651b -= r9;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private void a(boolean r12) throws java.io.IOException {
            /*
                r11 = this;
                oc.i r0 = oc.i.this
                monitor-enter(r0)
                oc.i r1 = oc.i.this     // Catch:{ all -> 0x0080 }
                oc.i$c r1 = r1.f13659j     // Catch:{ all -> 0x0080 }
                r1.k()     // Catch:{ all -> 0x0080 }
            L_0x000a:
                oc.i r1 = oc.i.this     // Catch:{ all -> 0x0077 }
                long r2 = r1.f13651b     // Catch:{ all -> 0x0077 }
                r4 = 0
                int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r6 > 0) goto L_0x0024
                boolean r2 = r11.f13665d     // Catch:{ all -> 0x0077 }
                if (r2 != 0) goto L_0x0024
                boolean r2 = r11.f13664c     // Catch:{ all -> 0x0077 }
                if (r2 != 0) goto L_0x0024
                oc.b r2 = r1.f13660k     // Catch:{ all -> 0x0077 }
                if (r2 != 0) goto L_0x0024
                r1.q()     // Catch:{ all -> 0x0077 }
                goto L_0x000a
            L_0x0024:
                oc.i$c r1 = r1.f13659j     // Catch:{ all -> 0x0080 }
                r1.u()     // Catch:{ all -> 0x0080 }
                oc.i r1 = oc.i.this     // Catch:{ all -> 0x0080 }
                r1.c()     // Catch:{ all -> 0x0080 }
                oc.i r1 = oc.i.this     // Catch:{ all -> 0x0080 }
                long r1 = r1.f13651b     // Catch:{ all -> 0x0080 }
                okio.c r3 = r11.f13662a     // Catch:{ all -> 0x0080 }
                long r3 = r3.size()     // Catch:{ all -> 0x0080 }
                long r9 = java.lang.Math.min(r1, r3)     // Catch:{ all -> 0x0080 }
                oc.i r1 = oc.i.this     // Catch:{ all -> 0x0080 }
                long r2 = r1.f13651b     // Catch:{ all -> 0x0080 }
                long r2 = r2 - r9
                r1.f13651b = r2     // Catch:{ all -> 0x0080 }
                monitor-exit(r0)     // Catch:{ all -> 0x0080 }
                oc.i$c r0 = r1.f13659j
                r0.k()
                if (r12 == 0) goto L_0x005a
                okio.c r12 = r11.f13662a     // Catch:{ all -> 0x0058 }
                long r0 = r12.size()     // Catch:{ all -> 0x0058 }
                int r12 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r12 != 0) goto L_0x005a
                r12 = 1
                r7 = 1
                goto L_0x005c
            L_0x0058:
                r12 = move-exception
                goto L_0x006f
            L_0x005a:
                r12 = 0
                r7 = 0
            L_0x005c:
                oc.i r12 = oc.i.this     // Catch:{ all -> 0x0058 }
                oc.f r5 = r12.f13653d     // Catch:{ all -> 0x0058 }
                int r6 = r12.f13652c     // Catch:{ all -> 0x0058 }
                okio.c r8 = r11.f13662a     // Catch:{ all -> 0x0058 }
                r5.e0(r6, r7, r8, r9)     // Catch:{ all -> 0x0058 }
                oc.i r12 = oc.i.this
                oc.i$c r12 = r12.f13659j
                r12.u()
                return
            L_0x006f:
                oc.i r0 = oc.i.this
                oc.i$c r0 = r0.f13659j
                r0.u()
                throw r12
            L_0x0077:
                r12 = move-exception
                oc.i r1 = oc.i.this     // Catch:{ all -> 0x0080 }
                oc.i$c r1 = r1.f13659j     // Catch:{ all -> 0x0080 }
                r1.u()     // Catch:{ all -> 0x0080 }
                throw r12     // Catch:{ all -> 0x0080 }
            L_0x0080:
                r12 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x0080 }
                throw r12
            */
            throw new UnsupportedOperationException("Method not decompiled: oc.i.a.a(boolean):void");
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x001e, code lost:
            if (r8.f13662a.size() <= 0) goto L_0x0022;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x0020, code lost:
            r2 = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x0022, code lost:
            r2 = false;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:15:0x0025, code lost:
            if (r8.f13663b == null) goto L_0x0029;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:16:0x0027, code lost:
            r3 = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0029, code lost:
            r3 = false;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:18:0x002a, code lost:
            if (r3 == false) goto L_0x004a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:20:0x0034, code lost:
            if (r8.f13662a.size() <= 0) goto L_0x003a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:21:0x0036, code lost:
            a(false);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:22:0x003a, code lost:
            r0 = r8.f13666e;
            r0.f13653d.g0(r0.f13652c, true, jc.e.J(r8.f13663b));
         */
        /* JADX WARNING: Code restructure failed: missing block: B:23:0x004a, code lost:
            if (r2 == false) goto L_0x005a;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0054, code lost:
            if (r8.f13662a.size() <= 0) goto L_0x0067;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:26:0x0056, code lost:
            a(true);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x005a, code lost:
            r0 = r8.f13666e;
            r0.f13653d.e0(r0.f13652c, true, (okio.c) null, 0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x0067, code lost:
            r2 = r8.f13666e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x0069, code lost:
            monitor-enter(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:?, code lost:
            r8.f13664c = true;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x006c, code lost:
            monitor-exit(r2);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x006d, code lost:
            r8.f13666e.f13653d.flush();
            r8.f13666e.b();
         */
        /* JADX WARNING: Code restructure failed: missing block: B:34:0x0079, code lost:
            return;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0011, code lost:
            if (r8.f13666e.f13657h.f13665d != false) goto L_0x0067;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void close() throws java.io.IOException {
            /*
                r8 = this;
                oc.i r0 = oc.i.this
                monitor-enter(r0)
                boolean r1 = r8.f13664c     // Catch:{ all -> 0x007d }
                if (r1 == 0) goto L_0x0009
                monitor-exit(r0)     // Catch:{ all -> 0x007d }
                return
            L_0x0009:
                monitor-exit(r0)     // Catch:{ all -> 0x007d }
                oc.i r0 = oc.i.this
                oc.i$a r0 = r0.f13657h
                boolean r0 = r0.f13665d
                r1 = 1
                if (r0 != 0) goto L_0x0067
                okio.c r0 = r8.f13662a
                long r2 = r0.size()
                r0 = 0
                r4 = 0
                int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r6 <= 0) goto L_0x0022
                r2 = 1
                goto L_0x0023
            L_0x0022:
                r2 = 0
            L_0x0023:
                ic.y r3 = r8.f13663b
                if (r3 == 0) goto L_0x0029
                r3 = 1
                goto L_0x002a
            L_0x0029:
                r3 = 0
            L_0x002a:
                if (r3 == 0) goto L_0x004a
            L_0x002c:
                okio.c r2 = r8.f13662a
                long r2 = r2.size()
                int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r6 <= 0) goto L_0x003a
                r8.a(r0)
                goto L_0x002c
            L_0x003a:
                oc.i r0 = oc.i.this
                oc.f r2 = r0.f13653d
                int r0 = r0.f13652c
                ic.y r3 = r8.f13663b
                java.util.List r3 = jc.e.J(r3)
                r2.g0(r0, r1, r3)
                goto L_0x0067
            L_0x004a:
                if (r2 == 0) goto L_0x005a
            L_0x004c:
                okio.c r0 = r8.f13662a
                long r2 = r0.size()
                int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r0 <= 0) goto L_0x0067
                r8.a(r1)
                goto L_0x004c
            L_0x005a:
                oc.i r0 = oc.i.this
                oc.f r2 = r0.f13653d
                int r3 = r0.f13652c
                r4 = 1
                r5 = 0
                r6 = 0
                r2.e0(r3, r4, r5, r6)
            L_0x0067:
                oc.i r2 = oc.i.this
                monitor-enter(r2)
                r8.f13664c = r1     // Catch:{ all -> 0x007a }
                monitor-exit(r2)     // Catch:{ all -> 0x007a }
                oc.i r0 = oc.i.this
                oc.f r0 = r0.f13653d
                r0.flush()
                oc.i r0 = oc.i.this
                r0.b()
                return
            L_0x007a:
                r0 = move-exception
                monitor-exit(r2)     // Catch:{ all -> 0x007a }
                throw r0
            L_0x007d:
                r1 = move-exception
                monitor-exit(r0)     // Catch:{ all -> 0x007d }
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: oc.i.a.close():void");
        }

        public void flush() throws IOException {
            synchronized (i.this) {
                i.this.c();
            }
            while (this.f13662a.size() > 0) {
                a(false);
                i.this.f13653d.flush();
            }
        }

        public u l() {
            return i.this.f13659j;
        }

        public void n0(okio.c cVar, long j10) throws IOException {
            this.f13662a.n0(cVar, j10);
            while (this.f13662a.size() >= 16384) {
                a(false);
            }
        }
    }

    private final class b implements t {

        /* renamed from: a  reason: collision with root package name */
        private final okio.c f13667a = new okio.c();

        /* renamed from: b  reason: collision with root package name */
        private final okio.c f13668b = new okio.c();

        /* renamed from: c  reason: collision with root package name */
        private final long f13669c;
        /* access modifiers changed from: private */

        /* renamed from: d  reason: collision with root package name */
        public y f13670d;

        /* renamed from: e  reason: collision with root package name */
        boolean f13671e;

        /* renamed from: f  reason: collision with root package name */
        boolean f13672f;

        b(long j10) {
            this.f13669c = j10;
        }

        private void c(long j10) {
            i.this.f13653d.c0(j10);
        }

        public long K0(okio.c cVar, long j10) throws IOException {
            Throwable th;
            long K0;
            if (j10 >= 0) {
                while (true) {
                    synchronized (i.this) {
                        i.this.f13658i.k();
                        try {
                            i iVar = i.this;
                            if (iVar.f13660k != null) {
                                th = iVar.f13661l;
                                if (th == null) {
                                    th = new n(i.this.f13660k);
                                }
                            } else {
                                th = null;
                            }
                            if (this.f13671e) {
                                throw new IOException("stream closed");
                            } else if (this.f13668b.size() > 0) {
                                okio.c cVar2 = this.f13668b;
                                K0 = cVar2.K0(cVar, Math.min(j10, cVar2.size()));
                                i iVar2 = i.this;
                                long j11 = iVar2.f13650a + K0;
                                iVar2.f13650a = j11;
                                if (th == null && j11 >= ((long) (iVar2.f13653d.f13581t.d() / 2))) {
                                    i iVar3 = i.this;
                                    iVar3.f13653d.r0(iVar3.f13652c, iVar3.f13650a);
                                    i.this.f13650a = 0;
                                }
                            } else if (this.f13672f || th != null) {
                                K0 = -1;
                            } else {
                                i.this.q();
                            }
                        } finally {
                            i.this.f13658i.u();
                        }
                    }
                }
                i.this.f13658i.u();
                if (K0 != -1) {
                    c(K0);
                    return K0;
                } else if (th == null) {
                    return -1;
                } else {
                    throw th;
                }
            } else {
                throw new IllegalArgumentException("byteCount < 0: " + j10);
            }
        }

        /* access modifiers changed from: package-private */
        public void b(e eVar, long j10) throws IOException {
            boolean z10;
            boolean z11;
            boolean z12;
            long j11;
            while (j10 > 0) {
                synchronized (i.this) {
                    z10 = this.f13672f;
                    z11 = true;
                    z12 = this.f13668b.size() + j10 > this.f13669c;
                }
                if (z12) {
                    eVar.skip(j10);
                    i.this.f(b.FLOW_CONTROL_ERROR);
                    return;
                } else if (z10) {
                    eVar.skip(j10);
                    return;
                } else {
                    long K0 = eVar.K0(this.f13667a, j10);
                    if (K0 != -1) {
                        j10 -= K0;
                        synchronized (i.this) {
                            if (this.f13671e) {
                                j11 = this.f13667a.size();
                                this.f13667a.c();
                            } else {
                                if (this.f13668b.size() != 0) {
                                    z11 = false;
                                }
                                this.f13668b.o0(this.f13667a);
                                if (z11) {
                                    i.this.notifyAll();
                                }
                                j11 = 0;
                            }
                        }
                        if (j11 > 0) {
                            c(j11);
                        }
                    } else {
                        throw new EOFException();
                    }
                }
            }
        }

        public void close() throws IOException {
            long size;
            synchronized (i.this) {
                this.f13671e = true;
                size = this.f13668b.size();
                this.f13668b.c();
                i.this.notifyAll();
            }
            if (size > 0) {
                c(size);
            }
            i.this.b();
        }

        public u l() {
            return i.this.f13658i;
        }
    }

    class c extends okio.a {
        c() {
        }

        /* access modifiers changed from: protected */
        public IOException o(IOException iOException) {
            SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
            if (iOException != null) {
                socketTimeoutException.initCause(iOException);
            }
            return socketTimeoutException;
        }

        /* access modifiers changed from: protected */
        public void t() {
            i.this.f(b.CANCEL);
            i.this.f13653d.P();
        }

        public void u() throws IOException {
            if (n()) {
                throw o((IOException) null);
            }
        }
    }

    i(int i10, f fVar, boolean z10, boolean z11, y yVar) {
        ArrayDeque arrayDeque = new ArrayDeque();
        this.f13654e = arrayDeque;
        this.f13658i = new c();
        this.f13659j = new c();
        if (fVar != null) {
            this.f13652c = i10;
            this.f13653d = fVar;
            this.f13651b = (long) fVar.f13582u.d();
            b bVar = new b((long) fVar.f13581t.d());
            this.f13656g = bVar;
            a aVar = new a();
            this.f13657h = aVar;
            bVar.f13672f = z11;
            aVar.f13665d = z10;
            if (yVar != null) {
                arrayDeque.add(yVar);
            }
            if (j() && yVar != null) {
                throw new IllegalStateException("locally-initiated streams shouldn't have headers yet");
            } else if (!j() && yVar == null) {
                throw new IllegalStateException("remotely-initiated streams should have headers");
            }
        } else {
            throw new NullPointerException("connection == null");
        }
    }

    private boolean e(b bVar, IOException iOException) {
        synchronized (this) {
            if (this.f13660k != null) {
                return false;
            }
            if (this.f13656g.f13672f && this.f13657h.f13665d) {
                return false;
            }
            this.f13660k = bVar;
            this.f13661l = iOException;
            notifyAll();
            this.f13653d.N(this.f13652c);
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public void a(long j10) {
        this.f13651b += j10;
        if (j10 > 0) {
            notifyAll();
        }
    }

    /* access modifiers changed from: package-private */
    public void b() throws IOException {
        boolean z10;
        boolean k10;
        synchronized (this) {
            b bVar = this.f13656g;
            if (!bVar.f13672f && bVar.f13671e) {
                a aVar = this.f13657h;
                if (aVar.f13665d || aVar.f13664c) {
                    z10 = true;
                    k10 = k();
                }
            }
            z10 = false;
            k10 = k();
        }
        if (z10) {
            d(b.CANCEL, (IOException) null);
        } else if (!k10) {
            this.f13653d.N(this.f13652c);
        }
    }

    /* access modifiers changed from: package-private */
    public void c() throws IOException {
        a aVar = this.f13657h;
        if (aVar.f13664c) {
            throw new IOException("stream closed");
        } else if (aVar.f13665d) {
            throw new IOException("stream finished");
        } else if (this.f13660k != null) {
            Throwable th = this.f13661l;
            if (th == null) {
                th = new n(this.f13660k);
            }
            throw th;
        }
    }

    public void d(b bVar, IOException iOException) throws IOException {
        if (e(bVar, iOException)) {
            this.f13653d.l0(this.f13652c, bVar);
        }
    }

    public void f(b bVar) {
        if (e(bVar, (IOException) null)) {
            this.f13653d.q0(this.f13652c, bVar);
        }
    }

    public int g() {
        return this.f13652c;
    }

    public s h() {
        synchronized (this) {
            if (!this.f13655f) {
                if (!j()) {
                    throw new IllegalStateException("reply before requesting the sink");
                }
            }
        }
        return this.f13657h;
    }

    public t i() {
        return this.f13656g;
    }

    public boolean j() {
        return this.f13653d.f13562a == ((this.f13652c & 1) == 1);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0023, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized boolean k() {
        /*
            r3 = this;
            monitor-enter(r3)
            oc.b r0 = r3.f13660k     // Catch:{ all -> 0x0025 }
            r1 = 0
            if (r0 == 0) goto L_0x0008
            monitor-exit(r3)
            return r1
        L_0x0008:
            oc.i$b r0 = r3.f13656g     // Catch:{ all -> 0x0025 }
            boolean r2 = r0.f13672f     // Catch:{ all -> 0x0025 }
            if (r2 != 0) goto L_0x0012
            boolean r0 = r0.f13671e     // Catch:{ all -> 0x0025 }
            if (r0 == 0) goto L_0x0022
        L_0x0012:
            oc.i$a r0 = r3.f13657h     // Catch:{ all -> 0x0025 }
            boolean r2 = r0.f13665d     // Catch:{ all -> 0x0025 }
            if (r2 != 0) goto L_0x001c
            boolean r0 = r0.f13664c     // Catch:{ all -> 0x0025 }
            if (r0 == 0) goto L_0x0022
        L_0x001c:
            boolean r0 = r3.f13655f     // Catch:{ all -> 0x0025 }
            if (r0 == 0) goto L_0x0022
            monitor-exit(r3)
            return r1
        L_0x0022:
            monitor-exit(r3)
            r0 = 1
            return r0
        L_0x0025:
            r0 = move-exception
            monitor-exit(r3)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.i.k():boolean");
    }

    public u l() {
        return this.f13658i;
    }

    /* access modifiers changed from: package-private */
    public void m(e eVar, int i10) throws IOException {
        this.f13656g.b(eVar, (long) i10);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x0018  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void n(ic.y r3, boolean r4) {
        /*
            r2 = this;
            monitor-enter(r2)
            boolean r0 = r2.f13655f     // Catch:{ all -> 0x002e }
            r1 = 1
            if (r0 == 0) goto L_0x000f
            if (r4 != 0) goto L_0x0009
            goto L_0x000f
        L_0x0009:
            oc.i$b r0 = r2.f13656g     // Catch:{ all -> 0x002e }
            ic.y unused = r0.f13670d = r3     // Catch:{ all -> 0x002e }
            goto L_0x0016
        L_0x000f:
            r2.f13655f = r1     // Catch:{ all -> 0x002e }
            java.util.Deque<ic.y> r0 = r2.f13654e     // Catch:{ all -> 0x002e }
            r0.add(r3)     // Catch:{ all -> 0x002e }
        L_0x0016:
            if (r4 == 0) goto L_0x001c
            oc.i$b r3 = r2.f13656g     // Catch:{ all -> 0x002e }
            r3.f13672f = r1     // Catch:{ all -> 0x002e }
        L_0x001c:
            boolean r3 = r2.k()     // Catch:{ all -> 0x002e }
            r2.notifyAll()     // Catch:{ all -> 0x002e }
            monitor-exit(r2)     // Catch:{ all -> 0x002e }
            if (r3 != 0) goto L_0x002d
            oc.f r3 = r2.f13653d
            int r4 = r2.f13652c
            r3.N(r4)
        L_0x002d:
            return
        L_0x002e:
            r3 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x002e }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.i.n(ic.y, boolean):void");
    }

    /* access modifiers changed from: package-private */
    public synchronized void o(b bVar) {
        if (this.f13660k == null) {
            this.f13660k = bVar;
            notifyAll();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x003a, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x003b, code lost:
        r2.f13658i.u();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0040, code lost:
        throw r0;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized ic.y p() throws java.io.IOException {
        /*
            r2 = this;
            monitor-enter(r2)
            oc.i$c r0 = r2.f13658i     // Catch:{ all -> 0x0041 }
            r0.k()     // Catch:{ all -> 0x0041 }
        L_0x0006:
            java.util.Deque<ic.y> r0 = r2.f13654e     // Catch:{ all -> 0x003a }
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x003a }
            if (r0 == 0) goto L_0x0016
            oc.b r0 = r2.f13660k     // Catch:{ all -> 0x003a }
            if (r0 != 0) goto L_0x0016
            r2.q()     // Catch:{ all -> 0x003a }
            goto L_0x0006
        L_0x0016:
            oc.i$c r0 = r2.f13658i     // Catch:{ all -> 0x0041 }
            r0.u()     // Catch:{ all -> 0x0041 }
            java.util.Deque<ic.y> r0 = r2.f13654e     // Catch:{ all -> 0x0041 }
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x0041 }
            if (r0 != 0) goto L_0x002d
            java.util.Deque<ic.y> r0 = r2.f13654e     // Catch:{ all -> 0x0041 }
            java.lang.Object r0 = r0.removeFirst()     // Catch:{ all -> 0x0041 }
            ic.y r0 = (ic.y) r0     // Catch:{ all -> 0x0041 }
            monitor-exit(r2)
            return r0
        L_0x002d:
            java.io.IOException r0 = r2.f13661l     // Catch:{ all -> 0x0041 }
            if (r0 == 0) goto L_0x0032
            goto L_0x0039
        L_0x0032:
            oc.n r0 = new oc.n     // Catch:{ all -> 0x0041 }
            oc.b r1 = r2.f13660k     // Catch:{ all -> 0x0041 }
            r0.<init>(r1)     // Catch:{ all -> 0x0041 }
        L_0x0039:
            throw r0     // Catch:{ all -> 0x0041 }
        L_0x003a:
            r0 = move-exception
            oc.i$c r1 = r2.f13658i     // Catch:{ all -> 0x0041 }
            r1.u()     // Catch:{ all -> 0x0041 }
            throw r0     // Catch:{ all -> 0x0041 }
        L_0x0041:
            r0 = move-exception
            monitor-exit(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.i.p():ic.y");
    }

    /* access modifiers changed from: package-private */
    public void q() throws InterruptedIOException {
        try {
            wait();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            throw new InterruptedIOException();
        }
    }

    public u r() {
        return this.f13659j;
    }
}
