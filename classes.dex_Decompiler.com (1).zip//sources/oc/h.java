package oc;

import com.appff.haptic.base.Utils;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import oc.d;
import okio.c;
import okio.e;
import okio.f;
import okio.t;
import okio.u;

final class h implements Closeable {

    /* renamed from: e  reason: collision with root package name */
    static final Logger f13639e = Logger.getLogger(e.class.getName());

    /* renamed from: a  reason: collision with root package name */
    private final e f13640a;

    /* renamed from: b  reason: collision with root package name */
    private final a f13641b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f13642c;

    /* renamed from: d  reason: collision with root package name */
    final d.a f13643d;

    static final class a implements t {

        /* renamed from: a  reason: collision with root package name */
        private final e f13644a;

        /* renamed from: b  reason: collision with root package name */
        int f13645b;

        /* renamed from: c  reason: collision with root package name */
        byte f13646c;

        /* renamed from: d  reason: collision with root package name */
        int f13647d;

        /* renamed from: e  reason: collision with root package name */
        int f13648e;

        /* renamed from: f  reason: collision with root package name */
        short f13649f;

        a(e eVar) {
            this.f13644a = eVar;
        }

        private void a() throws IOException {
            int i10 = this.f13647d;
            int h10 = h.h(this.f13644a);
            this.f13648e = h10;
            this.f13645b = h10;
            byte readByte = (byte) (this.f13644a.readByte() & 255);
            this.f13646c = (byte) (this.f13644a.readByte() & 255);
            Logger logger = h.f13639e;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(e.b(true, this.f13647d, this.f13645b, readByte, this.f13646c));
            }
            int readInt = this.f13644a.readInt() & Integer.MAX_VALUE;
            this.f13647d = readInt;
            if (readByte != 9) {
                throw e.d("%s != TYPE_CONTINUATION", Byte.valueOf(readByte));
            } else if (readInt != i10) {
                throw e.d("TYPE_CONTINUATION streamId changed", new Object[0]);
            }
        }

        public long K0(c cVar, long j10) throws IOException {
            while (true) {
                int i10 = this.f13648e;
                if (i10 == 0) {
                    this.f13644a.skip((long) this.f13649f);
                    this.f13649f = 0;
                    if ((this.f13646c & 4) != 0) {
                        return -1;
                    }
                    a();
                } else {
                    long K0 = this.f13644a.K0(cVar, Math.min(j10, (long) i10));
                    if (K0 == -1) {
                        return -1;
                    }
                    this.f13648e = (int) (((long) this.f13648e) - K0);
                    return K0;
                }
            }
        }

        public void close() throws IOException {
        }

        public u l() {
            return this.f13644a.l();
        }
    }

    interface b {
        void a();

        void b(int i10, b bVar, f fVar);

        void c(boolean z10, int i10, int i11, List<c> list);

        void d(int i10, long j10);

        void e(boolean z10, m mVar);

        void f(int i10, b bVar);

        void g(boolean z10, int i10, e eVar, int i11) throws IOException;

        void h(boolean z10, int i10, int i11);

        void i(int i10, int i11, int i12, boolean z10);

        void j(int i10, int i11, List<c> list) throws IOException;
    }

    h(e eVar, boolean z10) {
        this.f13640a = eVar;
        this.f13642c = z10;
        a aVar = new a(eVar);
        this.f13641b = aVar;
        this.f13643d = new d.a(Utils.CONTINUOUS_EVENT, aVar);
    }

    static int a(int i10, byte b10, short s10) throws IOException {
        if ((b10 & 8) != 0) {
            i10--;
        }
        if (s10 <= i10) {
            return (short) (i10 - s10);
        }
        throw e.d("PROTOCOL_ERROR padding %s > remaining length %s", Short.valueOf(s10), Integer.valueOf(i10));
    }

    private void d(b bVar, int i10, byte b10, int i11) throws IOException {
        short s10 = 0;
        if (i11 != 0) {
            boolean z10 = true;
            boolean z11 = (b10 & 1) != 0;
            if ((b10 & 32) == 0) {
                z10 = false;
            }
            if (!z10) {
                if ((b10 & 8) != 0) {
                    s10 = (short) (this.f13640a.readByte() & 255);
                }
                bVar.g(z11, i11, this.f13640a, a(i10, b10, s10));
                this.f13640a.skip((long) s10);
                return;
            }
            throw e.d("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA", new Object[0]);
        }
        throw e.d("PROTOCOL_ERROR: TYPE_DATA streamId == 0", new Object[0]);
    }

    private void e(b bVar, int i10, byte b10, int i11) throws IOException {
        if (i10 < 8) {
            throw e.d("TYPE_GOAWAY length < 8: %s", Integer.valueOf(i10));
        } else if (i11 == 0) {
            int readInt = this.f13640a.readInt();
            int readInt2 = this.f13640a.readInt();
            int i12 = i10 - 8;
            b a10 = b.a(readInt2);
            if (a10 != null) {
                f fVar = f.f13719e;
                if (i12 > 0) {
                    fVar = this.f13640a.w((long) i12);
                }
                bVar.b(readInt, a10, fVar);
                return;
            }
            throw e.d("TYPE_GOAWAY unexpected error code: %d", Integer.valueOf(readInt2));
        } else {
            throw e.d("TYPE_GOAWAY streamId != 0", new Object[0]);
        }
    }

    private List<c> f(int i10, short s10, byte b10, int i11) throws IOException {
        a aVar = this.f13641b;
        aVar.f13648e = i10;
        aVar.f13645b = i10;
        aVar.f13649f = s10;
        aVar.f13646c = b10;
        aVar.f13647d = i11;
        this.f13643d.k();
        return this.f13643d.e();
    }

    private void g(b bVar, int i10, byte b10, int i11) throws IOException {
        short s10 = 0;
        if (i11 != 0) {
            boolean z10 = (b10 & 1) != 0;
            if ((b10 & 8) != 0) {
                s10 = (short) (this.f13640a.readByte() & 255);
            }
            if ((b10 & 32) != 0) {
                k(bVar, i11);
                i10 -= 5;
            }
            bVar.c(z10, i11, -1, f(a(i10, b10, s10), s10, b10, i11));
            return;
        }
        throw e.d("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
    }

    static int h(e eVar) throws IOException {
        return (eVar.readByte() & 255) | ((eVar.readByte() & 255) << 16) | ((eVar.readByte() & 255) << 8);
    }

    private void i(b bVar, int i10, byte b10, int i11) throws IOException {
        boolean z10 = false;
        if (i10 != 8) {
            throw e.d("TYPE_PING length != 8: %s", Integer.valueOf(i10));
        } else if (i11 == 0) {
            int readInt = this.f13640a.readInt();
            int readInt2 = this.f13640a.readInt();
            if ((b10 & 1) != 0) {
                z10 = true;
            }
            bVar.h(z10, readInt, readInt2);
        } else {
            throw e.d("TYPE_PING streamId != 0", new Object[0]);
        }
    }

    private void k(b bVar, int i10) throws IOException {
        int readInt = this.f13640a.readInt();
        bVar.i(i10, readInt & Integer.MAX_VALUE, (this.f13640a.readByte() & 255) + 1, (Integer.MIN_VALUE & readInt) != 0);
    }

    private void m(b bVar, int i10, byte b10, int i11) throws IOException {
        if (i10 != 5) {
            throw e.d("TYPE_PRIORITY length: %d != 5", Integer.valueOf(i10));
        } else if (i11 != 0) {
            k(bVar, i11);
        } else {
            throw e.d("TYPE_PRIORITY streamId == 0", new Object[0]);
        }
    }

    private void n(b bVar, int i10, byte b10, int i11) throws IOException {
        short s10 = 0;
        if (i11 != 0) {
            if ((b10 & 8) != 0) {
                s10 = (short) (this.f13640a.readByte() & 255);
            }
            bVar.j(i11, this.f13640a.readInt() & Integer.MAX_VALUE, f(a(i10 - 4, b10, s10), s10, b10, i11));
            return;
        }
        throw e.d("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
    }

    private void o(b bVar, int i10, byte b10, int i11) throws IOException {
        if (i10 != 4) {
            throw e.d("TYPE_RST_STREAM length: %d != 4", Integer.valueOf(i10));
        } else if (i11 != 0) {
            int readInt = this.f13640a.readInt();
            b a10 = b.a(readInt);
            if (a10 != null) {
                bVar.f(i11, a10);
            } else {
                throw e.d("TYPE_RST_STREAM unexpected error code: %d", Integer.valueOf(readInt));
            }
        } else {
            throw e.d("TYPE_RST_STREAM streamId == 0", new Object[0]);
        }
    }

    private void p(b bVar, int i10, byte b10, int i11) throws IOException {
        if (i11 != 0) {
            throw e.d("TYPE_SETTINGS streamId != 0", new Object[0]);
        } else if ((b10 & 1) != 0) {
            if (i10 == 0) {
                bVar.a();
                return;
            }
            throw e.d("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]);
        } else if (i10 % 6 == 0) {
            m mVar = new m();
            for (int i12 = 0; i12 < i10; i12 += 6) {
                short readShort = this.f13640a.readShort() & 65535;
                int readInt = this.f13640a.readInt();
                if (readShort != 2) {
                    if (readShort == 3) {
                        readShort = 4;
                    } else if (readShort != 4) {
                        if (readShort == 5 && (readInt < 16384 || readInt > 16777215)) {
                            throw e.d("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: %s", Integer.valueOf(readInt));
                        }
                    } else if (readInt >= 0) {
                        readShort = 7;
                    } else {
                        throw e.d("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1", new Object[0]);
                    }
                } else if (!(readInt == 0 || readInt == 1)) {
                    throw e.d("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1", new Object[0]);
                }
                mVar.i(readShort, readInt);
            }
            bVar.e(false, mVar);
        } else {
            throw e.d("TYPE_SETTINGS length %% 6 != 0: %s", Integer.valueOf(i10));
        }
    }

    private void s(b bVar, int i10, byte b10, int i11) throws IOException {
        if (i10 == 4) {
            long readInt = ((long) this.f13640a.readInt()) & 2147483647L;
            if (readInt != 0) {
                bVar.d(i11, readInt);
            } else {
                throw e.d("windowSizeIncrement was 0", Long.valueOf(readInt));
            }
        } else {
            throw e.d("TYPE_WINDOW_UPDATE length !=4: %s", Integer.valueOf(i10));
        }
    }

    public boolean b(boolean z10, b bVar) throws IOException {
        try {
            this.f13640a.Q0(9);
            int h10 = h(this.f13640a);
            if (h10 < 0 || h10 > 16384) {
                throw e.d("FRAME_SIZE_ERROR: %s", Integer.valueOf(h10));
            }
            byte readByte = (byte) (this.f13640a.readByte() & 255);
            if (!z10 || readByte == 4) {
                byte readByte2 = (byte) (this.f13640a.readByte() & 255);
                int readInt = this.f13640a.readInt() & Integer.MAX_VALUE;
                Logger logger = f13639e;
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(e.b(true, readInt, h10, readByte, readByte2));
                }
                switch (readByte) {
                    case 0:
                        d(bVar, h10, readByte2, readInt);
                        break;
                    case 1:
                        g(bVar, h10, readByte2, readInt);
                        break;
                    case 2:
                        m(bVar, h10, readByte2, readInt);
                        break;
                    case 3:
                        o(bVar, h10, readByte2, readInt);
                        break;
                    case 4:
                        p(bVar, h10, readByte2, readInt);
                        break;
                    case 5:
                        n(bVar, h10, readByte2, readInt);
                        break;
                    case 6:
                        i(bVar, h10, readByte2, readInt);
                        break;
                    case 7:
                        e(bVar, h10, readByte2, readInt);
                        break;
                    case 8:
                        s(bVar, h10, readByte2, readInt);
                        break;
                    default:
                        this.f13640a.skip((long) h10);
                        break;
                }
                return true;
            }
            throw e.d("Expected a SETTINGS frame but was %s", Byte.valueOf(readByte));
        } catch (EOFException unused) {
            return false;
        }
    }

    public void c(b bVar) throws IOException {
        if (!this.f13642c) {
            e eVar = this.f13640a;
            f fVar = e.f13557a;
            f w10 = eVar.w((long) fVar.F());
            Logger logger = f13639e;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(jc.e.q("<< CONNECTION %s", w10.s()));
            }
            if (!fVar.equals(w10)) {
                throw e.d("Expected a connection header but was %s", w10.K());
            }
        } else if (!b(true, bVar)) {
            throw e.d("Required SETTINGS preface not received", new Object[0]);
        }
    }

    public void close() throws IOException {
        this.f13640a.close();
    }
}
