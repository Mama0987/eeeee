package oc;

import com.appff.haptic.base.Utils;
import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jc.e;
import oc.d;
import okio.c;
import okio.d;

final class j implements Closeable {

    /* renamed from: g  reason: collision with root package name */
    private static final Logger f13675g = Logger.getLogger(e.class.getName());

    /* renamed from: a  reason: collision with root package name */
    private final d f13676a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f13677b;

    /* renamed from: c  reason: collision with root package name */
    private final c f13678c;

    /* renamed from: d  reason: collision with root package name */
    private int f13679d = 16384;

    /* renamed from: e  reason: collision with root package name */
    private boolean f13680e;

    /* renamed from: f  reason: collision with root package name */
    final d.b f13681f;

    j(okio.d dVar, boolean z10) {
        this.f13676a = dVar;
        this.f13677b = z10;
        c cVar = new c();
        this.f13678c = cVar;
        this.f13681f = new d.b(cVar);
    }

    private void p(int i10, long j10) throws IOException {
        while (j10 > 0) {
            int min = (int) Math.min((long) this.f13679d, j10);
            long j11 = (long) min;
            j10 -= j11;
            e(i10, min, (byte) 9, j10 == 0 ? (byte) 4 : 0);
            this.f13676a.n0(this.f13678c, j11);
        }
    }

    private static void s(okio.d dVar, int i10) throws IOException {
        dVar.writeByte((i10 >>> 16) & Utils.MAX_STRENGTH_VALUE);
        dVar.writeByte((i10 >>> 8) & Utils.MAX_STRENGTH_VALUE);
        dVar.writeByte(i10 & Utils.MAX_STRENGTH_VALUE);
    }

    public synchronized void a(m mVar) throws IOException {
        if (!this.f13680e) {
            this.f13679d = mVar.f(this.f13679d);
            if (mVar.c() != -1) {
                this.f13681f.e(mVar.c());
            }
            e(0, 0, (byte) 4, (byte) 1);
            this.f13676a.flush();
        } else {
            throw new IOException("closed");
        }
    }

    public synchronized void b() throws IOException {
        if (this.f13680e) {
            throw new IOException("closed");
        } else if (this.f13677b) {
            Logger logger = f13675g;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(e.q(">> CONNECTION %s", e.f13557a.s()));
            }
            this.f13676a.write(e.f13557a.J());
            this.f13676a.flush();
        }
    }

    public synchronized void c(boolean z10, int i10, c cVar, int i11) throws IOException {
        if (!this.f13680e) {
            d(i10, z10 ? (byte) 1 : 0, cVar, i11);
        } else {
            throw new IOException("closed");
        }
    }

    public synchronized void close() throws IOException {
        this.f13680e = true;
        this.f13676a.close();
    }

    /* access modifiers changed from: package-private */
    public void d(int i10, byte b10, c cVar, int i11) throws IOException {
        e(i10, i11, (byte) 0, b10);
        if (i11 > 0) {
            this.f13676a.n0(cVar, (long) i11);
        }
    }

    public void e(int i10, int i11, byte b10, byte b11) throws IOException {
        Logger logger = f13675g;
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(e.b(false, i10, i11, b10, b11));
        }
        int i12 = this.f13679d;
        if (i11 > i12) {
            throw e.c("FRAME_SIZE_ERROR length > %d: %d", Integer.valueOf(i12), Integer.valueOf(i11));
        } else if ((Integer.MIN_VALUE & i10) == 0) {
            s(this.f13676a, i11);
            this.f13676a.writeByte(b10 & 255);
            this.f13676a.writeByte(b11 & 255);
            this.f13676a.writeInt(i10 & Integer.MAX_VALUE);
        } else {
            throw e.c("reserved bit set: %s", Integer.valueOf(i10));
        }
    }

    public synchronized void f(int i10, b bVar, byte[] bArr) throws IOException {
        if (this.f13680e) {
            throw new IOException("closed");
        } else if (bVar.f13527a != -1) {
            e(0, bArr.length + 8, (byte) 7, (byte) 0);
            this.f13676a.writeInt(i10);
            this.f13676a.writeInt(bVar.f13527a);
            if (bArr.length > 0) {
                this.f13676a.write(bArr);
            }
            this.f13676a.flush();
        } else {
            throw e.c("errorCode.httpCode == -1", new Object[0]);
        }
    }

    public synchronized void flush() throws IOException {
        if (!this.f13680e) {
            this.f13676a.flush();
        } else {
            throw new IOException("closed");
        }
    }

    public synchronized void g(boolean z10, int i10, List<c> list) throws IOException {
        if (!this.f13680e) {
            this.f13681f.g(list);
            long size = this.f13678c.size();
            int min = (int) Math.min((long) this.f13679d, size);
            long j10 = (long) min;
            int i11 = (size > j10 ? 1 : (size == j10 ? 0 : -1));
            byte b10 = i11 == 0 ? (byte) 4 : 0;
            if (z10) {
                b10 = (byte) (b10 | 1);
            }
            e(i10, min, (byte) 1, b10);
            this.f13676a.n0(this.f13678c, j10);
            if (i11 > 0) {
                p(i10, size - j10);
            }
        } else {
            throw new IOException("closed");
        }
    }

    public int h() {
        return this.f13679d;
    }

    public synchronized void i(boolean z10, int i10, int i11) throws IOException {
        if (!this.f13680e) {
            e(0, 8, (byte) 6, z10 ? (byte) 1 : 0);
            this.f13676a.writeInt(i10);
            this.f13676a.writeInt(i11);
            this.f13676a.flush();
        } else {
            throw new IOException("closed");
        }
    }

    public synchronized void k(int i10, int i11, List<c> list) throws IOException {
        if (!this.f13680e) {
            this.f13681f.g(list);
            long size = this.f13678c.size();
            int min = (int) Math.min((long) (this.f13679d - 4), size);
            long j10 = (long) min;
            int i12 = (size > j10 ? 1 : (size == j10 ? 0 : -1));
            e(i10, min + 4, (byte) 5, i12 == 0 ? (byte) 4 : 0);
            this.f13676a.writeInt(i11 & Integer.MAX_VALUE);
            this.f13676a.n0(this.f13678c, j10);
            if (i12 > 0) {
                p(i10, size - j10);
            }
        } else {
            throw new IOException("closed");
        }
    }

    public synchronized void m(int i10, b bVar) throws IOException {
        if (this.f13680e) {
            throw new IOException("closed");
        } else if (bVar.f13527a != -1) {
            e(i10, 4, (byte) 3, (byte) 0);
            this.f13676a.writeInt(bVar.f13527a);
            this.f13676a.flush();
        } else {
            throw new IllegalArgumentException();
        }
    }

    public synchronized void n(m mVar) throws IOException {
        if (!this.f13680e) {
            int i10 = 0;
            e(0, mVar.j() * 6, (byte) 4, (byte) 0);
            while (i10 < 10) {
                if (mVar.g(i10)) {
                    this.f13676a.writeShort(i10 == 4 ? 3 : i10 == 7 ? 4 : i10);
                    this.f13676a.writeInt(mVar.b(i10));
                }
                i10++;
            }
            this.f13676a.flush();
        } else {
            throw new IOException("closed");
        }
    }

    public synchronized void o(int i10, long j10) throws IOException {
        if (this.f13680e) {
            throw new IOException("closed");
        } else if (j10 == 0 || j10 > 2147483647L) {
            throw e.c("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", Long.valueOf(j10));
        } else {
            e(i10, 4, (byte) 8, (byte) 0);
            this.f13676a.writeInt((int) j10);
            this.f13676a.flush();
        }
    }
}
