package oc;

import java.io.Closeable;
import java.io.IOException;
import java.net.Socket;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import oc.h;

public final class f implements Closeable {
    /* access modifiers changed from: private */

    /* renamed from: z  reason: collision with root package name */
    public static final ExecutorService f13561z = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), jc.e.I("OkHttp Http2Connection", true));

    /* renamed from: a  reason: collision with root package name */
    final boolean f13562a;

    /* renamed from: b  reason: collision with root package name */
    final j f13563b;

    /* renamed from: c  reason: collision with root package name */
    final Map<Integer, i> f13564c = new LinkedHashMap();

    /* renamed from: d  reason: collision with root package name */
    final String f13565d;

    /* renamed from: e  reason: collision with root package name */
    int f13566e;

    /* renamed from: f  reason: collision with root package name */
    int f13567f;
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public boolean f13568g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public final ScheduledExecutorService f13569h;

    /* renamed from: i  reason: collision with root package name */
    private final ExecutorService f13570i;

    /* renamed from: j  reason: collision with root package name */
    final l f13571j;
    /* access modifiers changed from: private */

    /* renamed from: k  reason: collision with root package name */
    public long f13572k = 0;
    /* access modifiers changed from: private */

    /* renamed from: l  reason: collision with root package name */
    public long f13573l = 0;

    /* renamed from: m  reason: collision with root package name */
    private long f13574m = 0;

    /* renamed from: n  reason: collision with root package name */
    private long f13575n = 0;

    /* renamed from: o  reason: collision with root package name */
    private long f13576o = 0;

    /* renamed from: p  reason: collision with root package name */
    private long f13577p = 0;

    /* renamed from: q  reason: collision with root package name */
    private long f13578q = 0;

    /* renamed from: r  reason: collision with root package name */
    long f13579r = 0;

    /* renamed from: s  reason: collision with root package name */
    long f13580s;

    /* renamed from: t  reason: collision with root package name */
    m f13581t = new m();

    /* renamed from: u  reason: collision with root package name */
    final m f13582u;

    /* renamed from: v  reason: collision with root package name */
    final Socket f13583v;

    /* renamed from: w  reason: collision with root package name */
    final j f13584w;

    /* renamed from: x  reason: collision with root package name */
    final l f13585x;

    /* renamed from: y  reason: collision with root package name */
    final Set<Integer> f13586y;

    class a extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f13587b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ b f13588c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(String str, Object[] objArr, int i10, b bVar) {
            super(str, objArr);
            this.f13587b = i10;
            this.f13588c = bVar;
        }

        public void k() {
            try {
                f.this.l0(this.f13587b, this.f13588c);
            } catch (IOException e10) {
                f.this.o(e10);
            }
        }
    }

    class b extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f13590b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ long f13591c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(String str, Object[] objArr, int i10, long j10) {
            super(str, objArr);
            this.f13590b = i10;
            this.f13591c = j10;
        }

        public void k() {
            try {
                f.this.f13584w.o(this.f13590b, this.f13591c);
            } catch (IOException e10) {
                f.this.o(e10);
            }
        }
    }

    class c extends jc.b {
        c(String str, Object... objArr) {
            super(str, objArr);
        }

        public void k() {
            f.this.j0(false, 2, 0);
        }
    }

    class d extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f13594b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ List f13595c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(String str, Object[] objArr, int i10, List list) {
            super(str, objArr);
            this.f13594b = i10;
            this.f13595c = list;
        }

        public void k() {
            if (f.this.f13571j.b(this.f13594b, this.f13595c)) {
                try {
                    f.this.f13584w.m(this.f13594b, b.CANCEL);
                    synchronized (f.this) {
                        f.this.f13586y.remove(Integer.valueOf(this.f13594b));
                    }
                } catch (IOException unused) {
                }
            }
        }
    }

    class e extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f13597b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ List f13598c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ boolean f13599d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        e(String str, Object[] objArr, int i10, List list, boolean z10) {
            super(str, objArr);
            this.f13597b = i10;
            this.f13598c = list;
            this.f13599d = z10;
        }

        public void k() {
            boolean c10 = f.this.f13571j.c(this.f13597b, this.f13598c, this.f13599d);
            if (c10) {
                try {
                    f.this.f13584w.m(this.f13597b, b.CANCEL);
                } catch (IOException unused) {
                    return;
                }
            }
            if (c10 || this.f13599d) {
                synchronized (f.this) {
                    f.this.f13586y.remove(Integer.valueOf(this.f13597b));
                }
            }
        }
    }

    /* renamed from: oc.f$f  reason: collision with other inner class name */
    class C0229f extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f13601b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ okio.c f13602c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ int f13603d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ boolean f13604e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        C0229f(String str, Object[] objArr, int i10, okio.c cVar, int i11, boolean z10) {
            super(str, objArr);
            this.f13601b = i10;
            this.f13602c = cVar;
            this.f13603d = i11;
            this.f13604e = z10;
        }

        public void k() {
            try {
                boolean d10 = f.this.f13571j.d(this.f13601b, this.f13602c, this.f13603d, this.f13604e);
                if (d10) {
                    f.this.f13584w.m(this.f13601b, b.CANCEL);
                }
                if (d10 || this.f13604e) {
                    synchronized (f.this) {
                        f.this.f13586y.remove(Integer.valueOf(this.f13601b));
                    }
                }
            } catch (IOException unused) {
            }
        }
    }

    class g extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f13606b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ b f13607c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        g(String str, Object[] objArr, int i10, b bVar) {
            super(str, objArr);
            this.f13606b = i10;
            this.f13607c = bVar;
        }

        public void k() {
            f.this.f13571j.a(this.f13606b, this.f13607c);
            synchronized (f.this) {
                f.this.f13586y.remove(Integer.valueOf(this.f13606b));
            }
        }
    }

    public static class h {

        /* renamed from: a  reason: collision with root package name */
        Socket f13609a;

        /* renamed from: b  reason: collision with root package name */
        String f13610b;

        /* renamed from: c  reason: collision with root package name */
        okio.e f13611c;

        /* renamed from: d  reason: collision with root package name */
        okio.d f13612d;

        /* renamed from: e  reason: collision with root package name */
        j f13613e = j.f13618a;

        /* renamed from: f  reason: collision with root package name */
        l f13614f = l.f13689a;

        /* renamed from: g  reason: collision with root package name */
        boolean f13615g;

        /* renamed from: h  reason: collision with root package name */
        int f13616h;

        public h(boolean z10) {
            this.f13615g = z10;
        }

        public f a() {
            return new f(this);
        }

        public h b(j jVar) {
            this.f13613e = jVar;
            return this;
        }

        public h c(int i10) {
            this.f13616h = i10;
            return this;
        }

        public h d(Socket socket, String str, okio.e eVar, okio.d dVar) {
            this.f13609a = socket;
            this.f13610b = str;
            this.f13611c = eVar;
            this.f13612d = dVar;
            return this;
        }
    }

    final class i extends jc.b {
        i() {
            super("OkHttp %s ping", f.this.f13565d);
        }

        public void k() {
            boolean z10;
            synchronized (f.this) {
                if (f.this.f13573l < f.this.f13572k) {
                    z10 = true;
                } else {
                    f.e(f.this);
                    z10 = false;
                }
            }
            f fVar = f.this;
            if (z10) {
                fVar.o((IOException) null);
            } else {
                fVar.j0(false, 1, 0);
            }
        }
    }

    public static abstract class j {

        /* renamed from: a  reason: collision with root package name */
        public static final j f13618a = new a();

        class a extends j {
            a() {
            }

            public void c(i iVar) throws IOException {
                iVar.d(b.REFUSED_STREAM, (IOException) null);
            }
        }

        public void b(f fVar) {
        }

        public abstract void c(i iVar) throws IOException;
    }

    final class k extends jc.b {

        /* renamed from: b  reason: collision with root package name */
        final boolean f13619b;

        /* renamed from: c  reason: collision with root package name */
        final int f13620c;

        /* renamed from: d  reason: collision with root package name */
        final int f13621d;

        k(boolean z10, int i10, int i11) {
            super("OkHttp %s ping %08x%08x", f.this.f13565d, Integer.valueOf(i10), Integer.valueOf(i11));
            this.f13619b = z10;
            this.f13620c = i10;
            this.f13621d = i11;
        }

        public void k() {
            f.this.j0(this.f13619b, this.f13620c, this.f13621d);
        }
    }

    class l extends jc.b implements h.b {

        /* renamed from: b  reason: collision with root package name */
        final h f13623b;

        class a extends jc.b {

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ i f13625b;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(String str, Object[] objArr, i iVar) {
                super(str, objArr);
                this.f13625b = iVar;
            }

            public void k() {
                try {
                    f.this.f13563b.c(this.f13625b);
                } catch (IOException e10) {
                    qc.j l10 = qc.j.l();
                    l10.t(4, "Http2Connection.Listener failure for " + f.this.f13565d, e10);
                    try {
                        this.f13625b.d(b.PROTOCOL_ERROR, e10);
                    } catch (IOException unused) {
                    }
                }
            }
        }

        class b extends jc.b {

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ boolean f13627b;

            /* renamed from: c  reason: collision with root package name */
            final /* synthetic */ m f13628c;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            b(String str, Object[] objArr, boolean z10, m mVar) {
                super(str, objArr);
                this.f13627b = z10;
                this.f13628c = mVar;
            }

            public void k() {
                l.this.l(this.f13627b, this.f13628c);
            }
        }

        class c extends jc.b {
            c(String str, Object... objArr) {
                super(str, objArr);
            }

            public void k() {
                f fVar = f.this;
                fVar.f13563b.b(fVar);
            }
        }

        l(h hVar) {
            super("OkHttp %s", f.this.f13565d);
            this.f13623b = hVar;
        }

        public void a() {
        }

        public void b(int i10, b bVar, okio.f fVar) {
            i[] iVarArr;
            fVar.F();
            synchronized (f.this) {
                iVarArr = (i[]) f.this.f13564c.values().toArray(new i[f.this.f13564c.size()]);
                boolean unused = f.this.f13568g = true;
            }
            for (i iVar : iVarArr) {
                if (iVar.g() > i10 && iVar.j()) {
                    iVar.o(b.REFUSED_STREAM);
                    f.this.N(iVar.g());
                }
            }
        }

        public void c(boolean z10, int i10, int i11, List<c> list) {
            if (f.this.K(i10)) {
                f.this.F(i10, list, z10);
                return;
            }
            synchronized (f.this) {
                i p10 = f.this.p(i10);
                if (p10 != null) {
                    p10.n(jc.e.K(list), z10);
                } else if (!f.this.f13568g) {
                    f fVar = f.this;
                    if (i10 > fVar.f13566e) {
                        if (i10 % 2 != fVar.f13567f % 2) {
                            int i12 = i10;
                            i iVar = new i(i12, f.this, false, z10, jc.e.K(list));
                            f fVar2 = f.this;
                            fVar2.f13566e = i10;
                            fVar2.f13564c.put(Integer.valueOf(i10), iVar);
                            f.f13561z.execute(new a("OkHttp %s stream %d", new Object[]{f.this.f13565d, Integer.valueOf(i10)}, iVar));
                        }
                    }
                }
            }
        }

        public void d(int i10, long j10) {
            f fVar = f.this;
            if (i10 == 0) {
                synchronized (fVar) {
                    f fVar2 = f.this;
                    fVar2.f13580s += j10;
                    fVar2.notifyAll();
                }
                return;
            }
            i p10 = fVar.p(i10);
            if (p10 != null) {
                synchronized (p10) {
                    p10.a(j10);
                }
            }
        }

        public void e(boolean z10, m mVar) {
            try {
                f.this.f13569h.execute(new b("OkHttp %s ACK Settings", new Object[]{f.this.f13565d}, z10, mVar));
            } catch (RejectedExecutionException unused) {
            }
        }

        public void f(int i10, b bVar) {
            if (f.this.K(i10)) {
                f.this.H(i10, bVar);
                return;
            }
            i N = f.this.N(i10);
            if (N != null) {
                N.o(bVar);
            }
        }

        public void g(boolean z10, int i10, okio.e eVar, int i11) throws IOException {
            if (f.this.K(i10)) {
                f.this.B(i10, eVar, i11, z10);
                return;
            }
            i p10 = f.this.p(i10);
            if (p10 == null) {
                f.this.q0(i10, b.PROTOCOL_ERROR);
                long j10 = (long) i11;
                f.this.c0(j10);
                eVar.skip(j10);
                return;
            }
            p10.m(eVar, i11);
            if (z10) {
                p10.n(jc.e.f11906c, true);
            }
        }

        public void h(boolean z10, int i10, int i11) {
            if (z10) {
                synchronized (f.this) {
                    if (i10 == 1) {
                        try {
                            f.c(f.this);
                        } catch (Throwable th) {
                            throw th;
                        }
                    } else if (i10 == 2) {
                        f.k(f.this);
                    } else if (i10 == 3) {
                        f.m(f.this);
                        f.this.notifyAll();
                    }
                }
                return;
            }
            try {
                f.this.f13569h.execute(new k(true, i10, i11));
            } catch (RejectedExecutionException unused) {
            }
        }

        public void i(int i10, int i11, int i12, boolean z10) {
        }

        public void j(int i10, int i11, List<c> list) {
            f.this.G(i11, list);
        }

        /* access modifiers changed from: protected */
        public void k() {
            b bVar;
            b bVar2 = b.INTERNAL_ERROR;
            e = null;
            try {
                this.f13623b.c(this);
                while (this.f13623b.b(false, this)) {
                }
                bVar = b.NO_ERROR;
                try {
                    f.this.n(bVar, b.CANCEL, (IOException) null);
                } catch (IOException e10) {
                    e = e10;
                    try {
                        b bVar3 = b.PROTOCOL_ERROR;
                        f.this.n(bVar3, bVar3, e);
                        jc.e.g(this.f13623b);
                    } catch (Throwable th) {
                        th = th;
                        f.this.n(bVar, bVar2, e);
                        jc.e.g(this.f13623b);
                        throw th;
                    }
                }
            } catch (IOException e11) {
                e = e11;
                bVar = bVar2;
                b bVar32 = b.PROTOCOL_ERROR;
                f.this.n(bVar32, bVar32, e);
                jc.e.g(this.f13623b);
            } catch (Throwable th2) {
                th = th2;
                bVar = bVar2;
                f.this.n(bVar, bVar2, e);
                jc.e.g(this.f13623b);
                throw th;
            }
            jc.e.g(this.f13623b);
        }

        /* access modifiers changed from: package-private */
        public void l(boolean z10, m mVar) {
            i[] iVarArr;
            long j10;
            synchronized (f.this.f13584w) {
                synchronized (f.this) {
                    int d10 = f.this.f13582u.d();
                    if (z10) {
                        f.this.f13582u.a();
                    }
                    f.this.f13582u.h(mVar);
                    int d11 = f.this.f13582u.d();
                    iVarArr = null;
                    if (d11 == -1 || d11 == d10) {
                        j10 = 0;
                    } else {
                        j10 = (long) (d11 - d10);
                        if (!f.this.f13564c.isEmpty()) {
                            iVarArr = (i[]) f.this.f13564c.values().toArray(new i[f.this.f13564c.size()]);
                        }
                    }
                }
                try {
                    f fVar = f.this;
                    fVar.f13584w.a(fVar.f13582u);
                } catch (IOException e10) {
                    f.this.o(e10);
                }
            }
            if (iVarArr != null) {
                for (i iVar : iVarArr) {
                    synchronized (iVar) {
                        iVar.a(j10);
                    }
                }
            }
            f.f13561z.execute(new c("OkHttp %s settings", f.this.f13565d));
        }
    }

    f(h hVar) {
        h hVar2 = hVar;
        m mVar = new m();
        this.f13582u = mVar;
        this.f13586y = new LinkedHashSet();
        this.f13571j = hVar2.f13614f;
        boolean z10 = hVar2.f13615g;
        this.f13562a = z10;
        this.f13563b = hVar2.f13613e;
        int i10 = z10 ? 1 : 2;
        this.f13567f = i10;
        if (z10) {
            this.f13567f = i10 + 2;
        }
        if (z10) {
            this.f13581t.i(7, 16777216);
        }
        String str = hVar2.f13610b;
        this.f13565d = str;
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, jc.e.I(jc.e.q("OkHttp %s Writer", str), false));
        this.f13569h = scheduledThreadPoolExecutor;
        if (hVar2.f13616h != 0) {
            i iVar = new i();
            int i11 = hVar2.f13616h;
            scheduledThreadPoolExecutor.scheduleAtFixedRate(iVar, (long) i11, (long) i11, TimeUnit.MILLISECONDS);
        }
        this.f13570i = new ThreadPoolExecutor(0, 1, 60, TimeUnit.SECONDS, new LinkedBlockingQueue(), jc.e.I(jc.e.q("OkHttp %s Push Observer", str), true));
        mVar.i(7, 65535);
        mVar.i(5, 16384);
        this.f13580s = (long) mVar.d();
        this.f13583v = hVar2.f13609a;
        this.f13584w = new j(hVar2.f13612d, z10);
        this.f13585x = new l(new h(hVar2.f13611c, z10));
    }

    private synchronized void E(jc.b bVar) {
        if (!this.f13568g) {
            this.f13570i.execute(bVar);
        }
    }

    static /* synthetic */ long c(f fVar) {
        long j10 = fVar.f13573l;
        fVar.f13573l = 1 + j10;
        return j10;
    }

    static /* synthetic */ long e(f fVar) {
        long j10 = fVar.f13572k;
        fVar.f13572k = 1 + j10;
        return j10;
    }

    static /* synthetic */ long k(f fVar) {
        long j10 = fVar.f13575n;
        fVar.f13575n = 1 + j10;
        return j10;
    }

    static /* synthetic */ long m(f fVar) {
        long j10 = fVar.f13577p;
        fVar.f13577p = 1 + j10;
        return j10;
    }

    /* access modifiers changed from: private */
    public void o(IOException iOException) {
        b bVar = b.PROTOCOL_ERROR;
        n(bVar, bVar, iOException);
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0041  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private oc.i z(int r11, java.util.List<oc.c> r12, boolean r13) throws java.io.IOException {
        /*
            r10 = this;
            r6 = r13 ^ 1
            r4 = 0
            oc.j r7 = r10.f13584w
            monitor-enter(r7)
            monitor-enter(r10)     // Catch:{ all -> 0x0076 }
            int r0 = r10.f13567f     // Catch:{ all -> 0x0073 }
            r1 = 1073741823(0x3fffffff, float:1.9999999)
            if (r0 <= r1) goto L_0x0013
            oc.b r0 = oc.b.REFUSED_STREAM     // Catch:{ all -> 0x0073 }
            r10.Q(r0)     // Catch:{ all -> 0x0073 }
        L_0x0013:
            boolean r0 = r10.f13568g     // Catch:{ all -> 0x0073 }
            if (r0 != 0) goto L_0x006d
            int r8 = r10.f13567f     // Catch:{ all -> 0x0073 }
            int r0 = r8 + 2
            r10.f13567f = r0     // Catch:{ all -> 0x0073 }
            oc.i r9 = new oc.i     // Catch:{ all -> 0x0073 }
            r5 = 0
            r0 = r9
            r1 = r8
            r2 = r10
            r3 = r6
            r0.<init>(r1, r2, r3, r4, r5)     // Catch:{ all -> 0x0073 }
            if (r13 == 0) goto L_0x003a
            long r0 = r10.f13580s     // Catch:{ all -> 0x0073 }
            r2 = 0
            int r13 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r13 == 0) goto L_0x003a
            long r0 = r9.f13651b     // Catch:{ all -> 0x0073 }
            int r13 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r13 != 0) goto L_0x0038
            goto L_0x003a
        L_0x0038:
            r13 = 0
            goto L_0x003b
        L_0x003a:
            r13 = 1
        L_0x003b:
            boolean r0 = r9.k()     // Catch:{ all -> 0x0073 }
            if (r0 == 0) goto L_0x004a
            java.util.Map<java.lang.Integer, oc.i> r0 = r10.f13564c     // Catch:{ all -> 0x0073 }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r8)     // Catch:{ all -> 0x0073 }
            r0.put(r1, r9)     // Catch:{ all -> 0x0073 }
        L_0x004a:
            monitor-exit(r10)     // Catch:{ all -> 0x0073 }
            if (r11 != 0) goto L_0x0053
            oc.j r11 = r10.f13584w     // Catch:{ all -> 0x0076 }
            r11.g(r6, r8, r12)     // Catch:{ all -> 0x0076 }
            goto L_0x005c
        L_0x0053:
            boolean r0 = r10.f13562a     // Catch:{ all -> 0x0076 }
            if (r0 != 0) goto L_0x0065
            oc.j r0 = r10.f13584w     // Catch:{ all -> 0x0076 }
            r0.k(r11, r8, r12)     // Catch:{ all -> 0x0076 }
        L_0x005c:
            monitor-exit(r7)     // Catch:{ all -> 0x0076 }
            if (r13 == 0) goto L_0x0064
            oc.j r11 = r10.f13584w
            r11.flush()
        L_0x0064:
            return r9
        L_0x0065:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0076 }
            java.lang.String r12 = "client streams shouldn't have associated stream IDs"
            r11.<init>(r12)     // Catch:{ all -> 0x0076 }
            throw r11     // Catch:{ all -> 0x0076 }
        L_0x006d:
            oc.a r11 = new oc.a     // Catch:{ all -> 0x0073 }
            r11.<init>()     // Catch:{ all -> 0x0073 }
            throw r11     // Catch:{ all -> 0x0073 }
        L_0x0073:
            r11 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x0073 }
            throw r11     // Catch:{ all -> 0x0076 }
        L_0x0076:
            r11 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x0076 }
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.f.z(int, java.util.List, boolean):oc.i");
    }

    public i A(List<c> list, boolean z10) throws IOException {
        return z(0, list, z10);
    }

    /* access modifiers changed from: package-private */
    public void B(int i10, okio.e eVar, int i11, boolean z10) throws IOException {
        okio.c cVar = new okio.c();
        long j10 = (long) i11;
        eVar.Q0(j10);
        eVar.K0(cVar, j10);
        if (cVar.size() == j10) {
            E(new C0229f("OkHttp %s Push Data[%s]", new Object[]{this.f13565d, Integer.valueOf(i10)}, i10, cVar, i11, z10));
            return;
        }
        throw new IOException(cVar.size() + " != " + i11);
    }

    /* access modifiers changed from: package-private */
    public void F(int i10, List<c> list, boolean z10) {
        try {
            E(new e("OkHttp %s Push Headers[%s]", new Object[]{this.f13565d, Integer.valueOf(i10)}, i10, list, z10));
        } catch (RejectedExecutionException unused) {
        }
    }

    /* access modifiers changed from: package-private */
    public void G(int i10, List<c> list) {
        synchronized (this) {
            if (this.f13586y.contains(Integer.valueOf(i10))) {
                q0(i10, b.PROTOCOL_ERROR);
                return;
            }
            this.f13586y.add(Integer.valueOf(i10));
            try {
                E(new d("OkHttp %s Push Request[%s]", new Object[]{this.f13565d, Integer.valueOf(i10)}, i10, list));
            } catch (RejectedExecutionException unused) {
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void H(int i10, b bVar) {
        E(new g("OkHttp %s Push Reset[%s]", new Object[]{this.f13565d, Integer.valueOf(i10)}, i10, bVar));
    }

    /* access modifiers changed from: package-private */
    public boolean K(int i10) {
        return i10 != 0 && (i10 & 1) == 0;
    }

    /* access modifiers changed from: package-private */
    public synchronized i N(int i10) {
        i remove;
        remove = this.f13564c.remove(Integer.valueOf(i10));
        notifyAll();
        return remove;
    }

    /* access modifiers changed from: package-private */
    public void P() {
        synchronized (this) {
            long j10 = this.f13575n;
            long j11 = this.f13574m;
            if (j10 >= j11) {
                this.f13574m = j11 + 1;
                this.f13578q = System.nanoTime() + 1000000000;
                try {
                    this.f13569h.execute(new c("OkHttp %s ping", this.f13565d));
                } catch (RejectedExecutionException unused) {
                }
            }
        }
    }

    public void Q(b bVar) throws IOException {
        synchronized (this.f13584w) {
            synchronized (this) {
                if (!this.f13568g) {
                    this.f13568g = true;
                    int i10 = this.f13566e;
                    this.f13584w.f(i10, bVar, jc.e.f11904a);
                }
            }
        }
    }

    public void R() throws IOException {
        S(true);
    }

    /* access modifiers changed from: package-private */
    public void S(boolean z10) throws IOException {
        if (z10) {
            this.f13584w.b();
            this.f13584w.n(this.f13581t);
            int d10 = this.f13581t.d();
            if (d10 != 65535) {
                this.f13584w.o(0, (long) (d10 - 65535));
            }
        }
        new Thread(this.f13585x).start();
    }

    /* access modifiers changed from: package-private */
    public synchronized void c0(long j10) {
        long j11 = this.f13579r + j10;
        this.f13579r = j11;
        if (j11 >= ((long) (this.f13581t.d() / 2))) {
            r0(0, this.f13579r);
            this.f13579r = 0;
        }
    }

    public void close() {
        n(b.NO_ERROR, b.CANCEL, (IOException) null);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:26|27|28) */
    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        r3 = java.lang.Math.min((int) java.lang.Math.min(r12, r3), r8.f13584w.h());
        r6 = (long) r3;
        r8.f13580s -= r6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        java.lang.Thread.currentThread().interrupt();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0064, code lost:
        throw new java.io.InterruptedIOException();
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:26:0x0058 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void e0(int r9, boolean r10, okio.c r11, long r12) throws java.io.IOException {
        /*
            r8 = this;
            r0 = 0
            r1 = 0
            int r3 = (r12 > r1 ? 1 : (r12 == r1 ? 0 : -1))
            if (r3 != 0) goto L_0x000d
            oc.j r12 = r8.f13584w
            r12.c(r10, r9, r11, r0)
            return
        L_0x000d:
            int r3 = (r12 > r1 ? 1 : (r12 == r1 ? 0 : -1))
            if (r3 <= 0) goto L_0x0067
            monitor-enter(r8)
        L_0x0012:
            long r3 = r8.f13580s     // Catch:{ InterruptedException -> 0x0058 }
            int r5 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r5 > 0) goto L_0x0030
            java.util.Map<java.lang.Integer, oc.i> r3 = r8.f13564c     // Catch:{ InterruptedException -> 0x0058 }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r9)     // Catch:{ InterruptedException -> 0x0058 }
            boolean r3 = r3.containsKey(r4)     // Catch:{ InterruptedException -> 0x0058 }
            if (r3 == 0) goto L_0x0028
            r8.wait()     // Catch:{ InterruptedException -> 0x0058 }
            goto L_0x0012
        L_0x0028:
            java.io.IOException r9 = new java.io.IOException     // Catch:{ InterruptedException -> 0x0058 }
            java.lang.String r10 = "stream closed"
            r9.<init>(r10)     // Catch:{ InterruptedException -> 0x0058 }
            throw r9     // Catch:{ InterruptedException -> 0x0058 }
        L_0x0030:
            long r3 = java.lang.Math.min(r12, r3)     // Catch:{ all -> 0x0056 }
            int r4 = (int) r3     // Catch:{ all -> 0x0056 }
            oc.j r3 = r8.f13584w     // Catch:{ all -> 0x0056 }
            int r3 = r3.h()     // Catch:{ all -> 0x0056 }
            int r3 = java.lang.Math.min(r4, r3)     // Catch:{ all -> 0x0056 }
            long r4 = r8.f13580s     // Catch:{ all -> 0x0056 }
            long r6 = (long) r3     // Catch:{ all -> 0x0056 }
            long r4 = r4 - r6
            r8.f13580s = r4     // Catch:{ all -> 0x0056 }
            monitor-exit(r8)     // Catch:{ all -> 0x0056 }
            long r12 = r12 - r6
            oc.j r4 = r8.f13584w
            if (r10 == 0) goto L_0x0051
            int r5 = (r12 > r1 ? 1 : (r12 == r1 ? 0 : -1))
            if (r5 != 0) goto L_0x0051
            r5 = 1
            goto L_0x0052
        L_0x0051:
            r5 = 0
        L_0x0052:
            r4.c(r5, r9, r11, r3)
            goto L_0x000d
        L_0x0056:
            r9 = move-exception
            goto L_0x0065
        L_0x0058:
            java.lang.Thread r9 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0056 }
            r9.interrupt()     // Catch:{ all -> 0x0056 }
            java.io.InterruptedIOException r9 = new java.io.InterruptedIOException     // Catch:{ all -> 0x0056 }
            r9.<init>()     // Catch:{ all -> 0x0056 }
            throw r9     // Catch:{ all -> 0x0056 }
        L_0x0065:
            monitor-exit(r8)     // Catch:{ all -> 0x0056 }
            throw r9
        L_0x0067:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.f.e0(int, boolean, okio.c, long):void");
    }

    public void flush() throws IOException {
        this.f13584w.flush();
    }

    /* access modifiers changed from: package-private */
    public void g0(int i10, boolean z10, List<c> list) throws IOException {
        this.f13584w.g(z10, i10, list);
    }

    /* access modifiers changed from: package-private */
    public void j0(boolean z10, int i10, int i11) {
        try {
            this.f13584w.i(z10, i10, i11);
        } catch (IOException e10) {
            o(e10);
        }
    }

    /* access modifiers changed from: package-private */
    public void l0(int i10, b bVar) throws IOException {
        this.f13584w.m(i10, bVar);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x003b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void n(oc.b r4, oc.b r5, java.io.IOException r6) {
        /*
            r3 = this;
            r3.Q(r4)     // Catch:{ IOException -> 0x0003 }
        L_0x0003:
            monitor-enter(r3)
            java.util.Map<java.lang.Integer, oc.i> r4 = r3.f13564c     // Catch:{ all -> 0x004b }
            boolean r4 = r4.isEmpty()     // Catch:{ all -> 0x004b }
            if (r4 != 0) goto L_0x0026
            java.util.Map<java.lang.Integer, oc.i> r4 = r3.f13564c     // Catch:{ all -> 0x004b }
            java.util.Collection r4 = r4.values()     // Catch:{ all -> 0x004b }
            java.util.Map<java.lang.Integer, oc.i> r0 = r3.f13564c     // Catch:{ all -> 0x004b }
            int r0 = r0.size()     // Catch:{ all -> 0x004b }
            oc.i[] r0 = new oc.i[r0]     // Catch:{ all -> 0x004b }
            java.lang.Object[] r4 = r4.toArray(r0)     // Catch:{ all -> 0x004b }
            oc.i[] r4 = (oc.i[]) r4     // Catch:{ all -> 0x004b }
            java.util.Map<java.lang.Integer, oc.i> r0 = r3.f13564c     // Catch:{ all -> 0x004b }
            r0.clear()     // Catch:{ all -> 0x004b }
            goto L_0x0027
        L_0x0026:
            r4 = 0
        L_0x0027:
            monitor-exit(r3)     // Catch:{ all -> 0x004b }
            if (r4 == 0) goto L_0x0036
            int r0 = r4.length
            r1 = 0
        L_0x002c:
            if (r1 >= r0) goto L_0x0036
            r2 = r4[r1]
            r2.d(r5, r6)     // Catch:{ IOException -> 0x0033 }
        L_0x0033:
            int r1 = r1 + 1
            goto L_0x002c
        L_0x0036:
            oc.j r4 = r3.f13584w     // Catch:{ IOException -> 0x003b }
            r4.close()     // Catch:{ IOException -> 0x003b }
        L_0x003b:
            java.net.Socket r4 = r3.f13583v     // Catch:{ IOException -> 0x0040 }
            r4.close()     // Catch:{ IOException -> 0x0040 }
        L_0x0040:
            java.util.concurrent.ScheduledExecutorService r4 = r3.f13569h
            r4.shutdown()
            java.util.concurrent.ExecutorService r4 = r3.f13570i
            r4.shutdown()
            return
        L_0x004b:
            r4 = move-exception
            monitor-exit(r3)     // Catch:{ all -> 0x004b }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.f.n(oc.b, oc.b, java.io.IOException):void");
    }

    /* access modifiers changed from: package-private */
    public synchronized i p(int i10) {
        return this.f13564c.get(Integer.valueOf(i10));
    }

    /* access modifiers changed from: package-private */
    public void q0(int i10, b bVar) {
        try {
            this.f13569h.execute(new a("OkHttp %s stream %d", new Object[]{this.f13565d, Integer.valueOf(i10)}, i10, bVar));
        } catch (RejectedExecutionException unused) {
        }
    }

    /* access modifiers changed from: package-private */
    public void r0(int i10, long j10) {
        try {
            this.f13569h.execute(new b("OkHttp Window Update %s stream %d", new Object[]{this.f13565d, Integer.valueOf(i10)}, i10, j10));
        } catch (RejectedExecutionException unused) {
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0019, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized boolean s(long r7) {
        /*
            r6 = this;
            monitor-enter(r6)
            boolean r0 = r6.f13568g     // Catch:{ all -> 0x001b }
            r1 = 0
            if (r0 == 0) goto L_0x0008
            monitor-exit(r6)
            return r1
        L_0x0008:
            long r2 = r6.f13575n     // Catch:{ all -> 0x001b }
            long r4 = r6.f13574m     // Catch:{ all -> 0x001b }
            int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r0 >= 0) goto L_0x0018
            long r2 = r6.f13578q     // Catch:{ all -> 0x001b }
            int r0 = (r7 > r2 ? 1 : (r7 == r2 ? 0 : -1))
            if (r0 < 0) goto L_0x0018
            monitor-exit(r6)
            return r1
        L_0x0018:
            monitor-exit(r6)
            r7 = 1
            return r7
        L_0x001b:
            r7 = move-exception
            monitor-exit(r6)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: oc.f.s(long):boolean");
    }

    public synchronized int t() {
        return this.f13582u.e(Integer.MAX_VALUE);
    }
}
