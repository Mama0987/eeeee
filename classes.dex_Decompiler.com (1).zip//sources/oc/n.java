package oc;

import java.io.IOException;

public final class n extends IOException {

    /* renamed from: a  reason: collision with root package name */
    public final b f13692a;

    public n(b bVar) {
        super("stream was reset: " + bVar);
        this.f13692a = bVar;
    }
}
