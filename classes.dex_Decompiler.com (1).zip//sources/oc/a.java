package oc;

import java.io.IOException;

public final class a extends IOException {
}
