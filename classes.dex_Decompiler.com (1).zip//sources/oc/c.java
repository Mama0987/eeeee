package oc;

import jc.e;
import okio.f;

public final class c {

    /* renamed from: d  reason: collision with root package name */
    public static final f f13528d = f.o(":");

    /* renamed from: e  reason: collision with root package name */
    public static final f f13529e = f.o(":status");

    /* renamed from: f  reason: collision with root package name */
    public static final f f13530f = f.o(":method");

    /* renamed from: g  reason: collision with root package name */
    public static final f f13531g = f.o(":path");

    /* renamed from: h  reason: collision with root package name */
    public static final f f13532h = f.o(":scheme");

    /* renamed from: i  reason: collision with root package name */
    public static final f f13533i = f.o(":authority");

    /* renamed from: a  reason: collision with root package name */
    public final f f13534a;

    /* renamed from: b  reason: collision with root package name */
    public final f f13535b;

    /* renamed from: c  reason: collision with root package name */
    final int f13536c;

    public c(String str, String str2) {
        this(f.o(str), f.o(str2));
    }

    public c(f fVar, String str) {
        this(fVar, f.o(str));
    }

    public c(f fVar, f fVar2) {
        this.f13534a = fVar;
        this.f13535b = fVar2;
        this.f13536c = fVar.F() + 32 + fVar2.F();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.f13534a.equals(cVar.f13534a) && this.f13535b.equals(cVar.f13535b);
    }

    public int hashCode() {
        return ((527 + this.f13534a.hashCode()) * 31) + this.f13535b.hashCode();
    }

    public String toString() {
        return e.q("%s: %s", this.f13534a.K(), this.f13535b.K());
    }
}
