package oc;

import com.appff.haptic.base.Utils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import okio.c;
import okio.e;
import okio.f;
import okio.l;
import okio.t;

final class d {

    /* renamed from: a  reason: collision with root package name */
    static final c[] f13537a;

    /* renamed from: b  reason: collision with root package name */
    static final Map<f, Integer> f13538b = b();

    static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final List<c> f13539a;

        /* renamed from: b  reason: collision with root package name */
        private final e f13540b;

        /* renamed from: c  reason: collision with root package name */
        private final int f13541c;

        /* renamed from: d  reason: collision with root package name */
        private int f13542d;

        /* renamed from: e  reason: collision with root package name */
        c[] f13543e;

        /* renamed from: f  reason: collision with root package name */
        int f13544f;

        /* renamed from: g  reason: collision with root package name */
        int f13545g;

        /* renamed from: h  reason: collision with root package name */
        int f13546h;

        a(int i10, int i11, t tVar) {
            this.f13539a = new ArrayList();
            c[] cVarArr = new c[8];
            this.f13543e = cVarArr;
            this.f13544f = cVarArr.length - 1;
            this.f13545g = 0;
            this.f13546h = 0;
            this.f13541c = i10;
            this.f13542d = i11;
            this.f13540b = l.d(tVar);
        }

        a(int i10, t tVar) {
            this(i10, i10, tVar);
        }

        private void a() {
            int i10 = this.f13542d;
            int i11 = this.f13546h;
            if (i10 >= i11) {
                return;
            }
            if (i10 == 0) {
                b();
            } else {
                d(i11 - i10);
            }
        }

        private void b() {
            Arrays.fill(this.f13543e, (Object) null);
            this.f13544f = this.f13543e.length - 1;
            this.f13545g = 0;
            this.f13546h = 0;
        }

        private int c(int i10) {
            return this.f13544f + 1 + i10;
        }

        private int d(int i10) {
            int i11;
            int i12 = 0;
            if (i10 > 0) {
                int length = this.f13543e.length;
                while (true) {
                    length--;
                    i11 = this.f13544f;
                    if (length < i11 || i10 <= 0) {
                        c[] cVarArr = this.f13543e;
                        System.arraycopy(cVarArr, i11 + 1, cVarArr, i11 + 1 + i12, this.f13545g);
                        this.f13544f += i12;
                    } else {
                        int i13 = this.f13543e[length].f13536c;
                        i10 -= i13;
                        this.f13546h -= i13;
                        this.f13545g--;
                        i12++;
                    }
                }
                c[] cVarArr2 = this.f13543e;
                System.arraycopy(cVarArr2, i11 + 1, cVarArr2, i11 + 1 + i12, this.f13545g);
                this.f13544f += i12;
            }
            return i12;
        }

        private f f(int i10) throws IOException {
            c cVar;
            if (h(i10)) {
                cVar = d.f13537a[i10];
            } else {
                int c10 = c(i10 - d.f13537a.length);
                if (c10 >= 0) {
                    c[] cVarArr = this.f13543e;
                    if (c10 < cVarArr.length) {
                        cVar = cVarArr[c10];
                    }
                }
                throw new IOException("Header index too large " + (i10 + 1));
            }
            return cVar.f13534a;
        }

        private void g(int i10, c cVar) {
            this.f13539a.add(cVar);
            int i11 = cVar.f13536c;
            if (i10 != -1) {
                i11 -= this.f13543e[c(i10)].f13536c;
            }
            int i12 = this.f13542d;
            if (i11 > i12) {
                b();
                return;
            }
            int d10 = d((this.f13546h + i11) - i12);
            if (i10 == -1) {
                int i13 = this.f13545g + 1;
                c[] cVarArr = this.f13543e;
                if (i13 > cVarArr.length) {
                    c[] cVarArr2 = new c[(cVarArr.length * 2)];
                    System.arraycopy(cVarArr, 0, cVarArr2, cVarArr.length, cVarArr.length);
                    this.f13544f = this.f13543e.length - 1;
                    this.f13543e = cVarArr2;
                }
                int i14 = this.f13544f;
                this.f13544f = i14 - 1;
                this.f13543e[i14] = cVar;
                this.f13545g++;
            } else {
                this.f13543e[i10 + c(i10) + d10] = cVar;
            }
            this.f13546h += i11;
        }

        private boolean h(int i10) {
            return i10 >= 0 && i10 <= d.f13537a.length - 1;
        }

        private int i() throws IOException {
            return this.f13540b.readByte() & 255;
        }

        private void l(int i10) throws IOException {
            if (h(i10)) {
                this.f13539a.add(d.f13537a[i10]);
                return;
            }
            int c10 = c(i10 - d.f13537a.length);
            if (c10 >= 0) {
                c[] cVarArr = this.f13543e;
                if (c10 < cVarArr.length) {
                    this.f13539a.add(cVarArr[c10]);
                    return;
                }
            }
            throw new IOException("Header index too large " + (i10 + 1));
        }

        private void n(int i10) throws IOException {
            g(-1, new c(f(i10), j()));
        }

        private void o() throws IOException {
            g(-1, new c(d.a(j()), j()));
        }

        private void p(int i10) throws IOException {
            this.f13539a.add(new c(f(i10), j()));
        }

        private void q() throws IOException {
            this.f13539a.add(new c(d.a(j()), j()));
        }

        public List<c> e() {
            ArrayList arrayList = new ArrayList(this.f13539a);
            this.f13539a.clear();
            return arrayList;
        }

        /* access modifiers changed from: package-private */
        public f j() throws IOException {
            int i10 = i();
            boolean z10 = (i10 & 128) == 128;
            int m10 = m(i10, 127);
            return z10 ? f.y(k.f().c(this.f13540b.A0((long) m10))) : this.f13540b.w((long) m10);
        }

        /* access modifiers changed from: package-private */
        public void k() throws IOException {
            while (!this.f13540b.M()) {
                byte readByte = this.f13540b.readByte() & 255;
                if (readByte == 128) {
                    throw new IOException("index == 0");
                } else if ((readByte & 128) == 128) {
                    l(m(readByte, 127) - 1);
                } else if (readByte == 64) {
                    o();
                } else if ((readByte & 64) == 64) {
                    n(m(readByte, 63) - 1);
                } else if ((readByte & 32) == 32) {
                    int m10 = m(readByte, 31);
                    this.f13542d = m10;
                    if (m10 < 0 || m10 > this.f13541c) {
                        throw new IOException("Invalid dynamic table size update " + this.f13542d);
                    }
                    a();
                } else if (readByte == 16 || readByte == 0) {
                    q();
                } else {
                    p(m(readByte, 15) - 1);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public int m(int i10, int i11) throws IOException {
            int i12 = i10 & i11;
            if (i12 < i11) {
                return i12;
            }
            int i13 = 0;
            while (true) {
                int i14 = i();
                if ((i14 & 128) == 0) {
                    return i11 + (i14 << i13);
                }
                i11 += (i14 & 127) << i13;
                i13 += 7;
            }
        }
    }

    static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final c f13547a;

        /* renamed from: b  reason: collision with root package name */
        private final boolean f13548b;

        /* renamed from: c  reason: collision with root package name */
        private int f13549c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f13550d;

        /* renamed from: e  reason: collision with root package name */
        int f13551e;

        /* renamed from: f  reason: collision with root package name */
        int f13552f;

        /* renamed from: g  reason: collision with root package name */
        c[] f13553g;

        /* renamed from: h  reason: collision with root package name */
        int f13554h;

        /* renamed from: i  reason: collision with root package name */
        int f13555i;

        /* renamed from: j  reason: collision with root package name */
        int f13556j;

        b(int i10, boolean z10, c cVar) {
            this.f13549c = Integer.MAX_VALUE;
            c[] cVarArr = new c[8];
            this.f13553g = cVarArr;
            this.f13554h = cVarArr.length - 1;
            this.f13555i = 0;
            this.f13556j = 0;
            this.f13551e = i10;
            this.f13552f = i10;
            this.f13548b = z10;
            this.f13547a = cVar;
        }

        b(c cVar) {
            this(Utils.CONTINUOUS_EVENT, true, cVar);
        }

        private void a() {
            int i10 = this.f13552f;
            int i11 = this.f13556j;
            if (i10 >= i11) {
                return;
            }
            if (i10 == 0) {
                b();
            } else {
                c(i11 - i10);
            }
        }

        private void b() {
            Arrays.fill(this.f13553g, (Object) null);
            this.f13554h = this.f13553g.length - 1;
            this.f13555i = 0;
            this.f13556j = 0;
        }

        private int c(int i10) {
            int i11;
            int i12 = 0;
            if (i10 > 0) {
                int length = this.f13553g.length;
                while (true) {
                    length--;
                    i11 = this.f13554h;
                    if (length < i11 || i10 <= 0) {
                        c[] cVarArr = this.f13553g;
                        System.arraycopy(cVarArr, i11 + 1, cVarArr, i11 + 1 + i12, this.f13555i);
                        c[] cVarArr2 = this.f13553g;
                        int i13 = this.f13554h;
                        Arrays.fill(cVarArr2, i13 + 1, i13 + 1 + i12, (Object) null);
                        this.f13554h += i12;
                    } else {
                        int i14 = this.f13553g[length].f13536c;
                        i10 -= i14;
                        this.f13556j -= i14;
                        this.f13555i--;
                        i12++;
                    }
                }
                c[] cVarArr3 = this.f13553g;
                System.arraycopy(cVarArr3, i11 + 1, cVarArr3, i11 + 1 + i12, this.f13555i);
                c[] cVarArr22 = this.f13553g;
                int i132 = this.f13554h;
                Arrays.fill(cVarArr22, i132 + 1, i132 + 1 + i12, (Object) null);
                this.f13554h += i12;
            }
            return i12;
        }

        private void d(c cVar) {
            int i10 = cVar.f13536c;
            int i11 = this.f13552f;
            if (i10 > i11) {
                b();
                return;
            }
            c((this.f13556j + i10) - i11);
            int i12 = this.f13555i + 1;
            c[] cVarArr = this.f13553g;
            if (i12 > cVarArr.length) {
                c[] cVarArr2 = new c[(cVarArr.length * 2)];
                System.arraycopy(cVarArr, 0, cVarArr2, cVarArr.length, cVarArr.length);
                this.f13554h = this.f13553g.length - 1;
                this.f13553g = cVarArr2;
            }
            int i13 = this.f13554h;
            this.f13554h = i13 - 1;
            this.f13553g[i13] = cVar;
            this.f13555i++;
            this.f13556j += i10;
        }

        /* access modifiers changed from: package-private */
        public void e(int i10) {
            this.f13551e = i10;
            int min = Math.min(i10, 16384);
            int i11 = this.f13552f;
            if (i11 != min) {
                if (min < i11) {
                    this.f13549c = Math.min(this.f13549c, min);
                }
                this.f13550d = true;
                this.f13552f = min;
                a();
            }
        }

        /* access modifiers changed from: package-private */
        public void f(f fVar) throws IOException {
            int i10;
            int i11;
            if (!this.f13548b || k.f().e(fVar) >= fVar.F()) {
                i11 = fVar.F();
                i10 = 0;
            } else {
                c cVar = new c();
                k.f().d(fVar, cVar);
                fVar = cVar.H();
                i11 = fVar.F();
                i10 = 128;
            }
            h(i11, 127, i10);
            this.f13547a.H0(fVar);
        }

        /* access modifiers changed from: package-private */
        public void g(List<c> list) throws IOException {
            int i10;
            int i11;
            if (this.f13550d) {
                int i12 = this.f13549c;
                if (i12 < this.f13552f) {
                    h(i12, 31, 32);
                }
                this.f13550d = false;
                this.f13549c = Integer.MAX_VALUE;
                h(this.f13552f, 31, 32);
            }
            int size = list.size();
            for (int i13 = 0; i13 < size; i13++) {
                c cVar = list.get(i13);
                f I = cVar.f13534a.I();
                f fVar = cVar.f13535b;
                Integer num = d.f13538b.get(I);
                if (num != null) {
                    i11 = num.intValue() + 1;
                    if (i11 > 1 && i11 < 8) {
                        c[] cVarArr = d.f13537a;
                        if (Objects.equals(cVarArr[i11 - 1].f13535b, fVar)) {
                            i10 = i11;
                        } else if (Objects.equals(cVarArr[i11].f13535b, fVar)) {
                            i10 = i11;
                            i11++;
                        }
                    }
                    i10 = i11;
                    i11 = -1;
                } else {
                    i11 = -1;
                    i10 = -1;
                }
                if (i11 == -1) {
                    int i14 = this.f13554h + 1;
                    int length = this.f13553g.length;
                    while (true) {
                        if (i14 >= length) {
                            break;
                        }
                        if (Objects.equals(this.f13553g[i14].f13534a, I)) {
                            if (Objects.equals(this.f13553g[i14].f13535b, fVar)) {
                                i11 = d.f13537a.length + (i14 - this.f13554h);
                                break;
                            } else if (i10 == -1) {
                                i10 = (i14 - this.f13554h) + d.f13537a.length;
                            }
                        }
                        i14++;
                    }
                }
                if (i11 != -1) {
                    h(i11, 127, 128);
                } else {
                    if (i10 == -1) {
                        this.f13547a.writeByte(64);
                        f(I);
                    } else if (!I.G(c.f13528d) || c.f13533i.equals(I)) {
                        h(i10, 63, 64);
                    } else {
                        h(i10, 15, 0);
                        f(fVar);
                    }
                    f(fVar);
                    d(cVar);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void h(int i10, int i11, int i12) {
            int i13;
            c cVar;
            if (i10 < i11) {
                cVar = this.f13547a;
                i13 = i10 | i12;
            } else {
                this.f13547a.writeByte(i12 | i11);
                i13 = i10 - i11;
                while (i13 >= 128) {
                    this.f13547a.writeByte(128 | (i13 & 127));
                    i13 >>>= 7;
                }
                cVar = this.f13547a;
            }
            cVar.writeByte(i13);
        }
    }

    static {
        f fVar = c.f13530f;
        f fVar2 = c.f13531g;
        f fVar3 = c.f13532h;
        f fVar4 = c.f13529e;
        f13537a = new c[]{new c(c.f13533i, ""), new c(fVar, "GET"), new c(fVar, "POST"), new c(fVar2, "/"), new c(fVar2, "/index.html"), new c(fVar3, "http"), new c(fVar3, "https"), new c(fVar4, "200"), new c(fVar4, "204"), new c(fVar4, "206"), new c(fVar4, "304"), new c(fVar4, "400"), new c(fVar4, "404"), new c(fVar4, "500"), new c("accept-charset", ""), new c("accept-encoding", "gzip, deflate"), new c("accept-language", ""), new c("accept-ranges", ""), new c("accept", ""), new c("access-control-allow-origin", ""), new c("age", ""), new c("allow", ""), new c("authorization", ""), new c("cache-control", ""), new c("content-disposition", ""), new c("content-encoding", ""), new c("content-language", ""), new c("content-length", ""), new c("content-location", ""), new c("content-range", ""), new c("content-type", ""), new c("cookie", ""), new c("date", ""), new c("etag", ""), new c("expect", ""), new c("expires", ""), new c("from", ""), new c("host", ""), new c("if-match", ""), new c("if-modified-since", ""), new c("if-none-match", ""), new c("if-range", ""), new c("if-unmodified-since", ""), new c("last-modified", ""), new c("link", ""), new c("location", ""), new c("max-forwards", ""), new c("proxy-authenticate", ""), new c("proxy-authorization", ""), new c("range", ""), new c("referer", ""), new c("refresh", ""), new c("retry-after", ""), new c("server", ""), new c("set-cookie", ""), new c("strict-transport-security", ""), new c("transfer-encoding", ""), new c("user-agent", ""), new c("vary", ""), new c("via", ""), new c("www-authenticate", "")};
    }

    static f a(f fVar) throws IOException {
        int F = fVar.F();
        int i10 = 0;
        while (i10 < F) {
            byte p10 = fVar.p(i10);
            if (p10 < 65 || p10 > 90) {
                i10++;
            } else {
                throw new IOException("PROTOCOL_ERROR response malformed: mixed case name: " + fVar.K());
            }
        }
        return fVar;
    }

    private static Map<f, Integer> b() {
        LinkedHashMap linkedHashMap = new LinkedHashMap(f13537a.length);
        int i10 = 0;
        while (true) {
            c[] cVarArr = f13537a;
            if (i10 >= cVarArr.length) {
                return Collections.unmodifiableMap(linkedHashMap);
            }
            if (!linkedHashMap.containsKey(cVarArr[i10].f13534a)) {
                linkedHashMap.put(cVarArr[i10].f13534a, Integer.valueOf(i10));
            }
            i10++;
        }
    }
}
