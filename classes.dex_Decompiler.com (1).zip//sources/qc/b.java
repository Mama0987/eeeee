package qc;

public final /* synthetic */ class b {
}
