package qc;

import ic.d0;
import ic.e0;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import jc.e;
import okio.c;
import sc.a;
import sc.b;

public class j {

    /* renamed from: a  reason: collision with root package name */
    private static final j f14470a = k();

    /* renamed from: b  reason: collision with root package name */
    private static final Logger f14471b = Logger.getLogger(d0.class.getName());

    public static List<String> b(List<e0> list) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            e0 e0Var = list.get(i10);
            if (e0Var != e0.HTTP_1_0) {
                arrayList.add(e0Var.toString());
            }
        }
        return arrayList;
    }

    static byte[] e(List<e0> list) {
        c cVar = new c();
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            e0 e0Var = list.get(i10);
            if (e0Var != e0.HTTP_1_0) {
                cVar.writeByte(e0Var.toString().length());
                cVar.f0(e0Var.toString());
            }
        }
        return cVar.G();
    }

    private static j i() {
        j x10 = e.x();
        if (x10 != null) {
            return x10;
        }
        j x11 = f.x();
        if (x11 != null) {
            return x11;
        }
        throw new NullPointerException("No platform found on Android");
    }

    private static j j() {
        g v10;
        if (s() && (v10 = g.v()) != null) {
            return v10;
        }
        i v11 = i.v();
        if (v11 != null) {
            return v11;
        }
        j v12 = h.v();
        return v12 != null ? v12 : new j();
    }

    private static j k() {
        return q() ? i() : j();
    }

    public static j l() {
        return f14470a;
    }

    public static boolean q() {
        return "Dalvik".equals(System.getProperty("java.vm.name"));
    }

    public static boolean s() {
        if ("conscrypt".equals(e.r("okhttp.platform", (String) null))) {
            return true;
        }
        return "Conscrypt".equals(Security.getProviders()[0].getName());
    }

    public void a(SSLSocket sSLSocket) {
    }

    public sc.c c(X509TrustManager x509TrustManager) {
        return new a(d(x509TrustManager));
    }

    public sc.e d(X509TrustManager x509TrustManager) {
        return new b(x509TrustManager.getAcceptedIssuers());
    }

    public void f(SSLSocketFactory sSLSocketFactory) {
    }

    public void g(SSLSocket sSLSocket, String str, List<e0> list) throws IOException {
    }

    public void h(Socket socket, InetSocketAddress inetSocketAddress, int i10) throws IOException {
        socket.connect(inetSocketAddress, i10);
    }

    public String m() {
        return "OkHttp";
    }

    public SSLContext n() {
        try {
            return SSLContext.getInstance("TLS");
        } catch (NoSuchAlgorithmException e10) {
            throw new IllegalStateException("No TLS provider", e10);
        }
    }

    public String o(SSLSocket sSLSocket) {
        return null;
    }

    public Object p(String str) {
        if (f14471b.isLoggable(Level.FINE)) {
            return new Throwable(str);
        }
        return null;
    }

    public boolean r(String str) {
        return true;
    }

    public void t(int i10, String str, Throwable th) {
        f14471b.log(i10 == 5 ? Level.WARNING : Level.INFO, str, th);
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    public void u(String str, Object obj) {
        if (obj == null) {
            str = str + " To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);";
        }
        t(5, str, (Throwable) obj);
    }
}
