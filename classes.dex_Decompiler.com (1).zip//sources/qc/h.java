package qc;

import ic.e0;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import javax.net.ssl.SSLSocket;
import jc.e;

class h extends j {

    /* renamed from: c  reason: collision with root package name */
    private final Method f14460c;

    /* renamed from: d  reason: collision with root package name */
    private final Method f14461d;

    /* renamed from: e  reason: collision with root package name */
    private final Method f14462e;

    /* renamed from: f  reason: collision with root package name */
    private final Class<?> f14463f;

    /* renamed from: g  reason: collision with root package name */
    private final Class<?> f14464g;

    private static class a implements InvocationHandler {

        /* renamed from: a  reason: collision with root package name */
        private final List<String> f14465a;

        /* renamed from: b  reason: collision with root package name */
        boolean f14466b;

        /* renamed from: c  reason: collision with root package name */
        String f14467c;

        a(List<String> list) {
            this.f14465a = list;
        }

        public Object invoke(Object obj, Method method, Object[] objArr) throws Throwable {
            String name = method.getName();
            Class<?> returnType = method.getReturnType();
            if (objArr == null) {
                objArr = e.f11905b;
            }
            if (name.equals("supports") && Boolean.TYPE == returnType) {
                return Boolean.TRUE;
            }
            if (name.equals("unsupported") && Void.TYPE == returnType) {
                this.f14466b = true;
                return null;
            } else if (name.equals("protocols") && objArr.length == 0) {
                return this.f14465a;
            } else {
                if ((name.equals("selectProtocol") || name.equals("select")) && String.class == returnType && objArr.length == 1) {
                    Object obj2 = objArr[0];
                    if (obj2 instanceof List) {
                        List list = (List) obj2;
                        int size = list.size();
                        for (int i10 = 0; i10 < size; i10++) {
                            String str = (String) list.get(i10);
                            if (this.f14465a.contains(str)) {
                                this.f14467c = str;
                                return str;
                            }
                        }
                        String str2 = this.f14465a.get(0);
                        this.f14467c = str2;
                        return str2;
                    }
                }
                if ((!name.equals("protocolSelected") && !name.equals("selected")) || objArr.length != 1) {
                    return method.invoke(this, objArr);
                }
                this.f14467c = (String) objArr[0];
                return null;
            }
        }
    }

    h(Method method, Method method2, Method method3, Class<?> cls, Class<?> cls2) {
        this.f14460c = method;
        this.f14461d = method2;
        this.f14462e = method3;
        this.f14463f = cls;
        this.f14464g = cls2;
    }

    public static j v() {
        Class<SSLSocket> cls = SSLSocket.class;
        try {
            Class<?> cls2 = Class.forName("org.eclipse.jetty.alpn.ALPN", true, (ClassLoader) null);
            Class<?> cls3 = Class.forName("org.eclipse.jetty.alpn.ALPN" + "$Provider", true, (ClassLoader) null);
            Class<?> cls4 = Class.forName("org.eclipse.jetty.alpn.ALPN" + "$ClientProvider", true, (ClassLoader) null);
            Class<?> cls5 = Class.forName("org.eclipse.jetty.alpn.ALPN" + "$ServerProvider", true, (ClassLoader) null);
            return new h(cls2.getMethod("put", new Class[]{cls, cls3}), cls2.getMethod("get", new Class[]{cls}), cls2.getMethod("remove", new Class[]{cls}), cls4, cls5);
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return null;
        }
    }

    public void a(SSLSocket sSLSocket) {
        try {
            this.f14462e.invoke((Object) null, new Object[]{sSLSocket});
        } catch (IllegalAccessException | InvocationTargetException e10) {
            throw new AssertionError("failed to remove ALPN", e10);
        }
    }

    public void g(SSLSocket sSLSocket, String str, List<e0> list) {
        List<String> b10 = j.b(list);
        try {
            Object newProxyInstance = Proxy.newProxyInstance(j.class.getClassLoader(), new Class[]{this.f14463f, this.f14464g}, new a(b10));
            this.f14460c.invoke((Object) null, new Object[]{sSLSocket, newProxyInstance});
        } catch (IllegalAccessException | InvocationTargetException e10) {
            throw new AssertionError("failed to set ALPN", e10);
        }
    }

    public String o(SSLSocket sSLSocket) {
        try {
            a aVar = (a) Proxy.getInvocationHandler(this.f14461d.invoke((Object) null, new Object[]{sSLSocket}));
            boolean z10 = aVar.f14466b;
            if (!z10 && aVar.f14467c == null) {
                j.l().t(4, "ALPN callback dropped: HTTP/2 is disabled. Is alpn-boot on the boot class path?", (Throwable) null);
                return null;
            } else if (z10) {
                return null;
            } else {
                return aVar.f14467c;
            }
        } catch (IllegalAccessException | InvocationTargetException e10) {
            throw new AssertionError("failed to get ALPN selected protocol", e10);
        }
    }
}
