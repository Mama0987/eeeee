package qc;

import android.os.Build;
import android.util.Log;
import com.garena.unity.webview.UnityWebViewActivityProxy;
import ic.e0;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.TrustAnchor;
import java.security.cert.X509Certificate;
import java.util.List;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;
import sc.e;

class f extends j {

    /* renamed from: c  reason: collision with root package name */
    private final Class<?> f14446c;

    /* renamed from: d  reason: collision with root package name */
    private final Class<?> f14447d;

    /* renamed from: e  reason: collision with root package name */
    private final Method f14448e;

    /* renamed from: f  reason: collision with root package name */
    private final Method f14449f;

    /* renamed from: g  reason: collision with root package name */
    private final Method f14450g;

    /* renamed from: h  reason: collision with root package name */
    private final Method f14451h;

    /* renamed from: i  reason: collision with root package name */
    private final b f14452i = b.b();

    static final class a extends sc.c {

        /* renamed from: a  reason: collision with root package name */
        private final Object f14453a;

        /* renamed from: b  reason: collision with root package name */
        private final Method f14454b;

        a(Object obj, Method method) {
            this.f14453a = obj;
            this.f14454b = method;
        }

        public List<Certificate> a(List<Certificate> list, String str) throws SSLPeerUnverifiedException {
            try {
                return (List) this.f14454b.invoke(this.f14453a, new Object[]{(X509Certificate[]) list.toArray(new X509Certificate[list.size()]), "RSA", str});
            } catch (InvocationTargetException e10) {
                SSLPeerUnverifiedException sSLPeerUnverifiedException = new SSLPeerUnverifiedException(e10.getMessage());
                sSLPeerUnverifiedException.initCause(e10);
                throw sSLPeerUnverifiedException;
            } catch (IllegalAccessException e11) {
                throw new AssertionError(e11);
            }
        }

        public boolean equals(Object obj) {
            return obj instanceof a;
        }

        public int hashCode() {
            return 0;
        }
    }

    static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final Method f14455a;

        /* renamed from: b  reason: collision with root package name */
        private final Method f14456b;

        /* renamed from: c  reason: collision with root package name */
        private final Method f14457c;

        b(Method method, Method method2, Method method3) {
            this.f14455a = method;
            this.f14456b = method2;
            this.f14457c = method3;
        }

        static b b() {
            Method method;
            Method method2;
            Method method3;
            try {
                Class<?> cls = Class.forName("dalvik.system.CloseGuard");
                method2 = cls.getMethod("get", new Class[0]);
                method = cls.getMethod(UnityWebViewActivityProxy.IntentActions.OPEN, new Class[]{String.class});
                method3 = cls.getMethod("warnIfOpen", new Class[0]);
            } catch (Exception unused) {
                method2 = null;
                method3 = null;
                method = null;
            }
            return new b(method2, method, method3);
        }

        /* access modifiers changed from: package-private */
        public Object a(String str) {
            Method method = this.f14455a;
            if (method != null) {
                try {
                    Object invoke = method.invoke((Object) null, new Object[0]);
                    this.f14456b.invoke(invoke, new Object[]{str});
                    return invoke;
                } catch (Exception unused) {
                }
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        public boolean c(Object obj) {
            if (obj == null) {
                return false;
            }
            try {
                this.f14457c.invoke(obj, new Object[0]);
                return true;
            } catch (Exception unused) {
                return false;
            }
        }
    }

    static final class c implements e {

        /* renamed from: a  reason: collision with root package name */
        private final X509TrustManager f14458a;

        /* renamed from: b  reason: collision with root package name */
        private final Method f14459b;

        c(X509TrustManager x509TrustManager, Method method) {
            this.f14459b = method;
            this.f14458a = x509TrustManager;
        }

        public X509Certificate a(X509Certificate x509Certificate) {
            try {
                TrustAnchor trustAnchor = (TrustAnchor) this.f14459b.invoke(this.f14458a, new Object[]{x509Certificate});
                if (trustAnchor != null) {
                    return trustAnchor.getTrustedCert();
                }
                return null;
            } catch (IllegalAccessException e10) {
                throw new AssertionError("unable to get issues and signature", e10);
            } catch (InvocationTargetException unused) {
                return null;
            }
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            return this.f14458a.equals(cVar.f14458a) && this.f14459b.equals(cVar.f14459b);
        }

        public int hashCode() {
            return this.f14458a.hashCode() + (this.f14459b.hashCode() * 31);
        }
    }

    f(Class<?> cls, Class<?> cls2, Method method, Method method2, Method method3, Method method4) {
        this.f14446c = cls;
        this.f14447d = cls2;
        this.f14448e = method;
        this.f14449f = method2;
        this.f14450g = method3;
        this.f14451h = method4;
    }

    private boolean v(String str, Class<?> cls, Object obj) throws InvocationTargetException, IllegalAccessException {
        try {
            return ((Boolean) cls.getMethod("isCleartextTrafficPermitted", new Class[0]).invoke(obj, new Object[0])).booleanValue();
        } catch (NoSuchMethodException unused) {
            return super.r(str);
        }
    }

    private boolean w(String str, Class<?> cls, Object obj) throws InvocationTargetException, IllegalAccessException {
        try {
            return ((Boolean) cls.getMethod("isCleartextTrafficPermitted", new Class[]{String.class}).invoke(obj, new Object[]{str})).booleanValue();
        } catch (NoSuchMethodException unused) {
            return v(str, cls, obj);
        }
    }

    public static j x() {
        if (!j.q()) {
            return null;
        }
        try {
            Class<?> cls = Class.forName("com.android.org.conscrypt.SSLParametersImpl");
            Class<?> cls2 = Class.forName("com.android.org.conscrypt.OpenSSLSocketImpl");
            try {
                Method declaredMethod = cls2.getDeclaredMethod("setUseSessionTickets", new Class[]{Boolean.TYPE});
                Method method = cls2.getMethod("setHostname", new Class[]{String.class});
                return new f(cls, cls2, declaredMethod, method, cls2.getMethod("getAlpnSelectedProtocol", new Class[0]), cls2.getMethod("setAlpnProtocols", new Class[]{byte[].class}));
            } catch (NoSuchMethodException unused) {
                throw new IllegalStateException("Expected Android API level 21+ but was " + Build.VERSION.SDK_INT);
            }
        } catch (ClassNotFoundException unused2) {
            return null;
        }
    }

    static int y() {
        try {
            return Build.VERSION.SDK_INT;
        } catch (NoClassDefFoundError unused) {
            return 0;
        }
    }

    public sc.c c(X509TrustManager x509TrustManager) {
        Class<String> cls = String.class;
        try {
            Class<?> cls2 = Class.forName("android.net.http.X509TrustManagerExtensions");
            return new a(cls2.getConstructor(new Class[]{X509TrustManager.class}).newInstance(new Object[]{x509TrustManager}), cls2.getMethod("checkServerTrusted", new Class[]{X509Certificate[].class, cls, cls}));
        } catch (Exception unused) {
            return super.c(x509TrustManager);
        }
    }

    public e d(X509TrustManager x509TrustManager) {
        try {
            Method declaredMethod = x509TrustManager.getClass().getDeclaredMethod("findTrustAnchorByIssuerAndSignature", new Class[]{X509Certificate.class});
            declaredMethod.setAccessible(true);
            return new c(x509TrustManager, declaredMethod);
        } catch (NoSuchMethodException unused) {
            return super.d(x509TrustManager);
        }
    }

    public void g(SSLSocket sSLSocket, String str, List<e0> list) throws IOException {
        if (this.f14447d.isInstance(sSLSocket)) {
            if (str != null) {
                try {
                    this.f14448e.invoke(sSLSocket, new Object[]{Boolean.TRUE});
                    this.f14449f.invoke(sSLSocket, new Object[]{str});
                } catch (IllegalAccessException | InvocationTargetException e10) {
                    throw new AssertionError(e10);
                }
            }
            this.f14451h.invoke(sSLSocket, new Object[]{j.e(list)});
        }
    }

    public void h(Socket socket, InetSocketAddress inetSocketAddress, int i10) throws IOException {
        try {
            socket.connect(inetSocketAddress, i10);
        } catch (AssertionError e10) {
            if (jc.e.A(e10)) {
                throw new IOException(e10);
            }
            throw e10;
        } catch (ClassCastException e11) {
            if (Build.VERSION.SDK_INT == 26) {
                throw new IOException("Exception in connect", e11);
            }
            throw e11;
        }
    }

    public SSLContext n() {
        boolean z10 = true;
        try {
            if (Build.VERSION.SDK_INT >= 22) {
                z10 = false;
            }
        } catch (NoClassDefFoundError unused) {
        }
        if (z10) {
            try {
                return SSLContext.getInstance("TLSv1.2");
            } catch (NoSuchAlgorithmException unused2) {
            }
        }
        try {
            return SSLContext.getInstance("TLS");
        } catch (NoSuchAlgorithmException e10) {
            throw new IllegalStateException("No TLS provider", e10);
        }
    }

    public String o(SSLSocket sSLSocket) {
        if (!this.f14447d.isInstance(sSLSocket)) {
            return null;
        }
        try {
            byte[] bArr = (byte[]) this.f14450g.invoke(sSLSocket, new Object[0]);
            if (bArr != null) {
                return new String(bArr, StandardCharsets.UTF_8);
            }
            return null;
        } catch (IllegalAccessException | InvocationTargetException e10) {
            throw new AssertionError(e10);
        }
    }

    public Object p(String str) {
        return this.f14452i.a(str);
    }

    public boolean r(String str) {
        try {
            Class<?> cls = Class.forName("android.security.NetworkSecurityPolicy");
            return w(str, cls, cls.getMethod("getInstance", new Class[0]).invoke((Object) null, new Object[0]));
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return super.r(str);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e10) {
            throw new AssertionError("unable to determine cleartext support", e10);
        }
    }

    public void t(int i10, String str, Throwable th) {
        int min;
        int i11 = 5;
        if (i10 != 5) {
            i11 = 3;
        }
        if (th != null) {
            str = str + 10 + Log.getStackTraceString(th);
        }
        int length = str.length();
        int i12 = 0;
        while (i12 < length) {
            int indexOf = str.indexOf(10, i12);
            if (indexOf == -1) {
                indexOf = length;
            }
            while (true) {
                min = Math.min(indexOf, i12 + 4000);
                Log.println(i11, "OkHttp", str.substring(i12, min));
                if (min >= indexOf) {
                    break;
                }
                i12 = min;
            }
            i12 = min + 1;
        }
    }

    public void u(String str, Object obj) {
        if (!this.f14452i.c(obj)) {
            t(5, str, (Throwable) null);
        }
    }
}
