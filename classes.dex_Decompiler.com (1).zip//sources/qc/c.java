package qc;

public final /* synthetic */ class c {
}
