package com.twitter.sdk.android.core;

public class x extends RuntimeException {
    public x(String str) {
        super(str);
    }

    public x(String str, Throwable th) {
        super(str, th);
    }
}
