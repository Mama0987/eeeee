package com.twitter.sdk.android.core.models;

import w9.c;

public class Image {
    @c("h")

    /* renamed from: h  reason: collision with root package name */
    public final int f9701h;
    @c("image_type")
    public final String imageType;
    @c("w")

    /* renamed from: w  reason: collision with root package name */
    public final int f9702w;

    public Image(int i10, int i11, String str) {
        this.f9702w = i10;
        this.f9701h = i11;
        this.imageType = str;
    }
}
