package com.twitter.sdk.android.core;

import com.google.gson.Gson;
import com.twitter.sdk.android.core.models.BindingValues;
import com.twitter.sdk.android.core.models.BindingValuesAdapter;
import com.twitter.sdk.android.core.models.SafeListAdapter;
import com.twitter.sdk.android.core.models.SafeMapAdapter;
import com.twitter.sdk.android.core.services.AccountService;
import com.twitter.sdk.android.core.services.MediaService;
import com.twitter.sdk.android.core.services.StatusesService;
import ic.d0;
import java.util.concurrent.ConcurrentHashMap;
import ka.g;
import la.e;
import wc.y;
import xc.a;

public class m {

    /* renamed from: a  reason: collision with root package name */
    final ConcurrentHashMap<Class, Object> f9699a;

    /* renamed from: b  reason: collision with root package name */
    final y f9700b;

    public m() {
        this(e.d(w.g().e()), new g());
    }

    public m(z zVar) {
        this(e.e(zVar, w.g().d()), new g());
    }

    m(d0 d0Var, g gVar) {
        this.f9699a = a();
        this.f9700b = c(d0Var, gVar);
    }

    private ConcurrentHashMap a() {
        return new ConcurrentHashMap();
    }

    private Gson b() {
        return new com.google.gson.e().d(new SafeListAdapter()).d(new SafeMapAdapter()).c(BindingValues.class, new BindingValuesAdapter()).b();
    }

    private y c(d0 d0Var, g gVar) {
        return new y.b().f(d0Var).c(gVar.c()).a(a.g(b())).d();
    }

    public AccountService d() {
        return (AccountService) f(AccountService.class);
    }

    public MediaService e() {
        return (MediaService) f(MediaService.class);
    }

    /* access modifiers changed from: protected */
    public <T> T f(Class<T> cls) {
        if (!this.f9699a.contains(cls)) {
            this.f9699a.putIfAbsent(cls, this.f9700b.b(cls));
        }
        return this.f9699a.get(cls);
    }

    public StatusesService g() {
        return (StatusesService) f(StatusesService.class);
    }
}
