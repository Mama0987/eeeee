package com.twitter.sdk.android.core.models;

import w9.c;

public class HashtagEntity extends Entity {
    @c("text")
    public final String text;

    public HashtagEntity(String str, int i10, int i11) {
        super(i10, i11);
        this.text = str;
    }

    public /* bridge */ /* synthetic */ int getEnd() {
        return super.getEnd();
    }

    public /* bridge */ /* synthetic */ int getStart() {
        return super.getStart();
    }
}
