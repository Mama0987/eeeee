package com.twitter.sdk.android.core;

import w9.c;

public abstract class a {
    @c("created_at")

    /* renamed from: a  reason: collision with root package name */
    protected final long f9631a;

    public a() {
        this(System.currentTimeMillis());
    }

    protected a(long j10) {
        this.f9631a = j10;
    }
}
