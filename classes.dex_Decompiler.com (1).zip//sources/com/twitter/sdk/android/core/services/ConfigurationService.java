package com.twitter.sdk.android.core.services;

import com.twitter.sdk.android.core.models.Configuration;
import wc.b;
import yc.f;

public interface ConfigurationService {
    @f("/1.1/help/configuration.json")
    b<Configuration> configuration();
}
