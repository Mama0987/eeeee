package com.twitter.sdk.android.core.internal.oauth;

import w9.c;

class b {
    @c("guest_token")

    /* renamed from: a  reason: collision with root package name */
    public final String f9671a;
}
