package com.twitter.sdk.android.core;

public class y {

    /* renamed from: a  reason: collision with root package name */
    private int f9733a;

    /* renamed from: b  reason: collision with root package name */
    private int f9734b;

    /* renamed from: c  reason: collision with root package name */
    private long f9735c;

    y(ic.y yVar) {
        if (yVar != null) {
            for (int i10 = 0; i10 < yVar.i(); i10++) {
                if ("x-rate-limit-limit".equals(yVar.e(i10))) {
                    this.f9733a = Integer.parseInt(yVar.j(i10));
                } else if ("x-rate-limit-remaining".equals(yVar.e(i10))) {
                    this.f9734b = Integer.parseInt(yVar.j(i10));
                } else if ("x-rate-limit-reset".equals(yVar.e(i10))) {
                    this.f9735c = Long.parseLong(yVar.j(i10));
                }
            }
            return;
        }
        throw new IllegalArgumentException("headers must not be null");
    }
}
