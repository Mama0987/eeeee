package com.twitter.sdk.android.core.models;

import android.text.TextUtils;
import androidx.annotation.Keep;
import java.util.Collections;
import java.util.List;
import w9.c;

@Keep
public class TweetContent {
    @c("media")
    public final AttachedMedia media;
    @c("text")
    public final String text;

    @Keep
    public static class AttachedMedia {
        @c("media_ids")
        public final List<String> mediaIds;
        @c("tagged_user_ids")
        public final List<String> taggedUserIds;

        public AttachedMedia(List<String> list, List<String> list2) {
            this.mediaIds = list;
            this.taggedUserIds = list2;
        }
    }

    public TweetContent(String str, String str2) {
        this.text = str;
        if (TextUtils.isEmpty(str2)) {
            this.media = null;
        } else {
            this.media = new AttachedMedia(Collections.singletonList(str2), (List<String>) null);
        }
    }
}
