package com.twitter.sdk.android.core.models;

import java.util.List;
import w9.c;

public class UserEntities {
    @c("description")
    public final UrlEntities description;
    @c("url")
    public final UrlEntities url;

    public static class UrlEntities {
        @c("urls")
        public final List<UrlEntity> urls;

        private UrlEntities() {
            this((List<UrlEntity>) null);
        }

        public UrlEntities(List<UrlEntity> list) {
            this.urls = ModelUtils.getSafeList(list);
        }
    }

    public UserEntities(UrlEntities urlEntities, UrlEntities urlEntities2) {
        this.url = urlEntities;
        this.description = urlEntities2;
    }
}
