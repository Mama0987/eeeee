package com.twitter.sdk.android.core.models;

import w9.c;

public class ImageValue {
    @c("alt")
    public final String alt;
    @c("height")
    public final int height;
    @c("url")
    public final String url;
    @c("width")
    public final int width;

    public ImageValue(int i10, int i11, String str, String str2) {
        this.height = i10;
        this.width = i11;
        this.url = str;
        this.alt = str2;
    }
}
