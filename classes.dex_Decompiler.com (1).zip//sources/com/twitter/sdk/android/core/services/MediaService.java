package com.twitter.sdk.android.core.services;

import com.twitter.sdk.android.core.models.Media;
import ic.h0;
import wc.b;
import yc.c;
import yc.e;
import yc.f;
import yc.l;
import yc.o;
import yc.q;
import yc.t;

public interface MediaService {
    @l
    @o("https://upload.twitter.com/1.1/media/upload.json")
    b<Void> append(@q("command") h0 h0Var, @q("media_id") h0 h0Var2, @q("media") h0 h0Var3, @q("media_data") h0 h0Var4, @q("segment_index") h0 h0Var5);

    @f("https://upload.twitter.com/1.1/media/upload.json")
    b<Media> checkStatus(@t("command") String str, @t("media_id") long j10);

    @e
    @o("https://upload.twitter.com/1.1/media/upload.json")
    b<Media> finalize(@c("command") String str, @c("media_id") long j10);

    @e
    @o("https://upload.twitter.com/1.1/media/upload.json")
    b<Media> init(@c("command") String str, @c("media_type") String str2, @c("total_bytes") long j10, @c("media_category") String str3, @c("additional_owners") h0 h0Var);

    @l
    @o("https://upload.twitter.com/1.1/media/upload.json")
    b<Media> upload(@q("media") h0 h0Var, @q("media_data") h0 h0Var2, @q("additional_owners") h0 h0Var3);
}
