package com.twitter.sdk.android.core;

public interface g {
    void a(String str, String str2);

    void b(String str, String str2, Throwable th);

    void c(String str, String str2);
}
