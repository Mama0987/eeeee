package com.twitter.sdk.android.core.models;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.a;
import com.google.gson.w;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import z9.c;

public class SafeListAdapter implements w {
    public <T> TypeAdapter<T> create(Gson gson, final a<T> aVar) {
        final TypeAdapter<T> q10 = gson.q(this, aVar);
        return new TypeAdapter<T>() {
            public T read(z9.a aVar) throws IOException {
                T read = q10.read(aVar);
                return List.class.isAssignableFrom(aVar.getRawType()) ? read == null ? Collections.EMPTY_LIST : Collections.unmodifiableList((List) read) : read;
            }

            public void write(c cVar, T t10) throws IOException {
                q10.write(cVar, t10);
            }
        };
    }
}
