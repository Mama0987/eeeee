package com.twitter.sdk.android.core.models;

import java.io.Serializable;
import w9.c;

public class MediaEntity extends UrlEntity {
    @c("ext_alt_text")
    public final String altText;
    @c("id")
    public final long id;
    @c("id_str")
    public final String idStr;
    @c("media_url")
    public final String mediaUrl;
    @c("media_url_https")
    public final String mediaUrlHttps;
    @c("sizes")
    public final Sizes sizes;
    @c("source_status_id")
    public final long sourceStatusId;
    @c("source_status_id_str")
    public final String sourceStatusIdStr;
    @c("type")
    public final String type;
    @c("video_info")
    public final VideoInfo videoInfo;

    public static class Size implements Serializable {
        @c("h")

        /* renamed from: h  reason: collision with root package name */
        public final int f9703h;
        @c("resize")
        public final String resize;
        @c("w")

        /* renamed from: w  reason: collision with root package name */
        public final int f9704w;

        public Size(int i10, int i11, String str) {
            this.f9704w = i10;
            this.f9703h = i11;
            this.resize = str;
        }
    }

    public static class Sizes implements Serializable {
        @c("large")
        public final Size large;
        @c("medium")
        public final Size medium;
        @c("small")
        public final Size small;
        @c("thumb")
        public final Size thumb;

        public Sizes(Size size, Size size2, Size size3, Size size4) {
            this.thumb = size;
            this.small = size2;
            this.medium = size3;
            this.large = size4;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MediaEntity(String str, String str2, String str3, int i10, int i11, long j10, String str4, String str5, String str6, Sizes sizes2, long j11, String str7, String str8, VideoInfo videoInfo2, String str9) {
        super(str, str2, str3, i10, i11);
        this.id = j10;
        this.idStr = str4;
        this.mediaUrl = str5;
        this.mediaUrlHttps = str6;
        this.sizes = sizes2;
        this.sourceStatusId = j11;
        this.sourceStatusIdStr = str7;
        this.type = str8;
        this.videoInfo = videoInfo2;
        this.altText = str9;
    }
}
