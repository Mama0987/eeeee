package com.twitter.sdk.android.core.internal.oauth;

import java.util.Objects;
import w9.c;

public class a extends e {
    @c("guest_token")

    /* renamed from: d  reason: collision with root package name */
    private final String f9670d;

    public a(String str, String str2, String str3) {
        super(str, str2);
        this.f9670d = str3;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass() || !super.equals(obj)) {
            return false;
        }
        return Objects.equals(this.f9670d, ((a) obj).f9670d);
    }

    public int hashCode() {
        int hashCode = super.hashCode() * 31;
        String str = this.f9670d;
        return hashCode + (str != null ? str.hashCode() : 0);
    }

    public String k() {
        return this.f9670d;
    }

    public boolean l() {
        return System.currentTimeMillis() >= this.f9631a + 10800000;
    }
}
