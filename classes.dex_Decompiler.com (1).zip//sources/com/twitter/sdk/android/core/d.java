package com.twitter.sdk.android.core;

import android.text.TextUtils;
import com.google.gson.Gson;
import com.google.gson.e;

public class d extends j<com.twitter.sdk.android.core.internal.oauth.a> {

    public static class a implements ma.d<d> {

        /* renamed from: a  reason: collision with root package name */
        private final Gson f9633a = new e().c(com.twitter.sdk.android.core.internal.oauth.a.class, new AuthTokenAdapter()).b();

        /* renamed from: c */
        public d a(String str) {
            if (TextUtils.isEmpty(str)) {
                return null;
            }
            try {
                return (d) this.f9633a.l(str, d.class);
            } catch (Exception e10) {
                g g10 = l.g();
                g10.c("Twitter", "Failed to deserialize session " + e10.getMessage());
                return null;
            }
        }

        /* renamed from: d */
        public String b(d dVar) {
            if (dVar == null || dVar.a() == null) {
                return "";
            }
            try {
                return this.f9633a.v(dVar);
            } catch (Exception e10) {
                g g10 = l.g();
                g10.c("Twitter", "Failed to serialize session " + e10.getMessage());
                return "";
            }
        }
    }

    public d(com.twitter.sdk.android.core.internal.oauth.a aVar) {
        super(aVar, 0);
    }
}
