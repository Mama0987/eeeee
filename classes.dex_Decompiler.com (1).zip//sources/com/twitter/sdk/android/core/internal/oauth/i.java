package com.twitter.sdk.android.core.internal.oauth;

import androidx.annotation.NonNull;
import com.twitter.sdk.android.core.w;
import ic.a0;
import ic.d0;
import ic.i0;
import java.io.IOException;
import ka.g;
import la.e;
import tc.a;
import wc.y;

abstract class i {

    /* renamed from: a  reason: collision with root package name */
    private final w f9684a;

    /* renamed from: b  reason: collision with root package name */
    private final g f9685b;

    /* renamed from: c  reason: collision with root package name */
    private final String f9686c;

    /* renamed from: d  reason: collision with root package name */
    private final y f9687d;

    class a implements a0 {
        a() {
        }

        @NonNull
        public i0 intercept(@NonNull a0.a aVar) throws IOException {
            return aVar.f(aVar.d().h().d("User-Agent", i.this.d()).b());
        }
    }

    i(w wVar, g gVar) {
        this.f9684a = wVar;
        this.f9685b = gVar;
        this.f9686c = g.b("TwitterAndroidSDK", wVar.i());
        tc.a aVar = new tc.a();
        aVar.d(a.C0286a.BODY);
        this.f9687d = new y.b().c(a().c()).f(new d0.b().a(new a()).a(aVar).g(e.c()).d()).a(xc.a.f()).d();
    }

    /* access modifiers changed from: protected */
    public g a() {
        return this.f9685b;
    }

    /* access modifiers changed from: protected */
    public y b() {
        return this.f9687d;
    }

    /* access modifiers changed from: protected */
    public w c() {
        return this.f9684a;
    }

    /* access modifiers changed from: protected */
    public String d() {
        return this.f9686c;
    }
}
