package com.twitter.sdk.android.core.models;

import w9.c;

public class UserValue {
    @c("id_str")
    public final String idStr;

    public UserValue(String str) {
        this.idStr = str;
    }
}
