package com.twitter.sdk.android.core.internal.oauth;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Objects;
import w9.c;

public class e extends com.twitter.sdk.android.core.a implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new a();
    @c("token_type")

    /* renamed from: b  reason: collision with root package name */
    private final String f9679b;
    @c("access_token")

    /* renamed from: c  reason: collision with root package name */
    private final String f9680c;

    class a implements Parcelable.Creator<e> {
        a() {
        }

        /* renamed from: a */
        public e createFromParcel(Parcel parcel) {
            return new e(parcel);
        }

        /* renamed from: b */
        public e[] newArray(int i10) {
            return new e[i10];
        }
    }

    private e(Parcel parcel) {
        this.f9679b = parcel.readString();
        this.f9680c = parcel.readString();
    }

    public e(String str, String str2) {
        this.f9679b = str;
        this.f9680c = str2;
    }

    public String a() {
        return this.f9680c;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        e eVar = (e) obj;
        if (!Objects.equals(this.f9680c, eVar.f9680c)) {
            return false;
        }
        return Objects.equals(this.f9679b, eVar.f9679b);
    }

    public int hashCode() {
        String str = this.f9679b;
        int i10 = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.f9680c;
        if (str2 != null) {
            i10 = str2.hashCode();
        }
        return hashCode + i10;
    }

    public String j() {
        return this.f9679b;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f9679b);
        parcel.writeString(this.f9680c);
    }
}
