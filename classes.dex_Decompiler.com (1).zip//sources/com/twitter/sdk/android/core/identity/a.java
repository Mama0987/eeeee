package com.twitter.sdk.android.core.identity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import com.twitter.sdk.android.core.i;
import com.twitter.sdk.android.core.identity.c;
import com.twitter.sdk.android.core.internal.oauth.OAuth1aService;
import com.twitter.sdk.android.core.internal.oauth.g;
import com.twitter.sdk.android.core.l;
import com.twitter.sdk.android.core.o;
import com.twitter.sdk.android.core.q;
import com.twitter.sdk.android.core.r;
import com.twitter.sdk.android.core.x;

class a implements c.a {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final c f9650a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public r f9651b;

    /* renamed from: c  reason: collision with root package name */
    private final ProgressBar f9652c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final WebView f9653d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public final o f9654e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public final OAuth1aService f9655f;

    /* renamed from: com.twitter.sdk.android.core.identity.a$a  reason: collision with other inner class name */
    class C0120a extends com.twitter.sdk.android.core.b<g> {
        C0120a() {
        }

        public void c(x xVar) {
            l.g().b("Twitter", "Failed to get request token", xVar);
            a.this.l(1, new q("Failed to get request token"));
        }

        public void d(i<g> iVar) {
            a.this.f9651b = ((g) iVar.f9646a).f9681a;
            String g10 = a.this.f9655f.g(a.this.f9651b);
            l.g().c("Twitter", "Redirecting user to web view to complete authorization flow");
            a aVar = a.this;
            aVar.q(aVar.f9653d, new c(a.this.f9655f.e(a.this.f9654e), a.this), g10, new b());
        }
    }

    class b extends com.twitter.sdk.android.core.b<g> {
        b() {
        }

        public void c(x xVar) {
            l.g().b("Twitter", "Failed to get access token", xVar);
            a.this.l(1, new q("Failed to get access token"));
        }

        public void d(i<g> iVar) {
            Intent intent = new Intent();
            g gVar = (g) iVar.f9646a;
            intent.putExtra("screen_name", gVar.f9682b);
            intent.putExtra("user_id", gVar.f9683c);
            intent.putExtra("tk", gVar.f9681a.f9711b);
            intent.putExtra("ts", gVar.f9681a.f9712c);
            a.this.f9650a.a(-1, intent);
        }
    }

    interface c {
        void a(int i10, Intent intent);
    }

    a(ProgressBar progressBar, WebView webView, o oVar, OAuth1aService oAuth1aService, c cVar) {
        this.f9652c = progressBar;
        this.f9653d = webView;
        this.f9654e = oVar;
        this.f9655f = oAuth1aService;
        this.f9650a = cVar;
    }

    private void j() {
        this.f9652c.setVisibility(8);
    }

    private void k() {
        this.f9653d.stopLoading();
        j();
    }

    private void m(d dVar) {
        l.g().b("Twitter", "OAuth web view completed with an error", dVar);
        l(1, new q("OAuth web view completed with an error"));
    }

    private void n(Bundle bundle) {
        String string;
        l.g().c("Twitter", "OAuth web view completed successfully");
        if (bundle == null || (string = bundle.getString("oauth_verifier")) == null) {
            com.twitter.sdk.android.core.g g10 = l.g();
            g10.b("Twitter", "Failed to get authorization, bundle incomplete " + bundle, (Throwable) null);
            l(1, new q("Failed to get authorization, bundle incomplete"));
            return;
        }
        l.g().c("Twitter", "Converting the request token to an access token.");
        this.f9655f.k(o(), this.f9651b, string);
    }

    public void a(d dVar) {
        m(dVar);
        k();
    }

    public void b(WebView webView, String str) {
        j();
        webView.setVisibility(0);
    }

    public void c(Bundle bundle) {
        n(bundle);
        k();
    }

    /* access modifiers changed from: protected */
    public void l(int i10, q qVar) {
        Intent intent = new Intent();
        intent.putExtra("auth_error", qVar);
        this.f9650a.a(i10, intent);
    }

    /* access modifiers changed from: package-private */
    public com.twitter.sdk.android.core.b<g> o() {
        return new b();
    }

    /* access modifiers changed from: package-private */
    public com.twitter.sdk.android.core.b<g> p() {
        return new C0120a();
    }

    /* access modifiers changed from: package-private */
    public void q(WebView webView, WebViewClient webViewClient, String str, WebChromeClient webChromeClient) {
        WebSettings settings = webView.getSettings();
        settings.setAllowFileAccess(false);
        settings.setJavaScriptEnabled(true);
        settings.setSaveFormData(false);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setWebViewClient(webViewClient);
        webView.loadUrl(str);
        webView.setVisibility(4);
        webView.setWebChromeClient(webChromeClient);
    }

    /* access modifiers changed from: package-private */
    public void r() {
        l.g().c("Twitter", "Obtaining request token to start the sign in flow");
        this.f9655f.l(p());
    }
}
