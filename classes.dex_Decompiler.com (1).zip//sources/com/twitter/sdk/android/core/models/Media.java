package com.twitter.sdk.android.core.models;

import androidx.annotation.Keep;
import w9.c;

@Keep
public class Media {
    @c("expires_after_secs")
    public final long expiresAfterSecs;
    @c("image")
    public final Image image;
    @c("media_id")
    public final long mediaId;
    @c("media_id_string")
    public final String mediaIdString;
    @c("processing_info")
    public final TweetProcessingInfo processingInfo;
    @c("size")
    public final long size;
    @c("video")
    public final TweetVideo video;

    public Media(long j10, String str, long j11, long j12, TweetProcessingInfo tweetProcessingInfo, Image image2, TweetVideo tweetVideo) {
        this.mediaId = j10;
        this.mediaIdString = str;
        this.size = j11;
        this.expiresAfterSecs = j12;
        this.processingInfo = tweetProcessingInfo;
        this.image = image2;
        this.video = tweetVideo;
    }
}
