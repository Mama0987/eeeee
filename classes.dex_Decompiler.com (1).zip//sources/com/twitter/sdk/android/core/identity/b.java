package com.twitter.sdk.android.core.identity;

import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;

class b extends WebChromeClient {
    b() {
    }

    public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        return true;
    }
}
