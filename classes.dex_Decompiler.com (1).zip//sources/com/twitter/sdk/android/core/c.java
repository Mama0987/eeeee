package com.twitter.sdk.android.core;

import android.util.Log;

public class c implements g {

    /* renamed from: a  reason: collision with root package name */
    private int f9632a;

    public c() {
        this.f9632a = 4;
    }

    public c(int i10) {
        this.f9632a = i10;
    }

    public void a(String str, String str2) {
        f(str, str2, (Throwable) null);
    }

    public void b(String str, String str2, Throwable th) {
        if (e(str, 6)) {
            Log.e(str, str2, th);
        }
    }

    public void c(String str, String str2) {
        d(str, str2, (Throwable) null);
    }

    public void d(String str, String str2, Throwable th) {
        if (e(str, 3)) {
            Log.d(str, str2, th);
        }
    }

    public boolean e(String str, int i10) {
        return this.f9632a <= i10;
    }

    public void f(String str, String str2, Throwable th) {
        if (e(str, 5)) {
            Log.w(str, str2, th);
        }
    }
}
