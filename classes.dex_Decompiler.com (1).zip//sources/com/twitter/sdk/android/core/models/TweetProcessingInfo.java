package com.twitter.sdk.android.core.models;

import w9.c;

public class TweetProcessingInfo {
    @c("check_after_secs")
    public final long checkAfterSecs;
    @c("error")
    public final ApiError error;
    @c("progress_percent")
    public final int progressPercent;
    @c("state")
    public final String state;

    public TweetProcessingInfo(String str, long j10, int i10, ApiError apiError) {
        this.state = str;
        this.checkAfterSecs = j10;
        this.progressPercent = i10;
        this.error = apiError;
    }
}
