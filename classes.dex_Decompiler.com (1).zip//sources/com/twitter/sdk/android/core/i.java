package com.twitter.sdk.android.core;

import wc.x;

public class i<T> {

    /* renamed from: a  reason: collision with root package name */
    public final T f9646a;

    /* renamed from: b  reason: collision with root package name */
    public final x<T> f9647b;

    public i(T t10, x<T> xVar) {
        this.f9646a = t10;
        this.f9647b = xVar;
    }
}
