package com.twitter.sdk.android.core.models;

import com.google.gson.h;
import com.google.gson.i;
import com.google.gson.j;
import com.google.gson.m;
import com.google.gson.n;
import com.google.gson.p;
import com.google.gson.q;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class BindingValuesAdapter implements q<BindingValues>, i<BindingValues> {
    private static final String BOOLEAN_MEMBER = "boolean_value";
    private static final String BOOLEAN_TYPE = "BOOLEAN";
    private static final String IMAGE_TYPE = "IMAGE";
    private static final String IMAGE_VALUE_MEMBER = "image_value";
    private static final String STRING_TYPE = "STRING";
    private static final String TYPE_MEMBER = "type";
    private static final String TYPE_VALUE_MEMBER = "string_value";
    private static final String USER_TYPE = "USER";
    private static final String USER_VALUE_MEMBER = "user_value";

    public BindingValues deserialize(j jVar, Type type, h hVar) throws n {
        if (!jVar.p()) {
            return new BindingValues();
        }
        Set<Map.Entry<String, j>> w10 = jVar.i().w();
        HashMap hashMap = new HashMap(32);
        for (Map.Entry next : w10) {
            hashMap.put((String) next.getKey(), getValue(((j) next.getValue()).i(), hVar));
        }
        return new BindingValues(hashMap);
    }

    /* access modifiers changed from: package-private */
    public Object getValue(m mVar, h hVar) {
        j x10;
        Type type;
        j x11 = mVar.x(TYPE_MEMBER);
        if (x11 == null || !x11.q()) {
            return null;
        }
        String l10 = x11.l();
        l10.hashCode();
        char c10 = 65535;
        switch (l10.hashCode()) {
            case -1838656495:
                if (l10.equals(STRING_TYPE)) {
                    c10 = 0;
                    break;
                }
                break;
            case 2614219:
                if (l10.equals(USER_TYPE)) {
                    c10 = 1;
                    break;
                }
                break;
            case 69775675:
                if (l10.equals(IMAGE_TYPE)) {
                    c10 = 2;
                    break;
                }
                break;
            case 782694408:
                if (l10.equals(BOOLEAN_TYPE)) {
                    c10 = 3;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
                x10 = mVar.x(TYPE_VALUE_MEMBER);
                type = String.class;
                break;
            case 1:
                x10 = mVar.x(USER_VALUE_MEMBER);
                type = UserValue.class;
                break;
            case 2:
                x10 = mVar.x(IMAGE_VALUE_MEMBER);
                type = ImageValue.class;
                break;
            case 3:
                x10 = mVar.x(BOOLEAN_MEMBER);
                type = Boolean.class;
                break;
            default:
                return null;
        }
        return hVar.a(x10, type);
    }

    public j serialize(BindingValues bindingValues, Type type, p pVar) {
        return null;
    }
}
