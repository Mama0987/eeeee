package com.twitter.sdk.android.core.models;

import w9.c;

public class TweetVideo {
    @c("video_type")
    public final String videoType;

    public TweetVideo(String str) {
        this.videoType = str;
    }
}
