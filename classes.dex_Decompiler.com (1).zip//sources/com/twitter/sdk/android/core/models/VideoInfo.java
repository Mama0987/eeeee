package com.twitter.sdk.android.core.models;

import java.io.Serializable;
import java.util.List;
import w9.c;

public class VideoInfo implements Serializable {
    @c("aspect_ratio")
    public final List<Integer> aspectRatio;
    @c("duration_millis")
    public final long durationMillis;
    @c("variants")
    public final List<Variant> variants;

    public static class Variant implements Serializable {
        @c("bitrate")
        public final long bitrate;
        @c("content_type")
        public final String contentType;
        @c("url")
        public final String url;

        public Variant(long j10, String str, String str2) {
            this.bitrate = j10;
            this.contentType = str;
            this.url = str2;
        }
    }

    private VideoInfo() {
        this((List<Integer>) null, 0, (List<Variant>) null);
    }

    public VideoInfo(List<Integer> list, long j10, List<Variant> list2) {
        this.aspectRatio = ModelUtils.getSafeList(list);
        this.durationMillis = j10;
        this.variants = ModelUtils.getSafeList(list2);
    }
}
