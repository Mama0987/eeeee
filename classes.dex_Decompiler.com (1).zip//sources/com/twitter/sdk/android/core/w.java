package com.twitter.sdk.android.core;

import android.annotation.SuppressLint;
import android.content.Context;
import com.twitter.sdk.android.core.d;
import com.twitter.sdk.android.core.internal.oauth.OAuth2Service;
import com.twitter.sdk.android.core.z;
import java.util.concurrent.ConcurrentHashMap;
import ka.d;
import ka.g;
import ka.h;
import ma.b;

public class w {
    @SuppressLint({"StaticFieldLeak"})

    /* renamed from: h  reason: collision with root package name */
    static volatile w f9725h;

    /* renamed from: a  reason: collision with root package name */
    k<z> f9726a;

    /* renamed from: b  reason: collision with root package name */
    k<d> f9727b;

    /* renamed from: c  reason: collision with root package name */
    d<z> f9728c;

    /* renamed from: d  reason: collision with root package name */
    private final o f9729d;

    /* renamed from: e  reason: collision with root package name */
    private final ConcurrentHashMap<j, m> f9730e;

    /* renamed from: f  reason: collision with root package name */
    private volatile m f9731f;

    /* renamed from: g  reason: collision with root package name */
    private volatile e f9732g;

    class a implements Runnable {
        a() {
        }

        public void run() {
            w.f9725h.b();
        }
    }

    w(o oVar) {
        this(oVar, new ConcurrentHashMap(), (m) null);
    }

    w(o oVar, ConcurrentHashMap<j, m> concurrentHashMap, m mVar) {
        this.f9729d = oVar;
        this.f9730e = concurrentHashMap;
        this.f9731f = mVar;
        Context d10 = l.f().d(f());
        this.f9726a = new h(new b(d10, "session_store"), new z.a(), "active_twittersession", "twittersession");
        this.f9727b = new h(new b(d10, "session_store"), new d.a(), "active_guestsession", "guestsession");
        this.f9728c = new ka.d<>(this.f9726a, l.f().e(), new h());
    }

    private synchronized void a() {
        if (this.f9732g == null) {
            this.f9732g = new e(new OAuth2Service(this, new g()), this.f9727b);
        }
    }

    public static w g() {
        if (f9725h == null) {
            synchronized (w.class) {
                if (f9725h == null) {
                    f9725h = new w(l.f().h());
                    l.f().e().execute(new a());
                }
            }
        }
        return f9725h;
    }

    /* access modifiers changed from: package-private */
    public void b() {
        this.f9726a.d();
        this.f9727b.d();
        e();
        this.f9728c.a(l.f().c());
    }

    public m c(z zVar) {
        if (!this.f9730e.containsKey(zVar)) {
            this.f9730e.putIfAbsent(zVar, new m(zVar));
        }
        return this.f9730e.get(zVar);
    }

    public o d() {
        return this.f9729d;
    }

    public e e() {
        if (this.f9732g == null) {
            a();
        }
        return this.f9732g;
    }

    public String f() {
        return "com.twitter.sdk.android:twitter-core";
    }

    public k<z> h() {
        return this.f9726a;
    }

    public String i() {
        return "4.0.19P9";
    }
}
