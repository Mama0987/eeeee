package com.twitter.sdk.android.core;

import android.os.Parcel;
import android.os.Parcelable;

public class o implements Parcelable {
    public static final Parcelable.Creator<o> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    private final String f9709a;

    /* renamed from: b  reason: collision with root package name */
    private final String f9710b;

    class a implements Parcelable.Creator<o> {
        a() {
        }

        /* renamed from: a */
        public o createFromParcel(Parcel parcel) {
            return new o(parcel);
        }

        /* renamed from: b */
        public o[] newArray(int i10) {
            return new o[i10];
        }
    }

    private o(Parcel parcel) {
        this.f9709a = parcel.readString();
        this.f9710b = parcel.readString();
    }

    public o(String str, String str2) {
        if (str == null || str2 == null) {
            throw new IllegalArgumentException("TwitterAuthConfig must not be created with null consumer key or secret.");
        }
        this.f9709a = l(str);
        this.f9710b = l(str2);
    }

    static String l(String str) {
        if (str != null) {
            return str.trim();
        }
        return null;
    }

    public String a() {
        return this.f9709a;
    }

    public int describeContents() {
        return 0;
    }

    public String j() {
        return this.f9710b;
    }

    public int k() {
        return 140;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f9709a);
        parcel.writeString(this.f9710b);
    }
}
