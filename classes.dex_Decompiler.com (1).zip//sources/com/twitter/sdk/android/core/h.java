package com.twitter.sdk.android.core;

import com.twitter.sdk.android.core.j;
import h.b;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import ma.a;
import ma.c;
import ma.d;

public class h<T extends j> implements k<T> {

    /* renamed from: a  reason: collision with root package name */
    private final a f9638a;

    /* renamed from: b  reason: collision with root package name */
    private final d<T> f9639b;

    /* renamed from: c  reason: collision with root package name */
    private final ConcurrentHashMap<Long, T> f9640c;

    /* renamed from: d  reason: collision with root package name */
    private final ConcurrentHashMap<Long, c<T>> f9641d;

    /* renamed from: e  reason: collision with root package name */
    private final c<T> f9642e;

    /* renamed from: f  reason: collision with root package name */
    private final AtomicReference<T> f9643f;

    /* renamed from: g  reason: collision with root package name */
    private final String f9644g;

    /* renamed from: h  reason: collision with root package name */
    private volatile boolean f9645h;

    public h(a aVar, d<T> dVar, String str, String str2) {
        this(aVar, dVar, new ConcurrentHashMap(1), new ConcurrentHashMap(1), new c(aVar, dVar, str), str2);
    }

    h(a aVar, d<T> dVar, ConcurrentHashMap<Long, T> concurrentHashMap, ConcurrentHashMap<Long, c<T>> concurrentHashMap2, c<T> cVar, String str) {
        this.f9645h = true;
        this.f9638a = aVar;
        this.f9639b = dVar;
        this.f9640c = concurrentHashMap;
        this.f9641d = concurrentHashMap2;
        this.f9642e = cVar;
        this.f9643f = new AtomicReference<>();
        this.f9644g = str;
    }

    private void g(long j10, T t10, boolean z10) {
        this.f9640c.put(Long.valueOf(j10), t10);
        c cVar = this.f9641d.get(Long.valueOf(j10));
        if (cVar == null) {
            cVar = new c(this.f9638a, this.f9639b, f(j10));
            this.f9641d.putIfAbsent(Long.valueOf(j10), cVar);
        }
        cVar.c(t10);
        j jVar = (j) this.f9643f.get();
        if (jVar == null || jVar.b() == j10 || z10) {
            synchronized (this) {
                b.a(this.f9643f, jVar, t10);
                this.f9642e.c(t10);
            }
        }
    }

    private void i() {
        j jVar = (j) this.f9642e.b();
        if (jVar != null) {
            g(jVar.b(), jVar, false);
        }
    }

    private synchronized void j() {
        if (this.f9645h) {
            i();
            l();
            this.f9645h = false;
        }
    }

    private void l() {
        j jVar;
        for (Map.Entry next : this.f9638a.get().getAll().entrySet()) {
            if (h((String) next.getKey()) && (jVar = (j) this.f9639b.a((String) next.getValue())) != null) {
                g(jVar.b(), jVar, false);
            }
        }
    }

    public void a() {
        k();
        if (this.f9643f.get() != null) {
            c(((j) this.f9643f.get()).b());
        }
    }

    public Map<Long, T> b() {
        k();
        return Collections.unmodifiableMap(this.f9640c);
    }

    public void c(long j10) {
        k();
        if (this.f9643f.get() != null && ((j) this.f9643f.get()).b() == j10) {
            synchronized (this) {
                this.f9643f.set((Object) null);
                this.f9642e.a();
            }
        }
        this.f9640c.remove(Long.valueOf(j10));
        c remove = this.f9641d.remove(Long.valueOf(j10));
        if (remove != null) {
            remove.a();
        }
    }

    public T d() {
        k();
        return (j) this.f9643f.get();
    }

    public void e(T t10) {
        if (t10 != null) {
            k();
            g(t10.b(), t10, true);
            return;
        }
        throw new IllegalArgumentException("Session must not be null!");
    }

    /* access modifiers changed from: package-private */
    public String f(long j10) {
        return this.f9644g + "_" + j10;
    }

    /* access modifiers changed from: package-private */
    public boolean h(String str) {
        return str.startsWith(this.f9644g);
    }

    /* access modifiers changed from: package-private */
    public void k() {
        if (this.f9645h) {
            j();
        }
    }
}
