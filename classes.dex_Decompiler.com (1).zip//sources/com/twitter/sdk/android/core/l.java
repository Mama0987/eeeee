package com.twitter.sdk.android.core;

import android.content.Context;
import java.io.File;
import java.util.concurrent.ExecutorService;
import ka.a;
import ka.b;
import ka.c;

public class l {

    /* renamed from: g  reason: collision with root package name */
    static final g f9691g = new c();

    /* renamed from: h  reason: collision with root package name */
    private static volatile l f9692h;

    /* renamed from: a  reason: collision with root package name */
    private final Context f9693a;

    /* renamed from: b  reason: collision with root package name */
    private final ExecutorService f9694b;

    /* renamed from: c  reason: collision with root package name */
    private final o f9695c;

    /* renamed from: d  reason: collision with root package name */
    private final a f9696d;

    /* renamed from: e  reason: collision with root package name */
    private final g f9697e;

    /* renamed from: f  reason: collision with root package name */
    private final boolean f9698f;

    private l(t tVar) {
        Context applicationContext = tVar.f9713a.getApplicationContext();
        this.f9693a = applicationContext;
        this.f9696d = new a(applicationContext);
        o oVar = tVar.f9715c;
        if (oVar == null) {
            this.f9695c = new o(b.c(applicationContext, "com.twitter.sdk.android.CONSUMER_KEY", ""), b.c(applicationContext, "com.twitter.sdk.android.CONSUMER_SECRET", ""));
        } else {
            this.f9695c = oVar;
        }
        ExecutorService executorService = tVar.f9716d;
        this.f9694b = executorService == null ? c.c("twitter-worker") : executorService;
        g gVar = tVar.f9714b;
        this.f9697e = gVar == null ? f9691g : gVar;
        Boolean bool = tVar.f9717e;
        this.f9698f = bool == null ? false : bool.booleanValue();
    }

    static void a() {
        if (f9692h == null) {
            throw new IllegalStateException("Must initialize Twitter before using getInstance()");
        }
    }

    static synchronized l b(t tVar) {
        l lVar;
        synchronized (l.class) {
            if (f9692h == null) {
                f9692h = new l(tVar);
            }
            lVar = f9692h;
        }
        return lVar;
    }

    public static l f() {
        a();
        return f9692h;
    }

    public static g g() {
        return f9692h == null ? f9691g : f9692h.f9697e;
    }

    public static void i(t tVar) {
        b(tVar);
    }

    public a c() {
        return this.f9696d;
    }

    public Context d(String str) {
        Context context = this.f9693a;
        return new v(context, str, ".TwitterKit" + File.separator + str);
    }

    public ExecutorService e() {
        return this.f9694b;
    }

    public o h() {
        return this.f9695c;
    }
}
