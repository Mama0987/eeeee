package com.twitter.sdk.android.core.models;

import java.util.List;
import w9.c;

public class ApiErrors {
    @c("errors")
    public final List<ApiError> errors;

    private ApiErrors() {
        this((List<ApiError>) null);
    }

    public ApiErrors(List<ApiError> list) {
        this.errors = ModelUtils.getSafeList(list);
    }
}
