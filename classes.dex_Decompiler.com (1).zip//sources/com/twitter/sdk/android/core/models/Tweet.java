package com.twitter.sdk.android.core.models;

import java.util.List;
import w9.c;

public class Tweet implements Identifiable {
    public static final long INVALID_ID = -1;
    @c("card")
    public final Card card;
    @c("coordinates")
    public final Coordinates coordinates;
    @c("created_at")
    public final String createdAt;
    @c("current_user_retweet")
    public final Object currentUserRetweet;
    @c("display_text_range")
    public final List<Integer> displayTextRange;
    @c("entities")
    public final TweetEntities entities;
    @c("extended_entities")
    public final TweetEntities extendedEntities;
    @c("favorite_count")
    public final int favoriteCount;
    @c("favorited")
    public final boolean favorited;
    @c("filter_level")
    public final String filterLevel;
    @c("id")
    public final long id;
    @c("id_str")
    public final String idStr;
    @c("in_reply_to_screen_name")
    public final String inReplyToScreenName;
    @c("in_reply_to_status_id")
    public final long inReplyToStatusId;
    @c("in_reply_to_status_id_str")
    public final String inReplyToStatusIdStr;
    @c("in_reply_to_user_id")
    public final long inReplyToUserId;
    @c("in_reply_to_user_id_str")
    public final String inReplyToUserIdStr;
    @c("lang")
    public final String lang;
    @c("place")
    public final Place place;
    @c("possibly_sensitive")
    public final boolean possiblySensitive;
    @c("quoted_status")
    public final Tweet quotedStatus;
    @c("quoted_status_id")
    public final long quotedStatusId;
    @c("quoted_status_id_str")
    public final String quotedStatusIdStr;
    @c("retweet_count")
    public final int retweetCount;
    @c("retweeted")
    public final boolean retweeted;
    @c("retweeted_status")
    public final Tweet retweetedStatus;
    @c("scopes")
    public final Object scopes;
    @c("source")
    public final String source;
    @c(alternate = {"full_text"}, value = "text")
    public final String text;
    @c("truncated")
    public final boolean truncated;
    @c("user")
    public final User user;
    @c("withheld_copyright")
    public final boolean withheldCopyright;
    @c("withheld_in_countries")
    public final List<String> withheldInCountries;
    @c("withheld_scope")
    public final String withheldScope;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private Tweet() {
        /*
            r39 = this;
            r0 = r39
            r1 = 0
            r2 = 0
            r3 = 0
            com.twitter.sdk.android.core.models.TweetEntities r5 = com.twitter.sdk.android.core.models.TweetEntities.EMPTY
            r4 = r5
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            java.lang.String r11 = "0"
            r12 = 0
            r13 = 0
            java.lang.String r15 = "0"
            r16 = 0
            java.lang.String r18 = "0"
            r19 = 0
            r20 = 0
            r21 = 0
            r22 = 0
            r23 = 0
            java.lang.String r25 = "0"
            r26 = 0
            r27 = 0
            r28 = 0
            r29 = 0
            r30 = 0
            r31 = 0
            r32 = 0
            r33 = 0
            r34 = 0
            r35 = 0
            r36 = 0
            r37 = 0
            r38 = 0
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r11, r12, r13, r15, r16, r18, r19, r20, r21, r22, r23, r25, r26, r27, r28, r29, r30, r31, r32, r33, r34, r35, r36, r37, r38)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.twitter.sdk.android.core.models.Tweet.<init>():void");
    }

    public Tweet(Coordinates coordinates2, String str, Object obj, TweetEntities tweetEntities, TweetEntities tweetEntities2, int i10, boolean z10, String str2, long j10, String str3, String str4, long j11, String str5, long j12, String str6, String str7, Place place2, boolean z11, Object obj2, long j13, String str8, Tweet tweet, int i11, boolean z12, Tweet tweet2, String str9, String str10, List<Integer> list, boolean z13, User user2, boolean z14, List<String> list2, String str11, Card card2) {
        this.coordinates = coordinates2;
        this.createdAt = str;
        this.currentUserRetweet = obj;
        this.entities = tweetEntities == null ? TweetEntities.EMPTY : tweetEntities;
        this.extendedEntities = tweetEntities2 == null ? TweetEntities.EMPTY : tweetEntities2;
        this.favoriteCount = i10;
        this.favorited = z10;
        this.filterLevel = str2;
        this.id = j10;
        this.idStr = str3;
        this.inReplyToScreenName = str4;
        this.inReplyToStatusId = j11;
        this.inReplyToStatusIdStr = str5;
        this.inReplyToUserId = j12;
        this.inReplyToUserIdStr = str6;
        this.lang = str7;
        this.place = place2;
        this.possiblySensitive = z11;
        this.scopes = obj2;
        this.quotedStatusId = j13;
        this.quotedStatusIdStr = str8;
        this.quotedStatus = tweet;
        this.retweetCount = i11;
        this.retweeted = z12;
        this.retweetedStatus = tweet2;
        this.source = str9;
        this.text = str10;
        this.displayTextRange = ModelUtils.getSafeList(list);
        this.truncated = z13;
        this.user = user2;
        this.withheldCopyright = z14;
        this.withheldInCountries = ModelUtils.getSafeList(list2);
        this.withheldScope = str11;
        this.card = card2;
    }

    public boolean equals(Object obj) {
        return obj != null && (obj instanceof Tweet) && this.id == ((Tweet) obj).id;
    }

    public long getId() {
        return this.id;
    }

    public int hashCode() {
        return (int) this.id;
    }
}
