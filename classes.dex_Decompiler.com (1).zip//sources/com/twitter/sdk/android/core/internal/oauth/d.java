package com.twitter.sdk.android.core.internal.oauth;

import com.twitter.sdk.android.core.l;
import com.twitter.sdk.android.core.o;
import com.twitter.sdk.android.core.r;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import la.f;

class d {

    /* renamed from: g  reason: collision with root package name */
    private static final SecureRandom f9672g = new SecureRandom();

    /* renamed from: a  reason: collision with root package name */
    private final o f9673a;

    /* renamed from: b  reason: collision with root package name */
    private final r f9674b;

    /* renamed from: c  reason: collision with root package name */
    private final String f9675c;

    /* renamed from: d  reason: collision with root package name */
    private final String f9676d;

    /* renamed from: e  reason: collision with root package name */
    private final String f9677e;

    /* renamed from: f  reason: collision with root package name */
    private final Map<String, String> f9678f;

    d(o oVar, r rVar, String str, String str2, String str3, Map<String, String> map) {
        this.f9673a = oVar;
        this.f9674b = rVar;
        this.f9675c = str;
        this.f9676d = str2;
        this.f9677e = str3;
        this.f9678f = map;
    }

    private void a(StringBuilder sb2, String str, String str2) {
        if (str2 != null) {
            sb2.append(' ');
            sb2.append(f.c(str));
            sb2.append("=\"");
            sb2.append(f.c(str2));
            sb2.append("\",");
        }
    }

    private String f(TreeMap<String, String> treeMap) {
        StringBuilder sb2 = new StringBuilder();
        int size = treeMap.size();
        int i10 = 0;
        for (Map.Entry next : treeMap.entrySet()) {
            sb2.append(f.c(f.c((String) next.getKey())));
            sb2.append("%3D");
            sb2.append(f.c(f.c((String) next.getValue())));
            i10++;
            if (i10 < size) {
                sb2.append("%26");
            }
        }
        return sb2.toString();
    }

    private String g() {
        return System.nanoTime() + String.valueOf(Math.abs(f9672g.nextLong()));
    }

    private String h() {
        r rVar = this.f9674b;
        String str = rVar != null ? rVar.f9712c : null;
        return f.e(this.f9673a.j()) + '&' + f.e(str);
    }

    private String i() {
        return Long.toString(System.currentTimeMillis() / 1000);
    }

    /* access modifiers changed from: package-private */
    public String b(String str) {
        try {
            String h10 = h();
            byte[] bytes = str.getBytes("UTF8");
            SecretKeySpec secretKeySpec = new SecretKeySpec(h10.getBytes("UTF8"), "HmacSHA1");
            Mac instance = Mac.getInstance("HmacSHA1");
            instance.init(secretKeySpec);
            byte[] doFinal = instance.doFinal(bytes);
            return okio.f.z(doFinal, 0, doFinal.length).a();
        } catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException e10) {
            l.g().b("Twitter", "Failed to calculate signature", e10);
            return "";
        }
    }

    /* access modifiers changed from: package-private */
    public String c(String str, String str2, String str3) {
        StringBuilder sb2 = new StringBuilder("OAuth");
        a(sb2, "oauth_callback", this.f9675c);
        a(sb2, "oauth_consumer_key", this.f9673a.a());
        a(sb2, "oauth_nonce", str);
        a(sb2, "oauth_signature", str3);
        a(sb2, "oauth_signature_method", "HMAC-SHA1");
        a(sb2, "oauth_timestamp", str2);
        r rVar = this.f9674b;
        a(sb2, "oauth_token", rVar != null ? rVar.f9711b : null);
        a(sb2, "oauth_version", "1.0");
        return sb2.substring(0, sb2.length() - 1);
    }

    /* access modifiers changed from: package-private */
    public String d(String str, String str2) {
        String str3;
        URI create = URI.create(this.f9677e);
        TreeMap<String, String> b10 = f.b(create, true);
        Map<String, String> map = this.f9678f;
        if (map != null) {
            b10.putAll(map);
        }
        String str4 = this.f9675c;
        if (str4 != null) {
            b10.put("oauth_callback", str4);
        }
        b10.put("oauth_consumer_key", this.f9673a.a());
        b10.put("oauth_nonce", str);
        b10.put("oauth_signature_method", "HMAC-SHA1");
        b10.put("oauth_timestamp", str2);
        r rVar = this.f9674b;
        if (!(rVar == null || (str3 = rVar.f9711b) == null)) {
            b10.put("oauth_token", str3);
        }
        b10.put("oauth_version", "1.0");
        String str5 = create.getScheme() + "://" + create.getHost() + create.getPath();
        return this.f9676d.toUpperCase(Locale.ENGLISH) + '&' + f.c(str5) + '&' + f(b10);
    }

    public String e() {
        String g10 = g();
        String i10 = i();
        return c(g10, i10, b(d(g10, i10)));
    }
}
