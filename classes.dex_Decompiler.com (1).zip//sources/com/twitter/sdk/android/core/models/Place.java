package com.twitter.sdk.android.core.models;

import java.util.List;
import java.util.Map;
import w9.c;

public class Place {
    @c("attributes")
    public final Map<String, String> attributes;
    @c("bounding_box")
    public final BoundingBox boundingBox;
    @c("country")
    public final String country;
    @c("country_code")
    public final String countryCode;
    @c("full_name")
    public final String fullName;
    @c("id")
    public final String id;
    @c("name")
    public final String name;
    @c("place_type")
    public final String placeType;
    @c("url")
    public final String url;

    public static class BoundingBox {
        @c("coordinates")
        public final List<List<List<Double>>> coordinates;
        @c("type")
        public final String type;

        private BoundingBox() {
            this((List<List<List<Double>>>) null, (String) null);
        }

        public BoundingBox(List<List<List<Double>>> list, String str) {
            this.coordinates = ModelUtils.getSafeList(list);
            this.type = str;
        }
    }

    public Place(Map<String, String> map, BoundingBox boundingBox2, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.attributes = ModelUtils.getSafeMap(map);
        this.boundingBox = boundingBox2;
        this.country = str;
        this.countryCode = str2;
        this.fullName = str3;
        this.id = str4;
        this.name = str5;
        this.placeType = str6;
        this.url = str7;
    }
}
