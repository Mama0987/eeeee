package com.twitter.sdk.android.core;

import com.google.gson.Gson;
import com.google.gson.h;
import com.google.gson.i;
import com.google.gson.j;
import com.google.gson.m;
import com.google.gson.n;
import com.google.gson.p;
import com.google.gson.q;
import com.twitter.sdk.android.core.internal.oauth.a;
import com.twitter.sdk.android.core.internal.oauth.e;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class AuthTokenAdapter implements q<a>, i<a> {

    /* renamed from: b  reason: collision with root package name */
    static final Map<String, Class<? extends a>> f9629b;

    /* renamed from: a  reason: collision with root package name */
    private final Gson f9630a = new Gson();

    static {
        HashMap hashMap = new HashMap();
        f9629b = hashMap;
        hashMap.put("oauth1a", r.class);
        hashMap.put("oauth2", e.class);
        hashMap.put("guest", a.class);
    }

    static String b(Class<? extends a> cls) {
        for (Map.Entry next : f9629b.entrySet()) {
            if (((Class) next.getValue()).equals(cls)) {
                return (String) next.getKey();
            }
        }
        return "";
    }

    /* renamed from: a */
    public a deserialize(j jVar, Type type, h hVar) throws n {
        m i10 = jVar.i();
        String l10 = i10.y("auth_type").l();
        return (a) this.f9630a.h(i10.x("auth_token"), f9629b.get(l10));
    }

    /* renamed from: c */
    public j serialize(a aVar, Type type, p pVar) {
        m mVar = new m();
        mVar.v("auth_type", b(aVar.getClass()));
        mVar.r("auth_token", this.f9630a.B(aVar));
        return mVar;
    }
}
