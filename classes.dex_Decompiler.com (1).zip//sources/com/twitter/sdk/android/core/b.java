package com.twitter.sdk.android.core;

import androidx.annotation.NonNull;
import wc.d;
import wc.x;

public abstract class b<T> implements d<T> {
    public final void a(@NonNull wc.b<T> bVar, x<T> xVar) {
        if (xVar.f()) {
            d(new i(xVar.a(), xVar));
        } else {
            c(new n(xVar));
        }
    }

    public final void b(@NonNull wc.b<T> bVar, @NonNull Throwable th) {
        c(new x("Request Failure", th));
    }

    public abstract void c(x xVar);

    public abstract void d(i<T> iVar);
}
