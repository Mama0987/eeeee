package com.twitter.sdk.android.core;

import android.content.Context;
import java.util.concurrent.ExecutorService;

public class t {

    /* renamed from: a  reason: collision with root package name */
    final Context f9713a;

    /* renamed from: b  reason: collision with root package name */
    final g f9714b;

    /* renamed from: c  reason: collision with root package name */
    final o f9715c;

    /* renamed from: d  reason: collision with root package name */
    final ExecutorService f9716d;

    /* renamed from: e  reason: collision with root package name */
    final Boolean f9717e;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        private final Context f9718a;

        /* renamed from: b  reason: collision with root package name */
        private g f9719b;

        /* renamed from: c  reason: collision with root package name */
        private o f9720c;

        /* renamed from: d  reason: collision with root package name */
        private ExecutorService f9721d;

        /* renamed from: e  reason: collision with root package name */
        private Boolean f9722e;

        public a(Context context) {
            if (context != null) {
                this.f9718a = context.getApplicationContext();
                return;
            }
            throw new IllegalArgumentException("Context must not be null.");
        }

        public t a() {
            return new t(this.f9718a, this.f9719b, this.f9720c, this.f9721d, this.f9722e);
        }

        public a b(boolean z10) {
            this.f9722e = Boolean.valueOf(z10);
            return this;
        }

        public a c(ExecutorService executorService) {
            if (executorService != null) {
                this.f9721d = executorService;
                return this;
            }
            throw new IllegalArgumentException("ExecutorService must not be null.");
        }

        public a d(g gVar) {
            if (gVar != null) {
                this.f9719b = gVar;
                return this;
            }
            throw new IllegalArgumentException("Logger must not be null.");
        }

        public a e(o oVar) {
            if (oVar != null) {
                this.f9720c = oVar;
                return this;
            }
            throw new IllegalArgumentException("TwitterAuthConfig must not be null.");
        }
    }

    private t(Context context, g gVar, o oVar, ExecutorService executorService, Boolean bool) {
        this.f9713a = context.getApplicationContext();
        this.f9714b = gVar;
        this.f9715c = oVar;
        this.f9716d = executorService;
        this.f9717e = bool;
    }
}
