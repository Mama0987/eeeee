package com.twitter.sdk.android.core.models;

import java.util.List;
import w9.c;

public class Search {
    @c("search_metadata")
    public final SearchMetadata searchMetadata;
    @c("statuses")
    public final List<Tweet> tweets;

    private Search() {
        this((List<Tweet>) null, (SearchMetadata) null);
    }

    public Search(List<Tweet> list, SearchMetadata searchMetadata2) {
        this.tweets = ModelUtils.getSafeList(list);
        this.searchMetadata = searchMetadata2;
    }
}
