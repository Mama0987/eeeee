package com.twitter.sdk.android.core.models;

import w9.c;

public class SymbolEntity extends Entity {
    @c("text")
    public final String text;

    public SymbolEntity(String str, int i10, int i11) {
        super(i10, i11);
        this.text = str;
    }

    public /* bridge */ /* synthetic */ int getEnd() {
        return super.getEnd();
    }

    public /* bridge */ /* synthetic */ int getStart() {
        return super.getStart();
    }
}
