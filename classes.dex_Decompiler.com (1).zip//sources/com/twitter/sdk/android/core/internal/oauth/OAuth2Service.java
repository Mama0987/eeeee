package com.twitter.sdk.android.core.internal.oauth;

import com.twitter.sdk.android.core.l;
import com.twitter.sdk.android.core.w;
import com.twitter.sdk.android.core.x;
import ka.g;
import okio.f;
import wc.b;
import yc.c;
import yc.e;
import yc.i;
import yc.k;
import yc.o;

public class OAuth2Service extends i {

    /* renamed from: e  reason: collision with root package name */
    OAuth2Api f9665e = ((OAuth2Api) b().b(OAuth2Api.class));

    interface OAuth2Api {
        @e
        @o("/oauth2/token")
        @k({"Content-Type: application/x-www-form-urlencoded;charset=UTF-8"})
        b<e> getAppAuthToken(@i("Authorization") String str, @c("grant_type") String str2);

        @o("/1.1/guest/activate.json")
        b<b> getGuestToken(@i("Authorization") String str);
    }

    class a extends com.twitter.sdk.android.core.b<e> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ com.twitter.sdk.android.core.b f9666a;

        /* renamed from: com.twitter.sdk.android.core.internal.oauth.OAuth2Service$a$a  reason: collision with other inner class name */
        class C0121a extends com.twitter.sdk.android.core.b<b> {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ e f9668a;

            C0121a(e eVar) {
                this.f9668a = eVar;
            }

            public void c(x xVar) {
                l.g().b("Twitter", "Your app may not allow guest auth. Please talk to us regarding upgrading your consumer key.", xVar);
                a.this.f9666a.c(xVar);
            }

            public void d(com.twitter.sdk.android.core.i<b> iVar) {
                a.this.f9666a.d(new com.twitter.sdk.android.core.i(new a(this.f9668a.j(), this.f9668a.a(), ((b) iVar.f9646a).f9671a), (wc.x) null));
            }
        }

        a(com.twitter.sdk.android.core.b bVar) {
            this.f9666a = bVar;
        }

        public void c(x xVar) {
            l.g().b("Twitter", "Failed to get app auth token", xVar);
            com.twitter.sdk.android.core.b bVar = this.f9666a;
            if (bVar != null) {
                bVar.c(xVar);
            }
        }

        public void d(com.twitter.sdk.android.core.i<e> iVar) {
            e eVar = (e) iVar.f9646a;
            OAuth2Service.this.i(new C0121a(eVar), eVar);
        }
    }

    public OAuth2Service(w wVar, g gVar) {
        super(wVar, gVar);
    }

    private String e() {
        com.twitter.sdk.android.core.o d10 = c().d();
        f o10 = f.o(la.f.c(d10.a()) + ":" + la.f.c(d10.j()));
        return "Basic " + o10.a();
    }

    private String f(e eVar) {
        return "Bearer " + eVar.a();
    }

    /* access modifiers changed from: package-private */
    public void g(com.twitter.sdk.android.core.b<e> bVar) {
        this.f9665e.getAppAuthToken(e(), "client_credentials").A(bVar);
    }

    public void h(com.twitter.sdk.android.core.b<a> bVar) {
        g(new a(bVar));
    }

    /* access modifiers changed from: package-private */
    public void i(com.twitter.sdk.android.core.b<b> bVar, e eVar) {
        this.f9665e.getGuestToken(f(eVar)).A(bVar);
    }
}
