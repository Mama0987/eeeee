package com.twitter.sdk.android.core;

import android.text.TextUtils;
import com.google.gson.e;
import com.google.gson.r;
import com.twitter.sdk.android.core.models.ApiError;
import com.twitter.sdk.android.core.models.ApiErrors;
import com.twitter.sdk.android.core.models.SafeListAdapter;
import com.twitter.sdk.android.core.models.SafeMapAdapter;
import wc.x;

public class n extends x {

    /* renamed from: a  reason: collision with root package name */
    private final ApiError f9705a;

    /* renamed from: b  reason: collision with root package name */
    private final y f9706b;

    /* renamed from: c  reason: collision with root package name */
    private final int f9707c;

    /* renamed from: d  reason: collision with root package name */
    private final x f9708d;

    public n(x xVar) {
        this(xVar, c(xVar), d(xVar), xVar.b());
    }

    n(x xVar, ApiError apiError, y yVar, int i10) {
        super(a(i10));
        this.f9705a = apiError;
        this.f9706b = yVar;
        this.f9707c = i10;
        this.f9708d = xVar;
    }

    static String a(int i10) {
        return "HTTP request failed, Status: " + i10;
    }

    static ApiError b(String str) {
        try {
            ApiErrors apiErrors = (ApiErrors) new e().d(new SafeListAdapter()).d(new SafeMapAdapter()).b().l(str, ApiErrors.class);
            if (!apiErrors.errors.isEmpty()) {
                return apiErrors.errors.get(0);
            }
            return null;
        } catch (r e10) {
            g g10 = l.g();
            g10.b("Twitter", "Invalid json: " + str, e10);
            return null;
        }
    }

    public static ApiError c(x xVar) {
        try {
            String D0 = xVar.d().i().j().clone().D0();
            if (!TextUtils.isEmpty(D0)) {
                return b(D0);
            }
            return null;
        } catch (Exception e10) {
            l.g().b("Twitter", "Unexpected response", e10);
            return null;
        }
    }

    public static y d(x xVar) {
        return new y(xVar.e());
    }
}
