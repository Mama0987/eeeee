package com.twitter.sdk.android.core;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import java.util.Objects;
import w9.c;

public class r extends a implements Parcelable {
    public static final Parcelable.Creator<r> CREATOR = new a();
    @c("token")

    /* renamed from: b  reason: collision with root package name */
    public final String f9711b;
    @c("secret")

    /* renamed from: c  reason: collision with root package name */
    public final String f9712c;

    class a implements Parcelable.Creator<r> {
        a() {
        }

        /* renamed from: a */
        public r createFromParcel(Parcel parcel) {
            return new r(parcel);
        }

        /* renamed from: b */
        public r[] newArray(int i10) {
            return new r[i10];
        }
    }

    private r(Parcel parcel) {
        this.f9711b = parcel.readString();
        this.f9712c = parcel.readString();
    }

    public r(String str, String str2) {
        this.f9711b = str;
        this.f9712c = str2;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r)) {
            return false;
        }
        r rVar = (r) obj;
        if (!Objects.equals(this.f9712c, rVar.f9712c)) {
            return false;
        }
        return Objects.equals(this.f9711b, rVar.f9711b);
    }

    public int hashCode() {
        String str = this.f9711b;
        int i10 = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.f9712c;
        if (str2 != null) {
            i10 = str2.hashCode();
        }
        return hashCode + i10;
    }

    @NonNull
    public String toString() {
        return "token=" + this.f9711b + ",secret=" + this.f9712c;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f9711b);
        parcel.writeString(this.f9712c);
    }
}
