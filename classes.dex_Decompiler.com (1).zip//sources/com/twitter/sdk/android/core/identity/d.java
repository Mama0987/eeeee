package com.twitter.sdk.android.core.identity;

class d extends Exception {
    private static final long serialVersionUID = -7397331487240298819L;

    /* renamed from: a  reason: collision with root package name */
    private final int f9660a;

    /* renamed from: b  reason: collision with root package name */
    private final String f9661b;

    d(int i10, String str, String str2) {
        super(str);
        this.f9660a = i10;
        this.f9661b = str2;
    }
}
