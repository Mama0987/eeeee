package com.twitter.sdk.android.core.models;

public interface Identifiable {
    long getId();
}
