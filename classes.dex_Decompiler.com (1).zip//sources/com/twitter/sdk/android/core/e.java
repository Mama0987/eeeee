package com.twitter.sdk.android.core;

import com.twitter.sdk.android.core.internal.oauth.OAuth2Service;
import java.util.concurrent.CountDownLatch;

public class e {

    /* renamed from: a  reason: collision with root package name */
    private final OAuth2Service f9634a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final k<d> f9635b;

    class a extends b<com.twitter.sdk.android.core.internal.oauth.a> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ CountDownLatch f9636a;

        a(CountDownLatch countDownLatch) {
            this.f9636a = countDownLatch;
        }

        public void c(x xVar) {
            e.this.f9635b.c(0);
            this.f9636a.countDown();
        }

        public void d(i<com.twitter.sdk.android.core.internal.oauth.a> iVar) {
            e.this.f9635b.e(new d((com.twitter.sdk.android.core.internal.oauth.a) iVar.f9646a));
            this.f9636a.countDown();
        }
    }

    public e(OAuth2Service oAuth2Service, k<d> kVar) {
        this.f9634a = oAuth2Service;
        this.f9635b = kVar;
    }

    public synchronized d b() {
        d d10 = this.f9635b.d();
        if (c(d10)) {
            return d10;
        }
        e();
        return this.f9635b.d();
    }

    /* access modifiers changed from: package-private */
    public boolean c(d dVar) {
        return (dVar == null || dVar.a() == null || ((com.twitter.sdk.android.core.internal.oauth.a) dVar.a()).l()) ? false : true;
    }

    public synchronized d d(d dVar) {
        d d10 = this.f9635b.d();
        if (dVar != null && dVar.equals(d10)) {
            e();
        }
        return this.f9635b.d();
    }

    /* access modifiers changed from: package-private */
    public void e() {
        l.g().c("GuestSessionProvider", "Refreshing expired guest session.");
        CountDownLatch countDownLatch = new CountDownLatch(1);
        this.f9634a.h(new a(countDownLatch));
        try {
            countDownLatch.await();
        } catch (InterruptedException unused) {
            this.f9635b.c(0);
        }
    }
}
