package com.twitter.sdk.android.core;

import com.twitter.sdk.android.core.a;
import java.util.Objects;
import w9.c;

public class j<T extends a> {
    @c("auth_token")

    /* renamed from: a  reason: collision with root package name */
    private final T f9689a;
    @c("id")

    /* renamed from: b  reason: collision with root package name */
    private final long f9690b;

    public j(T t10, long j10) {
        if (t10 != null) {
            this.f9689a = t10;
            this.f9690b = j10;
            return;
        }
        throw new IllegalArgumentException("AuthToken must not be null.");
    }

    public T a() {
        return this.f9689a;
    }

    public long b() {
        return this.f9690b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        j jVar = (j) obj;
        if (this.f9690b != jVar.f9690b) {
            return false;
        }
        return Objects.equals(this.f9689a, jVar.f9689a);
    }

    public int hashCode() {
        T t10 = this.f9689a;
        int hashCode = t10 != null ? t10.hashCode() : 0;
        long j10 = this.f9690b;
        return (hashCode * 31) + ((int) (j10 ^ (j10 >>> 32)));
    }
}
