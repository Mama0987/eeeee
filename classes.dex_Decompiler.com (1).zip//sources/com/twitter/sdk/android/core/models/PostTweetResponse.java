package com.twitter.sdk.android.core.models;

import w9.c;

public class PostTweetResponse {
    @c("id")
    public final String id = "";
    @c("text")
    public final String text = "";
}
