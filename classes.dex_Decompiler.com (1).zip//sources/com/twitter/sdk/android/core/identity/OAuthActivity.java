package com.twitter.sdk.android.core.identity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.ProgressBar;
import com.twitter.sdk.android.core.identity.a;
import com.twitter.sdk.android.core.internal.oauth.OAuth1aService;
import com.twitter.sdk.android.core.o;
import com.twitter.sdk.android.core.q;
import com.twitter.sdk.android.core.w;
import ka.g;
import l5.d;
import l5.e;

public class OAuthActivity extends Activity implements a.c {

    /* renamed from: a  reason: collision with root package name */
    a f9648a;

    /* renamed from: b  reason: collision with root package name */
    private ProgressBar f9649b;

    public void a(int i10, Intent intent) {
        setResult(i10, intent);
        finish();
    }

    public void onBackPressed() {
        this.f9648a.l(0, new q("Authorization failed, request was canceled."));
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(e.f12697g);
        this.f9649b = (ProgressBar) findViewById(d.B);
        WebView webView = (WebView) findViewById(d.C);
        int i10 = 0;
        boolean z10 = bundle != null ? bundle.getBoolean("progress", false) : true;
        ProgressBar progressBar = this.f9649b;
        if (!z10) {
            i10 = 8;
        }
        progressBar.setVisibility(i10);
        a aVar = new a(this.f9649b, webView, (o) getIntent().getParcelableExtra("auth_config"), new OAuth1aService(w.g(), new g()), this);
        this.f9648a = aVar;
        aVar.r();
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        if (this.f9649b.getVisibility() == 0) {
            bundle.putBoolean("progress", true);
        }
        super.onSaveInstanceState(bundle);
    }
}
