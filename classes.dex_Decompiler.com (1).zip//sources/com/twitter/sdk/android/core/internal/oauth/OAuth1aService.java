package com.twitter.sdk.android.core.internal.oauth;

import android.net.Uri;
import com.twitter.sdk.android.core.r;
import com.twitter.sdk.android.core.w;
import com.twitter.sdk.android.core.x;
import ic.j0;
import java.util.Map;
import java.util.TreeMap;
import ka.g;
import la.f;
import wc.b;
import yc.i;
import yc.o;
import yc.t;

public class OAuth1aService extends i {

    /* renamed from: e  reason: collision with root package name */
    OAuthApi f9662e = ((OAuthApi) b().b(OAuthApi.class));

    interface OAuthApi {
        @o("/oauth/access_token")
        b<j0> getAccessToken(@i("Authorization") String str, @t("oauth_verifier") String str2);

        @o("/oauth/request_token")
        b<j0> getTempToken(@i("Authorization") String str);
    }

    class a extends com.twitter.sdk.android.core.b<j0> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ com.twitter.sdk.android.core.b f9663a;

        a(com.twitter.sdk.android.core.b bVar) {
            this.f9663a = bVar;
        }

        public void c(x xVar) {
            this.f9663a.c(xVar);
        }

        /* JADX WARNING: Removed duplicated region for block: B:16:0x005c A[Catch:{ IOException -> 0x0060 }] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void d(com.twitter.sdk.android.core.i<ic.j0> r5) {
            /*
                r4 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                r1 = 0
                java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch:{ all -> 0x0059 }
                java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch:{ all -> 0x0059 }
                T r5 = r5.f9646a     // Catch:{ all -> 0x0059 }
                ic.j0 r5 = (ic.j0) r5     // Catch:{ all -> 0x0059 }
                java.io.InputStream r5 = r5.b()     // Catch:{ all -> 0x0059 }
                r3.<init>(r5)     // Catch:{ all -> 0x0059 }
                r2.<init>(r3)     // Catch:{ all -> 0x0059 }
            L_0x0018:
                java.lang.String r5 = r2.readLine()     // Catch:{ all -> 0x0056 }
                if (r5 == 0) goto L_0x0022
                r0.append(r5)     // Catch:{ all -> 0x0056 }
                goto L_0x0018
            L_0x0022:
                r2.close()     // Catch:{ IOException -> 0x0060 }
                java.lang.String r5 = r0.toString()     // Catch:{ IOException -> 0x0060 }
                com.twitter.sdk.android.core.internal.oauth.g r0 = com.twitter.sdk.android.core.internal.oauth.OAuth1aService.j(r5)     // Catch:{ IOException -> 0x0060 }
                if (r0 != 0) goto L_0x004b
                com.twitter.sdk.android.core.b r0 = r4.f9663a     // Catch:{ IOException -> 0x0060 }
                com.twitter.sdk.android.core.q r1 = new com.twitter.sdk.android.core.q     // Catch:{ IOException -> 0x0060 }
                java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0060 }
                r2.<init>()     // Catch:{ IOException -> 0x0060 }
                java.lang.String r3 = "Failed to parse auth response: "
                r2.append(r3)     // Catch:{ IOException -> 0x0060 }
                r2.append(r5)     // Catch:{ IOException -> 0x0060 }
                java.lang.String r5 = r2.toString()     // Catch:{ IOException -> 0x0060 }
                r1.<init>(r5)     // Catch:{ IOException -> 0x0060 }
                r0.c(r1)     // Catch:{ IOException -> 0x0060 }
                goto L_0x006f
            L_0x004b:
                com.twitter.sdk.android.core.b r5 = r4.f9663a     // Catch:{ IOException -> 0x0060 }
                com.twitter.sdk.android.core.i r2 = new com.twitter.sdk.android.core.i     // Catch:{ IOException -> 0x0060 }
                r2.<init>(r0, r1)     // Catch:{ IOException -> 0x0060 }
                r5.d(r2)     // Catch:{ IOException -> 0x0060 }
                goto L_0x006f
            L_0x0056:
                r5 = move-exception
                r1 = r2
                goto L_0x005a
            L_0x0059:
                r5 = move-exception
            L_0x005a:
                if (r1 == 0) goto L_0x005f
                r1.close()     // Catch:{ IOException -> 0x0060 }
            L_0x005f:
                throw r5     // Catch:{ IOException -> 0x0060 }
            L_0x0060:
                r5 = move-exception
                com.twitter.sdk.android.core.b r0 = r4.f9663a
                com.twitter.sdk.android.core.q r1 = new com.twitter.sdk.android.core.q
                java.lang.String r2 = r5.getMessage()
                r1.<init>(r2, r5)
                r0.c(r1)
            L_0x006f:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.twitter.sdk.android.core.internal.oauth.OAuth1aService.a.d(com.twitter.sdk.android.core.i):void");
        }
    }

    public OAuth1aService(w wVar, g gVar) {
        super(wVar, gVar);
    }

    public static g j(String str) {
        TreeMap<String, String> a10 = f.a(str, false);
        String str2 = a10.get("oauth_token");
        String str3 = a10.get("oauth_token_secret");
        String str4 = a10.get("screen_name");
        long parseLong = a10.containsKey("user_id") ? Long.parseLong(a10.get("user_id")) : 0;
        if (str2 == null || str3 == null) {
            return null;
        }
        return new g(new r(str2, str3), str4, parseLong);
    }

    public String e(com.twitter.sdk.android.core.o oVar) {
        return Uri.parse("twittersdk://callback").buildUpon().appendQueryParameter("version", c().i()).appendQueryParameter("app", oVar.a()).build().toString();
    }

    /* access modifiers changed from: package-private */
    public String f() {
        return a().c() + "/oauth/access_token";
    }

    public String g(r rVar) {
        return a().a("oauth", "authorize").appendQueryParameter("oauth_token", rVar.f9711b).build().toString();
    }

    /* access modifiers changed from: package-private */
    public com.twitter.sdk.android.core.b<j0> h(com.twitter.sdk.android.core.b<g> bVar) {
        return new a(bVar);
    }

    /* access modifiers changed from: package-private */
    public String i() {
        return a().c() + "/oauth/request_token";
    }

    public void k(com.twitter.sdk.android.core.b<g> bVar, r rVar, String str) {
        this.f9662e.getAccessToken(new c().a(c().d(), rVar, (String) null, "POST", f(), (Map<String, String>) null), str).A(h(bVar));
    }

    public void l(com.twitter.sdk.android.core.b<g> bVar) {
        com.twitter.sdk.android.core.o d10 = c().d();
        this.f9662e.getTempToken(new c().a(d10, (r) null, e(d10), "POST", i(), (Map<String, String>) null)).A(h(bVar));
    }
}
