package com.twitter.sdk.android.core.internal.oauth;

import android.os.Parcel;
import android.os.Parcelable;
import com.twitter.sdk.android.core.r;

public class g implements Parcelable {
    public static final Parcelable.Creator<g> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public final r f9681a;

    /* renamed from: b  reason: collision with root package name */
    public final String f9682b;

    /* renamed from: c  reason: collision with root package name */
    public final long f9683c;

    class a implements Parcelable.Creator<g> {
        a() {
        }

        /* renamed from: a */
        public g createFromParcel(Parcel parcel) {
            return new g(parcel);
        }

        /* renamed from: b */
        public g[] newArray(int i10) {
            return new g[i10];
        }
    }

    private g(Parcel parcel) {
        this.f9681a = (r) parcel.readParcelable(r.class.getClassLoader());
        this.f9682b = parcel.readString();
        this.f9683c = parcel.readLong();
    }

    public g(r rVar, String str, long j10) {
        this.f9681a = rVar;
        this.f9682b = str;
        this.f9683c = j10;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "authToken=" + this.f9681a + ",userName=" + this.f9682b + ",userId=" + this.f9683c;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeParcelable(this.f9681a, i10);
        parcel.writeString(this.f9682b);
        parcel.writeLong(this.f9683c);
    }
}
