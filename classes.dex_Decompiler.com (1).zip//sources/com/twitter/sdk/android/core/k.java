package com.twitter.sdk.android.core;

import com.twitter.sdk.android.core.j;
import java.util.Map;

public interface k<T extends j> {
    void a();

    Map<Long, T> b();

    void c(long j10);

    T d();

    void e(T t10);
}
