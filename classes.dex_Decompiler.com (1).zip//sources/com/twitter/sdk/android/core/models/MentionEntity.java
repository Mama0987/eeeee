package com.twitter.sdk.android.core.models;

import w9.c;

public class MentionEntity extends Entity {
    @c("id")
    public final long id;
    @c("id_str")
    public final String idStr;
    @c("name")
    public final String name;
    @c("screen_name")
    public final String screenName;

    public MentionEntity(long j10, String str, String str2, String str3, int i10, int i11) {
        super(i10, i11);
        this.id = j10;
        this.idStr = str;
        this.name = str2;
        this.screenName = str3;
    }

    public /* bridge */ /* synthetic */ int getEnd() {
        return super.getEnd();
    }

    public /* bridge */ /* synthetic */ int getStart() {
        return super.getStart();
    }
}
