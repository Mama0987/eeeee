package com.twitter.sdk.android.core.models;

import w9.c;

public class Card {
    @c("binding_values")
    public final BindingValues bindingValues;
    @c("name")
    public final String name;

    public Card(BindingValues bindingValues2, String str) {
        this.bindingValues = bindingValues2;
        this.name = str;
    }
}
