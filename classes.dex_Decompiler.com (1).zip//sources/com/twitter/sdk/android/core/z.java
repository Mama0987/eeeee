package com.twitter.sdk.android.core;

import android.text.TextUtils;
import com.google.gson.Gson;
import java.util.Objects;
import ma.d;
import w9.c;

public class z extends j<r> {
    @c("user_name")

    /* renamed from: c  reason: collision with root package name */
    private final String f9736c;

    static class a implements d<z> {

        /* renamed from: a  reason: collision with root package name */
        private final Gson f9737a = new Gson();

        a() {
        }

        /* renamed from: c */
        public z a(String str) {
            if (TextUtils.isEmpty(str)) {
                return null;
            }
            try {
                return (z) this.f9737a.l(str, z.class);
            } catch (Exception e10) {
                l.g().c("Twitter", e10.getMessage());
                return null;
            }
        }

        /* renamed from: d */
        public String b(z zVar) {
            if (zVar == null || zVar.a() == null) {
                return "";
            }
            try {
                return this.f9737a.v(zVar);
            } catch (Exception e10) {
                l.g().c("Twitter", e10.getMessage());
                return "";
            }
        }
    }

    public z(r rVar, long j10, String str) {
        super(rVar, j10);
        this.f9736c = str;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass() || !super.equals(obj)) {
            return false;
        }
        return Objects.equals(this.f9736c, ((z) obj).f9736c);
    }

    public int hashCode() {
        int hashCode = super.hashCode() * 31;
        String str = this.f9736c;
        return hashCode + (str != null ? str.hashCode() : 0);
    }
}
