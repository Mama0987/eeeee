package com.twitter.sdk.android.core.internal.oauth;

import com.twitter.sdk.android.core.o;
import com.twitter.sdk.android.core.r;
import java.util.Map;

public class c {
    public String a(o oVar, r rVar, String str, String str2, String str3, Map<String, String> map) {
        return b(oVar, rVar, str, str2, str3, map).e();
    }

    /* access modifiers changed from: package-private */
    public d b(o oVar, r rVar, String str, String str2, String str3, Map<String, String> map) {
        return new d(oVar, rVar, str, str2, str3, map);
    }
}
