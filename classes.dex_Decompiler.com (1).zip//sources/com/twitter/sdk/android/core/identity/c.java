package com.twitter.sdk.android.core.identity;

import android.net.http.SslError;
import android.os.Bundle;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.URI;
import java.util.Map;
import java.util.TreeMap;
import la.f;

class c extends WebViewClient {

    /* renamed from: a  reason: collision with root package name */
    private final String f9658a;

    /* renamed from: b  reason: collision with root package name */
    private final a f9659b;

    interface a {
        void a(d dVar);

        void b(WebView webView, String str);

        void c(Bundle bundle);
    }

    c(String str, a aVar) {
        this.f9658a = str;
        this.f9659b = aVar;
    }

    public void onPageFinished(WebView webView, String str) {
        super.onPageFinished(webView, str);
        this.f9659b.b(webView, str);
    }

    public void onReceivedError(WebView webView, int i10, String str, String str2) {
        super.onReceivedError(webView, i10, str, str2);
        this.f9659b.a(new d(i10, str, str2));
    }

    public void onReceivedSslError(WebView webView, SslErrorHandler sslErrorHandler, SslError sslError) {
        super.onReceivedSslError(webView, sslErrorHandler, sslError);
        this.f9659b.a(new d(sslError.getPrimaryError(), (String) null, (String) null));
    }

    public boolean shouldOverrideUrlLoading(WebView webView, String str) {
        if (!str.startsWith(this.f9658a)) {
            return super.shouldOverrideUrlLoading(webView, str);
        }
        TreeMap<String, String> b10 = f.b(URI.create(str), false);
        Bundle bundle = new Bundle(b10.size());
        for (Map.Entry next : b10.entrySet()) {
            bundle.putString((String) next.getKey(), (String) next.getValue());
        }
        this.f9659b.c(bundle);
        return true;
    }
}
