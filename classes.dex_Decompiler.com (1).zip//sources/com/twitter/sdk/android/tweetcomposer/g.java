package com.twitter.sdk.android.tweetcomposer;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Size;
import com.twitter.Validator;
import com.twitter.sdk.android.core.i;
import com.twitter.sdk.android.core.m;
import com.twitter.sdk.android.core.models.User;
import com.twitter.sdk.android.core.services.AccountService;
import com.twitter.sdk.android.core.w;
import com.twitter.sdk.android.core.x;
import com.twitter.sdk.android.core.z;
import com.twitter.sdk.android.tweetcomposer.a;
import java.io.File;

class g {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final ComposerView f9763a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final z f9764b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final String f9765c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final String f9766d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public final a.b f9767e;

    /* renamed from: f  reason: collision with root package name */
    private final d f9768f;

    class a extends com.twitter.sdk.android.core.b<User> {
        a() {
        }

        public void c(x xVar) {
            g.this.f9763a.setProfilePhotoView((User) null);
        }

        public void d(i<User> iVar) {
            g.this.f9763a.setProfilePhotoView((User) iVar.f9646a);
        }
    }

    interface b {
        void a();

        void b(String str);

        void c(String str);
    }

    class c implements b {
        c() {
        }

        public void a() {
            g.this.q();
        }

        public void b(String str) {
            int i10;
            ComposerView composerView;
            int u10 = g.this.u(str);
            g.this.f9763a.setCharCount(g.r(u10));
            if (g.m(u10)) {
                composerView = g.this.f9763a;
                i10 = l5.g.f12711d;
            } else {
                composerView = g.this.f9763a;
                i10 = l5.g.f12710c;
            }
            composerView.setCharCountTextStyle(i10);
            g.this.f9763a.l(g.l(u10));
        }

        public void c(String str) {
            Intent intent = new Intent(g.this.f9763a.getContext(), n.class);
            intent.putExtra("EXTRA_USER_TOKEN", (Parcelable) g.this.f9764b.a());
            intent.putExtra("EXTRA_TWEET_TEXT", str);
            intent.putExtra("EXTRA_IMAGE_URI", g.this.f9765c);
            intent.putExtra("EXTRA_VIDEO_URI", g.this.f9766d);
            g.this.f9763a.getContext().startService(intent);
            g.this.f9767e.a();
        }
    }

    static class d {

        /* renamed from: a  reason: collision with root package name */
        final Validator f9771a = new Validator();

        d() {
        }

        /* access modifiers changed from: package-private */
        public m a(z zVar) {
            return w.g().c(zVar);
        }

        /* access modifiers changed from: package-private */
        public Validator b() {
            return this.f9771a;
        }
    }

    g(ComposerView composerView, z zVar, String str, String str2, String str3, String str4, a.b bVar) {
        this(composerView, zVar, str, str2, str3, str4, bVar, new d());
    }

    g(ComposerView composerView, z zVar, String str, String str2, String str3, String str4, a.b bVar, d dVar) {
        this.f9763a = composerView;
        this.f9764b = zVar;
        this.f9765c = str;
        this.f9766d = str2;
        this.f9767e = bVar;
        this.f9768f = dVar;
        composerView.setCallbacks(new c());
        composerView.setTweetText(i(str3, str4));
        t();
        if (!TextUtils.isEmpty(str)) {
            composerView.setImageView(str);
        } else if (!TextUtils.isEmpty(str2)) {
            v1.i.f(new d(this, str2)).l(new e(composerView), v1.i.f16633k);
        }
    }

    private String i(String str, String str2) {
        StringBuilder sb2 = new StringBuilder();
        if (!TextUtils.isEmpty(str)) {
            sb2.append(str);
        }
        if (!TextUtils.isEmpty(str2)) {
            if (sb2.length() > 0) {
                sb2.append(" ");
            }
            sb2.append(str2);
        }
        return sb2.toString();
    }

    private Bitmap j(String str, int i10) {
        return (Bitmap) oa.a.a(new MediaMetadataRetriever(), new f(str, i10));
    }

    /* access modifiers changed from: private */
    /* renamed from: k */
    public Bitmap o(String str) {
        try {
            return Build.VERSION.SDK_INT >= 29 ? ThumbnailUtils.createVideoThumbnail(new File(str), new Size(512, 512), (CancellationSignal) null) : ThumbnailUtils.createVideoThumbnail(str, 1);
        } catch (Exception e10) {
            e10.printStackTrace();
            return j(str, 512);
        }
    }

    static boolean l(int i10) {
        return i10 > 0 && i10 <= 140;
    }

    static boolean m(int i10) {
        return i10 > 140;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Bitmap n(String str, int i10, MediaMetadataRetriever mediaMetadataRetriever) {
        mediaMetadataRetriever.setDataSource(str);
        return Build.VERSION.SDK_INT >= 27 ? mediaMetadataRetriever.getScaledFrameAtTime(1000, 1, i10, i10) : mediaMetadataRetriever.getFrameAtTime();
    }

    static int r(int i10) {
        return 140 - i10;
    }

    private void t() {
        AccountService d10 = this.f9768f.a(this.f9764b).d();
        Boolean bool = Boolean.FALSE;
        d10.verifyCredentials(bool, Boolean.TRUE, bool).A(new a());
    }

    /* access modifiers changed from: package-private */
    public void q() {
        s();
        this.f9767e.a();
    }

    /* access modifiers changed from: package-private */
    public void s() {
        Intent intent = new Intent("com.twitter.sdk.android.tweetcomposer.TWEET_COMPOSE_CANCEL");
        intent.setPackage(this.f9763a.getContext().getPackageName());
        this.f9763a.getContext().sendBroadcast(intent);
    }

    /* access modifiers changed from: package-private */
    public int u(String str) {
        if (TextUtils.isEmpty(str)) {
            return 0;
        }
        return this.f9768f.b().getTweetLength(str);
    }
}
