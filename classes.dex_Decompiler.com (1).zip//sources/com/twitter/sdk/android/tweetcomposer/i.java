package com.twitter.sdk.android.tweetcomposer;

import android.view.View;

public final /* synthetic */ class i implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComposerView f9773a;

    public /* synthetic */ i(ComposerView composerView) {
        this.f9773a = composerView;
    }

    public final void onClick(View view) {
        this.f9773a.i(view);
    }
}
