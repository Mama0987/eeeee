package com.twitter.sdk.android.tweetcomposer.internal.util;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ScrollView;

public class ObservableScrollView extends ScrollView {

    /* renamed from: a  reason: collision with root package name */
    a f9774a;

    public interface a {
        void a(int i10);
    }

    public ObservableScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i10, int i11, int i12, int i13) {
        super.onScrollChanged(i10, i11, i12, i13);
        a aVar = this.f9774a;
        if (aVar != null) {
            aVar.a(i11);
        }
    }

    public void setScrollViewListener(a aVar) {
        this.f9774a = aVar;
    }
}
