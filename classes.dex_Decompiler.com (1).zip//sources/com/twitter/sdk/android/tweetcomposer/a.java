package com.twitter.sdk.android.tweetcomposer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.twitter.sdk.android.core.r;
import com.twitter.sdk.android.core.z;
import l5.d;
import l5.e;
import l5.g;

public class a extends Activity {

    /* renamed from: a  reason: collision with root package name */
    private g f9749a;

    /* renamed from: com.twitter.sdk.android.tweetcomposer.a$a  reason: collision with other inner class name */
    public static class C0122a {

        /* renamed from: a  reason: collision with root package name */
        private final Context f9750a;

        /* renamed from: b  reason: collision with root package name */
        private r f9751b;

        /* renamed from: c  reason: collision with root package name */
        private int f9752c = g.f12708a;

        /* renamed from: d  reason: collision with root package name */
        private String f9753d;

        /* renamed from: e  reason: collision with root package name */
        private String f9754e;

        /* renamed from: f  reason: collision with root package name */
        private String f9755f;

        /* renamed from: g  reason: collision with root package name */
        private String f9756g;

        public C0122a(Context context) {
            if (context != null) {
                this.f9750a = context;
                return;
            }
            throw new IllegalArgumentException("Context must not be null");
        }

        public Intent a() {
            if (this.f9751b != null) {
                Intent intent = new Intent(this.f9750a, a.class);
                intent.putExtra("EXTRA_USER_TOKEN", this.f9751b);
                intent.putExtra("EXTRA_IMAGE_URI", this.f9753d);
                intent.putExtra("EXTRA_VIDEO_URI", this.f9754e);
                intent.putExtra("EXTRA_THEME", this.f9752c);
                intent.putExtra("EXTRA_TEXT", this.f9755f);
                intent.putExtra("EXTRA_HASHTAGS", this.f9756g);
                return intent;
            }
            throw new IllegalStateException("Must set a TwitterSession");
        }

        public C0122a b(String str) {
            this.f9753d = str;
            return this;
        }

        public C0122a c(z zVar) {
            if (zVar != null) {
                r rVar = (r) zVar.a();
                if (rVar != null) {
                    this.f9751b = rVar;
                    return this;
                }
                throw new IllegalArgumentException("TwitterSession token must not be null");
            }
            throw new IllegalArgumentException("TwitterSession must not be null");
        }

        public C0122a d(String str) {
            this.f9755f = str;
            return this;
        }

        public C0122a e(String str) {
            this.f9754e = str;
            return this;
        }
    }

    interface b {
        void a();
    }

    class c implements b {
        c() {
        }

        public void a() {
            a.this.setResult(-1);
            a.this.finish();
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        this.f9749a.q();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        z zVar = new z((r) intent.getParcelableExtra("EXTRA_USER_TOKEN"), -1, "");
        String stringExtra = intent.getStringExtra("EXTRA_IMAGE_URI");
        String stringExtra2 = intent.getStringExtra("EXTRA_VIDEO_URI");
        String stringExtra3 = intent.getStringExtra("EXTRA_TEXT");
        String stringExtra4 = intent.getStringExtra("EXTRA_HASHTAGS");
        setTheme(intent.getIntExtra("EXTRA_THEME", g.f12708a));
        setContentView(e.f12696f);
        this.f9749a = new g((ComposerView) findViewById(d.f12688x), zVar, stringExtra, stringExtra2, stringExtra3, stringExtra4, new c());
    }
}
