package com.twitter.sdk.android.tweetcomposer;

import com.twitter.sdk.android.tweetcomposer.internal.util.ObservableScrollView;

public final /* synthetic */ class k implements ObservableScrollView.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComposerView f9776a;

    public /* synthetic */ k(ComposerView composerView) {
        this.f9776a = composerView;
    }

    public final void a(int i10) {
        this.f9776a.k(i10);
    }
}
