package com.twitter.sdk.android.tweetcomposer;

import android.app.IntentService;
import android.content.Intent;
import android.text.TextUtils;
import com.twitter.sdk.android.core.i;
import com.twitter.sdk.android.core.l;
import com.twitter.sdk.android.core.m;
import com.twitter.sdk.android.core.models.ApiError;
import com.twitter.sdk.android.core.models.Media;
import com.twitter.sdk.android.core.models.PostTweetResponse;
import com.twitter.sdk.android.core.models.TweetContent;
import com.twitter.sdk.android.core.models.TweetProcessingInfo;
import com.twitter.sdk.android.core.r;
import com.twitter.sdk.android.core.services.MediaService;
import com.twitter.sdk.android.core.w;
import com.twitter.sdk.android.core.x;
import com.twitter.sdk.android.core.z;
import ic.b0;
import ic.h0;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Objects;
import jc.e;

public class n extends IntentService {

    /* renamed from: a  reason: collision with root package name */
    c f9777a;

    /* renamed from: b  reason: collision with root package name */
    Intent f9778b;

    class a extends com.twitter.sdk.android.core.b<Media> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ m f9779a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ String f9780b;

        a(m mVar, String str) {
            this.f9779a = mVar;
            this.f9780b = str;
        }

        public void c(x xVar) {
            n.this.f(xVar);
        }

        public void d(i<Media> iVar) {
            n.this.k(this.f9779a, this.f9780b, ((Media) iVar.f9646a).mediaIdString);
        }
    }

    class b extends com.twitter.sdk.android.core.b<PostTweetResponse> {
        b() {
        }

        public void c(x xVar) {
            n.this.f(xVar);
        }

        public void d(i<PostTweetResponse> iVar) {
            n nVar = n.this;
            Objects.requireNonNull((PostTweetResponse) iVar.f9646a);
            nVar.h("");
            n.this.stopSelf();
        }
    }

    static class c {
        c() {
        }

        /* access modifiers changed from: package-private */
        public m a(z zVar) {
            return w.g().c(zVar);
        }
    }

    public n() {
        this(new c());
    }

    n(c cVar) {
        super("TweetUploadService");
        this.f9777a = cVar;
    }

    private static h0 d(String str) {
        return m.b(str, b0.d("text/plain"));
    }

    private void e(String str) {
        f(new x(str));
    }

    /* access modifiers changed from: private */
    public void f(Throwable th) {
        g(this.f9778b);
        l.g().b("TweetUploadService", "Post Tweet failed", th);
        stopSelf();
    }

    private void g(Intent intent) {
        Intent intent2 = new Intent("com.twitter.sdk.android.tweetcomposer.UPLOAD_FAILURE");
        intent2.putExtra("EXTRA_RETRY_INTENT", intent);
        intent2.setPackage(getApplicationContext().getPackageName());
        sendBroadcast(intent2);
    }

    /* access modifiers changed from: private */
    public void h(String str) {
        Intent intent = new Intent("com.twitter.sdk.android.tweetcomposer.UPLOAD_SUCCESS");
        intent.putExtra("EXTRA_TWEET_ID", str);
        intent.setPackage(getApplicationContext().getPackageName());
        sendBroadcast(intent);
    }

    private void i(z zVar, String str, com.twitter.sdk.android.core.b<Media> bVar) {
        m a10 = this.f9777a.a(zVar);
        File file = new File(str);
        a10.e().upload(m.a(file, b0.d(l.b(file))), (h0) null, (h0) null).A(bVar);
    }

    private void j(z zVar, String str, String str2, String str3) {
        m a10 = this.f9777a.a(zVar);
        if (!TextUtils.isEmpty(str2)) {
            i(zVar, str2, new a(a10, str));
        } else if (!TextUtils.isEmpty(str3)) {
            p(a10, str3, str);
        } else {
            k(a10, str, (String) null);
        }
    }

    /* access modifiers changed from: private */
    public void k(m mVar, String str, String str2) {
        mVar.g().postTweet(new TweetContent(str, str2)).A(new b());
    }

    private void l(m mVar, long j10, String str, RandomAccessFile randomAccessFile, String str2) throws IOException, InterruptedException {
        int length = (int) randomAccessFile.length();
        byte[] bArr = new byte[Math.min(length, 5242880)];
        MediaService e10 = mVar.e();
        boolean z10 = false;
        RandomAccessFile randomAccessFile2 = randomAccessFile;
        int i10 = 0;
        while (true) {
            if (randomAccessFile2.read(bArr) == -1) {
                z10 = true;
                break;
            }
            if (!e10.append(d("APPEND"), d(String.valueOf(j10)), m.c(bArr, b0.d(str)), (h0) null, d(String.valueOf(i10))).a().f()) {
                break;
            }
            int min = Math.min(5242880, (int) (((long) length) - randomAccessFile.getFilePointer()));
            if (min > 0 && min != bArr.length) {
                bArr = new byte[min];
            }
            i10++;
        }
        e.g(randomAccessFile);
        if (z10) {
            m mVar2 = mVar;
            m(mVar, j10, str2);
            return;
        }
        e("upload video failed");
    }

    private void m(m mVar, long j10, String str) throws IOException, InterruptedException {
        Media a10;
        wc.x<Media> a11 = mVar.e().finalize("FINALIZE", j10).a();
        if (!a11.f() || (a10 = a11.a()) == null) {
            e("request finalize api failed");
        } else {
            o(mVar, a10, str);
        }
    }

    private void n(m mVar, String str, RandomAccessFile randomAccessFile, String str2) throws IOException, InterruptedException {
        Media a10;
        wc.x<Media> a11 = mVar.e().init("INIT", str, randomAccessFile.length(), "tweet_video", (h0) null).a();
        if (!a11.f() || (a10 = a11.a()) == null) {
            e("request init api failed");
            return;
        }
        l(mVar, a10.mediaId, str, randomAccessFile, str2);
    }

    private void o(m mVar, Media media, String str) throws InterruptedException, IOException {
        if (media == null) {
            e("request finalize api failed");
            return;
        }
        TweetProcessingInfo tweetProcessingInfo = media.processingInfo;
        if (tweetProcessingInfo == null || Objects.equals(tweetProcessingInfo.state, "succeeded")) {
            k(mVar, str, media.mediaIdString);
        } else if (Objects.equals(tweetProcessingInfo.state, "failed")) {
            e("upload video failed");
        } else {
            ApiError apiError = tweetProcessingInfo.error;
            if (apiError != null) {
                e(apiError.message);
                return;
            }
            Thread.sleep(tweetProcessingInfo.checkAfterSecs * 1000);
            wc.x<Media> a10 = mVar.e().checkStatus("STATUS", media.mediaId).a();
            if (a10.f()) {
                o(mVar, a10.a(), str);
            } else {
                e("request check status api failed");
            }
        }
    }

    private void p(m mVar, String str, String str2) {
        File file = new File(str);
        try {
            n(mVar, l.b(file), new RandomAccessFile(file, "r"), str2);
        } catch (Exception e10) {
            f(e10);
        }
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        this.f9778b = intent;
        j(new z((r) intent.getParcelableExtra("EXTRA_USER_TOKEN"), -1, ""), intent.getStringExtra("EXTRA_TWEET_TEXT"), intent.getStringExtra("EXTRA_IMAGE_URI"), intent.getStringExtra("EXTRA_VIDEO_URI"));
    }
}
