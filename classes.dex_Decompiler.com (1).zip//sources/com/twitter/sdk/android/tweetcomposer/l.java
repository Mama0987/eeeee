package com.twitter.sdk.android.tweetcomposer;

import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import java.io.File;

class l {
    static String a(String str) {
        if (str == null) {
            return null;
        }
        int lastIndexOf = str.lastIndexOf(".");
        return lastIndexOf < 0 ? "" : str.substring(lastIndexOf + 1);
    }

    static String b(File file) {
        String a10 = a(file.getName());
        return !TextUtils.isEmpty(a10) ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(a10) : "application/octet-stream";
    }
}
