package com.twitter.sdk.android.tweetcomposer;

import java.util.concurrent.Callable;

public final /* synthetic */ class d implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f9758a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f9759b;

    public /* synthetic */ d(g gVar, String str) {
        this.f9758a = gVar;
        this.f9759b = str;
    }

    public final Object call() {
        return this.f9758a.o(this.f9759b);
    }
}
