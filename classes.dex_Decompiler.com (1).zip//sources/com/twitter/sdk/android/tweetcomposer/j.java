package com.twitter.sdk.android.tweetcomposer;

import android.view.KeyEvent;
import android.widget.TextView;

public final /* synthetic */ class j implements TextView.OnEditorActionListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComposerView f9775a;

    public /* synthetic */ j(ComposerView composerView) {
        this.f9775a = composerView;
    }

    public final boolean onEditorAction(TextView textView, int i10, KeyEvent keyEvent) {
        return this.f9775a.j(textView, i10, keyEvent);
    }
}
