package g;

import android.content.Context;
import android.content.Intent;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public abstract class a<I, O> {

    @Metadata
    /* renamed from: g.a$a  reason: collision with other inner class name */
    public static final class C0160a<T> {

        /* renamed from: a  reason: collision with root package name */
        private final T f10974a;

        public C0160a(T t10) {
            this.f10974a = t10;
        }

        public final T a() {
            return this.f10974a;
        }
    }

    @NotNull
    public abstract Intent a(@NotNull Context context, I i10);

    public C0160a<O> b(@NotNull Context context, I i10) {
        Intrinsics.checkNotNullParameter(context, "context");
        return null;
    }

    public abstract O c(int i10, Intent intent);
}
