package g;

import android.content.Context;
import android.content.Intent;
import eb.r;
import g.a;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class b extends a<String[], Map<String, Boolean>> {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final a f10975a = new a((DefaultConstructorMarker) null);

    @Metadata
    public static final class a {
        private a() {
        }

        public /* synthetic */ a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final Intent a(@NotNull String[] strArr) {
            Intrinsics.checkNotNullParameter(strArr, "input");
            Intent putExtra = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr);
            Intrinsics.checkNotNullExpressionValue(putExtra, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
            return putExtra;
        }
    }

    @NotNull
    /* renamed from: d */
    public Intent a(@NotNull Context context, @NotNull String[] strArr) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(strArr, "input");
        return f10975a.a(strArr);
    }

    /* renamed from: e */
    public a.C0160a<Map<String, Boolean>> b(@NotNull Context context, @NotNull String[] strArr) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(strArr, "input");
        boolean z10 = true;
        if (strArr.length == 0) {
            return new a.C0160a<>(i0.i());
        }
        int length = strArr.length;
        int i10 = 0;
        while (true) {
            if (i10 >= length) {
                break;
            }
            if (!(androidx.core.content.a.a(context, strArr[i10]) == 0)) {
                z10 = false;
                break;
            }
            i10++;
        }
        if (!z10) {
            return null;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(j.a(h0.e(strArr.length), 16));
        for (String a10 : strArr) {
            Pair a11 = r.a(a10, Boolean.TRUE);
            linkedHashMap.put(a11.c(), a11.d());
        }
        return new a.C0160a<>(linkedHashMap);
    }

    @NotNull
    /* renamed from: f */
    public Map<String, Boolean> c(int i10, Intent intent) {
        if (i10 != -1) {
            return i0.i();
        }
        if (intent == null) {
            return i0.i();
        }
        String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
        if (intArrayExtra == null || stringArrayExtra == null) {
            return i0.i();
        }
        ArrayList arrayList = new ArrayList(intArrayExtra.length);
        int length = intArrayExtra.length;
        for (int i11 = 0; i11 < length; i11++) {
            arrayList.add(Boolean.valueOf(intArrayExtra[i11] == 0));
        }
        return i0.r(CollectionsKt___CollectionsKt.e0(m.o(stringArrayExtra), arrayList));
    }
}
