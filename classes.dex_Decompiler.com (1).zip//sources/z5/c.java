package z5;

public interface c<TInput, TResult> {
    TInput a(TInput tinput, TResult tresult);
}
