package q8;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.firebase.crashlytics.internal.analytics.AnalyticsEventLogger;
import p8.f;

public class e implements AnalyticsEventLogger {
    public void a(@NonNull String str, Bundle bundle) {
        f.f().b("Skipping logging Crashlytics event to Firebase, no Firebase Analytics");
    }
}
