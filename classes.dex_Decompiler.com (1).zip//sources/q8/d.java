package q8;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.firebase.crashlytics.internal.analytics.AnalyticsEventLogger;
import l8.a;

public class d implements AnalyticsEventLogger {
    @NonNull

    /* renamed from: a  reason: collision with root package name */
    private final a f14366a;

    public d(@NonNull a aVar) {
        this.f14366a = aVar;
    }

    public void a(@NonNull String str, Bundle bundle) {
        this.f14366a.a("clx", str, bundle);
    }
}
