package q8;

import android.os.Bundle;
import androidx.annotation.NonNull;

public interface a {
    void n(@NonNull String str, @NonNull Bundle bundle);
}
