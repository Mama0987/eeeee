package q8;

import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.firebase.crashlytics.internal.breadcrumbs.BreadcrumbSource;
import org.json.JSONException;
import org.json.JSONObject;
import p8.f;
import r8.a;

public class c implements BreadcrumbSource, a {

    /* renamed from: a  reason: collision with root package name */
    private a f14365a;

    @NonNull
    private static String b(@NonNull String str, @NonNull Bundle bundle) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = new JSONObject();
        for (String next : bundle.keySet()) {
            jSONObject2.put(next, bundle.get(next));
        }
        jSONObject.put("name", str);
        jSONObject.put("parameters", jSONObject2);
        return jSONObject.toString();
    }

    public void a(a aVar) {
        this.f14365a = aVar;
        f.f().b("Registered Firebase Analytics event receiver for breadcrumbs");
    }

    public void n(@NonNull String str, @NonNull Bundle bundle) {
        a aVar = this.f14365a;
        if (aVar != null) {
            try {
                aVar.a("$A$:" + b(str, bundle));
            } catch (JSONException unused) {
                f.f().k("Unable to serialize Firebase Analytics event to breadcrumb.");
            }
        }
    }
}
