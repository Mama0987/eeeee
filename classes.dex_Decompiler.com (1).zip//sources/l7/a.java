package l7;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import e7.q;
import r6.n;
import s6.c;

public final class a extends q {
    @NonNull
    public static final Parcelable.Creator<a> CREATOR = new c();

    /* renamed from: a  reason: collision with root package name */
    private final boolean f12733a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f12734b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f12735c;

    /* renamed from: d  reason: collision with root package name */
    private final boolean[] f12736d;

    /* renamed from: e  reason: collision with root package name */
    private final boolean[] f12737e;

    public a(boolean z10, boolean z11, boolean z12, @NonNull boolean[] zArr, @NonNull boolean[] zArr2) {
        this.f12733a = z10;
        this.f12734b = z11;
        this.f12735c = z12;
        this.f12736d = zArr;
        this.f12737e = zArr2;
    }

    @NonNull
    public boolean[] d1() {
        return this.f12736d;
    }

    @NonNull
    public boolean[] e1() {
        return this.f12737e;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        a aVar = (a) obj;
        return n.b(aVar.d1(), d1()) && n.b(aVar.e1(), e1()) && n.b(Boolean.valueOf(aVar.f1()), Boolean.valueOf(f1())) && n.b(Boolean.valueOf(aVar.g1()), Boolean.valueOf(g1())) && n.b(Boolean.valueOf(aVar.h1()), Boolean.valueOf(h1()));
    }

    public boolean f1() {
        return this.f12733a;
    }

    public boolean g1() {
        return this.f12734b;
    }

    public boolean h1() {
        return this.f12735c;
    }

    public int hashCode() {
        return n.c(d1(), e1(), Boolean.valueOf(f1()), Boolean.valueOf(g1()), Boolean.valueOf(h1()));
    }

    @NonNull
    public String toString() {
        return n.d(this).a("SupportedCaptureModes", d1()).a("SupportedQualityLevels", e1()).a("CameraSupported", Boolean.valueOf(f1())).a("MicSupported", Boolean.valueOf(g1())).a("StorageWriteSupported", Boolean.valueOf(h1())).toString();
    }

    public void writeToParcel(@NonNull Parcel parcel, int i10) {
        int a10 = c.a(parcel);
        c.c(parcel, 1, f1());
        c.c(parcel, 2, g1());
        c.c(parcel, 3, h1());
        c.d(parcel, 4, d1(), false);
        c.d(parcel, 5, e1(), false);
        c.b(parcel, a10);
    }
}
