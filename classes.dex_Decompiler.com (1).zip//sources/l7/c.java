package l7;

import android.os.Parcel;
import android.os.Parcelable;
import s6.b;

public final class c implements Parcelable.Creator {
    public final /* bridge */ /* synthetic */ Object createFromParcel(Parcel parcel) {
        int w10 = b.w(parcel);
        boolean[] zArr = null;
        boolean[] zArr2 = null;
        boolean z10 = false;
        boolean z11 = false;
        boolean z12 = false;
        while (parcel.dataPosition() < w10) {
            int p10 = b.p(parcel);
            int k10 = b.k(p10);
            if (k10 == 1) {
                z10 = b.l(parcel, p10);
            } else if (k10 == 2) {
                z11 = b.l(parcel, p10);
            } else if (k10 == 3) {
                z12 = b.l(parcel, p10);
            } else if (k10 == 4) {
                zArr = b.a(parcel, p10);
            } else if (k10 != 5) {
                b.v(parcel, p10);
            } else {
                zArr2 = b.a(parcel, p10);
            }
        }
        b.j(parcel, w10);
        return new a(z10, z11, z12, zArr, zArr2);
    }

    public final /* synthetic */ Object[] newArray(int i10) {
        return new a[i10];
    }
}
