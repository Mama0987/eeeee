package l7;

@Deprecated
public interface b {
}
