package la;

import com.twitter.sdk.android.core.e;
import com.twitter.sdk.android.core.internal.oauth.a;
import ic.d;
import ic.g0;
import ic.i0;
import ic.k0;
import ic.y;
import java.io.IOException;

public class c implements d {

    /* renamed from: b  reason: collision with root package name */
    final e f12777b;

    public c(e eVar) {
        this.f12777b = eVar;
    }

    private boolean b(i0 i0Var) {
        int i10 = 1;
        while (true) {
            i0Var = i0Var.o();
            if (i0Var == null) {
                break;
            }
            i10++;
        }
        return i10 < 2;
    }

    private com.twitter.sdk.android.core.d c(i0 i0Var) {
        y d10 = i0Var.t().d();
        String c10 = d10.c("Authorization");
        String c11 = d10.c("x-guest-token");
        if (c10 == null || c11 == null) {
            return null;
        }
        return new com.twitter.sdk.android.core.d(new a("bearer", c10.replace("bearer ", ""), c11));
    }

    private g0 d(i0 i0Var) {
        if (b(i0Var)) {
            com.twitter.sdk.android.core.d d10 = this.f12777b.d(c(i0Var));
            a aVar = d10 == null ? null : (a) d10.a();
            if (aVar != null) {
                return e(i0Var.t(), aVar);
            }
        }
        return null;
    }

    private g0 e(g0 g0Var, a aVar) {
        g0.a h10 = g0Var.h();
        a.a(h10, aVar);
        return h10.b();
    }

    public g0 a(k0 k0Var, i0 i0Var) throws IOException {
        return d(i0Var);
    }
}
