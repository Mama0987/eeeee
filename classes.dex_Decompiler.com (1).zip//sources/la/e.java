package la;

import com.twitter.sdk.android.core.j;
import com.twitter.sdk.android.core.o;
import com.twitter.sdk.android.core.r;
import ic.d0;
import ic.i;
import java.util.concurrent.TimeUnit;
import tc.a;

public class e {
    private static d0.b a(d0.b bVar, com.twitter.sdk.android.core.e eVar) {
        return bVar.g(c()).c(new c(eVar)).a(new a(eVar)).b(new b());
    }

    private static d0.b b(d0.b bVar, j<? extends r> jVar, o oVar) {
        a aVar = new a();
        aVar.d(a.C0286a.BODY);
        d0.b g10 = bVar.g(c());
        TimeUnit timeUnit = TimeUnit.SECONDS;
        return g10.h(15, timeUnit).l(15, timeUnit).a(new d(jVar, oVar)).a(aVar);
    }

    public static i c() {
        return i.f11632c;
    }

    public static d0 d(com.twitter.sdk.android.core.e eVar) {
        return a(new d0.b(), eVar).d();
    }

    public static d0 e(j<? extends r> jVar, o oVar) {
        if (jVar != null) {
            return b(new d0.b(), jVar, oVar).d();
        }
        throw new IllegalArgumentException("Session must not be null.");
    }
}
