package la;

import androidx.annotation.NonNull;
import com.twitter.sdk.android.core.d;
import com.twitter.sdk.android.core.e;
import ic.a0;
import ic.g0;
import ic.i0;
import java.io.IOException;

public class a implements a0 {

    /* renamed from: a  reason: collision with root package name */
    final e f12776a;

    public a(e eVar) {
        this.f12776a = eVar;
    }

    static void a(g0.a aVar, com.twitter.sdk.android.core.internal.oauth.a aVar2) {
        aVar.d("Authorization", aVar2.j() + " " + aVar2.a());
        aVar.d("x-guest-token", aVar2.k());
    }

    @NonNull
    public i0 intercept(a0.a aVar) throws IOException {
        g0 d10 = aVar.d();
        d b10 = this.f12776a.b();
        com.twitter.sdk.android.core.internal.oauth.a aVar2 = b10 == null ? null : (com.twitter.sdk.android.core.internal.oauth.a) b10.a();
        if (aVar2 == null) {
            return aVar.f(d10);
        }
        g0.a h10 = d10.h();
        a(h10, aVar2);
        return aVar.f(h10.b());
    }
}
