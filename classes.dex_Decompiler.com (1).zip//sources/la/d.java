package la;

import androidx.annotation.NonNull;
import com.twitter.sdk.android.core.internal.oauth.c;
import com.twitter.sdk.android.core.j;
import com.twitter.sdk.android.core.o;
import com.twitter.sdk.android.core.r;
import ic.a0;
import ic.g0;
import ic.h0;
import ic.i0;
import ic.w;
import ic.z;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class d implements a0 {

    /* renamed from: a  reason: collision with root package name */
    final j<? extends r> f12778a;

    /* renamed from: b  reason: collision with root package name */
    final o f12779b;

    public d(j<? extends r> jVar, o oVar) {
        this.f12778a = jVar;
        this.f12779b = oVar;
    }

    private String a(g0 g0Var) {
        return new c().a(this.f12779b, (r) this.f12778a.a(), (String) null, g0Var.g(), g0Var.j().toString(), b(g0Var));
    }

    private Map<String, String> b(g0 g0Var) {
        HashMap hashMap = new HashMap();
        if ("POST".equals(g0Var.g().toUpperCase(Locale.US))) {
            h0 a10 = g0Var.a();
            if (a10 instanceof w) {
                w wVar = (w) a10;
                for (int i10 = 0; i10 < wVar.m(); i10++) {
                    hashMap.put(wVar.k(i10), wVar.n(i10));
                }
            }
        }
        return hashMap;
    }

    private z c(z zVar) {
        z.a q10 = zVar.p().q((String) null);
        int F = zVar.F();
        for (int i10 = 0; i10 < F; i10++) {
            q10.a(f.c(zVar.C(i10)), f.c(zVar.E(i10)));
        }
        return q10.c();
    }

    @NonNull
    public i0 intercept(a0.a aVar) throws IOException {
        g0 d10 = aVar.d();
        g0 b10 = d10.h().j(c(d10.j())).b();
        return aVar.f(b10.h().d("Authorization", a(b10)).b());
    }
}
