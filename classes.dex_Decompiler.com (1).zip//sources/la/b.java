package la;

import androidx.annotation.NonNull;
import ic.a0;
import ic.i0;
import java.io.IOException;

public class b implements a0 {
    @NonNull
    public i0 intercept(a0.a aVar) throws IOException {
        i0 f10 = aVar.f(aVar.d());
        return f10.c() == 403 ? f10.n().g(401).l("Unauthorized").c() : f10;
    }
}
