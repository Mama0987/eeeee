package q1;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class i {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final String f13993a;

    static {
        String i10 = n.i("ConstraintTracker");
        Intrinsics.checkNotNullExpressionValue(i10, "tagWithPrefix(\"ConstraintTracker\")");
        f13993a = i10;
    }
}
