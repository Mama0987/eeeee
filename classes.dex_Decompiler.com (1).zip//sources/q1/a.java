package q1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import org.jetbrains.annotations.NotNull;
import t1.c;

@Metadata
public final class a extends e<Boolean> {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(@NotNull Context context, @NotNull c cVar) {
        super(context, cVar);
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
    }

    private final boolean l(Intent intent) {
        if (Build.VERSION.SDK_INT >= 23) {
            int intExtra = intent.getIntExtra("status", -1);
            if (intExtra == 2 || intExtra == 5) {
                return true;
            }
        } else if (intent.getIntExtra("plugged", 0) != 0) {
            return true;
        }
        return false;
    }

    @NotNull
    public IntentFilter j() {
        String str;
        IntentFilter intentFilter = new IntentFilter();
        if (Build.VERSION.SDK_INT >= 23) {
            intentFilter.addAction("android.os.action.CHARGING");
            str = "android.os.action.DISCHARGING";
        } else {
            intentFilter.addAction("android.intent.action.ACTION_POWER_CONNECTED");
            str = "android.intent.action.ACTION_POWER_DISCONNECTED";
        }
        intentFilter.addAction(str);
        return intentFilter;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0057, code lost:
        r5 = java.lang.Boolean.FALSE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0059, code lost:
        g(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0042, code lost:
        r5 = java.lang.Boolean.TRUE;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void k(@org.jetbrains.annotations.NotNull android.content.Intent r5) {
        /*
            r4 = this;
            java.lang.String r0 = "intent"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r5 = r5.getAction()
            if (r5 != 0) goto L_0x000c
            return
        L_0x000c:
            m1.n r0 = m1.n.e()
            java.lang.String r1 = q1.b.f13981a
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Received "
            r2.append(r3)
            r2.append(r5)
            java.lang.String r2 = r2.toString()
            r0.a(r1, r2)
            int r0 = r5.hashCode()
            switch(r0) {
                case -1886648615: goto L_0x004e;
                case -54942926: goto L_0x0045;
                case 948344062: goto L_0x0039;
                case 1019184907: goto L_0x0030;
                default: goto L_0x002f;
            }
        L_0x002f:
            goto L_0x005c
        L_0x0030:
            java.lang.String r0 = "android.intent.action.ACTION_POWER_CONNECTED"
            boolean r5 = r5.equals(r0)
            if (r5 != 0) goto L_0x0042
            goto L_0x005c
        L_0x0039:
            java.lang.String r0 = "android.os.action.CHARGING"
            boolean r5 = r5.equals(r0)
            if (r5 != 0) goto L_0x0042
            goto L_0x005c
        L_0x0042:
            java.lang.Boolean r5 = java.lang.Boolean.TRUE
            goto L_0x0059
        L_0x0045:
            java.lang.String r0 = "android.os.action.DISCHARGING"
            boolean r5 = r5.equals(r0)
            if (r5 != 0) goto L_0x0057
            goto L_0x005c
        L_0x004e:
            java.lang.String r0 = "android.intent.action.ACTION_POWER_DISCONNECTED"
            boolean r5 = r5.equals(r0)
            if (r5 != 0) goto L_0x0057
            goto L_0x005c
        L_0x0057:
            java.lang.Boolean r5 = java.lang.Boolean.FALSE
        L_0x0059:
            r4.g(r5)
        L_0x005c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: q1.a.k(android.content.Intent):void");
    }

    @NotNull
    /* renamed from: m */
    public Boolean e() {
        Intent registerReceiver = d().registerReceiver((BroadcastReceiver) null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        if (registerReceiver != null) {
            return Boolean.valueOf(l(registerReceiver));
        }
        n.e().c(b.f13981a, "getInitialState - null intent received");
        return Boolean.FALSE;
    }
}
