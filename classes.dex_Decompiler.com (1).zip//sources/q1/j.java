package q1;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import o1.c;
import org.jetbrains.annotations.NotNull;
import s1.m;
import s1.q;

@Metadata
public final class j extends h<c> {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    public final ConnectivityManager f13994f;
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    private final a f13995g = new a(this);

    @Metadata
    public static final class a extends ConnectivityManager.NetworkCallback {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ j f13996a;

        a(j jVar) {
            this.f13996a = jVar;
        }

        public void onCapabilitiesChanged(@NotNull Network network, @NotNull NetworkCapabilities networkCapabilities) {
            Intrinsics.checkNotNullParameter(network, "network");
            Intrinsics.checkNotNullParameter(networkCapabilities, "capabilities");
            n e10 = n.e();
            String b10 = k.f13997a;
            e10.a(b10, "Network capabilities changed: " + networkCapabilities);
            j jVar = this.f13996a;
            jVar.g(k.c(jVar.f13994f));
        }

        public void onLost(@NotNull Network network) {
            Intrinsics.checkNotNullParameter(network, "network");
            n.e().a(k.f13997a, "Network connection lost");
            j jVar = this.f13996a;
            jVar.g(k.c(jVar.f13994f));
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(@NotNull Context context, @NotNull t1.c cVar) {
        super(context, cVar);
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
        Object systemService = d().getSystemService("connectivity");
        Intrinsics.d(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
        this.f13994f = (ConnectivityManager) systemService;
    }

    public void h() {
        try {
            n.e().a(k.f13997a, "Registering network callback");
            q.a(this.f13994f, this.f13995g);
        } catch (IllegalArgumentException | SecurityException e10) {
            n.e().d(k.f13997a, "Received exception while registering network callback", e10);
        }
    }

    public void i() {
        try {
            n.e().a(k.f13997a, "Unregistering network callback");
            m.c(this.f13994f, this.f13995g);
        } catch (IllegalArgumentException | SecurityException e10) {
            n.e().d(k.f13997a, "Received exception while unregistering network callback", e10);
        }
    }

    @NotNull
    /* renamed from: k */
    public c e() {
        return k.c(this.f13994f);
    }
}
