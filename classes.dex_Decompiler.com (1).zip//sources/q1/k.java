package q1;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import o1.c;
import org.jetbrains.annotations.NotNull;
import s1.m;
import s1.o;
import x.a;

@Metadata
public final class k {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final String f13997a;

    static {
        String i10 = n.i("NetworkStateTracker");
        Intrinsics.checkNotNullExpressionValue(i10, "tagWithPrefix(\"NetworkStateTracker\")");
        f13997a = i10;
    }

    @NotNull
    public static final h<c> a(@NotNull Context context, @NotNull t1.c cVar) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
        return Build.VERSION.SDK_INT >= 24 ? new j(context, cVar) : new l(context, cVar);
    }

    @NotNull
    public static final c c(@NotNull ConnectivityManager connectivityManager) {
        Intrinsics.checkNotNullParameter(connectivityManager, "<this>");
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        boolean z10 = true;
        boolean z11 = activeNetworkInfo != null && activeNetworkInfo.isConnected();
        boolean d10 = d(connectivityManager);
        boolean a10 = a.a(connectivityManager);
        if (activeNetworkInfo == null || activeNetworkInfo.isRoaming()) {
            z10 = false;
        }
        return new c(z11, d10, a10, z10);
    }

    public static final boolean d(@NotNull ConnectivityManager connectivityManager) {
        Intrinsics.checkNotNullParameter(connectivityManager, "<this>");
        if (Build.VERSION.SDK_INT < 23) {
            return false;
        }
        try {
            NetworkCapabilities a10 = m.a(connectivityManager, o.a(connectivityManager));
            if (a10 != null) {
                return m.b(a10, 16);
            }
            return false;
        } catch (SecurityException e10) {
            n.e().d(f13997a, "Unable to validate active network", e10);
            return false;
        }
    }
}
