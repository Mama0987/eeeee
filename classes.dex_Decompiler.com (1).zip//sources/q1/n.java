package q1;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class n {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final String f13999a;

    static {
        String i10 = m1.n.i("StorageNotLowTracker");
        Intrinsics.checkNotNullExpressionValue(i10, "tagWithPrefix(\"StorageNotLowTracker\")");
        f13999a = i10;
    }
}
