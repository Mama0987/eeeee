package q1;

import android.content.Context;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import o1.c;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class o {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final h<Boolean> f14000a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private final c f14001b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private final h<c> f14002c;
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private final h<Boolean> f14003d;

    public o(@NotNull Context context, @NotNull t1.c cVar, @NotNull h<Boolean> hVar, @NotNull c cVar2, @NotNull h<c> hVar2, @NotNull h<Boolean> hVar3) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
        Intrinsics.checkNotNullParameter(hVar, "batteryChargingTracker");
        Intrinsics.checkNotNullParameter(cVar2, "batteryNotLowTracker");
        Intrinsics.checkNotNullParameter(hVar2, "networkStateTracker");
        Intrinsics.checkNotNullParameter(hVar3, "storageNotLowTracker");
        this.f14000a = hVar;
        this.f14001b = cVar2;
        this.f14002c = hVar2;
        this.f14003d = hVar3;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public /* synthetic */ o(android.content.Context r8, t1.c r9, q1.h r10, q1.c r11, q1.h r12, q1.h r13, int r14, kotlin.jvm.internal.DefaultConstructorMarker r15) {
        /*
            r7 = this;
            r0 = r14 & 4
            java.lang.String r1 = "context.applicationContext"
            if (r0 == 0) goto L_0x0014
            q1.a r0 = new q1.a
            android.content.Context r3 = r8.getApplicationContext()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r1)
            r0.<init>(r3, r9)
            r3 = r0
            goto L_0x0015
        L_0x0014:
            r3 = r10
        L_0x0015:
            r0 = r14 & 8
            if (r0 == 0) goto L_0x0027
            q1.c r0 = new q1.c
            android.content.Context r4 = r8.getApplicationContext()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r1)
            r0.<init>(r4, r9)
            r4 = r0
            goto L_0x0028
        L_0x0027:
            r4 = r11
        L_0x0028:
            r0 = r14 & 16
            if (r0 == 0) goto L_0x0039
            android.content.Context r0 = r8.getApplicationContext()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            q1.h r0 = q1.k.a(r0, r9)
            r5 = r0
            goto L_0x003a
        L_0x0039:
            r5 = r12
        L_0x003a:
            r0 = r14 & 32
            if (r0 == 0) goto L_0x004c
            q1.m r0 = new q1.m
            android.content.Context r6 = r8.getApplicationContext()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r1)
            r0.<init>(r6, r9)
            r6 = r0
            goto L_0x004d
        L_0x004c:
            r6 = r13
        L_0x004d:
            r0 = r7
            r1 = r8
            r2 = r9
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: q1.o.<init>(android.content.Context, t1.c, q1.h, q1.c, q1.h, q1.h, int, kotlin.jvm.internal.DefaultConstructorMarker):void");
    }

    @NotNull
    public final h<Boolean> a() {
        return this.f14000a;
    }

    @NotNull
    public final c b() {
        return this.f14001b;
    }

    @NotNull
    public final h<c> c() {
        return this.f14002c;
    }

    @NotNull
    public final h<Boolean> d() {
        return this.f14003d;
    }
}
