package q1;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import o1.c;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class l extends e<c> {
    @NotNull

    /* renamed from: g  reason: collision with root package name */
    private final ConnectivityManager f13998g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l(@NotNull Context context, @NotNull t1.c cVar) {
        super(context, cVar);
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
        Object systemService = d().getSystemService("connectivity");
        Intrinsics.d(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
        this.f13998g = (ConnectivityManager) systemService;
    }

    @NotNull
    public IntentFilter j() {
        return new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
    }

    public void k(@NotNull Intent intent) {
        Intrinsics.checkNotNullParameter(intent, "intent");
        if (Intrinsics.a(intent.getAction(), "android.net.conn.CONNECTIVITY_CHANGE")) {
            n.e().a(k.f13997a, "Network broadcast received");
            g(k.c(this.f13998g));
        }
    }

    @NotNull
    /* renamed from: l */
    public c e() {
        return k.c(this.f13998g);
    }
}
