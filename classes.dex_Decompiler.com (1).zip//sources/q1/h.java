package q1;

import android.content.Context;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import o1.a;
import org.jetbrains.annotations.NotNull;
import t1.c;

@Metadata
public abstract class h<T> {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final c f13988a;
    @NotNull

    /* renamed from: b  reason: collision with root package name */
    private final Context f13989b;
    @NotNull

    /* renamed from: c  reason: collision with root package name */
    private final Object f13990c = new Object();
    @NotNull

    /* renamed from: d  reason: collision with root package name */
    private final LinkedHashSet<a<T>> f13991d = new LinkedHashSet<>();

    /* renamed from: e  reason: collision with root package name */
    private T f13992e;

    protected h(@NotNull Context context, @NotNull c cVar) {
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
        this.f13988a = cVar;
        Context applicationContext = context.getApplicationContext();
        Intrinsics.checkNotNullExpressionValue(applicationContext, "context.applicationContext");
        this.f13989b = applicationContext;
    }

    /* access modifiers changed from: private */
    public static final void b(List list, h hVar) {
        Intrinsics.checkNotNullParameter(list, "$listenersList");
        Intrinsics.checkNotNullParameter(hVar, "this$0");
        Iterator it = list.iterator();
        while (it.hasNext()) {
            ((a) it.next()).a(hVar.f13992e);
        }
    }

    public final void c(@NotNull a<T> aVar) {
        Intrinsics.checkNotNullParameter(aVar, "listener");
        synchronized (this.f13990c) {
            if (this.f13991d.add(aVar)) {
                if (this.f13991d.size() == 1) {
                    this.f13992e = e();
                    n e10 = n.e();
                    String a10 = i.f13993a;
                    e10.a(a10, getClass().getSimpleName() + ": initial state = " + this.f13992e);
                    h();
                }
                aVar.a(this.f13992e);
            }
            Unit unit = Unit.f12470a;
        }
    }

    /* access modifiers changed from: protected */
    @NotNull
    public final Context d() {
        return this.f13989b;
    }

    public abstract T e();

    public final void f(@NotNull a<T> aVar) {
        Intrinsics.checkNotNullParameter(aVar, "listener");
        synchronized (this.f13990c) {
            if (this.f13991d.remove(aVar) && this.f13991d.isEmpty()) {
                i();
            }
            Unit unit = Unit.f12470a;
        }
    }

    public final void g(T t10) {
        synchronized (this.f13990c) {
            T t11 = this.f13992e;
            if (t11 == null || !Intrinsics.a(t11, t10)) {
                this.f13992e = t10;
                this.f13988a.b().execute(new g(CollectionsKt___CollectionsKt.Z(this.f13991d), this));
                Unit unit = Unit.f12470a;
            }
        }
    }

    public abstract void h();

    public abstract void i();
}
