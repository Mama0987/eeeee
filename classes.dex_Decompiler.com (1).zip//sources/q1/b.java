package q1;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class b {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final String f13981a;

    static {
        String i10 = n.i("BatteryChrgTracker");
        Intrinsics.checkNotNullExpressionValue(i10, "tagWithPrefix(\"BatteryChrgTracker\")");
        f13981a = i10;
    }
}
