package q1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import org.jetbrains.annotations.NotNull;
import t1.c;

@Metadata
public abstract class e<T> extends h<T> {
    @NotNull

    /* renamed from: f  reason: collision with root package name */
    private final BroadcastReceiver f13983f = new a(this);

    @Metadata
    public static final class a extends BroadcastReceiver {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ e<T> f13984a;

        a(e<T> eVar) {
            this.f13984a = eVar;
        }

        public void onReceive(@NotNull Context context, @NotNull Intent intent) {
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(intent, "intent");
            this.f13984a.k(intent);
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e(@NotNull Context context, @NotNull c cVar) {
        super(context, cVar);
        Intrinsics.checkNotNullParameter(context, "context");
        Intrinsics.checkNotNullParameter(cVar, "taskExecutor");
    }

    public void h() {
        n e10 = n.e();
        String a10 = f.f13985a;
        e10.a(a10, getClass().getSimpleName() + ": registering receiver");
        d().registerReceiver(this.f13983f, j());
    }

    public void i() {
        n e10 = n.e();
        String a10 = f.f13985a;
        e10.a(a10, getClass().getSimpleName() + ": unregistering receiver");
        d().unregisterReceiver(this.f13983f);
    }

    @NotNull
    public abstract IntentFilter j();

    public abstract void k(@NotNull Intent intent);
}
