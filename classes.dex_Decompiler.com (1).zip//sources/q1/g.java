package q1;

import java.util.List;

public final /* synthetic */ class g implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ List f13986a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ h f13987b;

    public /* synthetic */ g(List list, h hVar) {
        this.f13986a = list;
        this.f13987b = hVar;
    }

    public final void run() {
        h.b(this.f13986a, this.f13987b);
    }
}
