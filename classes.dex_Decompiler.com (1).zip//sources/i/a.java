package i;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import androidx.annotation.NonNull;
import h.d;
import h.e;
import j.a;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;

public class a {

    /* renamed from: a  reason: collision with root package name */
    private final Context f11302a;
    @NonNull

    /* renamed from: b  reason: collision with root package name */
    private final C0177a f11303b;
    @NonNull

    /* renamed from: c  reason: collision with root package name */
    private final String f11304c;
    @NonNull

    /* renamed from: d  reason: collision with root package name */
    private final j.a f11305d;

    /* renamed from: e  reason: collision with root package name */
    private final AtomicLong f11306e = new AtomicLong(0);

    /* renamed from: i.a$a  reason: collision with other inner class name */
    class C0177a implements ServiceConnection {

        /* renamed from: a  reason: collision with root package name */
        private final BlockingQueue<IBinder> f11307a = new LinkedBlockingQueue();

        C0177a() {
        }

        /* access modifiers changed from: package-private */
        @NonNull
        public IBinder a() throws InterruptedException, TimeoutException {
            IBinder poll = this.f11307a.poll(10, TimeUnit.SECONDS);
            if (poll != null) {
                return poll;
            }
            throw new TimeoutException("Timed out waiting for the service connection");
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            this.f11307a.add(iBinder);
        }

        public void onServiceDisconnected(ComponentName componentName) {
            a.this.b();
        }
    }

    public a(@NonNull Context context) throws d, IOException, TimeoutException, InterruptedException {
        this.f11302a = context;
        ComponentName f10 = f(context);
        this.f11303b = g(f10);
        this.f11305d = d();
        this.f11304c = f10.getPackageName();
    }

    private static ComponentName f(Context context) throws d {
        PackageManager packageManager = context.getPackageManager();
        ServiceInfo e10 = e.e(e.a(packageManager), packageManager);
        if (e10 != null) {
            return new ComponentName(e10.packageName, e10.name);
        }
        throw new d("No compatible AndroidX Advertising ID Provider available.");
    }

    public long a() {
        return this.f11306e.incrementAndGet();
    }

    /* access modifiers changed from: package-private */
    public void b() {
        if (this.f11306e.getAndSet(Long.MIN_VALUE) >= 0) {
            this.f11302a.unbindService(this.f11303b);
        }
    }

    @NonNull
    public j.a c() {
        return this.f11305d;
    }

    /* access modifiers changed from: package-private */
    public j.a d() throws TimeoutException, InterruptedException {
        return a.C0181a.k(this.f11303b.a());
    }

    @NonNull
    public String e() {
        return this.f11304c;
    }

    /* access modifiers changed from: package-private */
    public C0177a g(ComponentName componentName) throws IOException {
        Intent intent = new Intent("androidx.ads.identifier.provider.GET_AD_ID");
        intent.setComponent(componentName);
        C0177a aVar = new C0177a();
        if (this.f11302a.bindService(intent, aVar, 1)) {
            return aVar;
        }
        throw new IOException("Connection failure");
    }

    public boolean h() {
        return this.f11306e.get() >= 0;
    }

    public boolean i(long j10) {
        if (!this.f11306e.compareAndSet(j10, Long.MIN_VALUE)) {
            return !h();
        }
        this.f11302a.unbindService(this.f11303b);
        return true;
    }
}
