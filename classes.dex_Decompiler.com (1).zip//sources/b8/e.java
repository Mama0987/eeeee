package b8;

import android.app.PendingIntent;

final class e extends b {

    /* renamed from: a  reason: collision with root package name */
    private final PendingIntent f4323a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f4324b;

    e(PendingIntent pendingIntent, boolean z10) {
        if (pendingIntent != null) {
            this.f4323a = pendingIntent;
            this.f4324b = z10;
            return;
        }
        throw new NullPointerException("Null pendingIntent");
    }

    /* access modifiers changed from: package-private */
    public final PendingIntent a() {
        return this.f4323a;
    }

    /* access modifiers changed from: package-private */
    public final boolean c() {
        return this.f4324b;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof b) {
            b bVar = (b) obj;
            return this.f4323a.equals(bVar.a()) && this.f4324b == bVar.c();
        }
    }

    public final int hashCode() {
        return ((this.f4323a.hashCode() ^ 1000003) * 1000003) ^ (true != this.f4324b ? 1237 : 1231);
    }

    public final String toString() {
        String obj = this.f4323a.toString();
        boolean z10 = this.f4324b;
        return "ReviewInfo{pendingIntent=" + obj + ", isNoOp=" + z10 + "}";
    }
}
