package b8;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import c8.i;
import c8.o;
import c8.t;
import c8.w;
import com.google.android.gms.common.GoogleApiAvailabilityLight;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.b;

@SuppressLint({"RestrictedApi"})
public final class m {
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public static final i f4335c = new i("ReviewService");

    /* renamed from: a  reason: collision with root package name */
    t f4336a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final String f4337b;

    public m(Context context) {
        this.f4337b = context.getPackageName();
        if (w.a(context)) {
            Context context2 = context;
            this.f4336a = new t(context2, f4335c, "com.google.android.finsky.inappreviewservice.InAppReviewService", new Intent("com.google.android.finsky.BIND_IN_APP_REVIEW_SERVICE").setPackage(GoogleApiAvailabilityLight.GOOGLE_PLAY_STORE_PACKAGE), i.f4328a, (o) null, (byte[]) null);
        }
    }

    public final Task a() {
        i iVar = f4335c;
        iVar.d("requestInAppReview (%s)", this.f4337b);
        if (this.f4336a == null) {
            iVar.b("Play Store app is either not installed or not the official version", new Object[0]);
            return b.d(new a(-1));
        }
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
        this.f4336a.p(new j(this, taskCompletionSource, taskCompletionSource), taskCompletionSource);
        return taskCompletionSource.a();
    }
}
