package b8;

public final /* synthetic */ class i {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ i f4328a = new i();

    private /* synthetic */ i() {
    }
}
