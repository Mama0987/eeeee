package b8;

import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.tasks.TaskCompletionSource;

final class j extends c8.j {

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ TaskCompletionSource f4329b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ m f4330c;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    j(m mVar, TaskCompletionSource taskCompletionSource, TaskCompletionSource taskCompletionSource2) {
        super(taskCompletionSource);
        this.f4330c = mVar;
        this.f4329b = taskCompletionSource2;
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [c8.f, android.os.IInterface] */
    /* access modifiers changed from: protected */
    public final void a() {
        try {
            ? e10 = this.f4330c.f4336a.e();
            String c10 = this.f4330c.f4337b;
            Bundle a10 = n.a();
            m mVar = this.f4330c;
            e10.x0(c10, a10, new l(mVar, this.f4329b, mVar.f4337b));
        } catch (RemoteException e11) {
            m.f4335c.c(e11, "error requesting in-app review for %s", this.f4330c.f4337b);
            this.f4329b.d(new RuntimeException(e11));
        }
    }
}
