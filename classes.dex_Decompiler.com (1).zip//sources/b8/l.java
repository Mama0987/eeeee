package b8;

import android.app.PendingIntent;
import android.os.Bundle;
import android.os.RemoteException;
import c8.i;
import com.google.android.gms.tasks.TaskCompletionSource;

final class l extends k {

    /* renamed from: h  reason: collision with root package name */
    final String f4334h;

    l(m mVar, TaskCompletionSource taskCompletionSource, String str) {
        super(mVar, new i("OnRequestInstallCallback"), taskCompletionSource);
        this.f4334h = str;
    }

    public final void F0(Bundle bundle) throws RemoteException {
        super.F0(bundle);
        this.f4332f.e(new e((PendingIntent) bundle.get("confirmation_intent"), bundle.getBoolean("is_review_no_op")));
    }
}
