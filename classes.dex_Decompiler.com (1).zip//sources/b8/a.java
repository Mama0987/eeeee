package b8;

import com.google.android.gms.common.api.Status;
import java.util.Locale;

public class a extends o6.a {
    public a(int i10) {
        super(new Status(i10, String.format(Locale.getDefault(), "Review Error(%d): %s", new Object[]{Integer.valueOf(i10), d8.a.a(i10)})));
    }
}
