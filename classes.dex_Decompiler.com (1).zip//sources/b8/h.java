package b8;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.b;
import com.google.android.play.core.common.PlayCoreDialogWrapperActivity;

@SuppressLint({"RestrictedApi"})
public final class h implements c {

    /* renamed from: a  reason: collision with root package name */
    private final m f4326a;

    /* renamed from: b  reason: collision with root package name */
    private final Handler f4327b = new Handler(Looper.getMainLooper());

    h(m mVar) {
        this.f4326a = mVar;
    }

    @NonNull
    public final Task<Void> a(@NonNull Activity activity, @NonNull b bVar) {
        if (bVar.c()) {
            return b.e(null);
        }
        Intent intent = new Intent(activity, PlayCoreDialogWrapperActivity.class);
        intent.putExtra("confirmation_intent", bVar.a());
        intent.putExtra("window_flags", activity.getWindow().getDecorView().getWindowSystemUiVisibility());
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource();
        intent.putExtra("result_receiver", new g(this, this.f4327b, taskCompletionSource));
        activity.startActivity(intent);
        return taskCompletionSource.a();
    }

    @NonNull
    public final Task<b> b() {
        return this.f4326a.a();
    }
}
