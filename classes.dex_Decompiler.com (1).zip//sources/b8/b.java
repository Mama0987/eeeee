package b8;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"RestrictedApi"})
public abstract class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new f();

    /* access modifiers changed from: package-private */
    public abstract PendingIntent a();

    /* access modifiers changed from: package-private */
    public abstract boolean c();

    public final int describeContents() {
        return 0;
    }

    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeParcelable(a(), 0);
        parcel.writeInt(c() ? 1 : 0);
    }
}
