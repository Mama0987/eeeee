package b8;

import android.app.Activity;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;

public interface c {
    @NonNull
    Task<Void> a(@NonNull Activity activity, @NonNull b bVar);

    @NonNull
    Task<b> b();
}
