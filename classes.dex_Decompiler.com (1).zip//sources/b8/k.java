package b8;

import android.os.Bundle;
import android.os.RemoteException;
import c8.g;
import c8.i;
import c8.t;
import com.google.android.gms.tasks.TaskCompletionSource;

class k extends g {

    /* renamed from: e  reason: collision with root package name */
    final i f4331e;

    /* renamed from: f  reason: collision with root package name */
    final TaskCompletionSource f4332f;

    /* renamed from: g  reason: collision with root package name */
    final /* synthetic */ m f4333g;

    k(m mVar, i iVar, TaskCompletionSource taskCompletionSource) {
        this.f4333g = mVar;
        this.f4331e = iVar;
        this.f4332f = taskCompletionSource;
    }

    public void F0(Bundle bundle) throws RemoteException {
        t tVar = this.f4333g.f4336a;
        if (tVar != null) {
            tVar.r(this.f4332f);
        }
        this.f4331e.d("onGetLaunchReviewFlowInfo", new Object[0]);
    }
}
