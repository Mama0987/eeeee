package q2;

import android.app.Activity;
import android.net.Uri;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.beetalk.sdk.plugin.PluginResult;
import e5.g;
import v3.o;
import v3.r;

public class e extends a<r2.a, PluginResult> {

    class a extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Exception f14020a;

        a(Exception exc) {
            this.f14020a = exc;
            this.source = e.this.d();
            this.status = -1;
            this.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            this.message = exc.getMessage();
        }
    }

    class b implements o<c5.a> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14022a;

        b(Activity activity) {
            this.f14022a = activity;
        }

        public void a(@NonNull r rVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = e.this.d();
            pluginResult.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            pluginResult.status = -1;
            pluginResult.message = rVar.getMessage();
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14022a, e.this.d());
        }

        /* renamed from: b */
        public void onSuccess(c5.a aVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = e.this.d();
            pluginResult.status = 0;
            pluginResult.flag = com.garena.pay.android.b.SUCCESS.g().intValue();
            pluginResult.message = "Successfully send msg";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14022a, e.this.d());
        }

        public void onCancel() {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = e.this.d();
            pluginResult.flag = com.garena.pay.android.b.USER_CANCELLED.g().intValue();
            pluginResult.status = -1;
            pluginResult.message = "Send msg cancelled";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14022a, e.this.d());
        }
    }

    public String d() {
        return "facebook.message";
    }

    public Integer e() {
        return 2884;
    }

    public void j(Exception exc, Activity activity) {
        com.beetalk.sdk.plugin.b.j().n(new a(exc), activity, d());
    }

    public void l(Activity activity) {
        S s10 = this.f14004a;
        if (s10 == null || TextUtils.isEmpty(((r2.a) s10).f14606d)) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = d();
            pluginResult.flag = com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue();
            pluginResult.status = -1;
            pluginResult.message = "The content url is empty";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, activity, d());
            return;
        }
        f5.a aVar = new f5.a(activity);
        aVar.j(this.f14005b, new b(activity));
        g.a aVar2 = (g.a) new g.a().h(Uri.parse(((r2.a) this.f14004a).f14606d));
        if (f5.a.p(g.class)) {
            aVar.l(aVar2.n());
        } else {
            com.beetalk.sdk.plugin.b.j().n(c(com.garena.pay.android.b.UNSUPPORTED_API.g().intValue(), "Cannot show Messenger dialog"), activity, d());
        }
    }
}
