package q2;

import a5.d0;
import a5.g0;
import android.app.Activity;
import android.content.Intent;
import com.beetalk.sdk.plugin.GGPluginActivity;
import com.beetalk.sdk.s;
import v3.m;
import v3.o;

public abstract class a<S, T> extends com.beetalk.sdk.plugin.a<S, T> {

    /* renamed from: a  reason: collision with root package name */
    protected S f14004a;

    /* renamed from: b  reason: collision with root package name */
    protected m f14005b;

    /* renamed from: q2.a$a  reason: collision with other inner class name */
    class C0235a implements o<g0> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14006a;

        C0235a(Activity activity) {
            this.f14006a = activity;
        }

        /* JADX WARNING: type inference failed for: r3v2, types: [f2.a] */
        /* JADX WARNING: Failed to insert additional move for type inference */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void a(v3.r r3) {
            /*
                r2 = this;
                if (r3 != 0) goto L_0x0009
                f2.a r3 = new f2.a
                java.lang.String r0 = "Login Failed for some reason"
                r3.<init>(r0)
            L_0x0009:
                q2.a r0 = q2.a.this
                android.app.Activity r1 = r2.f14006a
                r0.j(r3, r1)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: q2.a.C0235a.a(v3.r):void");
        }

        /* renamed from: b */
        public void onSuccess(g0 g0Var) {
            if (g0Var.a() != null) {
                a.this.l(this.f14006a);
            }
        }

        public void onCancel() {
            a.this.j(new f2.a("Login Cancelled"), this.f14006a);
        }
    }

    private boolean m(Activity activity) {
        v3.a k10 = v3.a.k();
        if (k10 == null || k10.z()) {
            d0.i().s(this.f14005b, new C0235a(activity));
            d0.i().m(activity, s.v());
            return true;
        }
        l(activity);
        return true;
    }

    /* access modifiers changed from: protected */
    public void b(Activity activity, S s10) {
        this.f14004a = s10;
        this.f14005b = m.a.a();
        m(activity);
    }

    public boolean f(Activity activity, int i10, Intent intent) {
        return false;
    }

    public abstract void j(Exception exc, Activity activity);

    public boolean k(int i10, int i11, Intent intent, GGPluginActivity gGPluginActivity) {
        return this.f14005b.a(i10, i11, intent);
    }

    public abstract void l(Activity activity);
}
