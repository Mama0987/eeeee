package q2;

import android.app.Activity;
import com.beetalk.sdk.plugin.PluginResult;
import e5.c;
import java.util.Collections;
import n4.a;
import v3.o;
import v3.r;

public class c extends a<r2.a, PluginResult> {

    class a extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Exception f14010a;

        a(Exception exc) {
            this.f14010a = exc;
            this.source = c.this.d();
            this.status = -1;
            this.flag = com.garena.pay.android.b.LOGIN_FAILED.g().intValue();
            this.message = exc.getMessage();
        }
    }

    class b implements o<a.f> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14012a;

        b(Activity activity) {
            this.f14012a = activity;
        }

        public void a(r rVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = c.this.d();
            pluginResult.status = -1;
            pluginResult.flag = com.garena.pay.android.b.ERROR.g().intValue();
            pluginResult.message = rVar != null ? rVar.getMessage() : "Failed to send message";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14012a, c.this.d());
        }

        /* renamed from: b */
        public void onSuccess(a.f fVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = c.this.d();
            pluginResult.status = 0;
            pluginResult.flag = com.garena.pay.android.b.SUCCESS.g().intValue();
            pluginResult.message = "Successfully sent";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14012a, c.this.d());
        }

        public void onCancel() {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = c.this.d();
            pluginResult.status = -1;
            com.garena.pay.android.b bVar = com.garena.pay.android.b.USER_CANCELLED;
            pluginResult.flag = bVar.g().intValue();
            pluginResult.message = bVar.i();
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14012a, c.this.d());
        }
    }

    public String d() {
        return "facebook.game.message";
    }

    public Integer e() {
        return 2900;
    }

    public void j(Exception exc, Activity activity) {
        com.beetalk.sdk.plugin.b.j().n(new a(exc), activity, d());
    }

    public void l(Activity activity) {
        S s10 = this.f14004a;
        if (s10 == null || ((r2.a) s10).f14603a.isEmpty()) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = d();
            pluginResult.status = -1;
            pluginResult.flag = com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue();
            pluginResult.message = "User id is invalid";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, activity, d());
            return;
        }
        n4.a aVar = new n4.a(activity);
        aVar.j(this.f14005b, new b(activity));
        e5.c a10 = new c.b().n(((r2.a) this.f14004a).f14604b).l(((r2.a) this.f14004a).f14605c).k(((r2.a) this.f14004a).f14608f).m(Collections.singletonList(String.valueOf(((r2.a) this.f14004a).f14603a))).a();
        if (aVar.b(a10)) {
            aVar.l(a10);
            return;
        }
        PluginResult pluginResult2 = new PluginResult();
        pluginResult2.source = d();
        pluginResult2.status = -1;
        pluginResult2.flag = com.garena.pay.android.b.UNSUPPORTED_API.g().intValue();
        pluginResult2.message = "Cannot show game request dialog";
        com.beetalk.sdk.plugin.b.j().n(pluginResult2, activity, d());
    }
}
