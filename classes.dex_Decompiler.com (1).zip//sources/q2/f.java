package q2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Pair;
import com.beetalk.sdk.plugin.GGPluginActivity;
import com.beetalk.sdk.plugin.PluginResult;
import com.garena.pay.android.b;
import i2.h;
import i2.i;
import java.io.File;
import v3.m;

public class f extends a<Pair<String, String>, PluginResult> {

    /* renamed from: c  reason: collision with root package name */
    private String f14024c;

    /* renamed from: d  reason: collision with root package name */
    private Uri f14025d;

    /* renamed from: e  reason: collision with root package name */
    private Uri f14026e;

    public String d() {
        return "facebook.reels";
    }

    public Integer e() {
        return 2903;
    }

    public void j(Exception exc, Activity activity) {
        h(activity, b.UNKNOWN_ERROR.g().intValue(), exc != null ? exc.getMessage() : b.UNKNOWN_ERROR.i());
    }

    public boolean k(int i10, int i11, Intent intent, GGPluginActivity gGPluginActivity) {
        int intValue;
        String str;
        if (super.k(i10, i11, intent, gGPluginActivity) || i10 != e().intValue()) {
            return false;
        }
        if (i11 == -1) {
            intValue = b.SUCCESS.g().intValue();
            str = "Successfully shared";
        } else if (i11 == 0) {
            intValue = b.USER_CANCELLED.g().intValue();
            str = "Share cancelled";
        } else {
            intValue = b.UNKNOWN_ERROR.g().intValue();
            str = "Share Failed";
        }
        h(gGPluginActivity, intValue, str);
        return true;
    }

    public void l(Activity activity) {
        Intent intent = new Intent("com.facebook.reels.SHARE_TO_REEL");
        intent.putExtra("com.facebook.platform.extra.APPLICATION_ID", i.m(activity));
        intent.setDataAndType(this.f14025d, this.f14024c);
        Uri uri = this.f14026e;
        if (uri != null) {
            intent.putExtra("interactive_asset_uri", uri);
            activity.grantUriPermission("com.facebook.katana", this.f14026e, 1);
        }
        intent.setFlags(1);
        if (activity.getPackageManager().resolveActivity(intent, 0) != null) {
            activity.startActivityForResult(intent, e().intValue());
        } else {
            h(activity, b.UNKNOWN_ERROR.g().intValue(), "Share Failed");
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: n */
    public void b(Activity activity, Pair<String, String> pair) {
        if (pair == null) {
            g(activity, b.ERROR_IN_PARAMS.g().intValue());
            return;
        }
        File file = new File((String) pair.second);
        if (file.exists()) {
            Uri b10 = h.b(activity, file);
            this.f14025d = b10;
            if (b10 != null) {
                String type = activity.getContentResolver().getType(this.f14025d);
                this.f14024c = type;
                if (type != null) {
                    this.f14026e = !TextUtils.isEmpty((CharSequence) pair.first) ? h.b(activity, new File((String) pair.first)) : null;
                    if (!i.v("com.facebook.katana", activity)) {
                        com.beetalk.sdk.plugin.b.j().n(c(b.APP_NOT_INSTALLED.g().intValue(), "Facebook App is not installed."), activity, d());
                        return;
                    }
                    this.f14005b = m.a.a();
                    l(activity);
                    return;
                }
            }
        }
        g(activity, b.ERROR_IN_PARAMS.g().intValue());
    }
}
