package q2;

import android.app.Activity;
import android.net.Uri;
import e5.m;
import e5.n;
import h2.b;
import i2.h;
import java.io.File;

public class i extends h {
    public String d() {
        return "facebook.share.video";
    }

    public Integer e() {
        return 2904;
    }

    public void l(Activity activity) {
        Uri b10;
        File file = new File(((b) this.f14004a).f11212g);
        if (!file.exists() || (b10 = h.b(activity, file)) == null) {
            g(activity, com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue());
            return;
        }
        s(activity).l(new n.a().s(new m.a().h(b10).d()).n());
    }

    /* access modifiers changed from: protected */
    public boolean t() {
        return true;
    }
}
