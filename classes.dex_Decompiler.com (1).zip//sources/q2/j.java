package q2;

import android.app.Activity;
import android.os.Bundle;
import com.beetalk.sdk.plugin.PluginResult;
import org.json.JSONObject;
import v3.i0;
import v3.n0;

public class j extends a<Void, PluginResult> {

    class a implements i0.d {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14033a;

        a(Activity activity) {
            this.f14033a = activity;
        }

        public void a(JSONObject jSONObject, n0 n0Var) {
            if (jSONObject == null) {
                j.this.p(this.f14033a, n0Var.toString());
            } else {
                j.this.q(this.f14033a, jSONObject);
            }
        }
    }

    class b extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ JSONObject f14035a;

        b(JSONObject jSONObject) {
            this.f14035a = jSONObject;
            this.status = 0;
            this.flag = com.garena.pay.android.b.SUCCESS.g().intValue();
            this.message = jSONObject.toString();
            this.source = j.this.d();
        }
    }

    class c extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ String f14037a;

        c(String str) {
            this.f14037a = str;
            this.status = -1;
            this.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            this.message = str;
            this.source = j.this.d();
        }
    }

    /* access modifiers changed from: private */
    public void p(Activity activity, String str) {
        com.beetalk.sdk.plugin.b.j().n(new c(str), activity, d());
    }

    /* access modifiers changed from: private */
    public void q(Activity activity, JSONObject jSONObject) {
        com.beetalk.sdk.plugin.b.j().n(new b(jSONObject), activity, d());
    }

    public String d() {
        return "facebook.request.me";
    }

    public Integer e() {
        return 2885;
    }

    public void j(Exception exc, Activity activity) {
        p(activity, exc.getMessage());
    }

    public void l(Activity activity) {
        i0 B = i0.B(v3.a.k(), new a(activity));
        Bundle bundle = new Bundle();
        bundle.putString("fields", "id,name,email,birthday,first_name,last_name");
        B.H(bundle);
        B.l();
    }
}
