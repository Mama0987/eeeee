package q2;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.annotation.NonNull;
import com.beetalk.sdk.plugin.PluginResult;
import e5.j;
import e5.k;
import h2.b;
import i2.d;
import i2.i;
import v3.o;
import v3.r;
import v3.t;

public class h extends a<b, PluginResult> {

    class a implements o<c5.a> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14031a;

        a(Activity activity) {
            this.f14031a = activity;
        }

        public void a(@NonNull r rVar) {
            if (rVar instanceof t) {
                com.beetalk.sdk.plugin.b.j().n(h.this.c(com.garena.pay.android.b.USER_CANCELLED.g().intValue(), "User cancelled"), this.f14031a, h.this.d());
                return;
            }
            com.beetalk.sdk.plugin.b.j().n(h.this.c(com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue(), rVar.getMessage()), this.f14031a, h.this.d());
        }

        /* renamed from: b */
        public void onSuccess(c5.a aVar) {
            com.beetalk.sdk.plugin.b.j().n(h.this.c(com.garena.pay.android.b.SUCCESS.g().intValue(), "Success"), this.f14031a, h.this.d());
        }

        public void onCancel() {
            com.beetalk.sdk.plugin.b.j().n(h.this.c(com.garena.pay.android.b.USER_CANCELLED.g().intValue(), "User cancelled"), this.f14031a, h.this.d());
        }
    }

    public String d() {
        return "facebook.share";
    }

    public Integer e() {
        return 2880;
    }

    public void j(Exception exc, Activity activity) {
        PluginResult pluginResult = new PluginResult();
        pluginResult.source = d();
        pluginResult.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
        pluginResult.status = -1;
        pluginResult.message = exc.getMessage();
        com.beetalk.sdk.plugin.b.j().n(pluginResult, activity, d());
    }

    public void l(Activity activity) {
        String str;
        int i10;
        com.beetalk.sdk.plugin.b bVar;
        Bitmap bitmap;
        if (f5.b.p(k.class)) {
            f5.b s10 = s(activity);
            try {
                S s11 = this.f14004a;
                bitmap = BitmapFactory.decodeByteArray(((b) s11).f11211f, 0, ((b) s11).f11211f.length);
            } catch (Exception e10) {
                d.b(e10);
                bitmap = null;
            } catch (OutOfMemoryError unused) {
                d.c("Failed to create bitmap: out of memory", new Object[0]);
                com.beetalk.sdk.plugin.b.j().n(c(com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue(), "Failed to create bitmap: out of memory"), activity, d());
                return;
            }
            if (bitmap != null) {
                s10.l(new k.a().n(new j.a().k(bitmap).d()).p());
                return;
            }
            bVar = com.beetalk.sdk.plugin.b.j();
            i10 = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            str = "Failed to create bitmap";
        } else {
            bVar = com.beetalk.sdk.plugin.b.j();
            i10 = com.garena.pay.android.b.UNSUPPORTED_API.g().intValue();
            str = "Facebook App is not installed.";
        }
        bVar.n(c(i10, str), activity, d());
    }

    /* access modifiers changed from: protected */
    /* renamed from: r */
    public void b(Activity activity, b bVar) {
        if (bVar == null) {
            g(activity, com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue());
        } else if (!t() || i.v("com.facebook.katana", activity)) {
            super.b(activity, bVar);
        } else {
            com.beetalk.sdk.plugin.b.j().n(c(com.garena.pay.android.b.UNSUPPORTED_API.g().intValue(), "Facebook App is not installed."), activity, d());
        }
    }

    /* access modifiers changed from: protected */
    @NonNull
    public f5.b s(Activity activity) {
        f5.b bVar = new f5.b(activity);
        bVar.j(this.f14005b, new a(activity));
        return bVar;
    }

    /* access modifiers changed from: protected */
    public boolean t() {
        return true;
    }
}
