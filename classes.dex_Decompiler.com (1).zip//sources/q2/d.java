package q2;

import android.app.Activity;
import com.beetalk.sdk.plugin.PluginResult;
import e5.c;
import n4.a;
import v3.o;
import v3.r;

public class d extends a<c, PluginResult> {

    class a extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Exception f14014a;

        a(Exception exc) {
            this.f14014a = exc;
            this.source = d.this.d();
            this.status = -1;
            this.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            this.message = exc.getMessage();
        }
    }

    class b implements o<a.f> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14016a;

        b(Activity activity) {
            this.f14016a = activity;
        }

        public void a(r rVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = d.this.d();
            pluginResult.status = -1;
            pluginResult.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            pluginResult.message = rVar != null ? rVar.getMessage() : "Share Failed";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14016a, d.this.d());
        }

        /* renamed from: b */
        public void onSuccess(a.f fVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = d.this.d();
            pluginResult.status = 0;
            pluginResult.flag = com.garena.pay.android.b.SUCCESS.g().intValue();
            pluginResult.message = "Successfully shared";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14016a, d.this.d());
        }

        public void onCancel() {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = d.this.d();
            pluginResult.status = -1;
            pluginResult.flag = com.garena.pay.android.b.USER_CANCELLED.g().intValue();
            pluginResult.message = "Share cancelled";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14016a, d.this.d());
        }
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public String f14018a;

        /* renamed from: b  reason: collision with root package name */
        public String f14019b;
    }

    public String d() {
        return "facebook.invite";
    }

    public Integer e() {
        return 2883;
    }

    public void j(Exception exc, Activity activity) {
        com.beetalk.sdk.plugin.b.j().n(new a(exc), activity, d());
    }

    public void l(Activity activity) {
        n4.a aVar = new n4.a(activity);
        aVar.j(this.f14005b, new b(activity));
        aVar.l(new c.b().n(((c) this.f14004a).f14018a).l(((c) this.f14004a).f14019b).a());
    }
}
