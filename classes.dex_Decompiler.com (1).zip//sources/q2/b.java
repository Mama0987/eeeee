package q2;

import android.app.Activity;
import android.net.Uri;
import android.text.TextUtils;
import com.beetalk.sdk.plugin.PluginResult;
import e5.g;

public class b extends h {

    class a extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Exception f14008a;

        a(Exception exc) {
            this.f14008a = exc;
            this.status = -1;
            this.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            this.message = exc.getMessage();
            this.source = "facebook.share.fallback";
        }
    }

    public String d() {
        return "facebook.share.fallback";
    }

    public Integer e() {
        return 2881;
    }

    public void j(Exception exc, Activity activity) {
        com.beetalk.sdk.plugin.b.j().n(new a(exc), activity, d());
    }

    public void l(Activity activity) {
        h2.b bVar = (h2.b) this.f14004a;
        try {
            s(activity).l(((g.a) new g.a().h(!TextUtils.isEmpty(bVar.f11209d) ? Uri.parse(bVar.f11209d) : null)).n());
        } catch (Exception unused) {
            com.beetalk.sdk.plugin.b.j().n(c(com.garena.pay.android.b.ERROR.g().intValue(), "Error Uri."), activity, d());
        }
    }

    /* access modifiers changed from: protected */
    public boolean t() {
        return false;
    }
}
