package q2;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.annotation.NonNull;
import com.beetalk.sdk.plugin.PluginResult;
import e5.j;
import e5.k;
import i2.d;
import v3.o;
import v3.r;

public class g extends a<byte[], PluginResult> {

    class a extends PluginResult {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Exception f14027a;

        a(Exception exc) {
            this.f14027a = exc;
            this.source = g.this.d();
            this.status = -1;
            this.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            this.message = exc.getMessage();
        }
    }

    class b implements o<c5.a> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Activity f14029a;

        b(Activity activity) {
            this.f14029a = activity;
        }

        public void a(@NonNull r rVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = g.this.d();
            pluginResult.flag = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            pluginResult.status = -1;
            pluginResult.message = rVar.getMessage();
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14029a, g.this.d());
        }

        /* renamed from: b */
        public void onSuccess(c5.a aVar) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = g.this.d();
            pluginResult.status = 0;
            pluginResult.flag = com.garena.pay.android.b.SUCCESS.g().intValue();
            pluginResult.message = "Successfully send msg";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14029a, g.this.d());
        }

        public void onCancel() {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = g.this.d();
            pluginResult.flag = com.garena.pay.android.b.USER_CANCELLED.g().intValue();
            pluginResult.status = -1;
            pluginResult.message = "Send msg cancelled";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, this.f14029a, g.this.d());
        }
    }

    public String d() {
        return "facebook.messenger.send.image";
    }

    public Integer e() {
        return 2902;
    }

    public void j(Exception exc, Activity activity) {
        com.beetalk.sdk.plugin.b.j().n(new a(exc), activity, d());
    }

    public void l(Activity activity) {
        String str;
        int i10;
        com.beetalk.sdk.plugin.b bVar;
        Bitmap bitmap;
        if (this.f14004a == null) {
            PluginResult pluginResult = new PluginResult();
            pluginResult.source = d();
            pluginResult.flag = com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue();
            pluginResult.status = -1;
            pluginResult.message = "The content url is empty";
            com.beetalk.sdk.plugin.b.j().n(pluginResult, activity, d());
            return;
        }
        if (f5.a.p(k.class)) {
            try {
                S s10 = this.f14004a;
                bitmap = BitmapFactory.decodeByteArray((byte[]) s10, 0, ((byte[]) s10).length);
            } catch (Exception e10) {
                d.b(e10);
                bitmap = null;
            } catch (OutOfMemoryError unused) {
                d.c("Failed to create bitmap: out of memory", new Object[0]);
                com.beetalk.sdk.plugin.b.j().n(c(com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue(), "Failed to create bitmap: out of memory"), activity, d());
                return;
            }
            if (bitmap != null) {
                k.a n10 = new k.a().n(new j.a().k(bitmap).d());
                f5.a aVar = new f5.a(activity);
                aVar.j(this.f14005b, new b(activity));
                aVar.l(n10.p());
                return;
            }
            bVar = com.beetalk.sdk.plugin.b.j();
            i10 = com.garena.pay.android.b.UNKNOWN_ERROR.g().intValue();
            str = "Failed to create bitmap";
        } else {
            bVar = com.beetalk.sdk.plugin.b.j();
            i10 = com.garena.pay.android.b.UNSUPPORTED_API.g().intValue();
            str = "Cannot show Messenger dialog";
        }
        bVar.n(c(i10, str), activity, d());
    }
}
