package i2;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.beetalk.sdk.j;
import java.util.Locale;

public class n {

    /* renamed from: a  reason: collision with root package name */
    static String f11338a = "SG";

    public static String a() {
        String country = Locale.getDefault().getCountry();
        if (country.length() > 2) {
            country = country.substring(0, 2);
        }
        return country.length() == 2 ? country.toUpperCase() : f11338a;
    }

    public static String b(Context context) {
        String c10 = o.b().c(context);
        return TextUtils.isEmpty(c10) ? a() : c10;
    }

    public static String c() {
        String language = Locale.getDefault().getLanguage();
        if (language.length() > 2) {
            language = language.substring(0, 2);
        }
        return language.length() == 2 ? language.toLowerCase() : f11338a;
    }

    public static Locale d() {
        return j.z() != null ? e(j.z()) : new Locale(c(), a());
    }

    public static Locale e(Context context) {
        return new Locale(c(), b(context));
    }

    public static String f(Locale locale) {
        return "in".equals(locale.getLanguage()) ? locale.toString().replace("in", "id") : locale.toString();
    }

    public static String g(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getApplicationContext().getSystemService("phone");
        return telephonyManager != null ? telephonyManager.getSimCountryIso().toUpperCase() : "";
    }
}
