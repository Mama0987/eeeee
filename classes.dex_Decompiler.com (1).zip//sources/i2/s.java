package i2;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import sb.a;
import vb.i;

@Metadata
public final class s<T> implements a {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    private final Object f11342a;

    /* renamed from: b  reason: collision with root package name */
    private T f11343b;

    public s(@NotNull Object obj, T t10) {
        Intrinsics.checkNotNullParameter(obj, "lock");
        this.f11342a = obj;
        this.f11343b = t10;
    }

    public T a(Object obj, @NotNull i<?> iVar) {
        T t10;
        Intrinsics.checkNotNullParameter(iVar, "property");
        synchronized (this.f11342a) {
            t10 = this.f11343b;
        }
        return t10;
    }

    public void b(Object obj, @NotNull i<?> iVar, T t10) {
        Intrinsics.checkNotNullParameter(iVar, "property");
        synchronized (this.f11342a) {
            this.f11343b = t10;
            Unit unit = Unit.f12470a;
        }
    }
}
