package i2;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class p {

    /* renamed from: a  reason: collision with root package name */
    private static final char[] f11341a;

    static {
        StringBuilder sb2 = new StringBuilder();
        for (char c10 = '0'; c10 <= '9'; c10 = (char) (c10 + 1)) {
            sb2.append(c10);
        }
        for (char c11 = 'a'; c11 <= 'z'; c11 = (char) (c11 + 1)) {
            sb2.append(c11);
        }
        for (int i10 = 0; i10 < 10; i10++) {
            sb2.append("!@#$%^&*()".charAt(i10));
        }
        f11341a = sb2.toString().toCharArray();
    }

    public static String a(String str, String str2) {
        return b(str2, str, "HMACSHA256");
    }

    private static String b(String str, String str2, String str3) {
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(str2.getBytes("UTF-8"), str3);
            Mac instance = Mac.getInstance(str3);
            instance.init(secretKeySpec);
            byte[] doFinal = instance.doFinal(str.getBytes("UTF-8"));
            StringBuilder sb2 = new StringBuilder();
            for (byte b10 : doFinal) {
                String hexString = Integer.toHexString(b10 & 255);
                if (hexString.length() == 1) {
                    sb2.append('0');
                }
                sb2.append(hexString);
            }
            return sb2.toString();
        } catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException e10) {
            e10.printStackTrace();
            return null;
        }
    }

    public static String c() {
        return j.a(e(d(64)));
    }

    public static String d(int i10) {
        char[] cArr = new char[i10];
        Random random = new Random();
        for (int i11 = 0; i11 < i10; i11++) {
            char[] cArr2 = f11341a;
            cArr[i11] = cArr2[random.nextInt(cArr2.length)];
        }
        return new String(cArr);
    }

    public static byte[] e(String str) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e10) {
            e10.printStackTrace();
            return null;
        }
    }

    public static String f(String str) {
        try {
            byte[] digest = MessageDigest.getInstance("MD5").digest(str.getBytes("UTF-8"));
            StringBuilder sb2 = new StringBuilder();
            for (byte b10 : digest) {
                sb2.append(Integer.toHexString((b10 & 255) | 256).substring(1, 3));
            }
            return sb2.toString();
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e10) {
            d.b(e10);
            return null;
        }
    }
}
