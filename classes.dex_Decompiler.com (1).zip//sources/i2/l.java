package i2;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.widget.ImageView;
import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.URL;
import v1.i;

public class l extends AsyncTask<String, Void, Bitmap> {

    /* renamed from: a  reason: collision with root package name */
    private final WeakReference<ImageView> f11331a;

    /* renamed from: b  reason: collision with root package name */
    private final Drawable f11332b;

    /* renamed from: c  reason: collision with root package name */
    private final g f11333c;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private String f11334a;

        /* renamed from: b  reason: collision with root package name */
        private String f11335b;

        /* renamed from: c  reason: collision with root package name */
        private int f11336c;

        /* renamed from: d  reason: collision with root package name */
        private Drawable f11337d;

        private a(File file) {
            this.f11336c = 0;
            this.f11335b = file.getAbsolutePath();
        }

        private a(String str) {
            this.f11336c = 0;
            this.f11334a = str;
        }

        public void a(ImageView imageView) {
            if (imageView != null) {
                (this.f11336c == 0 ? new l(imageView, this.f11337d) : new l(imageView, this.f11336c)).executeOnExecutor(i.f16631i, new String[]{this.f11334a, this.f11335b});
            }
        }

        public a b(int i10) {
            this.f11336c = i10;
            return this;
        }

        public a c(Drawable drawable) {
            this.f11337d = drawable;
            return this;
        }
    }

    private l(ImageView imageView, int i10) {
        this(imageView, androidx.core.content.a.e(imageView.getContext(), i10));
    }

    private l(ImageView imageView, Drawable drawable) {
        this.f11331a = new WeakReference<>(imageView);
        this.f11332b = drawable;
        this.f11333c = g.a(imageView.getContext(), "cache_images");
    }

    public static a b(File file) {
        return new a(file);
    }

    public static a c(String str) {
        return new a(str);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public Bitmap doInBackground(String... strArr) {
        Bitmap bitmap;
        String str = strArr[0];
        String str2 = strArr[1];
        String str3 = !TextUtils.isEmpty(str) ? str : !TextUtils.isEmpty(str2) ? str2 : "";
        if (TextUtils.isEmpty(str3)) {
            return null;
        }
        Bitmap d10 = this.f11333c.d(str3);
        if (d10 != null) {
            return d10;
        }
        try {
            if (!TextUtils.isEmpty(str)) {
                bitmap = BitmapFactory.decodeStream(new URL(str).openStream());
            } else if (TextUtils.isEmpty(str2)) {
                return null;
            } else {
                bitmap = BitmapFactory.decodeFile(str2);
            }
            Bitmap bitmap2 = bitmap;
            this.f11333c.f(str3, bitmap2, 172800);
            return bitmap2;
        } catch (IOException e10) {
            d.b(e10);
            return d10;
        } catch (OutOfMemoryError unused) {
            d.c("ImageLoader failed to load image: out of memory", new Object[0]);
            return d10;
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: d */
    public void onPostExecute(Bitmap bitmap) {
        if (bitmap != null) {
            ImageView imageView = this.f11331a.get();
            if (imageView != null) {
                imageView.setImageBitmap(bitmap);
                this.f11331a.clear();
            } else if (!bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() {
        ImageView imageView = this.f11331a.get();
        if (imageView != null) {
            imageView.setImageDrawable(this.f11332b);
        }
    }
}
