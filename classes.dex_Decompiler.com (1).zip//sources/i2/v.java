package i2;

import android.app.Activity;
import androidx.annotation.NonNull;
import com.beetalk.sdk.j;
import com.beetalk.sdk.networking.model.BaseResp;
import com.beetalk.sdk.networking.model.CommonResponse;
import com.garena.pay.android.b;
import i5.a;
import java.util.concurrent.Callable;
import org.json.JSONException;
import v1.i;

public final class v {
    public static <T> void c(Activity activity, @NonNull b bVar, @NonNull i<T> iVar, @NonNull j.e<a<T>> eVar) {
        iVar.m(new t(iVar, eVar, bVar), i.f16633k, bVar.c()).k(new u());
    }

    private static <T> a<T> d(T t10) {
        if (t10 instanceof BaseResp) {
            BaseResp baseResp = (BaseResp) t10;
            return baseResp.isFailure() ? new a.C0179a(b.ERROR, new Exception(baseResp.getErrorMessage())) : new a.b(t10);
        } else if (!(t10 instanceof CommonResponse)) {
            return new a.b(t10);
        } else {
            CommonResponse commonResponse = (CommonResponse) t10;
            return commonResponse.isSuccessResponse() ? new a.b(t10) : new a.C0179a(b.GOP_ERROR_SERVER, new Exception(commonResponse.getError()));
        }
    }

    public static <R> void e(@NonNull Activity activity, @NonNull j.e<a<R>> eVar, @NonNull Callable<R> callable) {
        b i10 = b.i(activity);
        c(activity, i10, i.g(callable, i10.c()), eVar);
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Object f(i iVar, j.e eVar, b bVar, i iVar2) throws Exception {
        Object obj;
        if (iVar.x()) {
            obj = new a.C0179a(b.USER_CANCELLED, new Exception("Task Cancelled"));
        } else if (iVar.z()) {
            obj = h(iVar.u());
        } else {
            Object v10 = iVar2.v();
            obj = v10 == null ? new a.C0179a(b.ERROR, new Exception("Unknown error, no result")) : d(v10);
        }
        eVar.onPluginResult(obj);
        bVar.k();
        return null;
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ Object g(i iVar) throws Exception {
        Exception u10 = iVar.u();
        if (u10 == null) {
            return null;
        }
        d.b(u10);
        return null;
    }

    public static <T> a<T> h(Exception exc) {
        if (exc == null) {
            exc = new Exception("request error");
        }
        return exc instanceof o5.b ? new a.C0179a(((o5.b) exc).a(), exc) : new a.C0179a(b.ERROR, exc);
    }

    public static <T> T i(Callable<T> callable) throws Exception {
        try {
            return callable.call();
        } catch (JSONException unused) {
            throw new o5.b(b.NETWORK_RESPONSE_PARSE_FAIL);
        }
    }

    public static void j(String str, @NonNull String str2) throws o5.b {
        if (str == null || str.isEmpty()) {
            throw new o5.b(b.ERROR_IN_PARAMS, str2);
        }
    }
}
