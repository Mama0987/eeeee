package i2;

import i2.g;
import java.util.concurrent.Callable;

public final /* synthetic */ class e implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g.a f11319a;

    public /* synthetic */ e(g.a aVar) {
        this.f11319a = aVar;
    }

    public final Object call() {
        return this.f11319a.i();
    }
}
