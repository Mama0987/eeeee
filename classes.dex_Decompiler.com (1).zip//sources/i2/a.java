package i2;

import i2.c;

public final /* synthetic */ class a implements c.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f11312a;

    public /* synthetic */ a(b bVar) {
        this.f11312a = bVar;
    }

    public final void a() {
        this.f11312a.a();
    }
}
