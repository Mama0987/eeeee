package i2;

import android.content.Context;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.TimeZone;
import l5.a;

public class o {

    /* renamed from: b  reason: collision with root package name */
    private static volatile o f11339b;

    /* renamed from: a  reason: collision with root package name */
    private HashMap<String, String> f11340a;

    private String a(Context context) {
        if (context == null) {
            return "";
        }
        String[] split = TimeZone.getDefault().getID().toLowerCase().split("/");
        return split.length == 2 ? d(context).get(split[1]) : "";
    }

    public static o b() {
        if (f11339b == null) {
            synchronized (o.class) {
                if (f11339b == null) {
                    f11339b = new o();
                }
            }
        }
        return f11339b;
    }

    private HashMap<String, String> d(Context context) {
        if (this.f11340a == null) {
            String[] stringArray = context.getResources().getStringArray(a.f12660a);
            this.f11340a = new HashMap<>();
            for (String split : stringArray) {
                String[] split2 = split.split(":");
                this.f11340a.put(split2[0], split2[1]);
            }
        }
        return this.f11340a;
    }

    public String c(Context context) {
        if (context == null) {
            return "";
        }
        String g10 = n.g(context);
        return !TextUtils.isEmpty(g10) ? g10 : a(context);
    }
}
