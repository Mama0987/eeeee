package i2;

import android.app.Activity;
import i2.c;
import v1.f;

public class b extends f {

    /* renamed from: g  reason: collision with root package name */
    private c.a f11313g;

    public b(Activity activity) {
        this.f11313g = c.a(activity, new a(this));
    }

    public static b i(Activity activity) {
        return new b(activity);
    }

    public void k() {
        c.a aVar = this.f11313g;
        if (aVar != null) {
            aVar.a();
            this.f11313g = null;
        }
    }
}
