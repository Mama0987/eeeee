package i2;

import com.beetalk.sdk.j;
import v1.g;
import v1.i;

public final /* synthetic */ class t implements g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i f11344a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ j.e f11345b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ b f11346c;

    public /* synthetic */ t(i iVar, j.e eVar, b bVar) {
        this.f11344a = iVar;
        this.f11345b = eVar;
        this.f11346c = bVar;
    }

    public final Object a(i iVar) {
        return v.f(this.f11344a, this.f11345b, this.f11346c, iVar);
    }
}
