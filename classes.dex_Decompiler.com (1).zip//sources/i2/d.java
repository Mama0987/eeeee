package i2;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import com.beetalk.sdk.j;
import com.beetalk.sdk.s;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Locale;

public class d {

    /* renamed from: a  reason: collision with root package name */
    private static String f11316a = "";

    /* renamed from: b  reason: collision with root package name */
    public static String f11317b = ("com.garena.msdk[" + j.e() + "]");

    /* renamed from: c  reason: collision with root package name */
    private static final boolean f11318c = (s.s() == s.a.PRODUCTION);

    public static void a(String str, Object... objArr) {
        if (!s.f5402c) {
            String g10 = g(str, objArr);
            Log.d(f11317b, g10);
            k("D", f11317b, g10);
        }
        if (d(str, objArr).contains("UnknownFormatConversionException")) {
            i("OK", new Object[0]);
        }
    }

    public static void b(Exception exc) {
        int i10;
        if (!s.f5402c && exc != null) {
            StackTraceElement[] stackTrace = exc.getStackTrace();
            int i11 = 0;
            while (true) {
                if (i11 >= stackTrace.length) {
                    i10 = -1;
                    break;
                } else if (stackTrace[i11].getMethodName().compareTo("e") == 0) {
                    i10 = i11 + 1;
                    break;
                } else {
                    i11++;
                }
            }
            if (i10 >= 0) {
                String className = stackTrace[i10].getClassName();
                String substring = className.substring(className.lastIndexOf(".") + 1);
                String str = "at " + className + "." + stackTrace[i10].getMethodName() + "(" + substring + ".java:" + String.valueOf(stackTrace[i10].getLineNumber()) + ")";
                Log.e(f11317b + " position", str);
                k("E", f11317b + " position", str);
                return;
            }
            StringWriter stringWriter = new StringWriter();
            exc.printStackTrace(new PrintWriter(stringWriter));
            Log.e(f11317b, stringWriter.toString());
            k("E", f11317b, stringWriter.toString());
        }
    }

    public static void c(String str, Object... objArr) {
        if (!s.f5402c) {
            String g10 = g(str, objArr);
            Log.e(f11317b, g10);
            k("E", f11317b, g10);
        }
        if (d(str, objArr).contains("UnknownFormatConversionException")) {
            i("OK", new Object[0]);
        }
    }

    private static String d(String str, Object... objArr) {
        return (objArr == null || objArr.length == 0) ? str : String.format(Locale.ENGLISH, str, objArr);
    }

    private static void e() {
        int i10;
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        int i11 = 0;
        while (true) {
            if (i11 >= stackTrace.length) {
                i10 = -1;
                break;
            } else if (stackTrace[i11].getMethodName().compareTo("i") == 0) {
                i10 = i11 + 1;
                break;
            } else {
                i11++;
            }
        }
        if (i10 == -1) {
            Log.i(f11317b, "CANNOT GENERATE DEBUG");
            return;
        }
        String className = stackTrace[i10].getClassName();
        String substring = className.substring(className.lastIndexOf(".") + 1);
        String methodName = stackTrace[i10].getMethodName();
        String valueOf = String.valueOf(stackTrace[i10].getLineNumber());
        Log.i(f11317b + " position", "at " + className + "." + methodName + "(" + substring + ".java:" + valueOf + ")");
    }

    private static String f() {
        int i10;
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        int i11 = 0;
        while (true) {
            if (i11 >= stackTrace.length) {
                i10 = -1;
                break;
            }
            if (stackTrace[i11].getClassName().equals(d.class.getName())) {
                String methodName = stackTrace[i11].getMethodName();
                if (methodName.equals("e") || methodName.equals("w") || methodName.equals("i") || methodName.equals("d")) {
                    i10 = i11 + 1;
                }
            }
            i11++;
        }
        i10 = i11 + 1;
        if (i10 == -1) {
            Log.i(f11317b, "CANNOT GENERATE DEBUG");
            return "";
        }
        StackTraceElement stackTraceElement = stackTrace[i10];
        String className = stackTraceElement.getClassName();
        String substring = className.substring(className.lastIndexOf(".") + 1);
        return stackTraceElement.getMethodName() + "(" + substring + ".java:" + stackTraceElement.getLineNumber() + "): ";
    }

    private static String g(String str, Object... objArr) {
        StringBuilder sb2;
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        if (objArr == null || objArr.length <= 0) {
            sb2 = new StringBuilder();
        } else {
            try {
                return f() + h() + l(d(str, objArr));
            } catch (Exception e10) {
                b(e10);
                sb2 = new StringBuilder();
            }
        }
        sb2.append(f());
        sb2.append(h());
        sb2.append(str);
        return sb2.toString();
    }

    private static String h() {
        return String.format(Locale.ENGLISH, "[thread_id:%d name=%s] ", new Object[]{Long.valueOf(Thread.currentThread().getId()), Thread.currentThread().getName()});
    }

    public static void i(String str, Object... objArr) {
        if (!s.f5402c) {
            if (!s.f5400a) {
                e();
            }
            String g10 = g(str, objArr);
            Log.i(f11317b, g10);
            k("I", f11317b, g10);
        }
    }

    public static void j(Context context) {
        if (context != null && context.getApplicationContext() != null) {
            f11316a = context.getApplicationContext().getPackageName();
        }
    }

    private static void k(String str, String str2, String str3) {
    }

    private static String l(String str) {
        return f11318c ? str.replaceAll("token=\\S*", "token=ACCESS_TOKEN_REMOVED ").replaceAll("client_secret=\\S*", "client_secret=CLIENT_SECRET_REMOVED ").replaceAll("app_key=\\S*", "appKey=APP_SECRET_REMOVED ").replaceAll("access_token=\\S*", "access_token=ACCESS_TOKEN_REMOVED ").replaceAll("code=\\S*", "code=SOME_CODE_REMOVED ") : str;
    }

    public static void m(String str, Object... objArr) {
        if (!s.f5402c) {
            String g10 = g(str, objArr);
            Log.w(f11317b, g10);
            k("W", f11317b, g10);
        }
        if (d(str, objArr).contains("UnknownFormatConversionException")) {
            i("OK", new Object[0]);
        }
    }
}
