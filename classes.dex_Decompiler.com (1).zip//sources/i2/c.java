package i2;

import android.app.Activity;
import androidx.annotation.NonNull;

public class c {

    public static class a extends q {

        /* renamed from: a  reason: collision with root package name */
        private Activity f11314a;

        /* renamed from: b  reason: collision with root package name */
        private final b f11315b;

        public a(@NonNull Activity activity, @NonNull b bVar) {
            this.f11314a = activity;
            this.f11315b = bVar;
        }

        public void a() {
            Activity activity = this.f11314a;
            if (activity != null) {
                activity.getApplication().unregisterActivityLifecycleCallbacks(this);
                this.f11314a = null;
            }
        }

        public void onActivityDestroyed(@NonNull Activity activity) {
            super.onActivityDestroyed(activity);
            if (activity == this.f11314a) {
                this.f11315b.a();
                a();
            }
        }
    }

    @FunctionalInterface
    public interface b {
        void a();
    }

    public static a a(@NonNull Activity activity, @NonNull b bVar) {
        a aVar = new a(activity, bVar);
        activity.getApplication().registerActivityLifecycleCallbacks(aVar);
        return aVar;
    }
}
