package i2;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import androidx.annotation.NonNull;
import androidx.core.view.c1;
import androidx.core.view.s2;
import androidx.core.view.u2;
import androidx.core.view.v0;
import com.beetalk.sdk.f;
import com.beetalk.sdk.j;
import com.garena.pay.android.b;
import org.json.JSONObject;

public class i {

    /* renamed from: a  reason: collision with root package name */
    private static Integer f11328a;

    class a implements v0 {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f11329a;

        a(View view) {
            this.f11329a = view;
        }

        public u2 a(View view, u2 u2Var) {
            this.f11329a.setPadding(0, 0, 0, u2Var.f(u2.m.a()).f2389d);
            return u2Var;
        }
    }

    public static void a(Window window, View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            s2.a(window, false);
            c1.T(view, new a(view));
            return;
        }
        window.setSoftInputMode(16);
    }

    public static b b(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        str.hashCode();
        char c10 = 65535;
        switch (str.hashCode()) {
            case -2054838772:
                if (str.equals("server_error")) {
                    c10 = 0;
                    break;
                }
                break;
            case -818885283:
                if (str.equals("error_scope")) {
                    c10 = 1;
                    break;
                }
                break;
            case -817608446:
                if (str.equals("error_token")) {
                    c10 = 2;
                    break;
                }
                break;
            case -95137703:
                if (str.equals("error_token_session")) {
                    c10 = 3;
                    break;
                }
                break;
            case 296700829:
                if (str.equals("error_params")) {
                    c10 = 4;
                    break;
                }
                break;
        }
        switch (c10) {
            case 0:
                return b.GOP_ERROR_SERVER;
            case 1:
                return b.GOP_ERROR_SCOPE;
            case 2:
                f.Y();
                return b.GOP_ERROR_TOKEN;
            case 3:
                f.Y();
                return b.ERROR_TOKEN_SESSION;
            case 4:
                return b.ERROR_IN_PARAMS;
            default:
                return b.UNKNOWN_ERROR;
        }
    }

    public static b c(String str) {
        if (TextUtils.isEmpty(str)) {
            return b.NETWORK_EXCEPTION;
        }
        if (!str.contains("error")) {
            return null;
        }
        if (str.contains("error_params")) {
            return b.ERROR_IN_PARAMS;
        }
        if (str.contains("error_scope")) {
            return b.GOP_ERROR_SCOPE;
        }
        if (str.contains("server_error")) {
            return b.GOP_ERROR_SERVER;
        }
        if (str.contains("error_token")) {
            f.Y();
            return b.GOP_ERROR_TOKEN;
        } else if (!str.contains("error_token_session")) {
            return b.UNKNOWN_ERROR;
        } else {
            f.Y();
            return b.ERROR_TOKEN_SESSION;
        }
    }

    public static b d(JSONObject jSONObject) {
        return jSONObject == null ? b.NETWORK_EXCEPTION : b(jSONObject.optString("error"));
    }

    @NonNull
    public static String e() {
        return h(j.z()).getString("com.garena.sdk.google_client_id", "");
    }

    public static String f(Context context) {
        return h(context).getString("com.garena.sdk.gms.games.OAUTH_CLIENT_ID");
    }

    public static int g(Context context) {
        return h(context).getInt("com.garena.sdk.applicationId", -1);
    }

    @NonNull
    private static Bundle h(Context context) {
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null) {
                return bundle;
            }
        } catch (Exception e10) {
            d.b(e10);
        }
        return new Bundle();
    }

    public static String i(Context context) {
        int g10 = g(context);
        if (g10 > 0) {
            return String.valueOf(g10);
        }
        d.c("App ID is less than or equal to 0.", new Object[0]);
        return null;
    }

    @NonNull
    public static String j(Context context) {
        return h(context).getString("com.garena.sdk.applicationVariant", "");
    }

    @NonNull
    public static String k() {
        return h(j.z()).getString("com.garena.sdk.applicationKey", "");
    }

    public static Integer l(Context context) {
        Integer num = f11328a;
        if (num != null) {
            return num;
        }
        Integer valueOf = Integer.valueOf(h(context).getInt("com.garena.sdk.ApplicationSourceId", 2));
        f11328a = valueOf;
        return valueOf;
    }

    public static String m(Context context) {
        w.b(context, "context");
        return h(context).getString("com.facebook.sdk.ApplicationId");
    }

    public static int n(Context context, String str) {
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                return 0;
            }
            return packageManager.getPackageInfo(str, 0).versionCode;
        } catch (PackageManager.NameNotFoundException unused) {
            return 0;
        }
    }

    public static String o(Context context) {
        return h(context).getString("com.garena.sdk.tiktok_client_key");
    }

    public static int p() {
        return (int) (System.currentTimeMillis() / 1000);
    }

    @NonNull
    public static String q(Context context) {
        String string = h(context).getString("com.garena.sdk.twitter.key");
        return string == null ? "" : string;
    }

    @NonNull
    public static String r(Context context) {
        String string = h(context).getString("com.garena.sdk.twitter.secret");
        return string == null ? "" : string;
    }

    public static boolean s(Context context) {
        return !TextUtils.isEmpty(h(context).getString("com.google.android.gms.games.APP_ID"));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x000f, code lost:
        r0 = r0.getActiveNetworkInfo();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean t() {
        /*
            android.content.Context r0 = com.beetalk.sdk.j.z()
            java.lang.String r1 = "connectivity"
            java.lang.Object r0 = r0.getSystemService(r1)
            android.net.ConnectivityManager r0 = (android.net.ConnectivityManager) r0
            r1 = 0
            if (r0 == 0) goto L_0x001c
            android.net.NetworkInfo r0 = r0.getActiveNetworkInfo()
            if (r0 == 0) goto L_0x001c
            boolean r0 = r0.isConnected()
            if (r0 == 0) goto L_0x001c
            r1 = 1
        L_0x001c:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: i2.i.t():boolean");
    }

    public static boolean u(String str) {
        return str == null || str.length() == 0;
    }

    public static boolean v(String str, Context context) {
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(str, 0);
            return applicationInfo != null && applicationInfo.enabled;
        } catch (PackageManager.NameNotFoundException unused) {
            return false;
        }
    }

    public static boolean w(Activity activity) {
        return j.j(activity, 1) >= 103;
    }

    public static boolean x(Activity activity) {
        return j.j(activity, 1) >= 60;
    }

    public static boolean y() {
        return (j.z().getResources().getConfiguration().screenLayout & 15) >= 3;
    }

    public static int z(Context context, String str) {
        try {
            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            return -1;
        } catch (ActivityNotFoundException unused) {
            return 0;
        }
    }
}
