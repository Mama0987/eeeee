package i2;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import k2.d;
import kotlin.text.Charsets;

public class r {
    private static String a(String str, boolean z10) throws UnsupportedEncodingException {
        return z10 ? URLEncoder.encode(str, Charsets.UTF_8.name()) : str;
    }

    public static String b(List<d> list) throws UnsupportedEncodingException {
        return c(list, true);
    }

    public static String c(List<d> list, boolean z10) throws UnsupportedEncodingException {
        if (list == null) {
            return "";
        }
        StringBuilder sb2 = new StringBuilder();
        Iterator<d> it = list.iterator();
        while (it.hasNext()) {
            d next = it.next();
            sb2.append(a(next.f12216a, z10));
            sb2.append("=");
            sb2.append(a(next.f12217b, z10));
            if (it.hasNext()) {
                sb2.append("&");
            }
        }
        return sb2.toString();
    }
}
