package i2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Process;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import v1.i;

public class g {

    /* renamed from: b  reason: collision with root package name */
    private static final Map<String, g> f11320b = new HashMap();

    /* renamed from: a  reason: collision with root package name */
    private final a f11321a;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        private final AtomicLong f11322a;

        /* renamed from: b  reason: collision with root package name */
        private final AtomicInteger f11323b;

        /* renamed from: c  reason: collision with root package name */
        private final long f11324c;

        /* renamed from: d  reason: collision with root package name */
        private final int f11325d;

        /* renamed from: e  reason: collision with root package name */
        private final Map<File, Long> f11326e;

        /* renamed from: f  reason: collision with root package name */
        protected File f11327f;

        private a(File file, long j10, int i10) {
            this.f11326e = Collections.synchronizedMap(new HashMap());
            this.f11327f = file;
            this.f11324c = j10;
            this.f11325d = i10;
            this.f11322a = new AtomicLong();
            this.f11323b = new AtomicInteger();
            f();
        }

        private void f() {
            i.f(new e(this));
        }

        private long g(File file) {
            return file.length();
        }

        /* access modifiers changed from: private */
        public File h(String str) {
            File j10 = j(str);
            long currentTimeMillis = System.currentTimeMillis();
            j10.setLastModified(currentTimeMillis);
            this.f11326e.put(j10, Long.valueOf(currentTimeMillis));
            return j10;
        }

        /* access modifiers changed from: private */
        public /* synthetic */ Object i() throws Exception {
            File[] listFiles = this.f11327f.listFiles();
            if (listFiles == null) {
                return null;
            }
            int i10 = 0;
            int i11 = 0;
            for (File file : listFiles) {
                i10 = (int) (((long) i10) + g(file));
                i11++;
                this.f11326e.put(file, Long.valueOf(file.lastModified()));
            }
            this.f11322a.set((long) i10);
            this.f11323b.set(i11);
            return null;
        }

        /* access modifiers changed from: private */
        public File j(String str) {
            File file = this.f11327f;
            return new File(file, str.hashCode() + "");
        }

        /* access modifiers changed from: private */
        public void k(File file) {
            int i10 = this.f11323b.get();
            while (i10 + 1 > this.f11325d) {
                this.f11322a.addAndGet(-m());
                i10 = this.f11323b.addAndGet(-1);
            }
            this.f11323b.addAndGet(1);
            long g10 = g(file);
            long j10 = this.f11322a.get();
            while (j10 + g10 > this.f11324c) {
                j10 = this.f11322a.addAndGet(-m());
            }
            this.f11322a.addAndGet(g10);
            long currentTimeMillis = System.currentTimeMillis();
            file.setLastModified(currentTimeMillis);
            this.f11326e.put(file, Long.valueOf(currentTimeMillis));
        }

        /* access modifiers changed from: private */
        public boolean l(String str) {
            return h(str).delete();
        }

        private long m() {
            File file;
            if (this.f11326e.isEmpty()) {
                return 0;
            }
            Set<Map.Entry<File, Long>> entrySet = this.f11326e.entrySet();
            synchronized (this.f11326e) {
                file = null;
                Long l10 = null;
                for (Map.Entry next : entrySet) {
                    if (file == null) {
                        file = (File) next.getKey();
                        l10 = (Long) next.getValue();
                    } else {
                        Long l11 = (Long) next.getValue();
                        if (l11.longValue() < l10.longValue()) {
                            file = (File) next.getKey();
                            l10 = l11;
                        }
                    }
                }
            }
            long g10 = g(file);
            if (file.delete()) {
                this.f11326e.remove(file);
            }
            return g10;
        }
    }

    private static class b {
        /* access modifiers changed from: private */
        public static byte[] f(Bitmap bitmap) {
            if (bitmap == null) {
                return null;
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        }

        /* access modifiers changed from: private */
        public static Bitmap g(byte[] bArr) {
            if (bArr.length == 0) {
                return null;
            }
            return BitmapFactory.decodeByteArray(bArr, 0, bArr.length);
        }

        /* access modifiers changed from: private */
        public static byte[] h(byte[] bArr) {
            return l(bArr) ? i(bArr, m(bArr, ' ') + 1, bArr.length) : bArr;
        }

        private static byte[] i(byte[] bArr, int i10, int i11) {
            int i12 = i11 - i10;
            if (i12 >= 0) {
                byte[] bArr2 = new byte[i12];
                System.arraycopy(bArr, i10, bArr2, 0, Math.min(bArr.length - i10, i12));
                return bArr2;
            }
            throw new IllegalArgumentException(i10 + " > " + i11);
        }

        private static String j(int i10) {
            StringBuilder sb2 = new StringBuilder(System.currentTimeMillis() + "");
            while (sb2.length() < 13) {
                sb2.insert(0, "0");
            }
            return sb2 + "-" + i10 + ' ';
        }

        private static String[] k(byte[] bArr) {
            if (!l(bArr)) {
                return null;
            }
            return new String[]{new String(i(bArr, 0, 13)), new String(i(bArr, 14, m(bArr, ' ')))};
        }

        private static boolean l(byte[] bArr) {
            return bArr != null && bArr.length > 15 && bArr[13] == 45 && m(bArr, ' ') > 14;
        }

        private static int m(byte[] bArr, char c10) {
            for (int i10 = 0; i10 < bArr.length; i10++) {
                if (bArr[i10] == c10) {
                    return i10;
                }
            }
            return -1;
        }

        /* access modifiers changed from: private */
        public static boolean n(byte[] bArr) {
            String[] k10 = k(bArr);
            if (k10 == null || k10.length != 2) {
                return false;
            }
            String str = k10[0];
            while (str.startsWith("0")) {
                str = str.substring(1);
            }
            return System.currentTimeMillis() > Long.parseLong(str) + (Long.parseLong(k10[1]) * 1000);
        }

        /* access modifiers changed from: private */
        public static byte[] o(int i10, byte[] bArr) {
            byte[] bytes = j(i10).getBytes();
            byte[] bArr2 = new byte[(bytes.length + bArr.length)];
            System.arraycopy(bytes, 0, bArr2, 0, bytes.length);
            System.arraycopy(bArr, 0, bArr2, bytes.length, bArr.length);
            return bArr2;
        }
    }

    private g(File file, long j10, int i10) {
        if (file.exists() || file.mkdirs()) {
            this.f11321a = new a(file, j10, i10);
            return;
        }
        throw new RuntimeException("can't make dirs in " + file.getAbsolutePath());
    }

    public static g a(Context context, String str) {
        return b(new File(context.getCacheDir(), str), 50000000, Integer.MAX_VALUE);
    }

    public static g b(File file, long j10, int i10) {
        Map<String, g> map = f11320b;
        g gVar = map.get(file.getAbsoluteFile() + e());
        if (gVar != null) {
            return gVar;
        }
        g gVar2 = new g(file, j10, i10);
        map.put(file.getAbsolutePath() + e(), gVar2);
        return gVar2;
    }

    private static String e() {
        return "_" + Process.myPid();
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0049 A[SYNTHETIC, Splitter:B:28:0x0049] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0056 A[SYNTHETIC, Splitter:B:36:0x0056] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public byte[] c(java.lang.String r6) {
        /*
            r5 = this;
            r0 = 0
            i2.g$a r1 = r5.f11321a     // Catch:{ Exception -> 0x0042, all -> 0x0040 }
            java.io.File r1 = r1.h(r6)     // Catch:{ Exception -> 0x0042, all -> 0x0040 }
            boolean r2 = r1.exists()     // Catch:{ Exception -> 0x0042, all -> 0x0040 }
            if (r2 != 0) goto L_0x000e
            return r0
        L_0x000e:
            java.io.RandomAccessFile r2 = new java.io.RandomAccessFile     // Catch:{ Exception -> 0x0042, all -> 0x0040 }
            java.lang.String r3 = "r"
            r2.<init>(r1, r3)     // Catch:{ Exception -> 0x0042, all -> 0x0040 }
            long r3 = r2.length()     // Catch:{ Exception -> 0x003e }
            int r1 = (int) r3     // Catch:{ Exception -> 0x003e }
            byte[] r1 = new byte[r1]     // Catch:{ Exception -> 0x003e }
            r2.read(r1)     // Catch:{ Exception -> 0x003e }
            boolean r3 = i2.g.b.n(r1)     // Catch:{ Exception -> 0x003e }
            if (r3 != 0) goto L_0x0032
            byte[] r6 = i2.g.b.h(r1)     // Catch:{ Exception -> 0x003e }
            r2.close()     // Catch:{ IOException -> 0x002d }
            goto L_0x0031
        L_0x002d:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0031:
            return r6
        L_0x0032:
            r2.close()     // Catch:{ IOException -> 0x0036 }
            goto L_0x003a
        L_0x0036:
            r1 = move-exception
            r1.printStackTrace()
        L_0x003a:
            r5.i(r6)
            return r0
        L_0x003e:
            r6 = move-exception
            goto L_0x0044
        L_0x0040:
            r6 = move-exception
            goto L_0x0054
        L_0x0042:
            r6 = move-exception
            r2 = r0
        L_0x0044:
            r6.printStackTrace()     // Catch:{ all -> 0x0052 }
            if (r2 == 0) goto L_0x0051
            r2.close()     // Catch:{ IOException -> 0x004d }
            goto L_0x0051
        L_0x004d:
            r6 = move-exception
            r6.printStackTrace()
        L_0x0051:
            return r0
        L_0x0052:
            r6 = move-exception
            r0 = r2
        L_0x0054:
            if (r0 == 0) goto L_0x005e
            r0.close()     // Catch:{ IOException -> 0x005a }
            goto L_0x005e
        L_0x005a:
            r0 = move-exception
            r0.printStackTrace()
        L_0x005e:
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: i2.g.c(java.lang.String):byte[]");
    }

    public Bitmap d(String str) {
        if (c(str) == null) {
            return null;
        }
        return b.g(c(str));
    }

    public void f(String str, Bitmap bitmap, int i10) {
        h(str, b.f(bitmap), i10);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0026 A[SYNTHETIC, Splitter:B:17:0x0026] */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0039 A[SYNTHETIC, Splitter:B:24:0x0039] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void g(java.lang.String r3, byte[] r4) {
        /*
            r2 = this;
            i2.g$a r0 = r2.f11321a
            java.io.File r3 = r0.j(r3)
            r0 = 0
            java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0020 }
            r1.<init>(r3)     // Catch:{ Exception -> 0x0020 }
            r1.write(r4)     // Catch:{ Exception -> 0x001b, all -> 0x0018 }
            r1.flush()     // Catch:{ IOException -> 0x0016 }
            r1.close()     // Catch:{ IOException -> 0x0016 }
            goto L_0x0031
        L_0x0016:
            r4 = move-exception
            goto L_0x002e
        L_0x0018:
            r4 = move-exception
            r0 = r1
            goto L_0x0037
        L_0x001b:
            r4 = move-exception
            r0 = r1
            goto L_0x0021
        L_0x001e:
            r4 = move-exception
            goto L_0x0037
        L_0x0020:
            r4 = move-exception
        L_0x0021:
            r4.printStackTrace()     // Catch:{ all -> 0x001e }
            if (r0 == 0) goto L_0x0031
            r0.flush()     // Catch:{ IOException -> 0x002d }
            r0.close()     // Catch:{ IOException -> 0x002d }
            goto L_0x0031
        L_0x002d:
            r4 = move-exception
        L_0x002e:
            r4.printStackTrace()
        L_0x0031:
            i2.g$a r4 = r2.f11321a
            r4.k(r3)
            return
        L_0x0037:
            if (r0 == 0) goto L_0x0044
            r0.flush()     // Catch:{ IOException -> 0x0040 }
            r0.close()     // Catch:{ IOException -> 0x0040 }
            goto L_0x0044
        L_0x0040:
            r0 = move-exception
            r0.printStackTrace()
        L_0x0044:
            i2.g$a r0 = r2.f11321a
            r0.k(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: i2.g.g(java.lang.String, byte[]):void");
    }

    public void h(String str, byte[] bArr, int i10) {
        g(str, b.o(i10, bArr));
    }

    public boolean i(String str) {
        return this.f11321a.l(str);
    }
}
