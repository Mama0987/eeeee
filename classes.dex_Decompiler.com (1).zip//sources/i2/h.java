package i2;

import android.content.Context;
import android.net.Uri;
import androidx.core.content.j;
import java.io.File;
import java.io.IOException;

public class h {
    public static File a(String str, String str2) throws IOException {
        File file = new File(str);
        if (file.exists() || file.mkdirs()) {
            File file2 = new File(str, str2);
            if (file2.exists() && !file2.delete()) {
                throw new IOException("can't delete " + file2.getAbsolutePath());
            } else if (file2.createNewFile()) {
                return file2;
            } else {
                throw new IOException("can't create" + file2.getAbsolutePath());
            }
        } else {
            throw new IOException("can't create" + file.getAbsolutePath());
        }
    }

    public static Uri b(Context context, File file) {
        String packageName = context.getPackageName();
        return j.getUriForFile(context, packageName + ".fileprovider", file);
    }
}
