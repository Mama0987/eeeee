package i2;

public final class w {
    public static <T> void a(T t10, T t11, String str) {
        if (!String.valueOf(t10).equals(String.valueOf(t11))) {
            throw new IllegalArgumentException("Argument " + str + " is not equal to expected value");
        }
    }

    public static void b(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException("Argument '" + str + "' cannot be null");
        }
    }
}
