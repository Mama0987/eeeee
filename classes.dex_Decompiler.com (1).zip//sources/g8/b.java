package g8;

public class b extends Exception {
    private static final long serialVersionUID = 1;

    public b(String str) {
        super(str);
    }
}
