package a0;

public final /* synthetic */ class b {
}
