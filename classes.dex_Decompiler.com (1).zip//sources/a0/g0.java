package a0;

public interface g0 {

    public static abstract class a {
    }

    public static final class b extends a {
    }

    public static final class c extends a {
    }

    public static final class d extends a {
    }

    public static final class e extends a {
    }

    public static final class f extends a {
    }

    public static final class g extends a {
    }

    public static final class h extends a {
    }
}
