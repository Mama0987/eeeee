package a0;

import android.view.accessibility.AccessibilityRecord;
import androidx.annotation.NonNull;

public class f0 {
    public static void a(@NonNull AccessibilityRecord accessibilityRecord, int i10) {
        accessibilityRecord.setMaxScrollX(i10);
    }

    public static void b(@NonNull AccessibilityRecord accessibilityRecord, int i10) {
        accessibilityRecord.setMaxScrollY(i10);
    }
}
