package a0;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;
import androidx.annotation.NonNull;

public final class a extends ClickableSpan {

    /* renamed from: a  reason: collision with root package name */
    private final int f1a;

    /* renamed from: b  reason: collision with root package name */
    private final y f2b;

    /* renamed from: c  reason: collision with root package name */
    private final int f3c;

    public a(int i10, @NonNull y yVar, int i11) {
        this.f1a = i10;
        this.f2b = yVar;
        this.f3c = i11;
    }

    public void onClick(@NonNull View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f1a);
        this.f2b.S(this.f3c, bundle);
    }
}
