package a0;

public final /* synthetic */ class e {
}
