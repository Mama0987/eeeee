package a0;

public final /* synthetic */ class a0 {
}
