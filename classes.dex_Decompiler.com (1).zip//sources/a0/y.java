package a0;

import a0.g0;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.annotation.NonNull;
import com.appff.haptic.base.Utils;
import java.lang.ref.WeakReference;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class y {

    /* renamed from: d  reason: collision with root package name */
    private static int f5d;

    /* renamed from: a  reason: collision with root package name */
    private final AccessibilityNodeInfo f6a;

    /* renamed from: b  reason: collision with root package name */
    public int f7b = -1;

    /* renamed from: c  reason: collision with root package name */
    private int f8c = -1;

    public static class a {
        public static final a A;
        public static final a B;
        public static final a C;
        public static final a D;
        public static final a E;
        @NonNull
        public static final a F;
        @NonNull
        public static final a G;
        @NonNull
        public static final a H;
        @NonNull
        public static final a I;
        public static final a J;
        public static final a K;
        public static final a L;
        public static final a M;
        public static final a N;
        @NonNull
        public static final a O;
        @NonNull
        public static final a P;
        @NonNull
        public static final a Q;
        @NonNull
        public static final a R;
        @NonNull
        public static final a S;
        @NonNull
        public static final a T;
        @NonNull
        public static final a U;

        /* renamed from: d  reason: collision with root package name */
        public static final a f9d = new a(1, (CharSequence) null);

        /* renamed from: e  reason: collision with root package name */
        public static final a f10e = new a(2, (CharSequence) null);

        /* renamed from: f  reason: collision with root package name */
        public static final a f11f = new a(4, (CharSequence) null);

        /* renamed from: g  reason: collision with root package name */
        public static final a f12g = new a(8, (CharSequence) null);

        /* renamed from: h  reason: collision with root package name */
        public static final a f13h = new a(16, (CharSequence) null);

        /* renamed from: i  reason: collision with root package name */
        public static final a f14i = new a(32, (CharSequence) null);

        /* renamed from: j  reason: collision with root package name */
        public static final a f15j = new a(64, (CharSequence) null);

        /* renamed from: k  reason: collision with root package name */
        public static final a f16k = new a(128, (CharSequence) null);

        /* renamed from: l  reason: collision with root package name */
        public static final a f17l;

        /* renamed from: m  reason: collision with root package name */
        public static final a f18m;

        /* renamed from: n  reason: collision with root package name */
        public static final a f19n;

        /* renamed from: o  reason: collision with root package name */
        public static final a f20o;

        /* renamed from: p  reason: collision with root package name */
        public static final a f21p = new a(Utils.CONTINUOUS_EVENT, (CharSequence) null);

        /* renamed from: q  reason: collision with root package name */
        public static final a f22q = new a(8192, (CharSequence) null);

        /* renamed from: r  reason: collision with root package name */
        public static final a f23r = new a(16384, (CharSequence) null);

        /* renamed from: s  reason: collision with root package name */
        public static final a f24s = new a(32768, (CharSequence) null);

        /* renamed from: t  reason: collision with root package name */
        public static final a f25t = new a(65536, (CharSequence) null);

        /* renamed from: u  reason: collision with root package name */
        public static final a f26u = new a(131072, (CharSequence) null, g0.g.class);

        /* renamed from: v  reason: collision with root package name */
        public static final a f27v = new a(262144, (CharSequence) null);

        /* renamed from: w  reason: collision with root package name */
        public static final a f28w = new a(524288, (CharSequence) null);

        /* renamed from: x  reason: collision with root package name */
        public static final a f29x = new a(1048576, (CharSequence) null);

        /* renamed from: y  reason: collision with root package name */
        public static final a f30y = new a(2097152, (CharSequence) null, g0.h.class);

        /* renamed from: z  reason: collision with root package name */
        public static final a f31z;

        /* renamed from: a  reason: collision with root package name */
        final Object f32a;

        /* renamed from: b  reason: collision with root package name */
        private final int f33b;

        /* renamed from: c  reason: collision with root package name */
        private final Class<? extends g0.a> f34c;

        static {
            AccessibilityNodeInfo.AccessibilityAction accessibilityAction = null;
            Class<g0.b> cls = g0.b.class;
            f17l = new a(256, (CharSequence) null, cls);
            f18m = new a(512, (CharSequence) null, cls);
            Class<g0.c> cls2 = g0.c.class;
            f19n = new a(1024, (CharSequence) null, cls2);
            f20o = new a(2048, (CharSequence) null, cls2);
            int i10 = Build.VERSION.SDK_INT;
            f31z = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN : null, 16908342, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            A = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION : null, 16908343, (CharSequence) null, (g0) null, g0.e.class);
            B = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP : null, 16908344, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            C = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT : null, 16908345, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            D = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN : null, 16908346, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            E = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT : null, 16908347, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            F = new a(i10 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_UP : null, 16908358, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            G = new a(i10 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_DOWN : null, 16908359, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            H = new a(i10 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_LEFT : null, 16908360, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            I = new a(i10 >= 29 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PAGE_RIGHT : null, 16908361, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            J = new a(i10 >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK : null, 16908348, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            K = new a(i10 >= 24 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS : null, 16908349, (CharSequence) null, (g0) null, g0.f.class);
            L = new a(i10 >= 26 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_MOVE_WINDOW : null, 16908354, (CharSequence) null, (g0) null, g0.d.class);
            M = new a(i10 >= 28 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TOOLTIP : null, 16908356, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            N = new a(i10 >= 28 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_HIDE_TOOLTIP : null, 16908357, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            O = new a(i10 >= 30 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_PRESS_AND_HOLD : null, 16908362, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            P = new a(i10 >= 30 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER : null, 16908372, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            Q = new a(i10 >= 32 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_START : null, 16908373, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            R = new a(i10 >= 32 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_DROP : null, 16908374, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            S = new a(i10 >= 32 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_DRAG_CANCEL : null, 16908375, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            T = new a(i10 >= 33 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TEXT_SUGGESTIONS : null, 16908376, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
            if (i10 >= 34) {
                accessibilityAction = d.a();
            }
            U = new a(accessibilityAction, 16908382, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
        }

        public a(int i10, CharSequence charSequence) {
            this((Object) null, i10, charSequence, (g0) null, (Class<? extends g0.a>) null);
        }

        private a(int i10, CharSequence charSequence, Class<? extends g0.a> cls) {
            this((Object) null, i10, charSequence, (g0) null, cls);
        }

        a(Object obj) {
            this(obj, 0, (CharSequence) null, (g0) null, (Class<? extends g0.a>) null);
        }

        a(Object obj, int i10, CharSequence charSequence, g0 g0Var, Class<? extends g0.a> cls) {
            this.f33b = i10;
            this.f32a = obj == null ? new AccessibilityNodeInfo.AccessibilityAction(i10, charSequence) : obj;
            this.f34c = cls;
        }

        public int a() {
            return ((AccessibilityNodeInfo.AccessibilityAction) this.f32a).getId();
        }

        public CharSequence b() {
            return ((AccessibilityNodeInfo.AccessibilityAction) this.f32a).getLabel();
        }

        public boolean c(View view, Bundle bundle) {
            return false;
        }

        public boolean equals(Object obj) {
            if (obj == null || !(obj instanceof a)) {
                return false;
            }
            Object obj2 = this.f32a;
            Object obj3 = ((a) obj).f32a;
            return obj2 == null ? obj3 == null : obj2.equals(obj3);
        }

        public int hashCode() {
            Object obj = this.f32a;
            if (obj != null) {
                return obj.hashCode();
            }
            return 0;
        }

        @NonNull
        public String toString() {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("AccessibilityActionCompat: ");
            String g10 = y.g(this.f33b);
            if (g10.equals("ACTION_UNKNOWN") && b() != null) {
                g10 = b().toString();
            }
            sb2.append(g10);
            return sb2.toString();
        }
    }

    private static class b {
        public static Object a(int i10, float f10, float f11, float f12) {
            return new AccessibilityNodeInfo.RangeInfo(i10, f10, f11, f12);
        }

        public static CharSequence b(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.getStateDescription();
        }

        public static void c(AccessibilityNodeInfo accessibilityNodeInfo, CharSequence charSequence) {
            accessibilityNodeInfo.setStateDescription(charSequence);
        }
    }

    private static class c {
        public static e a(boolean z10, int i10, int i11, int i12, int i13, boolean z11, String str, String str2) {
            return new e(new AccessibilityNodeInfo.CollectionItemInfo.Builder().setHeading(z10).setColumnIndex(i10).setRowIndex(i11).setColumnSpan(i12).setRowSpan(i13).setSelected(z11).setRowTitle(str).setColumnTitle(str2).build());
        }

        public static y b(AccessibilityNodeInfo accessibilityNodeInfo, int i10, int i11) {
            return y.d0(accessibilityNodeInfo.getChild(i10, i11));
        }

        public static String c(Object obj) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) obj).getColumnTitle();
        }

        public static String d(Object obj) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) obj).getRowTitle();
        }

        public static AccessibilityNodeInfo.ExtraRenderingInfo e(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.getExtraRenderingInfo();
        }

        public static y f(AccessibilityNodeInfo accessibilityNodeInfo, int i10) {
            return y.d0(accessibilityNodeInfo.getParent(i10));
        }

        public static String g(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.getUniqueId();
        }

        public static boolean h(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.isTextSelectable();
        }

        public static void i(AccessibilityNodeInfo accessibilityNodeInfo, boolean z10) {
            accessibilityNodeInfo.setTextSelectable(z10);
        }

        public static void j(AccessibilityNodeInfo accessibilityNodeInfo, String str) {
            accessibilityNodeInfo.setUniqueId(str);
        }
    }

    private static class d {
        public static AccessibilityNodeInfo.AccessibilityAction a() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_IN_DIRECTION;
        }

        public static void b(AccessibilityNodeInfo accessibilityNodeInfo, Rect rect) {
            accessibilityNodeInfo.getBoundsInWindow(rect);
        }

        public static CharSequence c(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.getContainerTitle();
        }

        public static long d(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.getMinDurationBetweenContentChanges().toMillis();
        }

        public static boolean e(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.hasRequestInitialAccessibilityFocus();
        }

        public static boolean f(AccessibilityNodeInfo accessibilityNodeInfo) {
            return accessibilityNodeInfo.isAccessibilityDataSensitive();
        }

        public static void g(AccessibilityNodeInfo accessibilityNodeInfo, boolean z10) {
            accessibilityNodeInfo.setAccessibilityDataSensitive(z10);
        }

        public static void h(AccessibilityNodeInfo accessibilityNodeInfo, Rect rect) {
            accessibilityNodeInfo.setBoundsInWindow(rect);
        }

        public static void i(AccessibilityNodeInfo accessibilityNodeInfo, CharSequence charSequence) {
            accessibilityNodeInfo.setContainerTitle(charSequence);
        }

        public static void j(AccessibilityNodeInfo accessibilityNodeInfo, long j10) {
            accessibilityNodeInfo.setMinDurationBetweenContentChanges(Duration.ofMillis(j10));
        }

        public static void k(AccessibilityNodeInfo accessibilityNodeInfo, View view, boolean z10) {
            accessibilityNodeInfo.setQueryFromAppProcessEnabled(view, z10);
        }

        public static void l(AccessibilityNodeInfo accessibilityNodeInfo, boolean z10) {
            accessibilityNodeInfo.setRequestInitialAccessibilityFocus(z10);
        }
    }

    public static class e {

        /* renamed from: a  reason: collision with root package name */
        final Object f35a;

        e(Object obj) {
            this.f35a = obj;
        }
    }

    private y(AccessibilityNodeInfo accessibilityNodeInfo) {
        this.f6a = accessibilityNodeInfo;
    }

    @Deprecated
    public y(Object obj) {
        this.f6a = (AccessibilityNodeInfo) obj;
    }

    private boolean A() {
        return !e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").isEmpty();
    }

    private int B(ClickableSpan clickableSpan, SparseArray<WeakReference<ClickableSpan>> sparseArray) {
        if (sparseArray != null) {
            for (int i10 = 0; i10 < sparseArray.size(); i10++) {
                if (clickableSpan.equals((ClickableSpan) sparseArray.valueAt(i10).get())) {
                    return sparseArray.keyAt(i10);
                }
            }
        }
        int i11 = f5d;
        f5d = i11 + 1;
        return i11;
    }

    private void T(View view) {
        SparseArray<WeakReference<ClickableSpan>> u10 = u(view);
        if (u10 != null) {
            ArrayList arrayList = new ArrayList();
            for (int i10 = 0; i10 < u10.size(); i10++) {
                if (u10.valueAt(i10).get() == null) {
                    arrayList.add(Integer.valueOf(i10));
                }
            }
            for (int i11 = 0; i11 < arrayList.size(); i11++) {
                u10.remove(((Integer) arrayList.get(i11)).intValue());
            }
        }
    }

    private void U(int i10, boolean z10) {
        Bundle q10 = q();
        if (q10 != null) {
            int i11 = q10.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0) & (~i10);
            if (!z10) {
                i10 = 0;
            }
            q10.putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", i10 | i11);
        }
    }

    private void b(ClickableSpan clickableSpan, Spanned spanned, int i10) {
        e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").add(Integer.valueOf(spanned.getSpanStart(clickableSpan)));
        e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY").add(Integer.valueOf(spanned.getSpanEnd(clickableSpan)));
        e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY").add(Integer.valueOf(spanned.getSpanFlags(clickableSpan)));
        e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY").add(Integer.valueOf(i10));
    }

    public static y c0(@NonNull AccessibilityNodeInfo accessibilityNodeInfo) {
        return new y(accessibilityNodeInfo);
    }

    private void d() {
        this.f6a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
        this.f6a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
        this.f6a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
        this.f6a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
    }

    static y d0(Object obj) {
        if (obj != null) {
            return new y(obj);
        }
        return null;
    }

    private List<Integer> e(String str) {
        ArrayList<Integer> integerArrayList = this.f6a.getExtras().getIntegerArrayList(str);
        if (integerArrayList != null) {
            return integerArrayList;
        }
        ArrayList arrayList = new ArrayList();
        this.f6a.getExtras().putIntegerArrayList(str, arrayList);
        return arrayList;
    }

    static String g(int i10) {
        if (i10 == 1) {
            return "ACTION_FOCUS";
        }
        if (i10 == 2) {
            return "ACTION_CLEAR_FOCUS";
        }
        switch (i10) {
            case 4:
                return "ACTION_SELECT";
            case 8:
                return "ACTION_CLEAR_SELECTION";
            case 16:
                return "ACTION_CLICK";
            case 32:
                return "ACTION_LONG_CLICK";
            case 64:
                return "ACTION_ACCESSIBILITY_FOCUS";
            case 128:
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            case 256:
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            case 512:
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            case 1024:
                return "ACTION_NEXT_HTML_ELEMENT";
            case 2048:
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            case Utils.CONTINUOUS_EVENT /*4096*/:
                return "ACTION_SCROLL_FORWARD";
            case 8192:
                return "ACTION_SCROLL_BACKWARD";
            case 16384:
                return "ACTION_COPY";
            case 32768:
                return "ACTION_PASTE";
            case 65536:
                return "ACTION_CUT";
            case 131072:
                return "ACTION_SET_SELECTION";
            case 262144:
                return "ACTION_EXPAND";
            case 524288:
                return "ACTION_COLLAPSE";
            case 2097152:
                return "ACTION_SET_TEXT";
            case 16908354:
                return "ACTION_MOVE_WINDOW";
            case 16908382:
                return "ACTION_SCROLL_IN_DIRECTION";
            default:
                switch (i10) {
                    case 16908342:
                        return "ACTION_SHOW_ON_SCREEN";
                    case 16908343:
                        return "ACTION_SCROLL_TO_POSITION";
                    case 16908344:
                        return "ACTION_SCROLL_UP";
                    case 16908345:
                        return "ACTION_SCROLL_LEFT";
                    case 16908346:
                        return "ACTION_SCROLL_DOWN";
                    case 16908347:
                        return "ACTION_SCROLL_RIGHT";
                    case 16908348:
                        return "ACTION_CONTEXT_CLICK";
                    case 16908349:
                        return "ACTION_SET_PROGRESS";
                    default:
                        switch (i10) {
                            case 16908356:
                                return "ACTION_SHOW_TOOLTIP";
                            case 16908357:
                                return "ACTION_HIDE_TOOLTIP";
                            case 16908358:
                                return "ACTION_PAGE_UP";
                            case 16908359:
                                return "ACTION_PAGE_DOWN";
                            case 16908360:
                                return "ACTION_PAGE_LEFT";
                            case 16908361:
                                return "ACTION_PAGE_RIGHT";
                            case 16908362:
                                return "ACTION_PRESS_AND_HOLD";
                            default:
                                switch (i10) {
                                    case 16908372:
                                        return "ACTION_IME_ENTER";
                                    case 16908373:
                                        return "ACTION_DRAG_START";
                                    case 16908374:
                                        return "ACTION_DRAG_DROP";
                                    case 16908375:
                                        return "ACTION_DRAG_CANCEL";
                                    default:
                                        return "ACTION_UNKNOWN";
                                }
                        }
                }
        }
    }

    private boolean h(int i10) {
        Bundle q10 = q();
        return q10 != null && (q10.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0) & i10) == i10;
    }

    public static ClickableSpan[] m(CharSequence charSequence) {
        if (charSequence instanceof Spanned) {
            return (ClickableSpan[]) ((Spanned) charSequence).getSpans(0, charSequence.length(), ClickableSpan.class);
        }
        return null;
    }

    private SparseArray<WeakReference<ClickableSpan>> s(View view) {
        SparseArray<WeakReference<ClickableSpan>> u10 = u(view);
        if (u10 != null) {
            return u10;
        }
        SparseArray<WeakReference<ClickableSpan>> sparseArray = new SparseArray<>();
        view.setTag(u.e.I, sparseArray);
        return sparseArray;
    }

    private SparseArray<WeakReference<ClickableSpan>> u(View view) {
        return (SparseArray) view.getTag(u.e.I);
    }

    public boolean C() {
        return Build.VERSION.SDK_INT >= 34 ? d.f(this.f6a) : h(64);
    }

    public boolean D() {
        return this.f6a.isCheckable();
    }

    public boolean E() {
        return this.f6a.isChecked();
    }

    public boolean F() {
        return this.f6a.isClickable();
    }

    public boolean G() {
        if (Build.VERSION.SDK_INT >= 23) {
            return this.f6a.isContextClickable();
        }
        return false;
    }

    public boolean H() {
        return this.f6a.isEnabled();
    }

    public boolean I() {
        return this.f6a.isFocusable();
    }

    public boolean J() {
        return this.f6a.isFocused();
    }

    public boolean K() {
        return h(67108864);
    }

    public boolean L() {
        if (Build.VERSION.SDK_INT >= 24) {
            return this.f6a.isImportantForAccessibility();
        }
        return true;
    }

    public boolean M() {
        return this.f6a.isLongClickable();
    }

    public boolean N() {
        return this.f6a.isPassword();
    }

    public boolean O() {
        return this.f6a.isScrollable();
    }

    public boolean P() {
        return this.f6a.isSelected();
    }

    public boolean Q() {
        return Build.VERSION.SDK_INT >= 33 ? c.h(this.f6a) : h(8388608);
    }

    public boolean R() {
        return this.f6a.isVisibleToUser();
    }

    public boolean S(int i10, Bundle bundle) {
        return this.f6a.performAction(i10, bundle);
    }

    public void V(CharSequence charSequence) {
        this.f6a.setClassName(charSequence);
    }

    public void W(boolean z10) {
        if (Build.VERSION.SDK_INT >= 28) {
            this.f6a.setHeading(z10);
        } else {
            U(2, z10);
        }
    }

    public void X(CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 28) {
            this.f6a.setPaneTitle(charSequence);
        } else {
            this.f6a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY", charSequence);
        }
    }

    public void Y(boolean z10) {
        if (Build.VERSION.SDK_INT >= 28) {
            this.f6a.setScreenReaderFocusable(z10);
        } else {
            U(1, z10);
        }
    }

    public void Z(boolean z10) {
        this.f6a.setScrollable(z10);
    }

    public void a(a aVar) {
        this.f6a.addAction((AccessibilityNodeInfo.AccessibilityAction) aVar.f32a);
    }

    public void a0(CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 30) {
            b.c(this.f6a, charSequence);
        } else {
            this.f6a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY", charSequence);
        }
    }

    public AccessibilityNodeInfo b0() {
        return this.f6a;
    }

    public void c(CharSequence charSequence, View view) {
        if (Build.VERSION.SDK_INT < 26) {
            d();
            T(view);
            ClickableSpan[] m10 = m(charSequence);
            if (m10 != null && m10.length > 0) {
                q().putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY", u.e.f16313a);
                SparseArray<WeakReference<ClickableSpan>> s10 = s(view);
                for (int i10 = 0; i10 < m10.length; i10++) {
                    int B = B(m10[i10], s10);
                    s10.put(B, new WeakReference(m10[i10]));
                    b(m10[i10], (Spanned) charSequence, B);
                }
            }
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof y)) {
            return false;
        }
        y yVar = (y) obj;
        AccessibilityNodeInfo accessibilityNodeInfo = this.f6a;
        if (accessibilityNodeInfo == null) {
            if (yVar.f6a != null) {
                return false;
            }
        } else if (!accessibilityNodeInfo.equals(yVar.f6a)) {
            return false;
        }
        return this.f8c == yVar.f8c && this.f7b == yVar.f7b;
    }

    public List<a> f() {
        List<AccessibilityNodeInfo.AccessibilityAction> actionList = this.f6a.getActionList();
        if (actionList == null) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        int size = actionList.size();
        for (int i10 = 0; i10 < size; i10++) {
            arrayList.add(new a(actionList.get(i10)));
        }
        return arrayList;
    }

    public int hashCode() {
        AccessibilityNodeInfo accessibilityNodeInfo = this.f6a;
        if (accessibilityNodeInfo == null) {
            return 0;
        }
        return accessibilityNodeInfo.hashCode();
    }

    @Deprecated
    public void i(Rect rect) {
        this.f6a.getBoundsInParent(rect);
    }

    public void j(Rect rect) {
        this.f6a.getBoundsInScreen(rect);
    }

    public void k(@NonNull Rect rect) {
        if (Build.VERSION.SDK_INT >= 34) {
            d.b(this.f6a, rect);
            return;
        }
        Rect rect2 = (Rect) this.f6a.getExtras().getParcelable("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOUNDS_IN_WINDOW_KEY");
        if (rect2 != null) {
            rect.set(rect2.left, rect2.top, rect2.right, rect2.bottom);
        }
    }

    public CharSequence l() {
        return this.f6a.getClassName();
    }

    public CharSequence n() {
        return Build.VERSION.SDK_INT >= 34 ? d.c(this.f6a) : this.f6a.getExtras().getCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.CONTAINER_TITLE_KEY");
    }

    public CharSequence o() {
        return this.f6a.getContentDescription();
    }

    public CharSequence p() {
        return this.f6a.getError();
    }

    public Bundle q() {
        return this.f6a.getExtras();
    }

    public int r() {
        return this.f6a.getMaxTextLength();
    }

    public CharSequence t() {
        return this.f6a.getPackageName();
    }

    @NonNull
    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.toString());
        Rect rect = new Rect();
        i(rect);
        sb2.append("; boundsInParent: " + rect);
        j(rect);
        sb2.append("; boundsInScreen: " + rect);
        k(rect);
        sb2.append("; boundsInWindow: " + rect);
        sb2.append("; packageName: ");
        sb2.append(t());
        sb2.append("; className: ");
        sb2.append(l());
        sb2.append("; text: ");
        sb2.append(w());
        sb2.append("; error: ");
        sb2.append(p());
        sb2.append("; maxTextLength: ");
        sb2.append(r());
        sb2.append("; stateDescription: ");
        sb2.append(v());
        sb2.append("; contentDescription: ");
        sb2.append(o());
        sb2.append("; tooltipText: ");
        sb2.append(x());
        sb2.append("; viewIdResName: ");
        sb2.append(z());
        sb2.append("; uniqueId: ");
        sb2.append(y());
        sb2.append("; checkable: ");
        sb2.append(D());
        sb2.append("; checked: ");
        sb2.append(E());
        sb2.append("; focusable: ");
        sb2.append(I());
        sb2.append("; focused: ");
        sb2.append(J());
        sb2.append("; selected: ");
        sb2.append(P());
        sb2.append("; clickable: ");
        sb2.append(F());
        sb2.append("; longClickable: ");
        sb2.append(M());
        sb2.append("; contextClickable: ");
        sb2.append(G());
        sb2.append("; enabled: ");
        sb2.append(H());
        sb2.append("; password: ");
        sb2.append(N());
        sb2.append("; scrollable: " + O());
        sb2.append("; containerTitle: ");
        sb2.append(n());
        sb2.append("; granularScrollingSupported: ");
        sb2.append(K());
        sb2.append("; importantForAccessibility: ");
        sb2.append(L());
        sb2.append("; visible: ");
        sb2.append(R());
        sb2.append("; isTextSelectable: ");
        sb2.append(Q());
        sb2.append("; accessibilityDataSensitive: ");
        sb2.append(C());
        sb2.append("; [");
        List<a> f10 = f();
        for (int i10 = 0; i10 < f10.size(); i10++) {
            a aVar = f10.get(i10);
            String g10 = g(aVar.a());
            if (g10.equals("ACTION_UNKNOWN") && aVar.b() != null) {
                g10 = aVar.b().toString();
            }
            sb2.append(g10);
            if (i10 != f10.size() - 1) {
                sb2.append(", ");
            }
        }
        sb2.append("]");
        return sb2.toString();
    }

    public CharSequence v() {
        return Build.VERSION.SDK_INT >= 30 ? b.b(this.f6a) : this.f6a.getExtras().getCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY");
    }

    public CharSequence w() {
        if (!A()) {
            return this.f6a.getText();
        }
        List<Integer> e10 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
        List<Integer> e11 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
        List<Integer> e12 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
        List<Integer> e13 = e("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
        SpannableString spannableString = new SpannableString(TextUtils.substring(this.f6a.getText(), 0, this.f6a.getText().length()));
        for (int i10 = 0; i10 < e10.size(); i10++) {
            spannableString.setSpan(new a(e13.get(i10).intValue(), this, q().getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY")), e10.get(i10).intValue(), e11.get(i10).intValue(), e12.get(i10).intValue());
        }
        return spannableString;
    }

    public CharSequence x() {
        return Build.VERSION.SDK_INT >= 28 ? this.f6a.getTooltipText() : this.f6a.getExtras().getCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.TOOLTIP_TEXT_KEY");
    }

    public String y() {
        return Build.VERSION.SDK_INT >= 33 ? c.g(this.f6a) : this.f6a.getExtras().getString("androidx.view.accessibility.AccessibilityNodeInfoCompat.UNIQUE_ID_KEY");
    }

    public String z() {
        return this.f6a.getViewIdResourceName();
    }
}
