package a0;

public class e0 {

    /* renamed from: a  reason: collision with root package name */
    private final Object f4a;

    public e0(Object obj) {
        this.f4a = obj;
    }

    public Object a() {
        return this.f4a;
    }
}
