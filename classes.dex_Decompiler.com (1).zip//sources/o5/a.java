package o5;

public class a extends c {

    /* renamed from: b  reason: collision with root package name */
    private final int f13479b;

    public a(String str, int i10) {
        super(str);
        this.f13479b = i10;
    }
}
