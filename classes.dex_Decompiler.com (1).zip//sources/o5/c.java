package o5;

public class c extends RuntimeException {

    /* renamed from: a  reason: collision with root package name */
    private final String f13483a;

    public c(String str) {
        super(str);
        this.f13483a = str;
    }

    public String getMessage() {
        return this.f13483a;
    }
}
