package o5;

import androidx.annotation.NonNull;
import org.jetbrains.annotations.NotNull;

public class b extends Exception {

    /* renamed from: a  reason: collision with root package name */
    private final com.garena.pay.android.b f13480a;

    /* renamed from: b  reason: collision with root package name */
    private final String f13481b;

    /* renamed from: c  reason: collision with root package name */
    private final String f13482c;

    public b(@NotNull com.garena.pay.android.b bVar) {
        this.f13480a = bVar;
        this.f13481b = "";
        this.f13482c = "";
    }

    public b(@NotNull com.garena.pay.android.b bVar, @NotNull String str) {
        this.f13480a = bVar;
        this.f13481b = str;
        this.f13482c = "";
    }

    public b(@NonNull com.garena.pay.android.b bVar, @NonNull String str, @NonNull String str2) {
        this.f13480a = bVar;
        this.f13481b = str;
        this.f13482c = str2;
    }

    @NonNull
    public com.garena.pay.android.b a() {
        return this.f13480a;
    }

    @NonNull
    public String b() {
        return this.f13482c;
    }

    public String getMessage() {
        return this.f13481b;
    }
}
