package x6;

import androidx.annotation.NonNull;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import r6.p;

public class a implements ThreadFactory {

    /* renamed from: a  reason: collision with root package name */
    private final String f17535a;

    /* renamed from: b  reason: collision with root package name */
    private final ThreadFactory f17536b = Executors.defaultThreadFactory();

    public a(@NonNull String str) {
        p.m(str, "Name must not be null");
        this.f17535a = str;
    }

    @NonNull
    public final Thread newThread(@NonNull Runnable runnable) {
        Thread newThread = this.f17536b.newThread(new b(runnable, 0));
        newThread.setName(this.f17535a);
        return newThread;
    }
}
