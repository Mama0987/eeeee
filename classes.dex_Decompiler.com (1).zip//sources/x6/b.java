package x6;

import android.os.Process;

final class b implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    private final Runnable f17537a;

    public b(Runnable runnable, int i10) {
        this.f17537a = runnable;
    }

    public final void run() {
        Process.setThreadPriority(0);
        this.f17537a.run();
    }
}
