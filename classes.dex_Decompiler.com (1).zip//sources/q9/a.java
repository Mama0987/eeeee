package q9;

public interface a {
}
