package b0;

public class a {
}
