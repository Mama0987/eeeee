package h1;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final int f11205a = 2131689499;
}
