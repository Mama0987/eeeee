package h1;

import android.content.Context;
import androidx.annotation.NonNull;
import java.util.List;

public interface a<T> {
    @NonNull
    List<Class<? extends a<?>>> a();

    @NonNull
    T b(@NonNull Context context);
}
