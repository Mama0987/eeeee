package h1;

import androidx.annotation.NonNull;

public final class c extends RuntimeException {
    public c(@NonNull String str) {
        super(str);
    }

    public c(@NonNull Throwable th) {
        super(th);
    }
}
