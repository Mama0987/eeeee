package n2;

import android.app.Activity;
import b7.a;
import b7.g;
import b7.p;
import com.beetalk.sdk.f;
import com.beetalk.sdk.networking.model.RecallTokenResponse;
import com.beetalk.sdk.networking.model.SaveTokenResponse;
import com.garena.pay.android.b;
import com.google.android.gms.tasks.Task;
import java.util.Arrays;
import java.util.List;
import v1.d;
import v1.i;
import v1.j;

public class l {
    public static i<SaveTokenResponse> A(Activity activity, d dVar) {
        return i.L(Arrays.asList(new i[]{m(dVar), n(activity, dVar)})).C(new g());
    }

    public static i<Boolean> B(Activity activity, d dVar) {
        return i.e(new e(activity), dVar).C(new f());
    }

    public static i<Boolean> l(Activity activity, d dVar) {
        return i.e(new a(activity), dVar).C(new c());
    }

    private static i<String> m(d dVar) throws RuntimeException {
        return i.g(new i(), dVar);
    }

    private static i<String> n(Activity activity, d dVar) {
        return B(activity, dVar).C(new h(activity));
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ i o(i iVar) throws Exception {
        j jVar = new j();
        ((g) iVar.v()).b().addOnCompleteListener(new j(jVar));
        return jVar.a();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void q(j jVar, Task task) {
        if (task.isCanceled()) {
            jVar.b();
        } else if (task.isSuccessful()) {
            jVar.d(Boolean.valueOf(((a) task.getResult()).a()));
        } else {
            jVar.c(task.getException());
        }
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ String r() throws Exception {
        e2.a H;
        if (i2.i.s(com.beetalk.sdk.j.z())) {
            f w10 = f.w();
            if (w10 != null && (H = w10.H()) != null) {
                return H.c();
            }
            throw new IllegalArgumentException(b.GOP_ERROR_TOKEN.i());
        }
        throw new IllegalArgumentException("Invalid Google Play Games app id");
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void s(j jVar, Task task) {
        if (task.isSuccessful()) {
            jVar.d(((p) task.getResult()).a());
            return;
        }
        Exception exception = task.getException();
        jVar.c(new IllegalArgumentException(exception != null ? exception.getMessage() : "retrieve session id failed"));
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ i t(Activity activity, i iVar) throws Exception {
        j jVar = new j();
        b7.i.b(activity).b().addOnCompleteListener(new b(jVar));
        return jVar.a();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ i v(i iVar) throws Exception {
        List list = (List) iVar.v();
        return m2.j.G((String) list.get(0), (String) list.get(1));
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void x(j jVar, Task task) {
        if (task.isCanceled()) {
            jVar.b();
        } else if (task.isSuccessful()) {
            jVar.d(Boolean.valueOf(((a) task.getResult()).a()));
        } else {
            jVar.c(task.getException());
        }
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ i y(i iVar) throws Exception {
        j jVar = new j();
        ((g) iVar.v()).c().addOnCompleteListener(new k(jVar));
        return jVar.a();
    }

    public static i<RecallTokenResponse> z(Activity activity, d dVar) {
        return n(activity, dVar).C(new d());
    }
}
