package n2;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import v1.j;

public final /* synthetic */ class b implements OnCompleteListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j f13223a;

    public /* synthetic */ b(j jVar) {
        this.f13223a = jVar;
    }

    public final void onComplete(Task task) {
        l.s(this.f13223a, task);
    }
}
