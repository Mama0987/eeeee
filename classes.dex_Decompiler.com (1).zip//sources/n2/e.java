package n2;

import android.app.Activity;
import b7.i;
import java.util.concurrent.Callable;

public final /* synthetic */ class e implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Activity f13224a;

    public /* synthetic */ e(Activity activity) {
        this.f13224a = activity;
    }

    public final Object call() {
        return i.a(this.f13224a);
    }
}
