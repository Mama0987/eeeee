package n2;

import android.app.Activity;
import b7.i;
import java.util.concurrent.Callable;

public final /* synthetic */ class a implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Activity f13222a;

    public /* synthetic */ a(Activity activity) {
        this.f13222a = activity;
    }

    public final Object call() {
        return i.a(this.f13222a);
    }
}
