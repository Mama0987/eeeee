package n2;

import v1.g;
import v1.i;

public final /* synthetic */ class f implements g {
    public final Object a(i iVar) {
        return l.y(iVar);
    }
}
