package n2;

import v1.g;
import v1.i;

public final /* synthetic */ class c implements g {
    public final Object a(i iVar) {
        return l.o(iVar);
    }
}
