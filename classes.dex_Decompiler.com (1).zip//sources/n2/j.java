package n2;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public final /* synthetic */ class j implements OnCompleteListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v1.j f13226a;

    public /* synthetic */ j(v1.j jVar) {
        this.f13226a = jVar;
    }

    public final void onComplete(Task task) {
        l.q(this.f13226a, task);
    }
}
