package n2;

import m2.j;
import v1.g;
import v1.i;

public final /* synthetic */ class d implements g {
    public final Object a(i iVar) {
        return j.D((String) iVar.v());
    }
}
