package n2;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import v1.j;

public final /* synthetic */ class k implements OnCompleteListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j f13227a;

    public /* synthetic */ k(j jVar) {
        this.f13227a = jVar;
    }

    public final void onComplete(Task task) {
        l.x(this.f13227a, task);
    }
}
