package n2;

import java.util.concurrent.Callable;

public final /* synthetic */ class i implements Callable {
    public final Object call() {
        return l.r();
    }
}
