package n2;

import android.app.Activity;
import androidx.annotation.NonNull;
import com.beetalk.sdk.f;
import com.beetalk.sdk.j;
import com.beetalk.sdk.networking.model.RecallToken;
import com.beetalk.sdk.networking.model.RecallTokenResponse;
import com.beetalk.sdk.networking.model.SaveTokenResponse;
import i2.b;
import i2.i;
import i2.v;
import i5.a;

public final class m {
    public static void a(@NonNull Activity activity, @NonNull j.e<a<Boolean>> eVar) {
        b i10 = b.i(activity);
        v.c(activity, i10, l.l(activity, i10.c()), eVar);
    }

    public static void b(Activity activity, @NonNull j.e<a<RecallTokenResponse>> eVar) {
        b i10 = b.i(activity);
        v.c(activity, i10, l.z(activity, i10.c()), eVar);
    }

    public static void c(Activity activity, RecallToken recallToken, f.h hVar) {
        e2.a aVar = new e2.a(recallToken.getAccessToken(), recallToken.getLoginPlatform(), recallToken.getOriginalPlatform());
        aVar.s(Integer.valueOf(recallToken.getPrimaryPlatform()));
        aVar.r(recallToken.getOpenId());
        aVar.o((int) recallToken.getExpiryTime());
        aVar.p(i.p());
        new d2.j(j.z()).l(aVar);
        if (j.E(activity)) {
            j.P(activity, hVar);
        }
    }

    public static void d(Activity activity, @NonNull j.e<a<SaveTokenResponse>> eVar) {
        b i10 = b.i(activity);
        v.c(activity, i10, l.A(activity, i10.c()), eVar);
    }

    public static void e(@NonNull Activity activity, @NonNull j.e<a<Boolean>> eVar) {
        b i10 = b.i(activity);
        v.c(activity, i10, l.B(activity, i10.c()), eVar);
    }
}
