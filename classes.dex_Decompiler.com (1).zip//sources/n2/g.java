package n2;

import v1.i;

public final /* synthetic */ class g implements v1.g {
    public final Object a(i iVar) {
        return l.v(iVar);
    }
}
