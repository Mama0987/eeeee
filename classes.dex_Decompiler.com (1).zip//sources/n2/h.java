package n2;

import android.app.Activity;
import v1.g;
import v1.i;

public final /* synthetic */ class h implements g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Activity f13225a;

    public /* synthetic */ h(Activity activity) {
        this.f13225a = activity;
    }

    public final Object a(i iVar) {
        return l.t(this.f13225a, iVar);
    }
}
