package o0;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f13418a = {16842755, 16842960, 16842961};

    /* renamed from: b  reason: collision with root package name */
    public static final int f13419b = 0;

    /* renamed from: c  reason: collision with root package name */
    public static final int f13420c = 1;

    /* renamed from: d  reason: collision with root package name */
    public static final int f13421d = 2;

    /* renamed from: e  reason: collision with root package name */
    public static final int[] f13422e = {16842755, 16842961};

    /* renamed from: f  reason: collision with root package name */
    public static final int f13423f = 0;

    /* renamed from: g  reason: collision with root package name */
    public static final int f13424g = 1;
}
