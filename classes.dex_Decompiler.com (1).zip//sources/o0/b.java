package o0;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final int f13415a = 2131296398;

    /* renamed from: b  reason: collision with root package name */
    public static final int f13416b = 2131296495;

    /* renamed from: c  reason: collision with root package name */
    public static final int f13417c = 2131296566;
}
