package u1;

import android.os.Build;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import org.jetbrains.annotations.NotNull;
import r1.b0;
import r1.i;
import r1.k;
import r1.p;
import r1.v;
import r1.y;

@Metadata
public final class e {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final String f16391a;

    static {
        String i10 = n.i("DiagnosticsWrkr");
        Intrinsics.checkNotNullExpressionValue(i10, "tagWithPrefix(\"DiagnosticsWrkr\")");
        f16391a = i10;
    }

    private static final String c(v vVar, String str, Integer num, String str2) {
        return 10 + vVar.f14524a + "\t " + vVar.f14526c + "\t " + num + "\t " + vVar.f14525b.name() + "\t " + str + "\t " + str2 + 9;
    }

    /* access modifiers changed from: private */
    public static final String d(p pVar, b0 b0Var, k kVar, List<v> list) {
        StringBuilder sb2 = new StringBuilder();
        String str = Build.VERSION.SDK_INT >= 23 ? "Job Id" : "Alarm Id";
        sb2.append("\n Id \t Class Name\t " + str + "\t State\t Unique Name\t Tags\t");
        for (v vVar : list) {
            i c10 = kVar.c(y.a(vVar));
            sb2.append(c(vVar, CollectionsKt___CollectionsKt.K(pVar.b(vVar.f14524a), ",", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null), c10 != null ? Integer.valueOf(c10.f14497c) : null, CollectionsKt___CollectionsKt.K(b0Var.a(vVar.f14524a), ",", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null)));
        }
        String sb3 = sb2.toString();
        Intrinsics.checkNotNullExpressionValue(sb3, "StringBuilder().apply(builderAction).toString()");
        return sb3;
    }
}
