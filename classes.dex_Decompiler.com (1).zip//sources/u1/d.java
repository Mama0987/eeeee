package u1;

import androidx.work.c;
import androidx.work.impl.utils.futures.c;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import m1.n;
import org.jetbrains.annotations.NotNull;

@Metadata
public final class d {
    /* access modifiers changed from: private */
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final String f16390a;

    static {
        String i10 = n.i("ConstraintTrkngWrkr");
        Intrinsics.checkNotNullExpressionValue(i10, "tagWithPrefix(\"ConstraintTrkngWrkr\")");
        f16390a = i10;
    }

    /* access modifiers changed from: private */
    public static final boolean d(c<c.a> cVar) {
        return cVar.p(c.a.a());
    }

    /* access modifiers changed from: private */
    public static final boolean e(androidx.work.impl.utils.futures.c<c.a> cVar) {
        return cVar.p(c.a.b());
    }
}
