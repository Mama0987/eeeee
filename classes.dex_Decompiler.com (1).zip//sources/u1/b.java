package u1;

import androidx.work.impl.workers.ConstraintTrackingWorker;
import xb.r1;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ r1 f16387a;

    public /* synthetic */ b(r1 r1Var) {
        this.f16387a = r1Var;
    }

    public final void run() {
        ConstraintTrackingWorker.t(this.f16387a);
    }
}
