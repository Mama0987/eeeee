package u1;

import androidx.work.impl.workers.ConstraintTrackingWorker;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ConstraintTrackingWorker f16386a;

    public /* synthetic */ a(ConstraintTrackingWorker constraintTrackingWorker) {
        this.f16386a = constraintTrackingWorker;
    }

    public final void run() {
        ConstraintTrackingWorker.v(this.f16386a);
    }
}
