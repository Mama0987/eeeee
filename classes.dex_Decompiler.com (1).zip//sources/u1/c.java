package u1;

import androidx.work.impl.workers.ConstraintTrackingWorker;
import j8.d;

public final /* synthetic */ class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ConstraintTrackingWorker f16388a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ d f16389b;

    public /* synthetic */ c(ConstraintTrackingWorker constraintTrackingWorker, d dVar) {
        this.f16388a = constraintTrackingWorker;
        this.f16389b = dVar;
    }

    public final void run() {
        ConstraintTrackingWorker.u(this.f16388a, this.f16389b);
    }
}
