package x2;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import com.beetalk.sdk.plugin.PluginResult;
import com.twitter.sdk.android.core.b;
import com.twitter.sdk.android.core.i;
import com.twitter.sdk.android.core.w;
import com.twitter.sdk.android.core.x;
import com.twitter.sdk.android.core.z;
import com.twitter.sdk.android.tweetcomposer.a;
import i2.d;
import ja.e;

public class a extends com.beetalk.sdk.plugin.a<g3.a, PluginResult> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public Activity f17468a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public g3.a f17469b;

    /* renamed from: c  reason: collision with root package name */
    private volatile e f17470c;

    /* renamed from: d  reason: collision with root package name */
    private int f17471d = 141;

    /* renamed from: e  reason: collision with root package name */
    private final b<z> f17472e = new C0319a();

    /* renamed from: x2.a$a  reason: collision with other inner class name */
    class C0319a extends b<z> {
        C0319a() {
        }

        public void c(x xVar) {
            a aVar = a.this;
            aVar.h(aVar.f17468a, com.garena.pay.android.b.APP_NOT_INSTALLED.g().intValue(), "Twitter not installed.");
        }

        public void d(i<z> iVar) {
            a aVar = a.this;
            aVar.q(aVar.f17469b);
            a aVar2 = a.this;
            aVar2.g(aVar2.f17468a, com.garena.pay.android.b.SUCCESS.g().intValue());
        }
    }

    private e p() {
        if (this.f17470c == null) {
            synchronized (a.class) {
                if (this.f17470c == null) {
                    this.f17470c = new e();
                }
            }
        }
        return this.f17470c;
    }

    /* access modifiers changed from: private */
    public void q(g3.a aVar) {
        z d10 = w.g().h().d();
        if (d10 == null) {
            r();
            return;
        }
        this.f17471d = 141;
        this.f17468a.startActivityForResult(new a.C0122a(this.f17468a).c(d10).b(aVar.f10985c).e(aVar.f10986d).d(aVar.a()).a(), this.f17471d);
    }

    private void r() {
        this.f17471d = 140;
        p().a(this.f17468a, this.f17472e);
    }

    public boolean a() {
        return true;
    }

    public String d() {
        return "twitter.share";
    }

    public Integer e() {
        return Integer.valueOf(this.f17471d);
    }

    public boolean f(Activity activity, int i10, Intent intent) {
        if (this.f17471d != 140) {
            return true;
        }
        p().f(e().intValue(), i10, intent);
        return true;
    }

    /* access modifiers changed from: protected */
    /* renamed from: o */
    public void b(Activity activity, g3.a aVar) {
        Uri c10;
        if (aVar == null) {
            g(activity, com.garena.pay.android.b.ERROR_IN_PARAMS.g().intValue());
        } else if (!i2.i.v("com.twitter.android", activity)) {
            this.f17468a = activity;
            this.f17469b = aVar;
            q(aVar);
        } else {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND");
            intent.setPackage("com.twitter.android");
            intent.setClassName("com.twitter.android", "com.twitter.composer.ComposerActivity");
            if (!TextUtils.isEmpty(aVar.f10985c)) {
                intent.setType("image/*");
                c10 = aVar.b(activity);
            } else if (!TextUtils.isEmpty(aVar.f10986d)) {
                intent.setType("video/*");
                c10 = aVar.c(activity);
            } else {
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.TEXT", aVar.a());
                activity.startActivity(intent);
                g(activity, com.garena.pay.android.b.SUCCESS.g().intValue());
            }
            intent.putExtra("android.intent.extra.STREAM", c10);
            intent.putExtra("android.intent.extra.TEXT", aVar.a());
            try {
                activity.startActivity(intent);
                g(activity, com.garena.pay.android.b.SUCCESS.g().intValue());
            } catch (ActivityNotFoundException e10) {
                d.b(e10);
                d.a("twitter not installed", new Object[0]);
                g(activity, com.garena.pay.android.b.APP_NOT_INSTALLED.g().intValue());
            }
        }
    }
}
