package t1;

import androidx.annotation.NonNull;

public final /* synthetic */ class b {
    public static void a(c cVar, @NonNull Runnable runnable) {
        cVar.c().execute(runnable);
    }
}
