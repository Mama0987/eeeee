package t1;

import java.util.concurrent.Executor;

public interface a extends Executor {
    boolean a();
}
