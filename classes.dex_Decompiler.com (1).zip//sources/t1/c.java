package t1;

import androidx.annotation.NonNull;
import java.util.concurrent.Executor;
import xb.g0;

public interface c {
    @NonNull
    g0 a();

    @NonNull
    Executor b();

    @NonNull
    a c();

    void d(@NonNull Runnable runnable);
}
