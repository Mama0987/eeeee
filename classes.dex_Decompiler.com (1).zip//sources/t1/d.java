package t1;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import java.util.concurrent.Executor;
import s1.u;
import xb.g0;
import xb.j1;

public class d implements c {

    /* renamed from: a  reason: collision with root package name */
    private final u f15430a;

    /* renamed from: b  reason: collision with root package name */
    private final g0 f15431b;

    /* renamed from: c  reason: collision with root package name */
    final Handler f15432c = new Handler(Looper.getMainLooper());

    /* renamed from: d  reason: collision with root package name */
    private final Executor f15433d = new a();

    class a implements Executor {
        a() {
        }

        public void execute(@NonNull Runnable runnable) {
            d.this.f15432c.post(runnable);
        }
    }

    public d(@NonNull Executor executor) {
        u uVar = new u(executor);
        this.f15430a = uVar;
        this.f15431b = j1.a(uVar);
    }

    @NonNull
    public g0 a() {
        return this.f15431b;
    }

    @NonNull
    public Executor b() {
        return this.f15433d;
    }

    public /* synthetic */ void d(Runnable runnable) {
        b.a(this, runnable);
    }

    @NonNull
    /* renamed from: e */
    public u c() {
        return this.f15430a;
    }
}
