package z0;

import java.util.concurrent.Executor;

public final /* synthetic */ class b implements Executor {
    public final void execute(Runnable runnable) {
        runnable.run();
    }
}
