package z0;

import android.adservices.measurement.DeletionRequest;
import android.adservices.measurement.MeasurementManager;
import android.adservices.measurement.WebSourceRegistrationRequest;
import android.adservices.measurement.WebTriggerRegistrationRequest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.InputEvent;
import androidx.core.os.q;
import ib.h;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.d;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import xb.m;

@Metadata
public abstract class c {
    @NotNull

    /* renamed from: a  reason: collision with root package name */
    public static final b f18070a = new b((DefaultConstructorMarker) null);

    @SuppressLint({"NewApi", "ClassVerificationFailure"})
    @Metadata
    private static final class a extends c {
        /* access modifiers changed from: private */
        @NotNull

        /* renamed from: b  reason: collision with root package name */
        public final MeasurementManager f18071b;

        public a(@NotNull MeasurementManager measurementManager) {
            Intrinsics.checkNotNullParameter(measurementManager, "mMeasurementManager");
            this.f18071b = measurementManager;
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public a(@org.jetbrains.annotations.NotNull android.content.Context r2) {
            /*
                r1 = this;
                java.lang.String r0 = "context"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.Class<android.adservices.measurement.MeasurementManager> r0 = android.adservices.measurement.MeasurementManager.class
                java.lang.Object r2 = r2.getSystemService(r0)
                java.lang.String r0 = "context.getSystemService…:class.java\n            )"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r0)
                android.adservices.measurement.MeasurementManager r2 = (android.adservices.measurement.MeasurementManager) r2
                r1.<init>((android.adservices.measurement.MeasurementManager) r2)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: z0.c.a.<init>(android.content.Context):void");
        }

        /* access modifiers changed from: private */
        public final DeletionRequest k(a aVar) {
            new DeletionRequest.Builder();
            throw null;
        }

        /* access modifiers changed from: private */
        public final WebSourceRegistrationRequest l(d dVar) {
            throw null;
        }

        /* access modifiers changed from: private */
        public final WebTriggerRegistrationRequest m(e eVar) {
            throw null;
        }

        public Object a(@NotNull a aVar, @NotNull d<? super Unit> dVar) {
            m mVar = new m(c.b(dVar), 1);
            mVar.A();
            this.f18071b.deleteRegistrations(k(aVar), new b(), q.a(mVar));
            Object w10 = mVar.w();
            if (w10 == d.c()) {
                h.c(dVar);
            }
            return w10 == d.c() ? w10 : Unit.f12470a;
        }

        public Object b(@NotNull d<? super Integer> dVar) {
            m mVar = new m(c.b(dVar), 1);
            mVar.A();
            this.f18071b.getMeasurementApiStatus(new b(), q.a(mVar));
            Object w10 = mVar.w();
            if (w10 == d.c()) {
                h.c(dVar);
            }
            return w10;
        }

        public Object c(@NotNull Uri uri, InputEvent inputEvent, @NotNull d<? super Unit> dVar) {
            m mVar = new m(c.b(dVar), 1);
            mVar.A();
            this.f18071b.registerSource(uri, inputEvent, new b(), q.a(mVar));
            Object w10 = mVar.w();
            if (w10 == d.c()) {
                h.c(dVar);
            }
            return w10 == d.c() ? w10 : Unit.f12470a;
        }

        public Object d(@NotNull Uri uri, @NotNull d<? super Unit> dVar) {
            m mVar = new m(c.b(dVar), 1);
            mVar.A();
            this.f18071b.registerTrigger(uri, new b(), q.a(mVar));
            Object w10 = mVar.w();
            if (w10 == d.c()) {
                h.c(dVar);
            }
            return w10 == d.c() ? w10 : Unit.f12470a;
        }

        public Object e(@NotNull d dVar, @NotNull d<? super Unit> dVar2) {
            m mVar = new m(c.b(dVar2), 1);
            mVar.A();
            this.f18071b.registerWebSource(l(dVar), new b(), q.a(mVar));
            Object w10 = mVar.w();
            if (w10 == d.c()) {
                h.c(dVar2);
            }
            return w10 == d.c() ? w10 : Unit.f12470a;
        }

        public Object f(@NotNull e eVar, @NotNull d<? super Unit> dVar) {
            m mVar = new m(c.b(dVar), 1);
            mVar.A();
            this.f18071b.registerWebTrigger(m(eVar), new b(), q.a(mVar));
            Object w10 = mVar.w();
            if (w10 == d.c()) {
                h.c(dVar);
            }
            return w10 == d.c() ? w10 : Unit.f12470a;
        }
    }

    @Metadata
    public static final class b {
        private b() {
        }

        public /* synthetic */ b(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @SuppressLint({"NewApi", "ClassVerificationFailure"})
        public final c a(@NotNull Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            StringBuilder sb2 = new StringBuilder();
            sb2.append("AdServicesInfo.version=");
            w0.a aVar = w0.a.f17071a;
            sb2.append(aVar.a());
            Log.d("MeasurementManager", sb2.toString());
            if (aVar.a() >= 5) {
                return new a(context);
            }
            return null;
        }
    }

    public abstract Object a(@NotNull a aVar, @NotNull d<? super Unit> dVar);

    public abstract Object b(@NotNull d<? super Integer> dVar);

    public abstract Object c(@NotNull Uri uri, InputEvent inputEvent, @NotNull d<? super Unit> dVar);

    public abstract Object d(@NotNull Uri uri, @NotNull d<? super Unit> dVar);

    public abstract Object e(@NotNull d dVar, @NotNull d<? super Unit> dVar2);

    public abstract Object f(@NotNull e eVar, @NotNull d<? super Unit> dVar);
}
