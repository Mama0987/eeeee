package hb;

import eb.o;
import ib.h;
import ib.j;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.d;
import kotlin.coroutines.g;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata
class c {

    @Metadata
    public static final class a extends j {

        /* renamed from: b  reason: collision with root package name */
        private int f11294b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Function2 f11295c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ Object f11296d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(d dVar, Function2 function2, Object obj) {
            super(dVar);
            this.f11295c = function2;
            this.f11296d = obj;
            Intrinsics.d(dVar, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
        }

        /* access modifiers changed from: protected */
        public Object n(@NotNull Object obj) {
            int i10 = this.f11294b;
            if (i10 == 0) {
                this.f11294b = 1;
                o.b(obj);
                Intrinsics.d(this.f11295c, "null cannot be cast to non-null type kotlin.Function2<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1>, kotlin.Any?>");
                return ((Function2) kotlin.jvm.internal.a.b(this.f11295c, 2)).k(this.f11296d, this);
            } else if (i10 == 1) {
                this.f11294b = 2;
                o.b(obj);
                return obj;
            } else {
                throw new IllegalStateException("This coroutine had already completed".toString());
            }
        }
    }

    @Metadata
    public static final class b extends ib.d {

        /* renamed from: d  reason: collision with root package name */
        private int f11297d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ Function2 f11298e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ Object f11299f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(d dVar, CoroutineContext coroutineContext, Function2 function2, Object obj) {
            super(dVar, coroutineContext);
            this.f11298e = function2;
            this.f11299f = obj;
            Intrinsics.d(dVar, "null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
        }

        /* access modifiers changed from: protected */
        public Object n(@NotNull Object obj) {
            int i10 = this.f11297d;
            if (i10 == 0) {
                this.f11297d = 1;
                o.b(obj);
                Intrinsics.d(this.f11298e, "null cannot be cast to non-null type kotlin.Function2<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1>, kotlin.Any?>");
                return ((Function2) kotlin.jvm.internal.a.b(this.f11298e, 2)).k(this.f11299f, this);
            } else if (i10 == 1) {
                this.f11297d = 2;
                o.b(obj);
                return obj;
            } else {
                throw new IllegalStateException("This coroutine had already completed".toString());
            }
        }
    }

    @NotNull
    public static <R, T> d<Unit> a(@NotNull Function2<? super R, ? super d<? super T>, ? extends Object> function2, R r10, @NotNull d<? super T> dVar) {
        Intrinsics.checkNotNullParameter(function2, "<this>");
        Intrinsics.checkNotNullParameter(dVar, "completion");
        d<? super T> a10 = h.a(dVar);
        if (function2 instanceof ib.a) {
            return ((ib.a) function2).e(r10, a10);
        }
        CoroutineContext a11 = a10.a();
        return a11 == g.f12515a ? new a(a10, function2, r10) : new b(a10, a11, function2, r10);
    }

    @NotNull
    public static <T> d<T> b(@NotNull d<? super T> dVar) {
        d<Object> p10;
        Intrinsics.checkNotNullParameter(dVar, "<this>");
        ib.d dVar2 = dVar instanceof ib.d ? (ib.d) dVar : null;
        return (dVar2 == null || (p10 = dVar2.p()) == null) ? dVar : p10;
    }
}
