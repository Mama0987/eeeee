package hb;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata
class d extends c {
    @NotNull
    public static Object c() {
        return a.COROUTINE_SUSPENDED;
    }
}
