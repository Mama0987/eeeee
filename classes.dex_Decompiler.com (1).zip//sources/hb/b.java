package hb;

import kotlin.Metadata;

@Metadata
public final class b extends d {
}
