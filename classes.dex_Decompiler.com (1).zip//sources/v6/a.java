package v6;

public final /* synthetic */ class a {
}
